#include "g_local.h"
#include "m_player.h"
#include <windows.h>

//typedef void (CALLBACK* LPFNDLLFUNC1)(char*);
typedef void (CALLBACK* LPFNDLLFUNC1)(void);

void LoadDLL () {
	HINSTANCE hDLL;               // Handle to DLL
	LPFNDLLFUNC1 lpfnDllFunc1;    // Function pointer
//	DWORD dwParam1;
//	UINT  uParam2, uReturnVal;
	
	hDLL = LoadLibrary("newfamke\\famkebot.dll");
	if (hDLL != NULL){
		gi.bprintf(PRINT_HIGH, "DLL loaded\n");

		lpfnDllFunc1 = (LPFNDLLFUNC1)GetProcAddress(hDLL, "git");
		if (!lpfnDllFunc1)   {
			FreeLibrary(hDLL);   
			gi.bprintf(PRINT_HIGH, "Function not found\n");
			return;
		}
		else
		{      // call the function
			lpfnDllFunc1();
			gi.bprintf(PRINT_HIGH, "Got to call\n");
		}
	}
	else
		gi.bprintf(PRINT_HIGH, "LoadLibrary returned NULL.\n");
//	git();
	gi.bprintf(PRINT_HIGH, "Done\n");
	FreeLibrary(hDLL);       
}
