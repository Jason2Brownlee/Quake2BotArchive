FAMKEBOT V7.0 GAMEX86 CODE RELEASE
---------------------------------------------------------------------------------
Author             : Rich Whitehouse
File Name          : fb69gx86.zip
Version            : 7.0
Date               : January 01, 2000
E-mail             : thefatal@telefragged.com
Web Site           : http://www.telefragged.com/thefatal/
---------------------------------------------------------------------------------
Note that all of the functions in the code defined as DLL exports CANNOT be modified
or deleted. The famkebot.dll file looks for them just as they are. You may also have
problems if you try to modify one of the structures (like edict_s).

The actual code modifications that call to the DLL or change things needed for the bot
are marked in the files using "FAMKE START" and "FAMKE END", so they shouldn't be hard
to find. Note that any file that calls a function from the famkebot.dll file also has
to include bot.h, as it defines the available functions from famkebot.dll. You'll also
have to edit the project's link settings to make it link with famkebot.lib (included
in this archive) before you compile. Replace the path I have to it to wherever you have
it on your hard drive.

This was written and done entirely in MS VC++ 5.0 Professional Edition. I can't
offer any support or help if you're trying to use a compiler other than that, so
please don't ask me for help on it.

Well then, I guess that's it. Have fun.

-Rich
