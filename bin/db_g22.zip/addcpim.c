/*
        addcpim.c
*/

#include <stdio.h>      // for file IO
#include <stdlib.h>     // for malloc

#define STARTSIGNAL "#*"

void main (void)
{
        char *name, *dir_name, *skin_file;

        char *filename;
        FILE *f;

        name = (char *) malloc (sizeof(char[30]));
        dir_name = (char *) malloc (sizeof(char[30]));
        skin_file = (char *) malloc (sizeof(char[30]));

        filename = (char *) malloc (sizeof(char[50]));
        if (!filename)
        {
                printf ("\nOut of Memory!\n");
                exit (EXIT_FAILURE);
        }
        printf ("Output filename to append to:");
        scanf ("%s", filename);

        f = fopen (filename, "ab");

        printf ("\nPIM Name:");
        scanf ("%s", name);
        printf ("\nDirectory (under baseq2\\players):");
        scanf ("%s", dir_name);
        printf ("\nSkin File (e.g. 'crakhorb'):");
        scanf ("%s", skin_file);

        // Note: The STARTSIGNAL is VERY IMPORTANT!! Hand-edited
        //       CPIM files might otherwise leave blank lines, etc.

        fputs (STARTSIGNAL, f);
        fputc (10, f);

        fputs (name, f);
        fputc (10, f);
        fputs (dir_name, f);
        fputc (10, f);
        fputs (skin_file, f);
        fputc (10, f);

        fclose (f);

        // Memory cleanup
        free (filename);
}
