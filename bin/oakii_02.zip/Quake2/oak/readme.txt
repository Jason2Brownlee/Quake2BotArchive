Oak II Build Release Notes:
===========================

Version 	0.2 (Public Alpha)

Author: 	John Crickett
Web Page: 	www.quake2.com/oak
Email: 		oak@quake2.com

Credits and Thanks:
===================

Web Site and Ideas:		Neil Henderson aka Hendo

Additional Coding:		Marcus Davies aka Ithacus

Help with Zip Code:		Ryan "Ridah" Feltrin 		(impact.frag.com)

Testing:			Bot Epidemic Crew 		(www.quake2.com/epidemic)
				Krunch-X			(www.krunch-x.co.uk)

Quake2:				id Software


Instructions:
=============

1. Unzip the dll to a dir named "oak" beneath you installation of Quake2 i.e. c:\quake2\oak. NOTE it MUST be in this 
   directory, for bot config and path files to work.

   If it doesnt exist, create a dir called "memory" beneath the quake2\oak dir, the bot path data will be stored here as 
   .pth files.

2. Add "+set deathmatch 1 +set game oak" to you command line when starting quake2.

3. Start Quake2

4. Bring down the console (press ~) type: "oak" to add a bot.


Additional Instructions:
------------------------

At the moment only bot names can be configured via the botnames.cfg file. All names must be less than 14 characters and must
NOT include any spaces.

The bots will improve as they learn a level, hence if you wish them to remember the level you must save it (oak_save)
before exiting a level. However the path data is saved automatically when a frag/timelimit is hit.


Release Notes:
==============

* - denotes public release.

* Version 0.2	- Path files now stored as zip files named as: levelname_pth.zip
		- Tweaked jumping code.
		- Bots jump in combat.
		- Added sex, team, skin number and min_health values to the config file.
		- Added teamplay support.
		- Major bug fixes to the pathing, some stupid ommissions when porting to 3.14 now added.
		- Increased the max number of bots to 128.
		- Fixed sexed sounds.

* Version 0.1a	- Added fast weapon switching.
		- Added some code that didnt get merged with 3.14, to remove bots from scoreboard.
		- Fixed CopyToBodyQue call.

* Version 0.1	- Changed to custom scoreboard.
		- Merged with 3.14 source from id.

Version 0.06	- Bot now glows with quad/invul.
		- Rewrote anim code, move to PostThink().
		- Tweaked anim code.

Version 0.05a	- Hacked to work with Quake2 v 3.13.
		- Dont set self as a enemy when hurting self.

Version 0.05	- Tweaked jumping.
		- Fixed death msg bug when weapon changing.
		- Fixed loading and saving of path files on level change.
		- Made bots die in lava/slime.
		- Made bots go for nearby weapons etc during combat.
		- Tweaked swimming code.

Version 0.04	- Improved bot jumping while using paths.
		- Added path support for items.
		- Added initial swimming code.
		- Added pathing support for swimming.

Version 0.03    - Added support for the skins, using new models with all the skins on.
		- Implemented the training mode.
		- Implemented path creation, loading and saving.
		- Aliased the commands.
		- Added dynamic pathing on/off toggle.
		- Bots now trigger fraglimit.

0.02  Build 1.0 - Slowed weapons down a little more.
		- Fixed botconfigs to work from oak dir.

0.02  Build 0.0 - Incresed vertical aiming range.
		- Slowed down bot rate of fire.

0.01  Build 0.0 - Sorted out some basic circle straffing etc. Got the scoreboard 50% sorted :( Added configurable bot names.
		  Made it fire grenades. The balance between circle straffing and left/right still needs work.

0.00a Build 0.0 - Just a quick demo of a few things, primarily the way the bots aim. Does it work? I havent yet seen a bot
		  that works this way.. it can only shoot dead ahead (like a player) it has to rotate/look up/down to aim
		  at you.

NOTE: version numbers increse by 0.01 each build shown to a tester, and 0.1 each full public release, letters denote bug 
fixes.


Features Still To Be Implemented:
---------------------------------

*	Combat AI - Projectile Avoidance
		  - Use of hand grenades.

*	User Interface 	- Better config files.
			- Remove hard coded game directory.
			- Respawn bots on map change.


Command List:
=============

Normal:
-------

* oak		- Add a bot.


Teamplay:
---------

* oak_join	- This command MUST be preceeded by "cmd", it allows the player to specify their team. i.e. 
                  "cmd oak_join QUTA"

* oak_help	- Calls for help, the nearest 2 bots will attempt to come and help you. 

* oak_stay	- Instructs your partner to stay here and cover the area.

* oak_come	- Calls your partner to you.


Advanced:
---------

* oak_load	- Loads the path data file for this level, if any. NOTE the path data is loaded on startup already.

* oak_save	- Save the path data to file. NOTE this is done automatically when the map changes.

* oak_precalc	- Precalculate all paths on this level, useful for speeding up the use of paths, though currently it is
 		  somewhat unstable. It can take upto 10 minutes to execute. I do NOT reccommend using it.


Variable List:
==============

oak_path	- Enables (1) or Disables (0) dynamic pathing of the levels. It defaults to 1 when starting the game.

oak_fastweaps	- Enables (1) or Disables (0) fast weapons switching. I defaults to 0 when starting a game.

oak_teamplay	- Enables (1) or Disables (0) teamplay. I defaults to 0 when starting a game. 


Advanced Instructions:
======================

Bot Config Files:
-----------------

The file named "botnames.cfg" contains a list of the 12 bots you can spawn, you can configure this file to suit your needs.
ALL the fields must contain a value. the fields are:

Name, Sex, Team, Skin Number, Min Health

i.e.

OakII male SR 0 40

Team names must be at most 4 letters.

Skin number referes to the number of the skin within the model.

Min Health is the value above which the bots will try to maintain their health, set high the bots will be somewhat cautious,
low and they`ll ignore health. The default setting is 40.

Pathing:
--------

The bots learn the levels by dynamically laying path nodes around the level. The node placement can unfortunately reduce 
the framerate. Hence as it only takes about 10 minutes for the bots to learn a level it is possible to disable the node 
placement. It will also be possible to optimise the bots memory files via a seperate program to further increase the speed,
(this optimization is performed by oak_precalc).


Team Play:
----------

This is based around teams working as groups of partners. Bots will attempt to pair up and hunt together, if they are 
getting hurt they will often call for help just like a player.


Known Bugs:
-----------

No Clipping Bot		- occasinally a bot can become unclipped.


Legal Notice:
=============

Distribution:

This bot is Copyright John Crickett 1998. It is being developed solely for my own amusement and as such is provided as is.
You may NOT distribute in any way shape or form, any version of this bot which states it is a private build. i.e the 
intro messages states "Build x.x Private". If you are given a private build by anyone other than myself (J. Crickett), 
please do not accept it and email me details of the distributer.

You may distribute any public i.e. states "Public Version x.x" in the intro message, via the internet so long as the 
zip/installation remains totally intact (intact being defined as containing the same files as the identical zip/installer
on the official web site). You may ONLY distribute this bot on permenant media (i.e. CD/floppy disk etc) if above conditions
are satisfied, and NO charge is made for the ENTIRE CD. A exception is made for regular magazine cover disk/CD's, in which 
case it may be included, though I`d ask any magazines that do to let me know about it, though its  not compulsory to do so.

Disclaimer:

You use the enclosed files entirely at your own risk, I accept NO liability for any damage or loss of data resulting
from the use of this bot.
