#include <stdio.h>

int _stdcall DLLMain(void *hinstDll,unsigned long dwReason,void *reserved)
{
	return(1);
}

