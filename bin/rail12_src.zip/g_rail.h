// by SumFuka

void RailShowCommands (edict_t *player);
void RailShowCredits (edict_t *player);
void RailUseRailMsg(edict_t *player);
void RailGiveBonus(edict_t *ent, int n);
void RailFire(edict_t *winner);
void RailHit(edict_t *winner, edict_t *loser);
void RailMiss(edict_t *winner);
qboolean RailHasBonus(edict_t *ent, int doihaveit);
void RailStats (edict_t *player);


// rail bonus constants
#define BONUS_NONE 0
#define BONUS_THREESOME 1
#define BONUS_SPEEED 2

// prototypes from id code :
typedef struct gitem_s gitem_t;
void Use_PowerArmor (edict_t *ent, gitem_t *item);
void DeathmatchScoreboard (edict_t *ent);
