// functions
void ReadMotd();
void CheckShowMotd(edict_t *player);

