Title       : Stupid Bot v0.99e For Quake2 Deathmatch
File Name   : stp099e.zip
Date        : February 14, 1998
Author      : ponpoko
E-mail add. : ponpoko@exa.co.jp
Web Site    : http://users.jp.tri6.net/~ponpoko
Build time  : 12 days


Type of mod 
-----------
DLL      : Yes
Sound    : No
MDL      : No
Maps     : No
Graphics : No


Setup and run
-------------
Unzip file and directory under your Quake2 diretory,and run Quake2 like below

Quake2 +set game stupid

and type console commands after start Deathmatch play mode.

Commands
--------
impulse 101-109    Add 1-9 bots
impulse 201-209   Kill 1-9 bots
skill 0-2  Set Bot's skill

