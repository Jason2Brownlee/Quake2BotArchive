NIQ for Quake II

The help and information file for NIQ is basically the web page from
www.geocities.com/TimesSquare/Labyrinth/8220. It should be included in the
NIQ zip files in both html (niqinfo.html) and text (niqinfo.txt) forms. 

For the very latest information please check the above web site.

NIQ: 

Make a \quake2\niq directory and unzip niqxxx.zip there.

NIQCTF:

Has to go in your \quake2\ctf directory (see Downloading and Installation) so
you might want to save your existing gamex86.dll somewhere.

Happy NIQing!

Mike Fox (a.k.a. Artful Dodger)
mfox@matrox.com
