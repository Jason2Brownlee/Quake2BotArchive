Extract to your Quake2 folder creating also a folder for the bot[use folder names on as well].
eg:extract to c:\quake2\gsbot[use folder names on]

Run with usual  command line stuff [+set game gsbot +set deathmatch 1 +map q2dm1 etc.]

Type sv add [# of bots] [skill 1-10] in console.[The mod will display this for you anyhow]

There is also team option presented- [team R/B].I have not used it but it looks pretty straight forward.

Now for what they dont say:

"rocketarena 1" [no quotes] in console will change to a variant of the mod upon map reload.

Very cool:

"railarena 1" [no quotes] in console becomes instagib upon map reload.

Making routes is the same as for 3ZB2;

*type set chedit 1
*reload map 
*run around map
*don't die
*type sv savechain
*set chedit 0
*reload map

Voila!

http://kamensk.far.ru/files/q2.htm  -This is where I got the bot!
 
This readme was created by jhan28@netscape.net and was not part of the original archive.
I did not code this bot I merely downloaded it.
I assume no responsibility for it blah blah blah.
 