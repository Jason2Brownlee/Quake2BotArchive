This is a multiplayer deathmatch simulation for Quake 2.

Installation:
This mod was was made to be played with KMQuake2 engine mod.
dd3zb2 was built from kmquake2_020_3zb2_lazarus source code.

Install in a new folder called dd3zb2 in your Quake2 directory.

Mod Features: 
3rd Zigock Bot II support.

ThreeWave Capture The Flag support.
maps q2ctf1 - q2ctf8 are included.

Xatrix Support. 
Weapon IonRipper
Weapon Phalanx  -  Ammo Magslug
Traps
Quadfire Powerup

Rogue support.
Weapon ETF Rifle  -   Ammo Flechettes
Weapon Disruptor  -   Ammo Disruptors
Weapon Plasma Beam Cannon
Weapon Prox Mine Launcher -  Ammo Prox
Tesla Mines
Antimatter Bomb
Doppleganger
Defender Sphere
Vengeance Sphere
Hunter Sphere
Double Powerup

Some new weapons and features have also been added.
Weapon Shockwave  -  Ammo Shockspheres
Weapon SniperRifle
Weapon Thunderbolt
Nbomb - BLU-86 (Neutron Bomb - Nuke)
Shockwave: This weapon shoots out Shockspheres that bounce off walls and create a 
dizziness like effect ending with giant explosion and rings of death.

SniperRifle: This weapon features locational damage and is very accurate.
Head shots are worth 200%, chest shots 100%, and Leg shots 50%.

Thunderbolt: Similar to the lightning gun in Quake 1, it fires a steady stream of
electricity.  If used in liquids, players are electrocuted and will explode.

Nbomb: The Neutron Bomb is a nuclear device. Set one of these and you only have
a few seconds to take cover. The explosion will clear a room. Also known as BLU-86.

Blaster and Hyperblaster: When enabled, the wall-bounce feature causes the bolts to
ricochet off walls with extra sounds. The color of the bolts can also be changed.

Grenades: These were modified into shrapnel grenades for a more realistic effect.
Velocity throw has also been added as an option.

Railgun: This weapon has been changed to a wall piercing Railgun. Walls that are
10 units or less thick can be pierced.

Flame Weapons:  Standard weapons can be replaced with unique flame weapons.
Each of these can be enabled or disabled in the server settings. If you catch on fire,
jump in the water to put out the flames or pickup health items.

Blaster - shoots fireballs
Shotgun - shoots beams of explosive energy
Super Shotgun - shoots incendiary pellets
Machinegun - shoots a spread of fireballs
Chaingun - shoots incendiary rounds
Grenades/Grenade Launcher - a cloud of fire will erupt and drop flames
Rocket Launcher - rockets produce the same pyrotechnics as grenades
Hyperblaster - this becomes a flamethrower
Railgun - shoots large fireballs called meteors, fire then falls from the sky
BFG10K - this becomes an antimatter gun

Tech Power Ups: These are now available in deathmatch mode. 
Two additional techs were also implemented, Vampire and Ammogen.

Fun Hook: An off-hand swinging grappling hook with shrink and grow ability,
as well as homing and vampire features.

Anti-Gravity Boots: Toggle them on and you can make low gravity jumps.
As an option, the server may require cells to use this feature.

Laser Sight: The name says it all, toggle it on to use the laser sight.

Portable Teleporter: Set a portable teleport location on the map and teleport there
instantly. Requires at least 30 health and costs 10 cells for each use.

Cloaking Device: When activated renders you invisible while standing still.
Requires cells to use and drains cells while activated.

Kamikaze: Take out nearby enemies by blowing yourself up!

Airstrike: There are two types of airstrikes that can be called.
Cluster Bomb:  Airstrike1 requires 10 grenades to use.
Rocket Bomb:  Airstrike2 requires 6 rockets to use.

Scanner: New TGA graphics were created for the heads up scanner display.
The following colors represent the players in game status.

green          shows the player on the map
light blue     an arrow will show if the player is above or below you
red            invulnerable
dark blue      quad damage
orange         double damage
purple         quadfire damage
white          player has activated kamikaze mode!

Server Variables: I created a long list of server side cvars to help you customize
your experience! Weapon and item balancing are now possible along with starting
and banning features.

Check out ddserver.cfg for a complete list of server variables.

For example, check out railmode.cfg. The possibilities are endless.

Tech power ups:
There are six different types of techs that can be enabled. They can be customized
with glow effects and be changed to look like lithium style key pyramids.

Resist               Disruptor Shield reduces all damage received.
Strength            Power Amplifier increases all damage given.
Haste                Time Accelerator increases firing speed.
Regen               Auto Doc regenerates health and armor.
Vampire            Increases your health by causing damage to players.
Ammogen         Produces an ammo pack over every player you frag.

Values for these items can be customized in the server config file.

Addons:
To use weapons and items from the official mission packs supported in
this mod, you need to install the following addons. 
Xatrix          The Reckoning official mission pack
Rogue         Ground Zero official mission pack

Once you have the mission packs installed add the following to KMQuake2's
command line: +set basegame xatrix +setbasegame2 rogue

Binds and Aliases:
Custom key binds are stored in an autoexec.cfg file in your mod folder.
This file will load whenever you start or join a server and it handles
most of the binds needed for the features of this mod.

Another file called aliases.cfg was created to handle multiple weapon binds.
You can change any of the binds in these files to your preferences.

Bots and Map Routes:
The botlist can be configured in 3ZBConfig.cfg  where you can also setup a
"message of the day" for your server.

If you are familiar with 3zb2 mod, and you already have a custom botlist setup,
you can copy your 3ZBConfig.cfg and place it in your dd3zb2 folder.

Once in the game, use (+/- enter) on the keypad to add or remove bots.
You can also use these server commands.

sv spb #           spawns # of bots from the list
sv rspb #          spawns a random # of bots from the list
sv rmb #           removes # of bots from the game
sv dsp #           used for debugging bot chaining
sv savechain    saves the chaining route file

To make a bot route type chedit 1 in the console, then
start and roam around the map. Advanced chaining is done
using sv dsp # to check if a bot can arrive at your current position
using a certain number of chaining pods. 

For example, use sv dsp 20. A bot will spawn and if it arrives at your current
position it will be removed. If the route fails, the bot is removed from it's last
position. To take back 20 pods, use cmd undo 20, and try a different route.

When you are finished type sv savechain in the console.

Routes are saved using the map's file name (map.chn or map.chf)
and are stored in either the chdtm or chctf folders. These routes 
will auto load each time the map starts.

Multiple maplists can be set up in 3ZBMaps.lst. Just set the
name of the maplist you want to use in your server.cfg file.

Gameplay:
The command line should look something like this:
kmquake2.exe +set game dd3zb2 +exec ddserver.cfg

If you have the official mission packs installed include this after kmquake2.exe:
+set basegame xatrix +setbasegame2 rogue

There are a few different ways to configure your game server.
 
Free for All Deathmatch
Team Deathmatch - by skin or by model
Capture the Flag
Zigmode

Zigmode is a flag keeper mode. At the start of the game a flag spawns.
The Holder of this flag gets an extra point for every 30 seconds the flag
is held. In Team Deathmatch, teammates will also get a point.

Spectator Mode is a way to watch the match from the sidelines. Type in the
console spectator 1  to observe, or spectator 0 to join. Use the fire button
to catch and release, and the [ or ] button to select a target.

Have Fun, and Long Live Quake 2!
Dirt Demon

9/9/2019
Q2dirtdemon@gmail.com