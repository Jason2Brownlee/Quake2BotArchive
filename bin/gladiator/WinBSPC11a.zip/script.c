//===========================================================================
//
// Name:         script.c
// Function:     script examples
// Programmer:   Mr Elusive (MrElusive@demigod.demon.nl)
// Last update:  1999-01-17
// Tab Size:     3
//===========================================================================

/*

//===========================================================================
// ask the user for a folder, the "string" message will be displayed to the
// user, the retrieved folder can be accessed in the script using the folder
// label
//===========================================================================
AskFolder(folderlabel, "string");

//===========================================================================
// the "string" message is displayed to the user
//===========================================================================
Message("string");

//===========================================================================
// when this is found somewhere in the script WinBSPC will automatically
// close when all files are converted and/or extracted
//===========================================================================
Exit();

//===========================================================================
// execute the script with the given filename
//===========================================================================
Script("filename");

//===========================================================================
// convert a bsp file to a map file
//===========================================================================
bsp2map("pakfile":"bspfile", outputfoler)

//===========================================================================
// convert a bsp file to an aas file
//===========================================================================
bsp2aas("pakfile":"bspfile", outputfoler)

//===========================================================================
// extract files from a .pak or .sin file
//===========================================================================
extract("pakfile":"file", outputfolder)


//*/

//*

//script for the gladiator v0.8 option
AskFolder(gladiatorfolder, "Please enter your Gladiator bot folder");
bsp2aas(gladiatorfolder"..\\baseq2\\pak1.pak":"maps/q2dm1.bsp", gladiatorfolder);
bsp2aas(gladiatorfolder"..\\baseq2\\pak1.pak":"maps/q2dm2.bsp", gladiatorfolder);
bsp2aas(gladiatorfolder"..\\baseq2\\pak1.pak":"maps/q2dm3.bsp", gladiatorfolder);
bsp2aas(gladiatorfolder"..\\baseq2\\pak1.pak":"maps/q2dm8.bsp", gladiatorfolder);
bsp2aas(gladiatorfolder"..\\baseq2\\maps\\ztn2dm?.bsp", gladiatorfolder);
Message("The .AAS files will now be created. When\n"
			"all conversions are done you can exit\n"
			"WinBSPC and launch the Gladiator bot\n");

/*
//NOTE: ussage of the scripted sequences below is NOT legal (read the legal
//      stuff in the winbspc.htm) they are just examples

Message("This script will extract all your Quake2 textures");
AskFolder(quake2folder, "Please enter your Quake2 folder");
AskFolder(outputfolder, "Please enter the folder to store the textures");
extract(quake2folder"baseq2\\pak?.pak":"*.wal", outputfolder);

Message("This script will convert all your Quake2 BSP files to MAP files");
AskFolder(quake2folder, "Please enter your Quake2 folder");
AskFolder(outputfolder, "Please enter the folder to store the MAP files");
bsp2map(quake2folder"baseq2\\pak?.pak":"maps/*.bsp", outputfolder);

Message("This script will convert all your Quake1 BSP files to MAP files");
AskFolder(quake1folder, "Please enter your Quake1 folder");
AskFolder(outputfolder, "Please enter the folder to store the MAP files");
bsp2map(quake1folder"id1\\pak?.pak":"maps/*.bsp", outputfolder);

Message("This script will convert all your Half-Life BSP files to MAP files");
AskFolder(halflifefolder, "Please enter your Half-Life folder");
AskFolder(outputfolder, "Please enter the folder to store the MAP files");
bsp2map(halflifefolder"valve\\pak0.pak":"maps/*.bsp", outputfolder);

Message("This script will convert all your Sin BSP files to MAP files");
AskFolder(sinfolder, "Please enter your Sin folder");
AskFolder(outputfolder, "Please enter the folder to store the MAP files");
bsp2map(sinfolder"base\\pak?.sin":"maps/*.bsp", outputfolder);

//*/

