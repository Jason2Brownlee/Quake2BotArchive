//===========================================================================
//
// Name:				bl_cmd.c
// Function:		bot commands
// Programmer:		Mr Elusive (MrElusive@demigod.demon.nl)
// Last update:	1999-02-10
// Tab Size:		3
//===========================================================================

#include "g_local.h"
#include "bl_main.h"
#include "bl_spawn.h"

void ClientUserinfoChanged (edict_t *ent, char *userinfo);

typedef struct nearbyitem_s
{
	char *classname;
	float weight;
} nearbyitem_t;

nearbyitem_t nearbyitems[] =
{
	{"item_armor_body",			70},
	{"item_armor_combat", 		70},
	{"item_armor_jacket", 		50},
	{"item_power_screen",		90},
	{"item_power_shield",		90},
	{"weapon_shotgun",			40},
	{"weapon_supershotgun",		60},
	{"weapon_machinegun",		50},
	{"weapon_chaingun",			100},
	{"weapon_grenadelauncher",	100},
	{"weapon_rocketlauncher",	100},
	{"weapon_hyperblaster",		100},
	{"weapon_railgun",			100},
	{"weapon_bfg",					100},
	{"item_quad",					100},
	{"item_invulnerability",	100},
	{"item_silencer",				60},
	{"item_breather",				60},
	{"item_enviro",				60},
	{"item_ancient_head",		60},
	{"item_bandolier",			60},
	{"item_pack",					70},
	{"key_data_cd",				40},
	{"key_power_cube",			40},
	{"key_pyramid",				40},
	{"key_data_spinner",			40},
	{"key_pass",					40},
	{"key_blue_key",				40},
	{"key_red_key",				40},
	//CTF
	{"item_flag_team1",			100},
	{"item_flag_team2",			100},
	{NULL,							0}
};

//===========================================================================
//
// Parameter:				-
// Returns:					-
// Changes Globals:		-
//===========================================================================
void TeamHelp_f(edict_t *ent)
{
	int i, j;
	float radius, weight, bestweight, dist;
	char buf[144];
	vec3_t eorg;
	edict_t *item, *bestitem;

	if (!ent) return;
	if (!ent->client) return;
#ifdef OBSERVER
	if (ent->flags & FL_OBSERVER) return;
#endif //OBSERVER

	radius = 500;

	bestweight = 0;
	bestitem = NULL;
	for (item = g_edicts; item < &g_edicts[globals.num_edicts]; item++)
	{
		if (!item->inuse) continue;
		for (j = 0; j < 3; j++)
		{
			eorg[j] = ent->s.origin[j] - (item->s.origin[j] + (item->mins[j] + item->maxs[j])*0.5);
		} //end for
		dist = VectorLength(eorg);
		//the item should be in the given radius
		if (dist > radius) continue;
		//never use dropped items
		if (item->spawnflags & DROPPED_ITEM) continue;
		//the location of the item should be visible
		if (!visible(ent, item)) continue;
		//check if item and calculate weight
		for (i = 0; nearbyitems[i].classname; i++)
		{
			if (!strcmp(item->classname, nearbyitems[i].classname))
			{
				weight = nearbyitems[i].weight / dist;
				if (weight > bestweight)
				{
					bestweight = weight;
					bestitem = item;
				} //end if
				break;
			} //end if
		} //end for
	} //end for
	strcpy(buf, "");
	//if addressed
	if (gi.argc() > 1)
	{
		strcat(buf, gi.argv(1));
		strcat(buf, " ");
	} //end if
	//help or accompany
	if (!strcmp(gi.argv(0), "teamhelp")) strcat(buf, "help me");
	else strcat(buf, "accompany me");
	//if near an item
	if (bestitem)
	{
		strcat(buf, " near the ");
		strcat(buf, bestitem->item->pickup_name);
	} //end if
	BotClientCommand(ent - g_edicts - 1, "say_team", buf, NULL);
} //end of the function TeamHelp_f
//===========================================================================
//
// Parameter:				-
// Returns:					-
// Changes Globals:		-
//===========================================================================
#ifdef BOT_DEBUG
void Cmd_ServerCommand(edict_t *ent)
{
	char str[1024];
	int i;

	str[0] = '\0';
	for (i = 1; i < gi.argc(); i++)
	{
		//add space and double quote
		if (i > 1) strncat(str, " \"", 1024 - strlen(str));
		//add the argument
		strncat(str, gi.argv(i), 1024 - strlen(str));
		//add double quote
		if (i > 1) strncat(str, "\"", 1024 - strlen(str));
	} //end for
	gi.dprintf("%s adds server command: %s\n", ent->client->pers.netname, str);
	gi.AddCommandString(str);
} //end of the function Cmd_ServerCommand
#endif //BOT_DEBUG
//===========================================================================
//
// Parameter:				-
// Returns:					-
// Changes Globals:		-
//===========================================================================
void BotDumpInventory(void)
{
	int i;

	for (i = 1; itemlist[i].pickup_name; i++)
	{
		gi.dprintf("%-16s %d\n", itemlist[i].pickup_name, i);
	} //end for
} //end of the function BotDumpInventory
//===========================================================================
//
// Parameter:				-
// Returns:					-
// Changes Globals:		-
//===========================================================================
#ifdef BOT_DEBUG
qboolean BotDebugCmd(char *cmd, edict_t *ent, int server)
{
} //end of the function BotDebugCmd
#endif BOT_DEBUG
//===========================================================================
//
// Parameter:				-
// Returns:					-
// Changes Globals:		-
//===========================================================================
qboolean BotServerCmd(char *cmd, edict_t *ent, int server)
{
	if (!server && (gi.cvar("serveronlybotcmds", "0", 0))->value) return false;

	if (Q_stricmp(cmd, "addbot") == 0)
	{
		BotAddDeathmatch(ent);
	} //end else if
	else if (Q_stricmp(cmd, "removebot") == 0)
	{
		BotRemoveDeathmatch(ent);
	} //end else if
	else if (Q_stricmp(cmd, "becomebot") == 0)
	{
		BotBecomeDeathmatch(ent);
	} //end else if
	else if (Q_stricmp(cmd, "nocldouble") == 0)
	{
		botglobals.nocldouble = !botglobals.nocldouble;
		gi.dprintf("nocldouble = %d\n", botglobals.nocldouble);
	} //end else if
	else if (!dedicated->value && Q_stricmp(cmd, "menu") == 0)
	{
		ToggleBotMenu(ent);
	} //end else if
	else
	{
		return false;
	} //end else
	return true;
} //end of the function BotServerCmd
//===========================================================================
//
// Parameter:				-
// Returns:					-
// Changes Globals:		-
//===========================================================================
qboolean BotCmd(char *cmd, edict_t *ent, int server)
{
	char userinfo[MAX_INFO_STRING];

	//check for commands that might be server only
	if (BotServerCmd(cmd, ent, server))
	{
	} //end if
	else if (server && Q_stricmp(cmd, "modelindex") == 0)
	{
		BotDumpModelindex();
	} //end else if
	else if (server && Q_stricmp(cmd, "soundindex") == 0)
	{
		BotDumpSoundindex();
	} //end else if
	else if (server && Q_stricmp(cmd, "imageindex") == 0)
	{
		BotDumpImageindex();
	} //end else if
	else if (server && Q_stricmp(cmd, "inventory") == 0)
	{
		BotDumpInventory();
	} //end else if
	else if (server && Q_stricmp(cmd, "botlibdump") == 0)
	{
		BotLibraryDump();
	} //end else if
	else if (server && Q_stricmp(cmd, "clientdump") == 0)
	{
		BotClientDump();
	} //end else if
	//so the bot can easily change it's name
	else if (!server && Q_stricmp(cmd, "name") == 0)
	{
		strncpy (userinfo, ent->client->pers.userinfo, sizeof(ent->client->pers.userinfo)-1);
		Info_SetValueForKey(userinfo, "name", gi.argv(1));
		ClientUserinfoChanged(ent, userinfo);
	} //end else if
	//so the bot can easily change it's skin
	else if (!server && Q_stricmp(cmd, "skin") == 0)
	{
		strncpy (userinfo, ent->client->pers.userinfo, sizeof(ent->client->pers.userinfo)-1);
		Info_SetValueForKey(userinfo, "skin", gi.argv(1));
		ClientUserinfoChanged(ent, userinfo);
	} //end else if
	else if (Q_stricmp(cmd, "teamhelp") == 0)
	{
		TeamHelp_f(ent);
	} //end else if
	else if (Q_stricmp(cmd, "teamaccompany") == 0)
	{
		TeamHelp_f(ent);
	} //end else if
#ifdef BOT_DEBUG
	else if (BotDebugCmd(cmd, ent, server))
	{
	} //end else if
#endif //BOT_DEBUG
	else
	{
		return false;
	} //end else
	return true;
} //end of the function BotCmd
