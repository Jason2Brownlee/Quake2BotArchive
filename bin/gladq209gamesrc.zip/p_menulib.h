//===========================================================================
//
// Name:				p_menulib.h
// Function:		menu
// Programmer:		Mr Elusive (MrElusive@demigod.demon.nl)
// Last update:	1998-01-12
// Tab Size:		3
//===========================================================================

#define MAX_MENU_NAME		32

#define MI_ITEM				1
#define MI_SUBMENU			2
#define MI_SEPERATOR			3

typedef struct menuitem_s
{
	unsigned char type;								//type of menu item
	char name[MAX_MENU_NAME];						//name of the menu item
	char bitmap[MAX_MENU_NAME];					//name of the menu item bitmap
	int id;												//menu id
	struct menu_s *menu;								//menu the item is in
	struct menu_s *submenu;							//submenu if it is a submenu
	struct menuitem_s *prev, *next;				//next and prev item in menu
} menuitem_t;

typedef struct menu_s
{
	char title[MAX_MENU_NAME];						//title of the menu
	char background[MAX_MENU_NAME];				//background picture
   unsigned char type;								//menu type
	struct menu_s *parent;							//parent menu if sub menu
   short nummenuitems;								//number of menu items
   struct menuitem_s *firstmenuitem, *lastmenuitem;
} menu_t;

typedef struct menustate_s
{
	int showmenu;										//true if the menu is up
	int redraw;											//true if the menu should be redrawn
	struct menu_s *menu;								//current menu
	void (*menuproc)(edict_t *ent, int id);	//menu procedure
   int highlighteditem;								//highlighted menu item
	int firstdisplayeditem;							//first item displayed
	float lastchange_time;							//last time the highlight changed
	int redrawmenu;
	int removemenu;
} menustate_t;

menuitem_t *GetMenuItemWithId(menu_t *menu, int id);
void ChangeMenuItemName(menu_t *menu, int id, char *name);
char *MenuItemName(menu_t *menu, int id);
menuitem_t *GetMenuItem(menu_t *menu, int item);
menu_t *QuakeCreateMenu(char *title, char *background);
void QuakeDeleteMenu(menu_t *menu);
void QuakeAppendMenu(menu_t *menu, unsigned char type, int id,
         menu_t *submenu, char *name, char *bitmap);
void QuakeRemoveMenuItem(menu_t *menu, int id);
//
void SendStatusBar(edict_t *ent, char *bar);
void ShowMenu(edict_t *ent);
int MenuForward(edict_t *ent);
int MenuBack(edict_t *ent);
int MenuUp(edict_t *ent);
int MenuDown(edict_t *ent);
void DoMenu(edict_t *ent, usercmd_t *ucmd);
