

Title:         Gladiator Bot for Quake2 game source code
Filename:      Gladq209gamesrc.zip
Version:       version 0.9
Date:          1999-02-14
Author:        Mr. Elusive
Email:         MrElusive@botepidemic.com
Bot Homepage:  http://www.botepidemic.com/gladiator


Description
-----------

This archive includes the game source code used for the Gladiator Bot.
This source code incorporates the following parts:

1. The Quake2 v3.20 game source code by id Software.
   ftp.idsoftware.com/idstuff/quake2/source/
2. The additional Quake2 v3.20 mission pack 1 "The Reckoning" game
   source code by Xatrix.
   ftp.idsoftware.com/idstuff/quake2/source/
3. The additional Quake2 v3.20 mission pack 2 "Ground Zero" game
   source code by Rogue.
   ftp.idsoftware.com/idstuff/quake2/source/
4. The Quake2 CTF game source code.
   ftp.idsoftware.com/idstuff/quake2/ctf/source/
5. Parts of the Rocket Arena 2 Bot Support Routines by David Wright
   http://www.planetquake.com/arena
6. The Gladiator Bot v0.9 game source code by MrElusive.

The source code of the Gladiator Bot DLL is NOT included!


Source code notes
-----------------

The source file g_local.h includes several defines at the top. These defines
have been used in combination with conditional compilation to mark the
different parts of the source code added to the Quake2 v3.20 game source code.
The following defines have been used:

#define BOT			//Gladiator Bot
#define BOT_IMPORT		//bot import redirection
#define BOT_DEBUG		//bot debug
#define OBSERVER		//observer mode
#define TRIGGER_COUNTING	//trigger counting
#define TRIGGER_LOG		//trigger log
#define FUNC_BUTTON_ROTATING	//rotating button
#define LOGFILE			//log file
#define VWEP			//VWep patch
#define ZOID			//CTF
#define CTF_HOOK		//CTF direct hook
#define ROCKETARENA		//Rocket Arena 2
#define CH			//
#define XATRIX			//Xatrix mission pack 1
#define ROGUE			//Rogue mission pack 2


The files bl_main.c and bl_main.h contain some Win32 specific code used to load
the Gladiator Bot DLL.


Copyright and distribution permissions 
--------------------------------------

By using this source code you agree to exempt, without reservation,
the authors and owners of this production or components thereof
from any responsibility for liability, damage caused, or loss,
directly or indirectly, by this software, including but not limited
to, any interruptions of service, loss of business, or any other
consequential damages resulting from the use of or operation of
this source code or components thereof. No warranties are made, expressed
or implied, regarding the usage, functionality, or implied operability
of this source code. All elements are available solely on an "as-is"
basis. Usage is subject to the user's own risk.

id Software, Xatrix, Rogue and David Wright do not distribute,
nor support this source code.

The Gladiator Bot v0.9 game source code may NOT be sold or used in
commercial products in ANY form.

Please read the included liscense.txt for the copyright information
regarding those files belonging to Id Software, Inc.

Contact David Wright for the copyright information regarding the
Rocket Arena 2 Bot Support Routines.

Should you decide to release a modified version of the
Gladiator Bot v0.9 game source code or parts of it, in source
code or compiled form, you MUST add the following text to the
documentation included with your product.

    This product incorporates source code from the Gladiator bot.
    The Gladiator bot is available at the Gladiator Bot page
    http://www.botepidemic.com/gladiator.

    This program is in NO way supported by MrElusive.

    This program may NOT be sold in ANY form whatsoever. If you have paid
    for this product, you should contact MrElusive immidiately via the
    Gladiator bot page or at MrElusive@botepidemic.com



Version Changes
---------------

-