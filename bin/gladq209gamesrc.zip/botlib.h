//===========================================================================
//
// Name:         botlib.h
// Function:     Bot library header
// Programmer:   Mr Elusive (MrElusive@demigod.demon.nl)
// Last update:  1999-02-10
// Tab Size:     3
//===========================================================================

//debug line colors
#define LINECOLOR_NONE			-1
#define LINECOLOR_RED			0xf2f2f0f0L
#define LINECOLOR_GREEN			0xd0d1d2d3L
#define LINECOLOR_BLUE			0xf3f3f1f1L
#define LINECOLOR_YELLOW		0xdcdddedfL
#define LINECOLOR_ORANGE		0xe0e1e2e3L

//Print types
#define PRT_MESSAGE				1
#define PRT_WARNING				2
#define PRT_ERROR					3
#define PRT_FATAL					4
#define PRT_EXIT					5

//console message types
#define CMS_NORMAL				0
#define CMS_CHAT					1

//some maxs
#define MAX_NETNAME				16
#define MAX_CLIENTSKINNAME		128
#define MAX_FILEPATH				144
#define MAX_CHARACTERNAME		144

//action flags
#define ACTION_ATTACK			1
#define ACTION_USE				2
#define ACTION_RESPAWN			4
#define ACTION_JUMP				8
#define ACTION_MOVEUP			8
#define ACTION_CROUCH			16
#define ACTION_MOVEDOWN			16
#define ACTION_MOVEFORWARD		32
#define ACTION_MOVEBACK			64
#define ACTION_MOVELEFT			128
#define ACTION_MOVERIGHT		256
#define ACTION_DELAYEDJUMP		512

//bsp_trace_t hit surface
typedef struct bsp_surface_s
{
	char name[16];
	int flags;
	int value;
} bsp_surface_t;

//remove the bsp_trace_s structure definition l8r on
//a trace is returned when a box is swept through the world
typedef struct bsp_trace_s
{
	qboolean		allsolid;	// if true, plane is not valid
	qboolean		startsolid;	// if true, the initial point was in a solid area
	float			fraction;	// time completed, 1.0 = didn't hit anything
	vec3_t		endpos;		// final position
	cplane_t		plane;		// surface normal at impact
	float			exp_dist;	// expanded plane distance
	int			sidenum;		// number of the brush side hit
	bsp_surface_t surface;	// the hit point surface
	int			contents;	// contents on other side of surface hit
	int			ent;			// number of entity hit
} bsp_trace_t;

//bot settings
typedef struct bot_settings_s
{
	char characterfile[MAX_FILEPATH];
	char charactername[MAX_CHARACTERNAME];
	char ailibrary[MAX_FILEPATH];
} bot_settings_t;

//client settings
typedef struct bot_clientsettings_s
{
	char netname[MAX_NETNAME];
	char skin[MAX_CLIENTSKINNAME];
} bot_clientsettings_t;

//the bot input, will be converted to an usercmd_t
typedef struct bot_input_s
{
	float thinktime;		//time since last output (in seconds)
	vec3_t dir;				//movement direction
	float speed;			//speed in the range [0, 400]
	vec3_t viewangles;	//the view angles
	int actionflags;		//one of the ACTION_? flags
	int lightlevel;		//light level at the bot location
} bot_input_t;

//bot client update
typedef struct bot_updateclient_s
{
	pmtype_t	pm_type;			// movement type
	vec3_t	origin;			// client origin
	vec3_t	velocity;		// client velocity
	byte		pm_flags;		// ducked, jump_held, etc
	byte		pm_time;			// each unit = 8 ms
	float		gravity;			// current gravity
	vec3_t	delta_angles;	// add to command angles to get view direction
									// changed by spawns, rotating objects, and teleporters
	//====================================
	vec3_t	viewangles;		// for fixed views
	vec3_t	viewoffset;		// add to origin for view coordinates
	vec3_t	kick_angles;	// add to view direction to get render angles
									// set by weapon kicks, pain effects, etc
	vec3_t	gunangles;		// angles of the gun
	vec3_t	gunoffset;		// offset of the gun relative to the client origin
	int		gunindex;		// gun model number
	int		gunframe;		// gun model frame number

	float		blend[4];		// rgba full screen effect
	float		fov;				// horizontal field of view
	int		rdflags;			// refdef flags
	short		stats[MAX_STATS];
	//====================================
	int		inventory[MAX_ITEMS];
	//
} bot_updateclient_t;

//entity update
typedef struct bot_updateentity_s
{
	vec3_t	origin;			// origin of the entity
	vec3_t	angles;			// angles of the model
	vec3_t	old_origin;		// for lerping
	vec3_t	mins;				// bounding box minimums
	vec3_t	maxs;				// bounding box maximums
	int		solid;
	int		modelindex;		// model used
	int		modelindex2, modelindex3, modelindex4;	// weapons, CTF flags, etc
	int		frame;			// model frame number
	int		skinnum;			// skin number
	int		effects;			// special effects
	int		renderfx;		// render fx flags
	int		sound;			// for looping sounds, to guarantee shutoff
	int		event;			// impulse events -- muzzle flashes, footsteps, etc
									// events only go out for a single frame, they
									// are automatically cleared each frame
} bot_updateentity_t;

//bot library exported functions
typedef struct bot_export_s
{
	//returns the version of the library
	char *(*BotVersion)(void);
	//setup the bot library
	void (*BotSetupLibrary)(void);
	//shutdown the bot library
	void (*BotShutdownLibrary)(void);
	//returns true if the bot library has been initialized
	int (*BotLibraryInitialized)(void);
	//sets a library variable
	void (*BotLibVarSet)(char *var_name, char *value);
	//sets a C-like define
	void (*BotDefine)(char *string);
	//load a map for the bot clients
	void (*BotLoadMap)(char *mapname, int modelindexes, char *modelindex[],
												int soundindexes, char *soundindex[],
												int imageindexes, char *imageindex[]);
	//setup a bot client (returns true if successfull)
	int (*BotSetupClient)(int client, bot_settings_t *settings);
	//shut down a bot client
	void (*BotShutdownClient)(int client);
	//move a client to another client number
	void (*BotMoveClient)(int oldclnum, int newclnum);
	//update the settings of a client
	void (*BotClientSettings)(int client, bot_clientsettings_t *settings);
	//update the settings of a bot
	void (*BotSettings)(int client, bot_settings_t *settings);
	//start the updates for this frame
	void (*BotStartFrame)(float time);
	//update a bot client
	void (*BotUpdateClient)(int client, bot_updateclient_t *buc);
	//update an entity
	void (*BotUpdateEntity)(int ent, bot_updateentity_t *bue);
	//send a sound
	void (*BotUpdateSound)(vec3_t origin, int ent, int channel, int soundindex,
										float volume, float attenuation, float timeofs);
	//trigger the bot AI for a client
	void (*BotAI)(int client, float thinktime);
	//send a console message to a bot client
	void (*BotConsoleMessage)(int client, int type, char *message);
	//just for testing
	int (*Test)(int parm0, char *parm1, vec3_t parm2, vec3_t parm3);
} bot_export_t;

//bot library imported functions
typedef struct bot_import_s
{
	//recieve bot input
	void		(*BotInput)(int client, bot_input_t *bi);
	//recieve a bot client command
	void		(*BotClientCommand)(int client, char *str, ...);
	//print messages from the bot library
	void		(*Print)(int type, char *fmt, ...);
	//remove trace and point contents, we don't use them anyway?
	bsp_trace_t (*Trace)(vec3_t start, vec3_t mins, vec3_t maxs, vec3_t end, int passent, int contentmask);
	int		(*PointContents)(vec3_t point);
	//memory allocation
	void		*(*GetMemory)(int size);
	void		(*FreeMemory)(void *ptr);
	//debug shit
	int		(*DebugLineCreate)(void);
	void		(*DebugLineDelete)(int line);
	void		(*DebugLineShow)(int line, vec3_t start, vec3_t end, int color);
} bot_import_t;

//linking of bot library
bot_export_t *GetBotAPI(bot_import_t *import);


/* Library variables:

name:							default:				module(s):						description:

"basedir"					""						l_utils.c						Quake2 base directory
														be_aas_load.c
"gamedir"					""						l_utils.c						Quake2 game directory
														be_aas_load.c
"autolaunchbspc"			"0"					be_aas_load.c					automatically launch BSPC
"maxclients"				"4"					be_interface.c					maximum number of clients
"maxentities"				"1024"				be_interface.c					maximum number of entities
														be_aas_bsp.c
"max_messages"				"256"					be_interface.c					console message heap size
"sv_friction"				"6"					be_interface.c					ground friction
"sv_stopspeed"				"100"					be_interface.c					stop speed
"sv_gravity"				"800"					be_interface.c					gravity value
"sv_waterfriction"		"1"					be_interface.c					water friction
"sv_watergravity"			"400"					be_interface.c					gravity in water
"sv_maxvelocity"			"300"					be_interface.c					maximum velocity
"sv_maxwalkvelocity"		"300"					be_interface.c
"sv_maxcrouchvelocity"	"100"					be_interface.c
"sv_maxswimvelocity"		"150"					be_interface.c
"sv_maxacceleration"		"2200"				be_interface.c					maximum acceleration
"sv_airaccelerate"		"0"					be_interface.c					maximum air acceleration
"sv_maxstep"				"18"					be_interface.c					maximum step height
"sv_maxbarrier"			"50"					be_interface.c					maximum barrier height
"sv_maxsteepness"			"0.7"					be_interface.c					maximum floor steepness
"sv_jumpvel"				"224"					be_interface.c					jump z velocity
"sv_maxwaterjump"			"20"					be_interface.c					maximum waterjump height
"max_aaslinks"				"4096"				be_aas_sample.c				maximum links in the AAS
"max_bsplinks"				"4096"				be_aas_bsp.c					maximum links in the BSP

"notspawnflags"			"2048"				be_ai_goal.c					entities with these spawnflags will be removed
"weaponconfig"				"weapons.c"			be_ai_weap.c					weapon configuration file
"itemconfig"				"items.c"			be_ai_goal.c					item configuration file
"soundconfig"				"sounds.c"			be_aas_sound.c					sound configuration file
"matchfile"					"match.c"			be_ai_chat.c					file with match strings
"max_weaponinfo"			"32"					be_ai_weap.c					maximum number of weapon info
"max_projectileinfo"		"32"					be_ai_weap.c					maximum number of projectile info
"max_iteminfo"				"256"					be_ai_goal.c					maximum number of item info
"max_levelitems"			"256"					be_ai_goal.c					maximum number of level items
"max_weights"				"256"					be_ai_goal.c					maximum number of item weights
"max_soundinfo"			"256"					be_aas_sound.c					maximum number of sound info
"max_aassounds"			"256"					be_aas_sound.c					maximum number of simultanious playing AAS sounds
"framereachability"		""						be_aas_reach.c
"forceclustering"			"0"					be_aas_main.c
"forcereachability"		"0"					be_aas_main.c
"forcewrite"				"0"					be_aas_main.c
"nooptimize"				"0"					be_aas_main.c

*/

