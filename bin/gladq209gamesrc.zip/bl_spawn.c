//===========================================================================
//
// Name:				bl_spawn.c
// Function:		spawning of bots
// Programmer:		Mr Elusive (MrElusive@demigod.demon.nl)
// Last update:	1999-02-10
// Tab Size:		3
//===========================================================================

#include "g_local.h"
#include "bl_main.h"


void ClientBegin(edict_t *ent);
void ClientUserinfoChanged(edict_t *ent, char *userinfo);
qboolean ClientConnect(edict_t *ent, char *userinfo);
void ClientDisconnect(edict_t *ent);

typedef struct queuedbot_s
{
	int count;
	char library[MAX_PATH];
	char userinfo[MAX_INFO_STRING];
	edict_t *ent;
	struct queuedbot_s *next;
} queuedbot_t;

queuedbot_t *queuedbots;

//===========================================================================
// spawns a client entity, initializes the edict and sets the pointer
// to the gclient_t structure
// searches a free client entity from top to bottom
//
// Parameter:				-
// Returns:					the spawned free client edict
// Changes Globals:		-
//===========================================================================
edict_t *G_SpawnClient(void)
{
	int i;
	edict_t *cl_ent;

	for (i = game.maxclients-1; i >= 0; i--)
	{
		cl_ent = g_edicts + 1 + i;
		if (!cl_ent->inuse)
		{
			memset(cl_ent, 0, sizeof(*cl_ent));
			G_InitEdict(cl_ent);
			cl_ent->client = &game.clients[cl_ent-g_edicts-1];
			return cl_ent;
		} //end if
	} //end for
	return NULL;
} //end of the function G_SpawnClient
//===========================================================================
//
// Parameter:				-
// Returns:					-
// Changes Globals:		-
//===========================================================================
void G_FreeClientEdict(edict_t *ent)
{
	ent->s.modelindex = 0;
	ent->solid = SOLID_NOT;
	ent->inuse = false;
	ent->classname = "disconnected";
	ent->client->pers.connected = false;
} //end of the function G_FreeClientEdict
//===========================================================================
// the entity will become a bot
//
// Parameter:				lib				: library the bot will use
// Returns:					-
// Changes Globals:		botglobals.states
//								botglobals.numbots
//===========================================================================
void BotBecome(edict_t *ent, bot_library_t *lib)
{
	bot_state_t *bs;

	//remove bot flag before calling ClientConnect to make sure
	//BotMoveToFreeClientEdict won't be called there
	ent->flags &= ~FL_BOT;
	//begin
	ClientBegin(ent);
	//set the bot flag
	ent->flags |= FL_BOT;
	//get pointer to the bot state structure
	bs = &botglobals.botstates[DF_ENTCLIENT(ent)];
	//clear the bot state
	memset(bs, 0, sizeof(bot_state_t));
	//set botstate active flag
	bs->active = true;
	//pointer to the library used by the bot
	bs->library = lib;
	//one extra bot
	botglobals.numbots++;
	//setup the bot client in the library
	BotLib_BotSetupClient(ent, ent->client->pers.userinfo);
} //end of the function BotBecome
//===========================================================================
// create a bot with the given user info
//
// Parameter:				userinfo			: userinfo for the bot to create
//								lib				: library the bot will use
// Returns:					created bot
// Changes Globals:		botglobals.states
//								botglobals.numbots
//===========================================================================
edict_t *BotCreate(char *userinfo, bot_library_t *lib)
{
	edict_t *ent;
	bot_state_t *bs;

	//spawn a client entity
	ent = G_SpawnClient();
	//check if there was a free client entity
	if (!ent) return NULL;
	//remove bot flag before calling ClientConnect to make sure
	//BotMoveToFreeClientEdict won't be called there
	ent->flags &= ~FL_BOT;
	//connect the client
	//NOTE: set entity inuse flag to false because the bot isn't spawned
	//			from a savegame
	ent->inuse = false;
	if (!ClientConnect(ent, userinfo))
	{
		G_FreeClientEdict(ent);
		return NULL;
	} //end if
	//set the inuse flag after connecting
	ent->inuse = true;
	//set the bot flag
	ent->flags |= FL_BOT;
	//get pointer to the bot state structure
	bs = &botglobals.botstates[DF_ENTCLIENT(ent)];
	//clear the bot state
	memset(bs, 0, sizeof(bot_state_t));
	//set botstate active flag
	bs->active = true;
	//pointer to the library used by the bot
	bs->library = lib;
	//setup the bot client in the library
	//NOTE: call after the bs->library pointer is set
	if (!BotLib_BotSetupClient(ent, userinfo))
	{
		G_FreeClientEdict(ent);
		return NULL;
	} //end if
	//
	memcpy(ent->client->pers.userinfo, userinfo, MAX_INFO_STRING);
	//
#ifdef ROCKETARENA
	if (ra->value)
	{
		ent->client->resp.context = (int) atof(Info_ValueForKey(userinfo, "arena"));
	} //end if
#endif //ROCKETARENA
	//one extra bot
	botglobals.numbots++;
	//
	return ent;
} //end of the function CreateBot
//===========================================================================
// destroy the given bot
//
// Parameter:				bot				: bot to destroy
// Returns:					-
// Changes Globals:		botglobals.botstates
//								botglobals.numbots
//===========================================================================
void BotDestroy(edict_t *bot)
{
	bot_state_t *bs;

	if (!(bot->flags & FL_BOT)) return;
	if (!bot->client) return;
	//disconnect the client
	ClientDisconnect(bot);
	//pointer to the bot state
	bs = &botglobals.botstates[DF_ENTCLIENT(bot)];
	//remove botstate active flag
	bs->active = false;
	//clear the entity
	memset(bot, 0, sizeof(*bot));
	//pointer to gclient_t structure
	bot->client = &game.clients[bot-g_edicts-1];
	//clear the gclient_t structure
	memset(bot->client, 0, sizeof(gclient_t));
	//there is a bot less
	botglobals.numbots--;
	//shutdown the bot client in the library
	BotLib_BotShutdownClient(bot);
	//free the library used by the bot
	BotFreeLibrary(bs->library);
	//remove library pointer
	bs->library = NULL;
	//free up the client edict
	G_FreeClientEdict(bot);
} //end of the function BotDestroy
//===========================================================================
// move the given bot from it's current client edict_t to a free one
// returns true if the bot is moved otherwise returns false
//
// Parameter:				bot				: bot to move
// Returns:					boolean depending on a succesfull move
// Changes Globals:		botglobals.botstates
//===========================================================================
qboolean BotMoveToFreeClientEdict(edict_t *bot)
{
	edict_t *newcl;
	bot_state_t *bs, *newbs;
	int playernum;

	if (!bot->inuse) return true;
	if (!(bot->flags & FL_BOT)) return true;
	//spawn a free client edict
	newcl = G_SpawnClient();
	//if there isn't a free client edict available
	if (!newcl) return false;
	//copy the bot to the new client edict
	memcpy(newcl, bot, sizeof(edict_t));
	//copy the contents of the g_client_t structure
	memcpy(newcl->client, bot->client, sizeof(gclient_t));
	//copy bot state
	bs = &botglobals.botstates[bot-g_edicts-1];
	newbs = &botglobals.botstates[newcl-g_edicts-1];
	memcpy(newbs, bs, sizeof(bot_state_t));
	//old bot state isn't used anymore
	bs->active = false;
	//the new state is
	newbs->active = true;
	//change the user info
	ClientUserinfoChanged(newcl, bot->client->pers.userinfo);
	//Initialize client edict previously used by the bot
	//clear the gclient_t structure the bot was using
	memset(bot->client, 0, sizeof(gclient_t));
	//clear the edict the bot was using
	memset(bot, 0, sizeof(edict_t));
	//initialize edict
	G_InitEdict(bot);
	//set pointer to g_client structure
	bot->client = &game.clients[bot-g_edicts-1];
	//remove client userinfo
	playernum = bot-g_edicts-1;
	gi.configstring(CS_PLAYERSKINS+playernum, "");
	//move the bot client in the library
	BotLib_BotMoveClient(bot, newcl);
	//the bot has been succesfully moved
	return true;
} //end of the function BotMoveToFreeClientEdict
//===========================================================================
// spawn bots after level changes
// called from SpawnEntities in g_spawn.c
// ClientConnect for real clients is called after SpawnEntities is executed
// so the bot will be moved to another client edict when new clients come
// into the game during the level change
//
// Parameter:				-
// Returns:					-
// Changes Globals:		-
//===========================================================================
void BotSpawn(void)
{
	int i;
	edict_t *cl_ent;

	for (i = 0; i < game.maxclients; i++)
	{
		//if the bot state was in use
		if (botglobals.botstates[i].active)
		{
			cl_ent = DF_CLIENTENT(i);
			//set started to false
			botglobals.botstates[i].started = false;
			//entity is used
			cl_ent->inuse = true;
			//set the bot flag
			cl_ent->flags |= FL_BOT;
			//set user info because Quake2 likes to remove it for fake clients
			ClientUserinfoChanged(cl_ent, cl_ent->client->pers.userinfo);
		} //end if
	} //end for
} //end of the function BotSpawn
//===========================================================================
//
// Parameter:				-
// Returns:					-
// Changes Globals:		-
//===========================================================================
void ShowLoadImage(edict_t *ent)
{
	char loadstring[1400];

	if (!ent->client) return;
	sprintf(loadstring, "xv 104 yv 128 picn loading");
	SendStatusBar(ent, loadstring);
	ent->client->showloading = true;
} //end of the function ShowLoadImage
//===========================================================================
//
// Parameter:				-
// Returns:					-
// Changes Globals:		-
//===========================================================================
extern char *dm_statusbar;			//g_spawn.c
extern char *single_statusbar;	//g_spawn.c

void RemoveLoadImage(edict_t *ent)
{
	if (!ent->client) return;
	//
	if (!ent->client->showmenu)
	{
		//clear the image by drawing the status bar
		if (deathmatch->value) SendStatusBar(ent, dm_statusbar);
		else SendStatusBar(ent, single_statusbar);
	} //end if
	ent->client->showloading = false;
} //end of the function RemoveLoadImage
//===========================================================================
//
// Parameter:				-
// Returns:					-
// Changes Globals:		-
//===========================================================================
void AddBotToQueue(edict_t *ent, char *library, char *userinfo)
{
	queuedbot_t *bot;

	gi.dprintf("loading...\n");
	if (ent) ShowLoadImage(ent);
	bot = gi.TagMalloc(sizeof(queuedbot_t), TAG_GAME);
	bot->ent = ent;
	bot->count = 2;
	strcpy(bot->library, library);
	strcpy(bot->userinfo, userinfo);

	bot->next = queuedbots;
	queuedbots = bot;
} //end of the function AddBotToQueue
//===========================================================================
//
// Parameter:				-
// Returns:					-
// Changes Globals:		-
//===========================================================================
void AddQueuedBots(void)
{
	char *str;
	queuedbot_t *bot;
	bot_library_t *lib;
	edict_t *botent;

	if (queuedbots)
	{
		if (queuedbots->count-- <= 0)
		{
			bot = queuedbots;
			queuedbots = queuedbots->next;
			//load the default library
			lib = BotUseLibrary(bot->library);
			if (!lib)
			{
				str = "%s not available\n";
				if (bot->ent) gi.cprintf(bot->ent, PRINT_HIGH, str, bot->library);
				else gi.dprintf(str, bot->library);
			} //end if
			else
			{
				botent = BotCreate(bot->userinfo, lib);
				if (!botent)
				{
					str = "can't create bot, maxclients = %d\n";
					if (bot->ent) gi.cprintf(bot->ent, PRINT_HIGH, str, game.maxclients);
					else gi.dprintf(str, game.maxclients);
					//free the library
					BotFreeLibrary(lib);
				} //end if
			} //end else
			if (bot->ent) RemoveLoadImage(bot->ent);
			gi.TagFree(bot);
		} //end if
	} //end if
} //end of the function AddQueuedBots
//===========================================================================
// returns true if there is a client with the given name
//
// Parameter:				-
// Returns:					-
// Changes Globals:		-
//===========================================================================
qboolean ClientNameExists(char *name)
{
	int i;
	edict_t *cl_ent;

	for (i = 0; i < game.maxclients; i++)
	{
		cl_ent = g_edicts + 1 + i;
		if (cl_ent->inuse)
		{
			if (Q_strcasecmp(cl_ent->client->pers.netname, name) == 0)
			{
				return true;
			} //end if
		} //end if
	} //end for
	return false;
} //end of the function ClientNameExists
//===========================================================================
// add a deathmatch bot
//
// Parameter:				-
// Returns:					-
// Changes Globals:		-
//===========================================================================
void BotAddDeathmatch(edict_t *ent)
{
	char uinfo[MAX_INFO_STRING];
	char *str;
	int max, i;

	if (!stricmp(gi.argv(0), "sv"))
	{
		max = 7;
		i = 1;
	} //end if
	else
	{
		max = 6;
		i = 0;
	} //end else
	//need at least 6 parmeters (command name incuded)
	if (gi.argc() < max)
	{
		str = "too few parameters\n";
		if (ent) gi.cprintf(ent, PRINT_HIGH, str);
		else gi.dprintf(str);
		str = 		"Usage:   addbot <botlib> <name> <skin> <charfile> <charname>\n"
						"Example: addbot q2bot.dll brianna female/brianna char.c Brianna\n"
						"\n"
						"<botlib>   = filename of the bot library to use\n"
						"<name>     = name of the bot\n"
						"<skin>     = skin of the bot\n"
						"<charfile> = character file\n"
						"<charname> = character name\n";
		if (ent) gi.cprintf(ent, PRINT_HIGH, str);
		else gi.dprintf(str);
		return;
	} //end if

	memset(uinfo, 0, MAX_INFO_STRING);
	if (ClientNameExists(gi.argv(i+2)))
	{
		str = "client name %s is already used\n";
		if (ent) gi.cprintf(ent, PRINT_HIGH, str, gi.argv(i+2));
		else gi.dprintf(str, gi.argv(i+2));
		return;
	} //end if
	Info_SetValueForKey(uinfo, "name", gi.argv(i+2));
	Info_SetValueForKey(uinfo, "skin", gi.argv(i+3));
	Info_SetValueForKey(uinfo, "charfile", gi.argv(i+4));
	Info_SetValueForKey(uinfo, "charname", gi.argv(i+5));
	//
#ifdef ROCKETARENA
	if (ra->value)
	{
		if (arena->value > 0 && arena->value <= RA2_NumArenas())
		{
			Info_SetValueForKey(uinfo, "arena", arena->string);
		} //end if
		else Info_SetValueForKey(uinfo, "arena", "1");
	} //end if
#endif //ROCKETARENA
	//load the default library
	/*
	bot_library_t *lib;
	edict_t *bot;

	lib = BotUseLibrary(gi.argv(1));
	if (!lib)
	{
		str = "%s not available\n";
		if (ent) gi.cprintf(ent, PRINT_HIGH, str, gi.argv(1));
		else gi.dprintf(str, gi.argv(1));
		return;
	} //end if
	bot = BotCreate(uinfo, lib);
	if (!bot)
	{
		str = "can't create bot, maxclients = %d\n";
		if (ent) gi.cprintf(ent, PRINT_HIGH, str, game.maxclients);
		else gi.dprintf(str, game.maxclients);
		//free the library
		BotFreeLibrary(lib);
		return;
	} //end if*/
	AddBotToQueue(ent, gi.argv(i+1), uinfo);
} //end of the function AddDeathmatchBot
//===========================================================================
// become a bot
//
// Parameter:				-
// Returns:					-
// Changes Globals:		-
//===========================================================================
void BotBecomeDeathmatch(edict_t *ent)
{
	bot_library_t *lib;

	//need at least 2 parmeters (command name incuded)
	if (gi.argc() < 2)
	{
		gi.cprintf(ent, PRINT_HIGH,
						"Usage:   becomebot <botlib>\n"
						"Example: becomebot q2bot.dll\n"
						"\n"
						"<botlib> = filename of the bot library to use\n");
		return;
	} //end if

	//load the default library
	lib = BotUseLibrary(gi.argv(1));
	if (!lib)
	{
		gi.cprintf(ent, PRINT_HIGH, "%s not available\n", gi.argv(1));
		return;
	} //end if
	BotBecome(ent, lib);
} //end of the function BotBecomeDeathmatchBot
//===========================================================================
// add a deathmatch bot
//
// Parameter:				-
// Returns:					-
// Changes Globals:		-
//===========================================================================

/*QUAKED bot (0 .5 .8) ?
Spawns a bot.

"botlib"			bot library to use
"name"			name
"skin"			skin
"charfile"		file which contains the bot character
"charname"		name of the bot character
*/

void SP_bot(edict_t *self)
{
	BotStoreClientCommand("sv", "addbot", st.botlib, st.name, st.skin, st.charfile, st.charname, NULL);
	BotAddDeathmatch(NULL);
	BotClearCommandArguments();
} //end of the function SP_bot
//===========================================================================
// remove a deathmatch bot
//
// Parameter:				-
// Returns:					-
// Changes Globals:		-
//===========================================================================
void BotRemoveDeathmatch(edict_t *ent)
{
	int i;
	edict_t *cl_ent;
	char *name;
	qboolean botname;

	name = gi.argv(1);
	//check if there's a name available
	if (gi.argc() > 1) botname = true;
	else botname = false;
	//
	for (i = 0; i < game.maxclients; i++)
	{
		cl_ent = g_edicts + 1 + i;
		if (!cl_ent->inuse) continue;
		if (cl_ent->flags & FL_BOT)
		{
			if (!botname || Q_strcasecmp(cl_ent->client->pers.netname, name) == 0)
			{
				BotDestroy(cl_ent);
				return;
			} //end if
		} //end if
	} //end for
	if (ent)
	{
		if (botname) gi.cprintf(ent, PRINT_HIGH, "no bot found with name %s\n", name);
		else gi.cprintf(ent, PRINT_HIGH, "no bots to remove\n");
	} //end if
	else
	{
		if (botname) gi.dprintf("no bot found with name %s\n", name);
		else gi.dprintf("no bots to remove\n");
	} //end else
} //end of the functoin BotRemoveDeathmatch
