//===========================================================================
//
// Name:				p_menu.c
// Function:		menu
// Programmer:		Mr Elusive (MrElusive@demigod.demon.nl)
// Last update:	1998-01-12
// Tab Size:		3
//===========================================================================

#include "g_local.h"
#include "bl_spawn.h"
#include "bl_main.h"
#ifdef OBSERVER
#include "p_observer.h"
#endif //OBSERVER

#ifndef MAX_PATH
	#define MAX_PATH			144
#endif

#ifndef PATHSEPERATOR_STR
	#if defined(WIN32)|defined(_WIN32)
		#define PATHSEPERATOR_STR		"\\"
	#else
		#define PATHSEPERATOR_STR		"/"
	#endif
#endif
#ifndef PATHSEPERATOR_CHAR
	#if defined(WIN32)|defined(_WIN32)
		#define PATHSEPERATOR_CHAR		'\\'
	#else
		#define PATHSEPERATOR_CHAR		'/'
	#endif
#endif

#define MAX_DISPLAYEDMENUITEMS	16
#define MENUCHANGE_MOVE				1
//menu IDs
#define MID_GAME						1
#define MID_GAME_TIMELIMIT			2
#define MID_GAME_FRAGLIMIT			3
#define MID_BOT						4
#define MID_BOT_ADD					5
#define MID_BOT_ADDRANDOM			6
#define MID_BOT_REMOVE				7
#define MID_BOT_REMOVEALL			8
#define MID_BOT_ADD_FIRST			256
#define MID_BOT_ADD_LAST			511
#define MID_BOT_REMOVE_FIRST		512
#define MID_BOT_REMOVE_LAST		1024
#define MID_CTF						9
#define MID_RA2						10
#define MID_RA2_BOTARENA			11
#define MID_RA2_SHOTGUN				12
#define MID_RA2_SUPERSHOTGUN		13
#define MID_RA2_MACHINEGUN			14
#define MID_RA2_CHAINGUN			15
#define MID_RA2_GRENADELAUNCHER	16
#define MID_RA2_ROCKETLAUNCHER	17
#define MID_RA2_HYPERBLASTER		18
#define MID_RA2_RAILGUN				19
#define MID_RA2_BFG					20
#define MID_HELP						21
#define MID_EXIT						22
#define MID_BACK						23

typedef struct bot_s
{
	char botlib[MAX_PATH];
	char name[16];
	char skin[MAX_PATH];
	char charfile[MAX_PATH];
	char charname[MAX_PATH];
	struct bot_s *next;
} bot_t;

bot_t *botlist;
char botfilename[MAX_PATH];

menu_t *mainmenu;

//===========================================================================
//
// Parameter:				-
// Returns:					-
// Changes Globals:		-
//===========================================================================
void AddBotToList(bot_t *bot)
{
	bot_t *b, *lastbot;

	lastbot = NULL;
	for (b = botlist; b; b = b->next)
	{
		if (stricmp(bot->name, b->name) < 0)
		{
			//add the new bot before the current bot
			bot->next = b;
			if (lastbot) lastbot->next = bot;
			else botlist = bot;
			return;
		} //end if
		lastbot = b;
	} //end for
	//add the bot to the end of the list
	if (lastbot) lastbot->next = bot;
	else botlist = bot;
	bot->next = NULL;
} //end of the function AddBotToList
//===========================================================================
//
// Parameter:				-
// Returns:					-
// Changes Globals:		-
//===========================================================================
void ConvertPath(char *path)
{
	while(*path)
	{
		if (*path == '/' || *path == '\\') *path = PATHSEPERATOR_CHAR;
		path++;
	} //end while
} //end of the function ConvertPath
//========================================================================
//
// Parameter:				-
// Returns:					-
// Changes Globals:		-
//========================================================================
int ReadString(FILE *fp, char *filename, int line, char *string, int maxlen)
{
	int c, i;

	c = fgetc(fp);
	if (c != '"')
	{
		gi.dprintf("leading \" not found in %s line %d\n", filename, line);
		return false;
	} //end if
	c = fgetc(fp);
	for (i = 0; c != '\"'; i++)
	{
		if (i >= maxlen)
		{
			gi.dprintf("string too long in %s line %d\n", filename, line);
			string[i] = 0;
			return false;
		} //end if
		string[i] = c;
		c = fgetc(fp);
		if (c == EOF || c == '\n')
		{
			gi.dprintf("string without trailing \" in %s line %d\n", filename, line);
			string[i] = 0;
			return false;
		} //end if
	} //end while
	string[i] = 0;
	return true;
} //end of the function ReadString
//========================================================================
//
// Parameter:				-
// Returns:					-
// Changes Globals:		-
//========================================================================
int ReadSpace(FILE *fp, char *filename, int line)
{
	int c;

	do
	{
		c = fgetc(fp);
		if (c == EOF)
		{
			gi.dprintf("unexpected end of file in %s line %d\n", filename, line);
			return false;
		} //end if
		if (c == '\n')
		{
			gi.dprintf("found unexpected end of line in %s line %d\n", filename, line);
			return false;
		} //end if
	} while(c <= ' ');
	ungetc(c, fp);
	return true;
} //end of the function ReadSpace
//========================================================================
//
// Parameter:				-
// Returns:					-
// Changes Globals:		-
//========================================================================
int LoadBots(char *filename)
{
	int line, c, numbots;
	FILE *fp;
	char path[MAX_PATH];
	char addbot[MAX_PATH];
	cvar_t *gamedir;
	bot_t *bot, tmpbot;

	gamedir = gi.cvar("game", "", 0);

	strcpy(path, "./");
	strcat(path, gamedir->string);
	strcat(path, "/");
	strcat(path, filename);
	ConvertPath(path);

	//free the current botlist
	while(botlist)
	{
		bot = botlist;
		botlist = botlist->next;
		gi.TagFree(bot);
	} //end for

	gi.dprintf("loading %s...\n", path);
	fp = fopen(path, "rb");
	if (!fp)
	{
		gi.dprintf("error opening %s\n", filename);
		return false;
	} //end if

	line = 0;
	numbots = 0;
	while(!feof(fp))
	{
		do
		{
			c = fgetc(fp);
			if (c == '\n') line++;
			else if (c == ';')
			{
				while(c != EOF && c != '\n') c = fgetc(fp);
				line++;
			} //end if
			if (c == EOF) break;
		} while(c <= ' ');
		if (c == EOF) break;
		ungetc(c, fp);
		//sv
		if (!ReadString(fp, filename, line, addbot, MAX_PATH)) break;
		if (!ReadSpace(fp, filename, line)) break;
		//addbot
		if (!ReadString(fp, filename, line, addbot, MAX_PATH)) break;
		if (!ReadSpace(fp, filename, line)) break;
		//botlib
		if (!ReadString(fp, filename, line, tmpbot.botlib, MAX_PATH)) break;
		if (!ReadSpace(fp, filename, line)) break;
		//name
		if (!ReadString(fp, filename, line, tmpbot.name, 16)) break;
		if (!ReadSpace(fp, filename, line)) break;
		//skin
		if (!ReadString(fp, filename, line, tmpbot.skin, MAX_PATH)) break;
		if (!ReadSpace(fp, filename, line)) break;
		//charfile
		if (!ReadString(fp, filename, line, tmpbot.charfile, MAX_PATH)) break;
		if (!ReadSpace(fp, filename, line)) break;
		//charname
		if (!ReadString(fp, filename, line, tmpbot.charname, MAX_PATH)) break;
		//
		bot = gi.TagMalloc(sizeof(bot_t), TAG_GAME);
		memcpy(bot, &tmpbot, sizeof(bot_t));
		AddBotToList(bot);
		//
		numbots++;
	} //end while
	fclose(fp);
	//if not at the end of the file something was wrong
	if (c != EOF) return false;
	gi.dprintf("loaded %d bots from %s\n", numbots, filename);
	return true;
} //end of the function LoadBots
//========================================================================
//
// Parameter:				-
// Returns:					-
// Changes Globals:		-
//========================================================================
bot_t *FindBotWithName(char *name)
{
	bot_t *bot;

	for (bot = botlist; bot; bot = bot->next)
	{
		if (!strcmp(bot->name, name)) return bot;
	} //end for
	return NULL;
} //end of the function FindBotWithName
//========================================================================
//
// Parameter:				-
// Returns:					-
// Changes Globals:		-
//========================================================================
void CheckForNewBotFile(void)
{
	cvar_t *botfile;

	botfile = gi.cvar("botfile", "bots.cfg", 0);
	if (stricmp(botfilename, botfile->string))
	{
		LoadBots(botfile->string);
		strcpy(botfilename, botfile->string);
	} //end if
} //end of the function CheckForNewBotFile
//========================================================================
//
// Parameter:				-
// Returns:					-
// Changes Globals:		-
//========================================================================
void SetupRemoveBotMenu(void)
{
	int i, n;
	edict_t *cl_ent;
	menuitem_t *menuitem;
	menu_t *removemenu, *parent = NULL;

	menuitem = GetMenuItemWithId(mainmenu, MID_BOT_REMOVE);
	if (menuitem->submenu)
	{
		parent = menuitem->submenu->parent;
		QuakeDeleteMenu(menuitem->submenu);
	} //end if
	//
	removemenu = QuakeCreateMenu("", "m_remove"); //"Bot remove menu"
	n = 0;
	for (i = 0; i < game.maxclients; i++)
	{
		cl_ent = g_edicts + 1 + i;
		if (!cl_ent->inuse) continue;
		if (!(cl_ent->flags & FL_BOT)) continue;
		QuakeAppendMenu(removemenu, MI_ITEM, MID_BOT_REMOVE_FIRST + n,
			NULL, cl_ent->client->pers.netname, NULL);
		n++;
	} //end for
	QuakeAppendMenu(removemenu, MI_SEPERATOR, -1, NULL, "-----------", NULL);
	QuakeAppendMenu(removemenu, MI_ITEM, MID_BACK, NULL, "back", NULL);
	removemenu->parent = parent;
	menuitem->submenu = removemenu;
} //end of the function SetupRemoveBotMenu
//========================================================================
//
// Parameter:				-
// Returns:					-
// Changes Globals:		-
//========================================================================
void SetupAddBotMenu(void)
{
	int i, n;
	edict_t *cl_ent;
	menuitem_t *menuitem;
	menu_t *addmenu, *parent = NULL;
	bot_t *bot;

	CheckForNewBotFile();
	//
	menuitem = GetMenuItemWithId(mainmenu, MID_BOT_ADD);
	if (menuitem->submenu)
	{
		parent = menuitem->submenu->parent;
		QuakeDeleteMenu(menuitem->submenu);
	} //end if
	//
	addmenu = QuakeCreateMenu("", "m_add"); //"Bot add menu"
	n = 0;
	for (bot = botlist; bot; bot = bot->next)
	{
		for (i = 0; i < game.maxclients; i++)
		{
			cl_ent = g_edicts + 1 + i;
			if (!cl_ent->inuse) continue;
			if (!(cl_ent->flags & FL_BOT)) continue;
			if (!strcmp(bot->name, cl_ent->client->pers.netname)) break;
		} //end for
		if (i < game.maxclients) continue;
		QuakeAppendMenu(addmenu, MI_ITEM, MID_BOT_ADD_FIRST + n, NULL, bot->name, NULL);
		n++;
	} //end for
	QuakeAppendMenu(addmenu, MI_SEPERATOR, -1, NULL, "-----------", NULL);
	QuakeAppendMenu(addmenu, MI_ITEM, MID_BACK, NULL, "back", NULL);
	addmenu->parent = parent;
	menuitem->submenu = addmenu;
} //end of the function SetupAddBotMenu
//========================================================================
//
// Parameter:				-
// Returns:					-
// Changes Globals:		-
//========================================================================
void AddRandomBot(edict_t *ent)
{
	int rnd, i, numbots;
	bot_t *bot;
	edict_t *cl_ent;

	CheckForNewBotFile();
	for (numbots = 0, bot = botlist; bot; bot = bot->next) numbots++;
	rnd = random() * numbots;
	for (bot = botlist; bot; bot = bot->next)
	{
		for (i = 0; i < game.maxclients; i++)
		{
			cl_ent = g_edicts + 1 + i;
			if (!cl_ent->inuse) continue;
			if (!(cl_ent->flags & FL_BOT)) continue;
			if (!strcmp(bot->name, cl_ent->client->pers.netname)) break;
		} //end for
		//if the bot is not already in the game
		if (i >= game.maxclients)
		{
			if (--rnd <= 0) break;
		} //end if
	} //end for
	if (bot)
	{
		BotClientCommand(DF_ENTCLIENT(ent), "addbot", bot->botlib, bot->name, bot->skin, bot->charfile, bot->charname, NULL);
	} //end if
	else
	{
		gi.cprintf(ent, PRINT_HIGH, "no bots to add\n");
	} //end else
} //end of the function AddRandomBot
//========================================================================
//
// Parameter:				-
// Returns:					-
// Changes Globals:		-
//========================================================================
char *OnOffString(char *name, int value)
{
	static char buf[128];

	if (value) sprintf(buf, "%-18son", name);
	else sprintf(buf, "%-18soff", name);
	return buf;
} //end of the function OnOffString
//========================================================================
//
// Parameter:				-
// Returns:					-
// Changes Globals:		-
//========================================================================
void ToggleMenuCVarBoolean(cvar_t *cvar, char *name, int id)
{
	char buf[32];

	cvar->value = !cvar->value;
	sprintf(buf, "%d", (int)cvar->value);
	gi.cvar_set(name, buf);
	ChangeMenuItemName(mainmenu, id, OnOffString(name, (int) cvar->value));
} //end of the function ToggleMenuCVarBoolean
//========================================================================
//
// Parameter:				-
// Returns:					-
// Changes Globals:		-
//========================================================================
void MenuProc(edict_t *ent, int id)
{
	int i;
	bot_t *bot;
	edict_t *cl_ent;
	char buf[256];

	if (id >= MID_BOT_ADD_FIRST && id <= MID_BOT_ADD_LAST)
	{
		bot = FindBotWithName(MenuItemName(mainmenu, id));
		BotClientCommand(DF_ENTCLIENT(ent), "addbot", bot->botlib, bot->name, bot->skin, bot->charfile, bot->charname, NULL);
		QuakeRemoveMenuItem(mainmenu, id);
		return;
	} //end if
	if (id >= MID_BOT_REMOVE_FIRST && id <= MID_BOT_REMOVE_LAST)
	{
		bot = FindBotWithName(MenuItemName(mainmenu, id));
		BotClientCommand(DF_ENTCLIENT(ent), "removebot", bot->name, NULL);
		QuakeRemoveMenuItem(mainmenu, id);
		return;
	} //end if
	switch(id)
	{
		case MID_BOT_ADD: //entering the add bot menu
		{
			SetupAddBotMenu();
			break;
		} //end case
		case MID_BOT_ADDRANDOM: //add a random bot
		{
			AddRandomBot(ent);
			break;
		} //end case
		case MID_BOT_REMOVE: //entering the bot remove menu
		{
			SetupRemoveBotMenu();
			break;
		} //end case
		case MID_BOT_REMOVEALL: //remove all the bots
		{
			for (i = 0; i < game.maxclients; i++)
			{
				cl_ent = g_edicts + 1 + i;
				if (!cl_ent->inuse) continue;
				if (!(cl_ent->flags & FL_BOT)) continue;
				BotClientCommand(DF_ENTCLIENT(ent), "removebot", cl_ent->client->pers.netname, NULL);
			} //end for
			break;
		} //end case
		case MID_RA2_BOTARENA:
		{
			if (arena->value < 1) arena->value = 1;
			else arena->value = floor(arena->value) + 1;
			if (arena->value > RA2_NumArenas()) arena->value = 1;
			sprintf(buf, "%d", (int) arena->value);
			gi.cvar_set("arena", buf);
			sprintf(buf, "bot arena %d", (int) arena->value);
			ChangeMenuItemName(mainmenu, MID_RA2_BOTARENA, buf);
			break;
		} //end case
		case MID_RA2_SHOTGUN: ToggleMenuCVarBoolean(gi.cvar("shotgun", "", 0), "Shotgun", MID_RA2_SHOTGUN); break;
		case MID_RA2_SUPERSHOTGUN: ToggleMenuCVarBoolean(gi.cvar("supershotgun", "", 0), "Super Shotgun", MID_RA2_SUPERSHOTGUN); break;
		case MID_RA2_MACHINEGUN: ToggleMenuCVarBoolean(gi.cvar("machinegun", "", 0), "Machinegun", MID_RA2_MACHINEGUN); break;
		case MID_RA2_CHAINGUN: ToggleMenuCVarBoolean(gi.cvar("chaingun", "", 0), "Chaingun", MID_RA2_CHAINGUN); break;
		case MID_RA2_GRENADELAUNCHER: ToggleMenuCVarBoolean(gi.cvar("grenadelauncher", "", 0), "Grenade Launcher", MID_RA2_GRENADELAUNCHER); break;
		case MID_RA2_ROCKETLAUNCHER: ToggleMenuCVarBoolean(gi.cvar("rocketlauncher", "", 0), "Rocket Launcher", MID_RA2_ROCKETLAUNCHER); break;
		case MID_RA2_HYPERBLASTER: ToggleMenuCVarBoolean(gi.cvar("hyperblaster", "", 0), "Hyperblaster", MID_RA2_HYPERBLASTER); break;
		case MID_RA2_RAILGUN: ToggleMenuCVarBoolean(gi.cvar("railgun", "", 0), "Railgun", MID_RA2_RAILGUN); break;
		case MID_RA2_BFG: ToggleMenuCVarBoolean(gi.cvar("bfg", "", 0), "BFG10K", MID_RA2_BFG); break;
		case MID_BACK: //back to the parent menu
		{
			MenuBack(ent);
			break;
		} //end case
		case MID_EXIT:
		{
			ToggleBotMenu(ent);
			return;
		} //end case
	} //end switch
} //end of the function MenuProc
//========================================================================
//
// Parameter:				-
// Returns:					-
// Changes Globals:		-
//========================================================================
void OpenBotMenu(edict_t *ent)
{
	menustate_t *menustate;

	menustate = &ent->client->menustate;
	menustate->showmenu = true;
	ent->client->showmenu = true;
	ent->client->showscores = true;
	//
	menustate->menu = mainmenu;
	menustate->highlighteditem = 0;
	menustate->menuproc = MenuProc;
	menustate->redrawmenu = true;
	menustate->removemenu = false;
} //end of the function OpenBotMenu
//========================================================================
//
// Parameter:				-
// Returns:					-
// Changes Globals:		-
//========================================================================
void CloseBotMenu(edict_t *ent)
{
	menustate_t *menustate;

	menustate = &ent->client->menustate;
	menustate->showmenu = false;
	ent->client->showmenu = false;
	ent->client->showscores = false;

	menustate->redrawmenu = false;
	menustate->removemenu = true;
} //end of the function CloseBotMenu
//========================================================================
//
// Parameter:				-
// Returns:					-
// Changes Globals:		-
//========================================================================
void ToggleBotMenu(edict_t *ent)
{
	menustate_t *menustate;

	if (!ent)
	{
		gi.dprintf("only clients can open the menu\n");
		return;
	} //end if
	menustate = &ent->client->menustate;
	if (menustate->showmenu) CloseBotMenu(ent);
	else OpenBotMenu(ent);
} //end of the function ToggleBotMenu
//========================================================================
//
// Parameter:				-
// Returns:					-
// Changes Globals:		-
//========================================================================
void CreateBotMenu(void)
{
	menu_t *helpmenu, *botmenu, *addmenu, *removemenu, *ra2menu, *ctfmenu;

	helpmenu = QuakeCreateMenu("", "m_help"); //"Menu help"
	QuakeAppendMenu(helpmenu, MI_SEPERATOR, -1, NULL, "Use your forward and", NULL);
	QuakeAppendMenu(helpmenu, MI_SEPERATOR, -1, NULL, "backward keys (usually ", NULL);
	QuakeAppendMenu(helpmenu, MI_SEPERATOR, -1, NULL, "the arrow keys) to move", NULL);
	QuakeAppendMenu(helpmenu, MI_SEPERATOR, -1, NULL, "the cursor,", NULL);
	QuakeAppendMenu(helpmenu, MI_SEPERATOR, -1, NULL, "your inventory key", NULL);
	QuakeAppendMenu(helpmenu, MI_SEPERATOR, -1, NULL, "(usually Enter) to", NULL);
	QuakeAppendMenu(helpmenu, MI_SEPERATOR, -1, NULL, "select,", NULL);
	QuakeAppendMenu(helpmenu, MI_SEPERATOR, -1, NULL, "Esc to exit the menu", NULL);
	QuakeAppendMenu(helpmenu, MI_SEPERATOR, -1, NULL, "", NULL);
	QuakeAppendMenu(helpmenu, MI_SEPERATOR, -1, NULL, "-----------", NULL);
	QuakeAppendMenu(helpmenu, MI_ITEM, MID_BACK, NULL, "back", NULL);
	//
	addmenu = QuakeCreateMenu("", "m_add"); //"Bot add menu"
	removemenu = QuakeCreateMenu("", "m_remove"); //"Bot remove menu"
	//
 	botmenu = QuakeCreateMenu("", "m_bots"); //"Bot menu"
	QuakeAppendMenu(botmenu, MI_SEPERATOR, -1, NULL, "", NULL);
	QuakeAppendMenu(botmenu, MI_SEPERATOR, -1, NULL, "", NULL);
	QuakeAppendMenu(botmenu, MI_SEPERATOR, -1, NULL, "", NULL);
	QuakeAppendMenu(botmenu, MI_SUBMENU, MID_BOT_ADD, addmenu, "add bot", NULL);
	QuakeAppendMenu(botmenu, MI_ITEM, MID_BOT_ADDRANDOM, NULL, "add random", NULL);
	QuakeAppendMenu(botmenu, MI_SUBMENU, MID_BOT_REMOVE, removemenu, "remove bot", NULL);
	QuakeAppendMenu(botmenu, MI_ITEM, MID_BOT_REMOVEALL, NULL, "remove all", NULL);
	QuakeAppendMenu(botmenu, MI_SEPERATOR, -1, NULL, "-----------", NULL);
	QuakeAppendMenu(botmenu, MI_ITEM, MID_BACK, NULL, "back", NULL);
	//
	ctfmenu = QuakeCreateMenu("CTF menu", NULL);
	QuakeAppendMenu(ctfmenu, MI_SEPERATOR, -1, NULL, "-----------", NULL);
	QuakeAppendMenu(ctfmenu, MI_ITEM, MID_BACK, NULL, "back", NULL);
	//
	ra2menu = QuakeCreateMenu("RA2 menu", NULL);
	QuakeAppendMenu(ra2menu, MI_ITEM, MID_RA2_BOTARENA, NULL, "bot arena 1", NULL);
	QuakeAppendMenu(ra2menu, MI_ITEM, MID_RA2_SHOTGUN, NULL, OnOffString("Shotgun", (int) (gi.cvar("shotgun", "1", 0))->value), NULL);
	QuakeAppendMenu(ra2menu, MI_ITEM, MID_RA2_SUPERSHOTGUN, NULL, OnOffString("Super Shotgun", (int) (gi.cvar("supershotgun", "1", 0))->value), NULL);
	QuakeAppendMenu(ra2menu, MI_ITEM, MID_RA2_MACHINEGUN, NULL, OnOffString("Machinegun", (int) (gi.cvar("machinegun", "1", 0))->value), NULL);
	QuakeAppendMenu(ra2menu, MI_ITEM, MID_RA2_CHAINGUN, NULL, OnOffString("Chaingun", (int) (gi.cvar("chaingun", "1", 0))->value), NULL);
	QuakeAppendMenu(ra2menu, MI_ITEM, MID_RA2_GRENADELAUNCHER, NULL, OnOffString("Grenade Launcher", (int) (gi.cvar("grenadelauncher", "1", 0))->value), NULL);
	QuakeAppendMenu(ra2menu, MI_ITEM, MID_RA2_ROCKETLAUNCHER, NULL, OnOffString("Rocket Launcher", (int) (gi.cvar("rocketlauncher", "1", 0))->value), NULL);
	QuakeAppendMenu(ra2menu, MI_ITEM, MID_RA2_HYPERBLASTER, NULL, OnOffString("Hyperblaster", (int) (gi.cvar("hyperblaster", "1", 0))->value), NULL);
	QuakeAppendMenu(ra2menu, MI_ITEM, MID_RA2_RAILGUN, NULL, OnOffString("Railgun", (int) (gi.cvar("railgun", "0", 0))->value), NULL);
	QuakeAppendMenu(ra2menu, MI_ITEM, MID_RA2_BFG, NULL, OnOffString("BFG", (int) (gi.cvar("bfg", "0", 0))->value), NULL);
	/*
	"armor", "200", CVAR_SERVERINFO);
	"health", "100", CVAR_SERVERINFO);
	"shells", "100", CVAR_SERVERINFO);
	"bullets", "200" ,CVAR_SERVERINFO);
	"slugs", "50", CVAR_SERVERINFO);
	"grenades", "50", CVAR_SERVERINFO);
	"rockets", "50", CVAR_SERVERINFO);
	"cells", "150", CVAR_SERVERINFO);
	*/
	QuakeAppendMenu(ra2menu, MI_SEPERATOR, -1, NULL, "-----------", NULL);
	QuakeAppendMenu(ra2menu, MI_ITEM, MID_BACK, NULL, "back", NULL);
	//
	mainmenu = QuakeCreateMenu("", "m_main"); //"Main menu"
	QuakeAppendMenu(mainmenu, MI_SEPERATOR, -1, NULL, "", NULL);
	QuakeAppendMenu(mainmenu, MI_SEPERATOR, -1, NULL, "", NULL);
	QuakeAppendMenu(mainmenu, MI_SEPERATOR, -1, NULL, "", NULL);
	QuakeAppendMenu(mainmenu, MI_SEPERATOR, -1, NULL, "", NULL);
	QuakeAppendMenu(mainmenu, MI_SUBMENU, MID_BOT, botmenu, "Bots", NULL);
	//QuakeAppendMenu(mainmenu, MI_SUBMENU, MID_CTF, ctfmenu, "CTF", NULL);
	QuakeAppendMenu(mainmenu, MI_SUBMENU, MID_RA2, ra2menu, "RA2", NULL);
	QuakeAppendMenu(mainmenu, MI_SUBMENU, MID_HELP, helpmenu, "Help", NULL);
	QuakeAppendMenu(mainmenu, MI_SEPERATOR, -1, NULL, "-----------", NULL);
	QuakeAppendMenu(mainmenu, MI_ITEM, MID_EXIT, NULL, "Exit", NULL);
} //end of the function CreateBotMenu
