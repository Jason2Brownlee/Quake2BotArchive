ACE 
A Quake2 BOT
---------------------------------------------- [ BeOS Release ]

Current Version:
----------------
Version 008


Thanks To:
----------

  - A whole s*#$load of people, you know who you are....


Installation Instructions:
--------------------------

  Unzip the files under your main Quake2 directory, for example expand
  the zip file into /boot/apps/Quake2 on BeOS.

  Here's a sample command line for DM play;

    Quake2 +set game ace +set deathmatch 1 +set ctf 0 +map q2dm1
    
  Here's a sample command line for CTF play;
  
    Quake2 +set game ace +set ctf 1 +map q2ctf1


ACE Commands (Playing):
-----------------------

(DM)
sv addbot <name> <skin>       - Add a bot in DM play
                                  i.e. "sv addbot Masher male/sniper" 
                                  or   "sv addbot" to spawn a random bot
(CTF)
sv addbot <red|blue> <name> <skin>
                              - Add a bot in CTF play
                                  i.e. "sv addbot blue Masher male/sniper"
                                  or   "sv addbot" to spawn a random bot
(BOTH)
sv removebot <name>           - Remove a bot by name.

sv savenodes                  - Updates pathing data and saves bots 
                                  current knowledge of level.
sv acedebug <on|off>          - Turns on ACE's debugging messages. 
                                  Shows when stuck, bot's thought process, 
                                  node placement and linkage information.

(NOTE: The below commands only give you feedback when debug mode is on.)

cmd addnode <0|1|2|3|4|5|6>   - Adds a new node of type 0-6. 
                                  See details below.
cmd addlink <from> <to>       - Adds a link between nodes.
cmd removelink <from> <to>    - Removes a link between nodes.
cmd movenode <node> <x y z>   - Moves a node to a new location, useful 
                                  for nudging a node about.
cmd showpath <node>           - Shows a path to a given node.
cmd findnode <node>           - Find the closest reachable node to your 
                                  current position.


ACE Commands (Camera):
---------------------

spectator <on/off>            - Turns on/off ACE's spectator mode.
                                  As long as you don't tap the "space" 
                                  key, the camera can be moved around 
                                  the map independent of the active
                                  bots/players.  The "space" key is
                                  used to enable the chase cam mode 
                                  and once activated, can be used to 
                                  switch the chase cam target between 
                                  the various active bots/players...

Legal Info:
-----------

I = Steve Yeager (syeager@axionfx.com)

NO WARRANTIES. I am providing this software as is, without warranty 
of any kind.  I and all my suppliers disclaim all warranties, either 
expressed or implied, including, but not limited to, implied warranties 
of merchantability and fitness for a particular purpose, with regard to 
the ACE Bot and any other software included in the distribution package 
or archive.

NO LIABILITIES FOR CONSEQUENTIAL DAMAGES.  To the maximum amount 
permitted by applicable law, in no event shall I or my suppliers be 
liable for any damages whatsoever (including, without limitation, 
damages for loss of business profits, business interruption, loss of 
business information, or any other loss) arising out of the use of or 
inability to use this product, even if I have been advised of the 
possibility of such damages.  

--
08.23.99 - updated by Richard Hess for BeOS release of ACE bot...
         - fixed addbot command info... [ no skill values? ]
         - added info on spectator mode...
         - added symbolic link to the ../ctf/pak0.pak file to fix the
             "Can't find pic: tech*" errors...
--
