

TourneyCE - OSP Tourney DM Config Editor
========================================
Version: 2.51
Date: 1:21 AM 1/7/99 GMT
HomePage: http://homepage.esoterica.pt/~smashing/tourneyce/

NOTE: Im not going to be very expansive in the README
file, because i prefer to hack code than be friendly.. :)



Instalation
~~~~~~~~~~~
 The program will run anywhere, but for organization purposes
you should create a sub-directory in your \quake2\tourney
dir, something like '\ConfigEditor' will do nicely. Just put
in all of the files there, and run.

The zip file should have four files: tourneyce.exe, tourney.ini,
tourneyce.cnt and tourneyce.hlp. If it didnt, youve been had.
Some Gremlin is stealing your bytes right under your modem.


Troubleshoot
~~~~~~~~~~~~

 If you get a missing export MFC42.DLL, or any error of this
type, please download the available DLL on the editors page.
Close all the running applications, and copy the MFC42.DLL
into your \windows\system directory in case of a Win95/98 box,
or \winnt\system32 in case of WinNT4.


Source Code Dsitribution
~~~~~~~~~~~~~~~~~~~~~~~~

Source code will only be available when everything works
ok. I dont like putting up spaghetti code, it tarnishes
my good reputation..
  I think it should be soon, but id just like to add a few
more features 'til i release it.


Author/Contact
~~~~~~~~~~~~~~
 Bugs/suggestions/candy about the editor should be sent to
me. Dont hassle the OSP team with it, they are very busy doing
Quake2 mods. :)

 Thanks go to a lot of people. They're all in the HLP file,
so i wont use up any more byte space: you know who are! :)

Filipe Toscano
Email: smashing@esoterica.pt
ICQ#: 1589104
Homepage: http://homepage.esoterica.pt/~smashing/
Clan 7: http://www.terravista.pt/Ancora/2774/

