@quake2 +set game eraser +deathmatch 1
