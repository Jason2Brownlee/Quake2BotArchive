#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <gl\glut.h>

#define CONSOLE_SCALE 16.0F
#define CONSOLE_WIDTH 48
#define CONSOLE_HEIGHT 16

char consoleContents[CONSOLE_WIDTH*CONSOLE_HEIGHT];
int consoleX=0;
int consoleY=0;

void drawConsole(void) {
	int x,y;
	GLfloat font_scale = 119.05F + 33.33F;

	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();
	gluOrtho2D(0, 640, 0, 480);

	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glLoadIdentity();

	glPushAttrib(GL_ENABLE_BIT);
	glDisable(GL_LIGHTING);
	glDisable(GL_TEXTURE_2D);
	glDisable(GL_DEPTH_TEST);

	for(y=0;y<CONSOLE_HEIGHT;y++) {
		glLoadIdentity();
		glTranslatef(0.0F, 480.0F-CONSOLE_SCALE*(y+1), 0.0F);
		glScalef(CONSOLE_SCALE/font_scale, CONSOLE_SCALE/font_scale, CONSOLE_SCALE/font_scale);
		for(x=0;x<CONSOLE_WIDTH;x++) {
			glutStrokeCharacter(GLUT_STROKE_MONO_ROMAN, consoleContents[CONSOLE_WIDTH*((y+consoleY)%CONSOLE_HEIGHT)+x]);
		}
	}

	glPopAttrib();

	glPopMatrix();
	glMatrixMode(GL_PROJECTION);
	glPopMatrix();
	glMatrixMode(GL_MODELVIEW);
}

void printfx(char *format, ...) {
	va_list args;
	char buffer[8192];
	int i,j;

	va_start(args, format);
	vsprintf(buffer, format, args);
	va_end(args);

	for(i=0;buffer[i];i++) {
		if(buffer[i]==10 || buffer[i]==13) {
			consoleX=CONSOLE_WIDTH;
		} else {
			consoleContents[CONSOLE_WIDTH*consoleY+consoleX]=buffer[i];
			consoleX++;
		}
		if(consoleX==CONSOLE_WIDTH) {
			consoleY=(consoleY+1)%CONSOLE_HEIGHT;
			consoleX=0;
			for(j=0;j<CONSOLE_WIDTH;j++) {
				consoleContents[CONSOLE_WIDTH*consoleY+j]=32;
			}
		}
	}
}
