
#ifndef __CONSOLE_H
#define __CONSOLE_H

void drawConsole(void);
void printfx(char *format, ...);

#endif