/*	glbastard.cpp
 *	9/7/98 Ben Swartzlander
 */

#include <gl\glut.h>
#include "console.h"
#include "../common/common.h"
#include "../common/bot.h"

void qxArraySizes(int *, int *);
bool qxFillArrays(vec3_t **, vec3_t **);

HDC hDeviceContext;
HWND hWindow;
HGLRC hRenderingContext;

vec3_t *edgelines=NULL;
vec3_t *linklines=NULL;

int edgelineCount;
int linklineCount;

bool arraysFilled=false;
bool console=true;
bool follow=true;
bool frameOK=false;

float yaw=0,pitch=0;
vec3_t playerorigin={0.0,0.0,0.0};
vec3_t position={0.0,0.0,0.0};

extern int move;
extern gamestate_t gs;
extern bool attack;
extern path_t path;
extern int path_point;
extern vec3_t destination,target;

void print(char *s) {
	printfx("%s",s);
}

void initDisplay(void) {
	GLfloat fog_color[]={0.0,0.0,0.0,1.0};

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glFrustum(-1.0,1.0,-0.75,0.75,1.0,1024.0);
	glMatrixMode(GL_MODELVIEW);

	glClearColor(0.0, 0.0, 0.0, 1.0);
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_POINT_SMOOTH);
	glPointSize(4.0);
	glShadeModel(GL_SMOOTH);
	glEnable(GL_CULL_FACE);
	glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
	glEnable(GL_BLEND);
	glEnable(GL_LINE_SMOOTH);

	glEnable(GL_FOG);
	glFogi(GL_FOG_MODE,GL_LINEAR);
	glFogf(GL_FOG_DENSITY,1.0);
	glFogf(GL_FOG_START,0.0);
	glFogf(GL_FOG_END,512.0);
	glFogfv(GL_FOG_COLOR,fog_color);

	glEnableClientState(GL_VERTEX_ARRAY);
	SetCursorPos(320,240);
}

void destroyDisplay(void) {

	if(edgelines) free(edgelines);
	edgelines=NULL;

	if(linklines) free(linklines);
	linklines=NULL;
}

void input(void) {
	POINT mouse;

	GetCursorPos(&mouse);

	yaw+=(float)(mouse.x-320)*0.5;
	pitch+=(float)(mouse.y-240)*0.5;
	if(pitch<-90.0) {
		pitch=-90.0;
	} else if(pitch>90.0) {
		pitch=90.0;
	}
	if(GetAsyncKeyState(VK_LBUTTON)<0) {
		if(GetAsyncKeyState(VK_RBUTTON)<0) {
			position[0]-=16.0*sin(yaw*PI/180.0)*cos(pitch*PI/180.0);
			position[2]-=16.0*sin(pitch*PI/180.0);
			position[1]-=16.0*cos(yaw*PI/180.0)*cos(pitch*PI/180.0);
		} else {
			position[0]-=8.0*sin(yaw*PI/180.0)*cos(pitch*PI/180.0);
			position[2]-=8.0*sin(pitch*PI/180.0);
			position[1]-=8.0*cos(yaw*PI/180.0)*cos(pitch*PI/180.0);
		}
	} else if(GetAsyncKeyState(VK_RBUTTON)<0) {
		position[0]+=8.0*sin(yaw*PI/180.0)*cos(pitch*PI/180.0);
		position[2]+=8.0*sin(pitch*PI/180.0);
		position[1]+=8.0*cos(yaw*PI/180.0)*cos(pitch*PI/180.0);
	}
	if(GetAsyncKeyState('S')<0) {
		position[0]+=8.0*sin((yaw+90.0)*PI/180.0);
		position[1]+=8.0*cos((yaw+90.0)*PI/180.0);
	} else if(GetAsyncKeyState('D')<0) {
		position[0]-=8.0*sin((yaw+90.0)*PI/180.0);
		position[1]-=8.0*cos((yaw+90.0)*PI/180.0);
	}
	SetCursorPos(320,240);
}

void display(void) {
	int i;

	playerorigin[0]=gs.player.origin[0];
	playerorigin[1]=gs.player.origin[1];
	playerorigin[2]=gs.player.origin[2];

	glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);

	glLoadIdentity();

	if(follow) {
		glTranslatef(0.0,0.0,-128.0);
		glRotatef(pitch, 1.0, 0.0, 0.0);
		glRotatef(yaw, 0.0, 1.0, 0.0);
		glScalef(-1.0, -1.0, 1.0);
		glRotatef(90.0, 1.0, 0.0, 0.0);
		glTranslatef(-playerorigin[0],-playerorigin[1],-playerorigin[2]);
	} else {
		glRotatef(pitch, 1.0, 0.0, 0.0);
		glRotatef(yaw, 0.0, 1.0, 0.0);
		glScalef(-1.0, -1.0, 1.0);
		glRotatef(90.0, 1.0, 0.0, 0.0);
		glTranslatef(-position[0],-position[1],-position[2]);
	}

	if(arraysFilled) {
		glColor4f(1.0, 1.0, 1.0, 1.0);
		glVertexPointer(3,GL_FLOAT,0,edgelines);
		glDrawArrays(GL_LINES,0,edgelineCount*2);

		glBegin(GL_POINTS);
		glVertex3fv(playerorigin);
		glEnd();

		glColor4f(0.0, 1.0, 0.0, 1.0);
		glVertexPointer(3,GL_FLOAT,0,linklines);
		glDrawArrays(GL_LINES,0,linklineCount*2);

		if(attack) {
			glColor4f(1.0, 0.0, 0.0, 1.0);
			glBegin(GL_LINES);
			glVertex3fv(playerorigin);
			glVertex3fv(target);
			glEnd();
		}

		if(move==MOVE_GRAB) {
			glColor4f(0.0, 1.0, 1.0, 1.0);
			glBegin(GL_LINES);
			glVertex3fv(playerorigin);
			glVertex3fv(destination);
			glEnd();
		} else if(move==MOVE_QUEST) {
			glColor4f(0.0, 0.0, 1.0, 1.0);
			glBegin(GL_LINES);
			for(i=path_point+1;i<path.length;i++) {
				glVertex3fv(path.points[i-1]);
				glVertex3fv(path.points[i]);
			}
			glEnd();
		} else if(move==MOVE_WANDER) {
			glColor4f(1.0, 0.0, 1.0, 1.0);
			glBegin(GL_LINES);
			for(i=path_point+1;i<path.length;i++) {
				glVertex3fv(path.points[i-1]);
				glVertex3fv(path.points[i]);
			}
			glEnd();
		}
	}

	if(console) {
		glColor4f(1.0,1.0,1.0,1.0);
		drawConsole();
	}

	glFlush();
	SwapBuffers(hDeviceContext);
}

LONG WINAPI WindowProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
	static PAINTSTRUCT ps;

	switch(uMsg) {
		case WM_PAINT:
			display();
			BeginPaint(hWnd, &ps);
			EndPaint(hWnd, &ps);
			return 0;

		case WM_SIZE:
			glViewport(0, 0, LOWORD(lParam), HIWORD(lParam));
			PostMessage(hWnd, WM_PAINT, 0, 0);
			return 0;

		case WM_CHAR:
			switch (wParam) {
				case 'c':
					console=!console;
					break;
				case 'f':
					follow=!follow;
					break;
				case 27:
					PostQuitMessage(0);
					break;
			}		
			return 0;

		case WM_CLOSE:
			PostQuitMessage(0);
			return 0;
	}

	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}

HWND CreateOpenGLWindow(char* title, int x, int y, int width, int height, BYTE type, DWORD flags) {
	int 		pf;
	HDC 		hDC;
	HWND		hWnd;
	WNDCLASS	wc;
	PIXELFORMATDESCRIPTOR pfd;
	static HINSTANCE hInstance = 0;

	/* only register the window class once - use hInstance as a flag. */
	if (!hInstance) {
		hInstance = GetModuleHandle(NULL);
		wc.style		 = CS_OWNDC;
		wc.lpfnWndProc	 = (WNDPROC)WindowProc;
		wc.cbClsExtra	 = 0;
		wc.cbWndExtra	 = 0;
		wc.hInstance	 = hInstance;
		wc.hIcon		 = LoadIcon(NULL, IDI_WINLOGO);
		wc.hCursor		 = LoadCursor(NULL, IDC_ARROW);
		wc.hbrBackground = NULL;
		wc.lpszMenuName  = NULL;
		wc.lpszClassName = "OpenGL";

		if (!RegisterClass(&wc)) {
			MessageBox(NULL, "RegisterClass() failed:  "
					"Cannot register window class.", "Error", MB_OK);
			return NULL;
		}
	}

	hWnd = CreateWindow("OpenGL", title, WS_OVERLAPPEDWINDOW |
		WS_CLIPSIBLINGS | WS_CLIPCHILDREN,
		x, y, width, height, NULL, NULL, hInstance, NULL);

	if (hWnd == NULL) {
		MessageBox(NULL, "CreateWindow() failed:  Cannot create a window.",
			"Error", MB_OK);
		return NULL;
	}

	hDC = GetDC(hWnd);

	/* there is no guarantee that the contents of the stack that become
	   the pfd are zeroed, therefore _make sure_ to clear these bits. */
	memset(&pfd, 0, sizeof(pfd));
	pfd.nSize		 = sizeof(pfd);
	pfd.nVersion	 = 1;
	pfd.dwFlags 	 = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | flags;
	pfd.iPixelType	 = type;
	pfd.cColorBits	 = 16;

	pf = ChoosePixelFormat(hDC, &pfd);
	if (pf == 0) {
		MessageBox(NULL, "ChoosePixelFormat() failed:  "
			"Cannot find a suitable pixel format.", "Error", MB_OK);
		return 0;
	}

	if (SetPixelFormat(hDC, pf, &pfd) == FALSE) {
		MessageBox(NULL, "SetPixelFormat() failed:  "
			"Cannot set format specified.", "Error", MB_OK);
		return 0;
	}

	DescribePixelFormat(hDC, pf, sizeof(PIXELFORMATDESCRIPTOR), &pfd);

	ReleaseDC(hWnd,hDC);

	return hWnd;
}

char hostname[80];
unsigned short port;
char quakedir[80];
char gamedir[80];

DWORD botThread(void *ptr) {

	if(!botInit(hostname,port,"BastardBot",NULL,quakedir,gamedir)) {
		PostQuitMessage(0);
		return 1;
	}

	qxArraySizes(&edgelineCount,&linklineCount);
	edgelines=(vec3_t *)malloc(2*edgelineCount*sizeof(vec3_t));
	linklines=(vec3_t *)malloc(2*linklineCount*sizeof(vec3_t));
	qxFillArrays(&edgelines,&linklines);
	arraysFilled=true;

	while(true) {
		while(!frameOK) {
			Sleep(10);
		}
		botFrame();
		frameOK=false;
	}
	return 0;
}

void printUsage(void) {
	MessageBox(NULL,
		"Usage: glbastard [-h hostname] [-p port] [-dir quake2_directory] [-game gamedir]",
		"Usage Error (see bastard.exe)", MB_OK);
}

char seps[]=" \t\n";

int APIENTRY WinMain(HINSTANCE hCurrentInst,HINSTANCE hPreviousInst,LPSTR lpszCmdLine,int nCmdShow) {
	HANDLE thread;
	DWORD thread_id;
	MSG msg;
	char *p,*v;

	hostname[0]='\0';
	port=27910;
	strcpy(quakedir,"c:/quake2/");
	strcpy(gamedir,"ctf/");

	for(p=strtok(lpszCmdLine,seps);p;p=strtok(NULL,seps)) {
		v=strtok(NULL,seps);
		if(!v) {
			printUsage();
			return 1;
		}
		if(strcmp(p,"-h")==0) {
			strcpy(hostname,v);
		} else if(strcmp(p,"-p")==0) {
			port=atoi(v);
		} else if(strcmp(p,"-dir")==0) {
			strcpy(quakedir,v);
		} else if(strcmp(p,"-game")==0) {
			strcpy(gamedir,v);
		} else {
			printUsage();
			return 1;
		}
	}

	if(!hostname[0]) {
		printUsage();
		return 1;
	}

	hWindow=CreateOpenGLWindow("GL BastardBot", 0, 0, 640, 480, PFD_TYPE_RGBA, PFD_DOUBLEBUFFER);
	if(hWindow==NULL) {
		return 1;
	}
	hDeviceContext=GetDC(hWindow);
	hRenderingContext=wglCreateContext(hDeviceContext);
	wglMakeCurrent(hDeviceContext,hRenderingContext);
	initDisplay();

	ShowWindow(hWindow, nCmdShow);

	thread=CreateThread(NULL,0,(LPTHREAD_START_ROUTINE)botThread,NULL,0,&thread_id);
	if(thread==NULL) {
		return 0;
	}

	while(1) {
		while(PeekMessage(&msg, hWindow, 0, 0, PM_NOREMOVE)) {
			if(GetMessage(&msg, hWindow, 0, 0)) {
				TranslateMessage(&msg);
				DispatchMessage(&msg);
			} else {
				TerminateThread(thread,0); 
				botDie();
				destroyDisplay();
				wglMakeCurrent(NULL, NULL);
				ReleaseDC(hWindow,hDeviceContext);
				wglDeleteContext(hRenderingContext);
				DestroyWindow(hWindow);
				return msg.wParam;
			}
		}
		frameOK=true;
		input();
		display();
	}
}