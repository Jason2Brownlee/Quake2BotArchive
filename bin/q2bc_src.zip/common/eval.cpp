#include "../common/common.h"

extern inventory_t inventory;
extern gamestate_t gs;

bool haveItem(char *name) {
	int i;

	for(i=0;i<256;i++) {
		if(strcmp(name,inventory[i].name)==0) {
			if(inventory[i].number) {
				return true;
			} else {
				return false;
			}
		}
	}
	return false;
}


int evalMediumHealth(void) {
	if(gs.player.health<100)
		return 50;
	else
		return 0;
}

int evalLargeHealth(void) {
	if(gs.player.health<100)
		return 100;
	else
		return 0;
}

int evalStimpack(void) {
	return 20;
}

int evalMegaHealth(void) {
	if(gs.player.health<250)
		return 500;
	else
		return 0;
}

int evalAdrenaline(void) {
	if(gs.player.health<100)
		return 200;
	else
		return 0;
}

int evalBullets(void) {
	return 25;
}

int evalCells(void) {
	return 50;
}

int evalShells(void) {
	return 30;
}

int evalGrenades(void) {
	return 40;
}

int evalRockets(void) {
	return 50;
}

int evalSlugs(void) {
	return 50;
}

int evalBodyArmor(void) {
	if(gs.player.armor<200)
		return 500;
	else
		return 0;
}

int evalCombatArmor(void) {
	if(gs.player.armor<100)
		return 250;
	else if(strcmp(gs.player.armor_icon,"i_bodyarmor")==0 && gs.player.armor<200)
		return 250;
	else
		return 0;
}

int evalJacketArmor(void) {
	if(gs.player.armor<50)
		return 125;
	else if(strcmp(gs.player.armor_icon,"i_combatarmor")==0 && gs.player.armor<100)
		return 125;
	else if(strcmp(gs.player.armor_icon,"i_bodyarmor")==0 && gs.player.armor<200)
		return 125;
	else
		return 0;
}

int evalArmorShard(void) {
	return 15;
}

int evalPowerScreen(void) {
	return 150;
}

int evalPowerSheild(void) {
	return 150;
}

int evalBandolier(void) {
	return 75;
}

int evalInvulnerability(void) {
	return 1000;
}

int evalBackpack(void) {
	return 100;
}

int evalQuad(void) {
	return 300;
}

int evalSilencer(void) {
	if(haveItem("Silencer")) return 0;
	return 50;
}

int evalShotgun(void) {
	if(haveItem("Shotgun")) return 0;
	return 40;
}

int evalSuperShotgun(void) {
	if(haveItem("Super Shotgun")) return 0;
	return 100;
}

int evalMachineGun(void) {
	if(haveItem("Machinegun")) return 0;
	return 75;
}

int evalChainGun(void) {
	if(haveItem("Chaingun")) return 0;
	return 100;
}

int evalGrenadeLauncher(void) {
	if(haveItem("Grenade Launcher")) return 0;
	return 150;
}

int evalRocketLauncher(void) {
	if(haveItem("Rocket Launcher")) return 0;
	return 250;
}

int evalHyperBlaster(void) {
	if(haveItem("HyberBlaster")) return 0;
	return 250;
}

int evalRailgun(void) {
	if(haveItem("Railgun")) return 0;
	return 300;
}

int evalBFG(void) {
	if(haveItem("BFG10K")) return 0;
	return 200;
}

int eval(void) {
	return 0;
}


EVALUATOR evalFunction(char *s) {
	if(strstr(s,"models/items")) {
		if(strcmp(s,"models/items/healing/medium/tris.md2")==0) {
			return (EVALUATOR)evalMediumHealth;
		} else if(strcmp(s,"models/items/healing/large/tris.md2")==0) {
			return (EVALUATOR)evalLargeHealth;
		} else if(strcmp(s,"models/items/healing/stimpack/tris.md2")==0) {
			return (EVALUATOR)evalStimpack;
		} else if(strcmp(s,"models/items/mega_h/tris.md2")==0) {
			return (EVALUATOR)evalMegaHealth;
		} else if(strcmp(s,"models/items/adrenal/tris.md2")==0) {
			return (EVALUATOR)evalAdrenaline;
		} else if(strcmp(s,"models/items/ammo/bullets/medium/tris.md2")==0) {
			return (EVALUATOR)evalBullets;
		} else if(strcmp(s,"models/items/ammo/cells/medium/tris.md2")==0) {
			return (EVALUATOR)evalCells;
		} else if(strcmp(s,"models/items/ammo/grenades/medium/tris.md2")==0) {
			return (EVALUATOR)evalGrenades;
		} else if(strcmp(s,"models/items/ammo/rockets/medium/tris.md2")==0) {
			return (EVALUATOR)evalRockets;
		} else if(strcmp(s,"models/items/ammo/shells/medium/tris.md2")==0) {
			return (EVALUATOR)evalShells;
		} else if(strcmp(s,"models/items/ammo/slugs/medium/tris.md2")==0) {
			return (EVALUATOR)evalSlugs;
		} else if(strcmp(s,"models/items/armor/body/tris.md2")==0) {
			return (EVALUATOR)evalBodyArmor;
		} else if(strcmp(s,"models/items/armor/combat/tris.md2")==0) {
			return (EVALUATOR)evalCombatArmor;
		} else if(strcmp(s,"models/items/armor/jacket/tris.md2")==0) {
			return (EVALUATOR)evalJacketArmor;
		} else if(strcmp(s,"models/items/armor/screen/tris.md2")==0) {
			return (EVALUATOR)evalPowerScreen;
		} else if(strcmp(s,"models/items/armor/shard/tris.md2")==0) {
			return (EVALUATOR)evalArmorShard;
		} else if(strcmp(s,"models/items/armor/shield/tris.md2")==0) {
			return (EVALUATOR)evalPowerSheild;
		} else if(strcmp(s,"models/items/band/tris.md2")==0) {
			return (EVALUATOR)evalBandolier;
		} else if(strcmp(s,"models/items/invulner/tris.md2")==0) {
			return (EVALUATOR)evalInvulnerability;
		} else if(strcmp(s,"models/items/pack/tris.md2")==0) {
			return (EVALUATOR)evalBackpack;
		} else if(strcmp(s,"models/items/quaddama/tris.md2")==0) {
			return (EVALUATOR)evalQuad;
		} else if(strcmp(s,"models/items/silencer/tris.md2")==0) {
			return (EVALUATOR)evalSilencer;
		}
	} else if (strstr(s,"models/weapons")) {
		if(strcmp(s,"models/weapons/g_shotg/tris.md2")==0) {
			return (EVALUATOR)evalShotgun;
		} else if(strcmp(s,"models/weapons/g_shotg2/tris.md2")==0) {
			return (EVALUATOR)evalSuperShotgun;
		} else if(strcmp(s,"models/weapons/g_machn/tris.md2")==0) {
			return (EVALUATOR)evalMachineGun;
		} else if(strcmp(s,"models/weapons/g_chain/tris.md2")==0) {
			return (EVALUATOR)evalChainGun;
		} else if(strcmp(s,"models/weapons/g_launch/tris.md2")==0) {
			return (EVALUATOR)evalGrenadeLauncher;
		} else if(strcmp(s,"models/weapons/g_rocket/tris.md2")==0) {
			return (EVALUATOR)evalRocketLauncher;
		} else if(strcmp(s,"models/weapons/g_hyperb/tris.md2")==0) {
			return (EVALUATOR)evalHyperBlaster;
		} else if(strcmp(s,"models/weapons/g_rail/tris.md2")==0) {
			return (EVALUATOR)evalRailgun;
		} else if(strcmp(s,"models/weapons/g_bfg/tris.md2")==0) {
			return (EVALUATOR)evalBFG;
		}
	}
	return (EVALUATOR)eval;
}