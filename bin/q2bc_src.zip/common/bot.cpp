/*	bot.cpp
 *	10/27/98 Ben Swartzlander
 */

#include "../common/common.h"

#define VERSION_STRING "v0.47 BUILD 67 (11/6/98)"

typedef struct {
	char *model;
	char *name;
	char *ammoname;
	int value;
	float inv_speed;
} weapon_t;

HANDLE quest_thread;
DWORD quest_thread_id;

gamestate_t gs;
vec3_t vzero={0.0,0.0,0.0};
bool hello=false;
bool teamset=false;
bool attack=false;
int move=MOVE_UNDEF;
bool jump=false;
path_t path;
int path_point;
vec3_t destination,target;
int last_time;
vec3_t last_origin;
float speed=-1;
bool evalValid[256];
EVALUATOR modelEval[256];
int last_inven_time=0;
inventory_t inventory;
int last_use_time=0;
int bad_entity_time[512];
int lastAmmo=0;
char goalName[256]="";
int runlevel=0;

static weapon_t weaponinfo[] = {
	{"models/weapons/v_blast/tris.md2", "Blaster","Blaster", 10, 1.0/100.0},
	{"models/weapons/v_shotg/tris.md2", "Shotgun","Shells", 50, 0.0},
	{"models/weapons/v_shotg2/tris.md2", "Super Shotgun","Shells", 55, 0.0},
	{"models/weapons/v_machn/tris.md2", "Machinegun","Bullets", 70, 0.0},
	{"models/weapons/v_chain/tris.md2", "Chaingun","Bullets", 80, 0.0},
	{"models/weapons/v_launch/tris.md2", "Grenade Launcher","Grenades", 20, 1.0/60.0},
	{"models/weapons/v_rocket/tris.md2", "Rocket Launcher","Rockets", 60, 1.0/55.0},
	{"models/weapons/v_hyperb/tris.md2", "HyperBlaster","Cells", 75, 1.0/100.0},
	{"models/weapons/v_rail/tris.md2", "Railgun","Slugs", 100, 0.0},
	{"models/weapons/v_bfg/tris.md2", "BFG10K","Cells", 40, 1.0/40.0},
	{NULL, NULL, 0, 0.0}
};

void print(char *s);
void ignore(char *s);

void printx(char *format, ...) {
	va_list args;
	char buffer[8192];
	int i,j;

	va_start(args, format);
	vsprintf(buffer, format, args);
	va_end(args);
	buffer[8191]='\0';
	print(buffer);
}

void printVect(vec3_t v) {
	printx("(%.2f,%.2f,%.2f)",v[0],v[1],v[2]);
}

DWORD questThread(void *);

bool botPreInit(void) {
	HANDLE hProcess;

	if(qbGetAPIVersion()!=Q2BOT_API_VERSION) {
		return false;
	}
	if(qmGetAPIVersion()!=Q2MAP_API_VERSION) {
		return false;
	}

	hProcess=GetCurrentProcess();
	SetPriorityClass(hProcess,HIGH_PRIORITY_CLASS);

	if(!qbStartup(print,print)) {
		return false;
	}
	return true;
}

bool botInit(char *hostname, unsigned short port, char *botname, char *demoname, char *quakedir, char *gamedir) {
	int i;

	qbSetPrintFunc(print);
	qbUpdateUserinfo("name",botname);
	if(demoname) {
		qbRecordDemo(demoname);
	}
	if(!qbConnect(hostname,port)) {
		return false;
	}
	runlevel=1;
	
	for(i=0;i<256;i++) {
		modelEval[i]=(EVALUATOR)eval;
		evalValid[i]=false;
	}
	printx("Bastard %s initialized\n",VERSION_STRING);

	char mapname[64];
	if(!qbGetModelString(1,mapname)) {
		printx("Error: no map\n");
		return false;
	}
	if(!qmLoadMap(quakedir,gamedir,mapname,print,print)) {
		printx("Error: could not load map\n");
		return false;
	}
	runlevel=2;

	qbBegin();

	quest_thread=CreateThread(NULL,0,(LPTHREAD_START_ROUTINE)questThread,NULL,0,&quest_thread_id);
	runlevel=3;
	if(quest_thread==NULL) {
		printx("Could not create quest thread\n");
		return false;
	}
	SetThreadPriority(quest_thread,THREAD_PRIORITY_BELOW_NORMAL);

	return true;
}

void botDie(void) {
	if(runlevel>=3) TerminateThread(quest_thread,0);
	if(runlevel>=1) qbDisconnect();
	qbShutdown();
	if(runlevel>=2) qmUnloadMap();
	runlevel=0;
}

void pickBestWeapon(void) {
	int i;
	int best=0;
	int bestvalue=0;
	int current=-1;

	for(i=0;weaponinfo[i].model;i++) {
		if(strcmp(weaponinfo[i].model,gs.player.weapon_model)==0) {
			current=i;
		}
		if(haveItem(weaponinfo[i].name) && haveItem(weaponinfo[i].ammoname)) {
			if(weaponinfo[i].value>bestvalue) {
				bestvalue=weaponinfo[i].value;
				best=i;
			}
		}
	}
	if(current==-1) {
		printx("Unknown weapon model: %s\n",gs.player.weapon_model);
		return;
	}
	i=GetTickCount()-last_use_time;
	if(i>1000) {
		if(current!=best) {
			if(weaponinfo[best].value>weaponinfo[current].value) {
				char s[81];
				sprintf(s,"use %s",weaponinfo[best].name);
				qbAsynchConsole(s);
				last_use_time+=i;
			}
		}
	}
}

void sideAdjust(vec3_t *delta) {
	int i;
	vec3_t a,b,p;
	float angle;
	float s,t;
	float yaw=yawFromVect(*delta);
	float height;

	t=sqrt((*delta)[0]*(*delta)[0]+(*delta)[1]*(*delta)[1]);
	if(t==0) {
		return;
	}
	(*delta)[0]=(*delta)[0]/t;
	(*delta)[1]=(*delta)[1]/t;

	a[0]=0.0;
	a[1]=0.0;
	p[0]=gs.player.origin[0];
	p[1]=gs.player.origin[1];
	for(i=-8;i<=8;i++) {
		angle=yaw+(float)i*(PI/32.0);
		b[0]=gs.player.origin[0]+64.0*cos(angle);
		b[1]=gs.player.origin[1]+64.0*sin(angle);
		t=0;
		for(height=-16;height<=32;height+=16) {
			p[2]=gs.player.origin[2]+height;
			b[2]=p[2];
			s=(1.0-qmTraceLine(p,b,CONTENTS_SOLID));
			if(s>t) t=s;
		}
		a[0]-=t*cos(angle);
		a[1]-=t*sin(angle);
	}

	b[0]=cos(yaw+(PI/2.0));
	b[1]=sin(yaw+(PI/2.0));
	t=a[0]*b[0]+a[1]*b[1];
	a[0]=t*b[0];
	a[1]=t*b[1];

	(*delta)[0]+=a[0];
	(*delta)[1]+=a[1];
}

int valueForModelindex(int modelindex) {
	if(!evalValid[modelindex]) {
		char model[64];
		if(qbGetModelString(modelindex,model)) {
			evalValid[modelindex]=true;
			modelEval[modelindex]=evalFunction(model);
		}
	}
	return modelEval[modelindex]();
}

float pathLength(path_t p) {
	int i;
	float length=0;
	float x1,x2,y1,y2,z1,z2;
	
	x1=p.points[0][0];
	y1=p.points[0][1];
	z1=p.points[0][2];
	for(i=1;i<p.length;i+=2) {
		x2=p.points[i][0];
		y2=p.points[i][1];
		z2=p.points[i][2];
		length+=sqrt((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1)+(z2-z1)*(z2-z1));
		x1=p.points[i+1][0];
		y1=p.points[i+1][1];
		z1=p.points[i+1][2];
		length+=sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2)+(z1-z2)*(z1-z2));
	}
	return length;
}

float timeTillHit(entity_t *object,float speed) {
	float pdx,pdy,pdz;
	float vex,vey,vez;
	float a,b,c;
	pdx=object->origin[0]-gs.player.origin[0];
	pdy=object->origin[1]-gs.player.origin[1];
	pdz=object->origin[2]-gs.player.origin[2];
	vex=object->velocity[0];
	vey=object->velocity[1];
	vez=object->velocity[2];
	a=vex*vex+vey*vey+vez*vez-speed*speed;
	b=2*(pdx*vex+pdy*vey+pdz*vez);
	c=pdx*pdx+pdy*pdy+pdz*pdz;
    return quadricRoot(a,b,c);
}

void predict(entity_t *object) {
	float inv_speed=0.0;
	float time;
	int i;

	for(i=0;weaponinfo[i].model;i++) {
		if(strcmp(weaponinfo[i].model,gs.player.weapon_model)==0) {
			inv_speed=weaponinfo[i].inv_speed;
		}
	}

    if(inv_speed>0.0) {
		time=timeTillHit(object,1/inv_speed);
	    object->origin[0]=object->origin[0]+time*object->velocity[0];
	    object->origin[1]=object->origin[1]+time*object->velocity[1];
	    object->origin[2]=object->origin[2]+time*object->velocity[2];
	}
}

void findTarget(void) {
	int i,j;
	float targ_ofs[4];
	targ_ofs[0]=0.0;
	targ_ofs[1]=-16.0;
	targ_ofs[2]=16.0;
	targ_ofs[3]=32.0;

	for(i=1;i<=gs.max_players;i++) {
		char name[64];

		if(!qbGetPlayerName(i,name)) {
			continue;
		}
		if(!name[0]) {
			continue;
		}
		if(i==gs.player_entity) {
			continue;
		}
		if(!gs.entities[i].updated) {
			continue;
		}
		if(gs.entities[i].framenum>177 && gs.entities[i].framenum<198) {
			continue;
		}

		predict(&(gs.entities[i]));

		target[0]=gs.entities[i].origin[0];
		target[1]=gs.entities[i].origin[1];
		for(j=0;j<4;j++) {
			target[2]=gs.entities[i].origin[2]+targ_ofs[j];
			if(qmTraceLine(gs.player.origin,target,CONTENTS_SOLID)>=1.0) {
				attack=true;
				return;
			}
		}
	}
}

void findItem(void) {
	int i;
	int value;
	int bestvalue=0;
	int best=-1;

	if(move==MOVE_GRAB) {
		move=MOVE_IDLE;
	}

	for(i=gs.max_players+1;i<1024;i++) {
		if(!gs.entities[i].updated) {
			continue;
		}
		value=valueForModelindex(gs.entities[i].modelindex);
		if(value==0) {
			continue;
		}
		if(distFromVect(gs.player.origin,gs.entities[i].origin)>128.0) {
			continue;
		}
		if(qmTraceLine(gs.player.origin,gs.entities[i].origin,CONTENTS_SOLID)<1.0) {
			continue;
		}
		if(value>bestvalue) {
			bestvalue=value;
			best=i;
		}
	}
	if(best>0) {
		destination[0]=gs.entities[best].origin[0];
		destination[1]=gs.entities[best].origin[1];
		destination[2]=gs.entities[best].origin[2];
		move=MOVE_GRAB;
		qbGetModelString(gs.entities[best].modelindex,goalName);
	}
}

void findQuest(void) {
	int i;
	int value;
	int bestvalue=0;
	int best=-1;
	float n;
	path_t temp;

	for(i=gs.max_players+1;i<1024;i++) {
		value=valueForModelindex(gs.entities[i].modelindex);
		if(value==0) continue;
		if(gs.entities[i].updated || qmTraceLine(gs.player.origin,gs.entities[i].origin,CONTENTS_SOLID)<1.0) {
			if(qmFindPath(gs.player.origin,gs.entities[i].origin,&temp,true)) {
				n=pathLength(temp);
				value*=exp(-0.003*n);
				if(value>bestvalue) {
					bestvalue=value;
					best=i;
				}
			}
		}
	}
	if(best>0) {
		qmFindPath(gs.player.origin,gs.entities[best].origin,&path,true);
		path_point=0;
		move=MOVE_QUEST;
		qbGetModelString(gs.entities[best].modelindex,goalName);
	}
}

void findWander(void) {
	*((int *)&(path.points[0][0]))=-1;
	qmFindPath(gs.player.origin,vzero,&path,true);
	path_point=0;
	move=MOVE_WANDER;
}

DWORD questThread(void *ptr) {

	while(1) {
		if(move==MOVE_IDLE || move==MOVE_WANDER) {
			findQuest();
		}
		if(move==MOVE_IDLE) {
			findWander();
		}
		switch(move) {
		case MOVE_IDLE:
			print("Idle\n");
			break;

		case MOVE_WANDER:
			printx("Wander: %d/%d\n",path_point,path.length-1);
			break;

		case MOVE_QUEST:
			printx("Quest: %d/%d %s\n",path_point,path.length-1,goalName+7);
			break;

		case MOVE_GRAB:
			printx("Grab: %s\n",goalName+7);
			break;
		}
		Sleep(200);
	}
	return 0;
}

void followPath(void) {
	int i;
	float n;
	vec3_t v;

	for(i=path.length-2;i>=path_point;i--) {
		n=gs.player.origin[2]-path.points[i][2];
		if(n<-16 || n>64) {
			continue;
		}
		v[0]=path.points[i][0];
		v[1]=path.points[i][1];
		v[2]=gs.player.origin[2];
		if(distFromVect(gs.player.origin,v)<24.0) {
			path_point=i+1;
			break;
		}
	}
	if(path_point==(path.length-1)) {
		move=MOVE_IDLE;
	}
	destination[0]=path.points[path_point][0];
	destination[1]=path.points[path_point][1];
	destination[2]=path.points[path_point][2];
}

void botFrame(void) {
	vec3_t angles,velocity;
	vec3_t delta;
	float vx,vy,vl;
	float botYaw,botPitch;
	int i;

	if(!teamset) {
		char s[81];
		qbGetModelString(1,s);
		if(strstr(s,"ctf")) {
			sprintf(s,"team red");
			qbSynchConsole(s);
		}
		teamset=true;
	}

	if(teamset && !hello) {
		char s[81];
		sprintf(s,"say %s",VERSION_STRING);
		qbSynchConsole(s);
		hello=true;
		move=MOVE_IDLE;
	}

	qbGetGameState(&gs);

	if(gs.player.health<=0) {
		move=MOVE_IDLE;
		jump=false;
		path_point=0;
		attack=!attack;
		qbMovementOrder(vzero,vzero,attack);
		Sleep(50);
		return;
	}

	qbGetInventory(&inventory);
	i=GetTickCount()-last_inven_time;
	if(i>5000 || (lastAmmo>0 && gs.player.ammo==0)) {
		qbAsynchConsole("inven");
		last_inven_time+=i;
	}
	lastAmmo=gs.player.ammo;

	if(speed>0) {
		i=GetTickCount()-last_time;
		if(i>0) {
			speed=0.05*(1000*distFromVect(gs.player.origin,last_origin)/i+19.0*speed);
		}
		last_time+=i;
	} else {
		last_time=GetTickCount();
		speed=400;
	}
	last_origin[0]=gs.player.origin[0];
	last_origin[1]=gs.player.origin[1];
	last_origin[2]=gs.player.origin[2];
	if(speed<10) {
		if(move==MOVE_QUEST) {
			qmMarkLinkInvalid(path.links[(path_point-1)/2]);
		}
		move=MOVE_IDLE;
		speed=-1;
	}

	pickBestWeapon();
	
	attack=false;

	findTarget();
	findItem();

	if(move==MOVE_QUEST || move==MOVE_WANDER) {
		followPath();
	}

	if(!attack) {
		target[0]=destination[0];
		target[1]=destination[1];
		target[2]=destination[2];
	}

	delta[0]=target[0]-gs.player.origin[0];
	delta[1]=target[1]-gs.player.origin[1];
	delta[2]=target[2]-gs.player.origin[2];

	botPitch=pitchFromVect(delta);
	botYaw=yawFromVect(delta);

	delta[0]=destination[0]-gs.player.origin[0];
	delta[1]=destination[1]-gs.player.origin[1];
	delta[2]=destination[2]-gs.player.origin[2];

	sideAdjust(&delta);

	vx=delta[0]*(float)cos(-botYaw)-delta[1]*(float)sin(-botYaw);
	vy=-delta[0]*(float)sin(-botYaw)-delta[1]*(float)cos(-botYaw);
	vl=sqrt(vx*vx+vy*vy);

	angles[0]=botPitch;
	angles[1]=botYaw;
	angles[2]=0;
	velocity[0]=(move>MOVE_IDLE) ? 400.0*vx/vl : 0;
	velocity[1]=(move>MOVE_IDLE) ? 400.0*vy/vl : 0;
	velocity[2]=(jump) ? 400.0 : 0;
	
	qbMovementOrder(angles,velocity,attack);
}
