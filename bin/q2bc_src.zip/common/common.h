
#ifndef __COMMON_H
#define __COMMON_H

#include <windows.h>
#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "../q2bot/q2bot.h"
#include "../q2map/q2map.h"
#include "../common/eval.h"

#define PI 3.1415926535

#define MOVE_UNDEF 0
#define MOVE_IDLE 1
#define MOVE_WANDER 2
#define MOVE_QUEST 3
#define MOVE_GRAB 4

float yawFromVect(vec3_t);
float pitchFromVect(vec3_t);
float distFromVect(vec3_t,vec3_t);
int log2(int);
float quadricRoot(float,float,float);

#endif