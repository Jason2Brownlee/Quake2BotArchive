
#include "../common/common.h"

float yawFromVect(vec3_t delta) {
	if(delta[0]==0) {
		if(delta[1]>=0) {
			return PI/2;
		} else {
			return 3*PI/2;
		}
	} else {
		if(delta[0]>=0) {
			if(delta[1]>=0) {
				return (float)atan(delta[1]/delta[0]);
			} else {
				return 2*PI+(float)atan(delta[1]/delta[0]);
			}
		} else {
			return PI+(float)atan(delta[1]/delta[0]);
		}
	}
}

float pitchFromVect(vec3_t delta) {
	float delta2;

	delta2=sqrt(delta[0]*delta[0]+delta[1]*delta[1]);
	if(delta2==0) {
		if(delta[2]>=0) {
			return PI/2;
		} else {
			return 3*PI/2;
		}
	} else {
		if(delta2>=0) {
			if(delta[2]>=0) {
				return (float)atan(delta[2]/delta2);
			} else {
				return 2*PI+(float)atan(delta[2]/delta2);
			}
		} else {
			return PI+(float)atan(delta[2]/delta2);
		}
	}
}

float distFromVect(vec3_t u,vec3_t v) {
	float x,y,z;

	x=v[0]-u[0];
	y=v[1]-u[1];
	z=v[2]-u[2];
	return (float)sqrt(x*x+y*y+z*z);
}

int log2(int n) {
	int i=-1;

	while(n) {
		i++;
		n=(n>>1);
	}
	return i;
}

float quadricRoot(float a,float b,float c) {
	float d,e,q;

	d=-b/(2*a);
    q=b*b-4*a*c;
    if(q>=0) {
		e=(float)sqrt(q)/(2*a);
    } else {
		return 0.0;
    }
	if((d+e)>0) {
		return d+e;
	} else {
		return d-e;
	}
}
