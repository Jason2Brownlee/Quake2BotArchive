
#ifndef __EVAL_H
#define __EVAL_H

typedef int (*EVALUATOR)(void);

EVALUATOR evalFunction(char *);
int eval(void);
bool haveItem(char *);

#endif