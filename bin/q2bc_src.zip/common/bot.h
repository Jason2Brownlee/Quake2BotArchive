
#ifndef __BOT_H
#define __BOT_H

bool botPreInit(void);
bool botInit(char *,unsigned short,char *,char *,char *,char *);
void botDie(void);
void botFrame(void);

#endif