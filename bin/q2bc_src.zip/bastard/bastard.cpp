/*	bastard.cpp
 *	7/19/98 Ben Swartzlander
 */

#include <conio.h>
#include "../common/common.h"
#include "../common/bot.h"

HANDLE main_thread;

void print(char *s) {
	printf("%s",s);
}

void ignore(char *s) {
	;
}

void printUsage(void) {
	fprintf(stderr,"Usage: bastard [-h hostname] [-p port] [-dir quake2_directory] [-game gamedir]\n");
	fprintf(stderr," -h\tHostname to connect to (required)\n");
	fprintf(stderr," -p\tPort to connect to (default: 27910)\n");
	fprintf(stderr," -dir\tDirectory where Quake is installed (default: c:/quake2)\n");
	fprintf(stderr," -game\tIf you are playing a modified version of Quake (optional)\n");
	fprintf(stderr,"\nExample: bastard -h satan.idsoftware.com -p 27912 -dir e:/games/quake -game ctf\n");
}

BOOL WINAPI signalHandler(DWORD code) {
	printf("Caught a signal\n");
	TerminateThread(main_thread,0);
	botDie();
	ExitProcess(0);
	return TRUE;
}

int main(int argc, char **argv) {
	int i;
	char hostname[80];
	unsigned short port=27910;
	char quakedir[80];
	char gamedir[80];
	char botname[80];

	hostname[0]='\0';
	strcpy(quakedir,"c:/quake2/");
	strcpy(gamedir,"ctf/");
	strcpy(botname,"BastardBot");

	if((argc%2)!=1) {
		printUsage();
		return 1;
	}

	for(i=1;i<argc;i++) {
		if(strcmp(argv[i],"-h")==0) {
			strcpy(hostname,argv[++i]);
		} else if(strcmp(argv[i],"-p")==0) {
			port=atoi(argv[++i]);
		} else if(strcmp(argv[i],"-dir")==0) {
			strcpy(quakedir,argv[++i]);
		} else if(strcmp(argv[i],"-game")==0) {
			strcpy(gamedir,argv[++i]);
		} else if(strcmp(argv[i],"-name")==0) {
			strcpy(botname,argv[++i]);
			i++;
		} else {
			printUsage();
			return 1;
		}
	}
	if(!hostname[0]) {
		printUsage();
		return 1;
	}
/*
	strcpy(hostname,"localhost");
	strcpy(quakedir,"d:/quake2");
*/
	if(!botPreInit()) {
		printf("Initialization error\n");
		return 1;
	}

	{
		HANDLE hProcess;
		HANDLE temp;

		hProcess=GetCurrentProcess();
		temp=GetCurrentThread();
		if(!DuplicateHandle(hProcess,temp,hProcess,&main_thread,0,TRUE,DUPLICATE_SAME_ACCESS)) {
			printf("Error: DuplicateHandle()\n");
		}
		if(!SetConsoleCtrlHandler(signalHandler,true)) {
			printf("Error: SetConsoleCtrlHandler()\n");
		}
	}

	if(!botInit(hostname,port,botname,NULL,quakedir,gamedir)) {
		printf("Initialization error\n");
		return 1;
	}

	while(!kbhit() && qbIsConnected()) {
		botFrame();
	}

	botDie();
	
	return 0;
}