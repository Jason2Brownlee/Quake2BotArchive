/*
 * util.h
 *
 * Copyright (C) 1999, Ben Swartzlander
 * This file is part of Q2BotCore.
 * For conditions of distribution and use,
 * see the accompanying README file.
 */

#ifndef __UTIL_H
#define __UTIL_H

#include "q2map.h"

#define PI 3.14159265358979323846

#define RDTSC(var) \
	_asm _emit 0x0F \
	_asm _emit 0x31 \
	_asm mov DWORD PTR var,eax \
	_asm mov DWORD PTR var+4,edx

void setPrintFuncs(PRINTFUNC,PRINTFUNC);
void print(char *,...);
void printe(char *,...);

float yawFromVect(vec3_t);
float pitchFromVect(vec3_t);
float distFromVect(vec3_t,vec3_t);
double clockFrequency(void);

void randomize(void);
unsigned short int irand(void);
unsigned long int lrand(void);

#endif