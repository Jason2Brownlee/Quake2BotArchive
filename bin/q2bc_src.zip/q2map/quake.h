/*
 * quake.h
 *
 * Copyright (C) 1999, Ben Swartzlander
 * This file is part of Q2BotCore.
 * For conditions of distribution and use,
 * see the accompanying README file.
 */

#ifndef __QUAKE_H
#define __QUAKE_H

#define IDBSPHEADER (('P'<<24)+('S'<<16)+('B'<<8)+'I')
#define IDPAKHEADER (('K'<<24)+('C'<<16)+('A'<<8)+'P')
#define BSPVERSION 38

typedef struct {
	char filename[0x38];
	long offset;
	long size;
} pakDirEntry_t;

typedef struct {
	long magic;
	long diroffset;
	long dirsize;
} pakHeader_t;

typedef struct {
	long offset,size;
} bspDirEntry_t;

typedef struct {
	long ident;
    long version;
	bspDirEntry_t entities;
	bspDirEntry_t planes;
	bspDirEntry_t vertexes;
	bspDirEntry_t vislist;
	bspDirEntry_t nodes;
	bspDirEntry_t texinfo;
	bspDirEntry_t faces;
	bspDirEntry_t lightmaps;
	bspDirEntry_t leafs;
	bspDirEntry_t leaffaces;
	bspDirEntry_t leafbrushes;
	bspDirEntry_t edges;
	bspDirEntry_t surfedges;
	bspDirEntry_t models;
	bspDirEntry_t brushes;
	bspDirEntry_t brushsides;
	bspDirEntry_t pop;
	bspDirEntry_t areas;
	bspDirEntry_t areaportals;
} bspHeader_t;

typedef struct {
	vec3_t mins, maxs;
    vec3_t origin;
    long rootnode;
    long firstface;
    long numfaces;
} model_t;

typedef struct {
	vec3_t origin;
} vertex_t;

typedef struct {
	vec3_t normal;
	float dist;
	long type;
} plane_t;

typedef struct {
	long planenum;
	long front; // negative numbers are -(leafs+1), not nodes
    long back;
	short mins[3];
	short maxs[3];
	unsigned short firstface;
	unsigned short numfaces;
} node_t;

typedef struct {
	float vecs[2][4]; // [s/t][xyz offset]
	long flags; // miptex flags + overrides
	long value; // light emission, etc
	char texture[32]; // texture name (textures/*.wal)
	long nexttexinfo; // for animations, -1 = end of chain
} texinfo_t;

typedef struct {
	unsigned short v[2];
} edge_t;

typedef struct {
	unsigned short planenum;
	short side;
	long firstedge;
	short numedges;
	short texinfo;
	char styles[4];
	long lightofs;
} face_t;

typedef struct {
	long contents; // OR of all brushes (not needed?)
	short cluster;
	short area;
	short mins[3];
	short maxs[3];
	unsigned short firstleafface;
	unsigned short numleaffaces;
	unsigned short firstleafbrush;
	unsigned short numleafbrushes;
} leaf_t;

typedef struct {
	unsigned short planenum;
	short texinfo;
} brushside_t;

typedef struct {
	long firstside;
	long numsides;
	long contents;
} brush_t;

typedef struct {
	long numclusters;
	long bitofs[8][2];
} vis_t;

typedef struct {
	long portalnum;
	long otherarea;
} areaportal_t;

typedef struct {
	long numareaportals;
	long firstareaportal;
} area_t;

#endif