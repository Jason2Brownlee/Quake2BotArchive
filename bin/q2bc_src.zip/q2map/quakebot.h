/*
 * quakebot.h
 *
 * Copyright (C) 1999, Ben Swartzlander
 * This file is part of Q2BotCore.
 * For conditions of distribution and use,
 * see the accompanying README file.
 */

#ifndef __QUAKEBOT_H
#define __QUAKEBOT_H

#include "quake.h"

typedef struct {
	long type;
    unsigned short firstlink;
    unsigned short numlinks;
    vec3_t origin;
} xface_t;

typedef struct {
	unsigned char pitch;
	unsigned char yaw;
	unsigned short key;
	unsigned int key2;
    unsigned short firstfriend;
    unsigned short numfriends;
} xedge_t;

typedef struct {
	unsigned short face;
	bool valid;
    char pad;
    vec3_t origin;
} link_t;

typedef struct {
	long face[2];
} edgeface_t;

#endif