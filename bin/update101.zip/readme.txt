++++++-------------------------------------------------------------++++++

++++++              The    C.H.A.O.S.  DEATHMATCH                  ++++++    

++++++-------------------------------------------------------------++++++

  

Version:		1.01
Authors:   		Flash  ( flash@telefragged.com )
			SPA    (   spa@telefragged.com )
			
Website:		http://chaosdm.telefragged.com
Coding:			Flash
Graphics:       	SPA
Ideas/Testing:  	again Flash & SPA
Readme.txt:		SPA
Maps:			Nat (Chaosdm2 & 3). Craig (Chaosdm1)
Distri. Date:   	Juli 11 1998
Distri. File:   	chaos10.exe (Main File)
Patch to v1.01:		update101.zip
Requ. Quake2 Version:	3.17
		
Type: Dll:      yes
      Graphics  yes (new models, console logo, etc.)
      Levels:   yes  
      Sound:    yes (whole bunch of!) 

Use:  DM:       yes (of course!!)
      CTF:      yes
      1Player:  no (Sorry, but PLEASE look at the name!)
      Co-op:    no
      

Graphic-Mode:   Tested in both 3dfx AND normal (Super)VGA


++++++-------------------------------------------------------------++++++


 This little Quake2-Addon is dedicated to every DM-Player who got tired
of all those Deathmatch-Mods that where released in the last few months
and who only knows weapons like the 'Triple-NUKE' or the 'Mega-Super-Huge-
Kill-All-Guys-In-The-Whole-Level-With-One-Single-Shot-BLASTER'.
 Ever played "PainKeep" for Quake1? MODs like this little gem are our
inspiration! Weapons that don't give you a chance to survive
longer than two seconds after your opponent got that BIG BABY do not make 
a good MOD! But integrating items into the game that make you roll 
laughing on the floor holding your stomach after using them on your 
enemy or just giving you this great "BOAH"-Effect starring with open
mouth at your screen.  Things that really make sense in the game and
you like to use them without getting unfair.
Blah, blah, blah...ok, enough foreword, let's get concrete.
      


        == INSTALLATION ==

 Very easy, indeed! Just start the chaos1_0.exe file, hit the "browse" 
button, find your Quake2 directory and let it uncompress all files
into it...your directory structure should afterwards look
something like this:

..._Quake2_
           \_BaseQ2
           |
           \_CHAOS
		

VERY IMPORTANT: 
Then copy your standard shortcut for running Quake2 into a new one and add
 
 "+set game CHAOS +set deathmatch 1 +set ctf 0 +menu_main"      for Deathmatch games
 "+set game CHAOS +set deathmatch 1 +set ctf 1 +menu_main"      for CTF games

to the command line.
Don't forget that "+menu_main", otherwise you'll see the intro from where
you currently only can exit with the tilde key (" ~ ") !!!

IMPORTANT: If you want to play CTF games you have to copy the file pak0.pak
from your Quake2 ThreeWave CTF directory into a neutral folder, rename it 
to "pak9.pak" and move it to your Chaos directory.
 You can change the game mode (DM or CTF) in game by typing 
"ctf 0" or "ctf 1" on the console and then restarting the level afterwards.


 One more special point: in your CHAOS folder you'll find 
THIS readme file again and a config file called "settings.cfg".
Edit this file if you want to remap our pre-set chaos item keystrokes 
to other keys! Important: look also that there exists a 'autoexec.cfg'
with the command 'exec settings.cfg'in it! 
Otherwise the extra keys won't work!

SPECIAL NOTE FOR GAMESPY USERS:

As far as I know some versions of Gamespy don't start Quake2 mods directly in
their game subdirectory but instead it's launching standart Q2 and afterwards
the mod. This method has one disadvantage: during switching from the
standart Quake2 gamedirectory named baseq2 to e.g. chaos Quake is copying the
config.cfg and autoexec.cfg (-the config files where all Quake2 settings and
key bindings are placed-). Problem: the chaos 'cfg' files get killed!
So PLEASE if you're using GAMESPY: after first configuring your prefered
key bindings and other settings quit back into Windows.
Then copy the config.cfg and the autoexec.cfg from chaos into the baseq2...
(..in normal Quake2-Mode you'll get afterwards probably a short message
line saying "settings.cfg not found" ...but that just doesn't matter there :)
The most important point here is that there's still a line with 
"exec settings.cfg" in the autoexec.cfg....otherwise you will wonder why you
cannot use the extra weapons!

Got it? :)

EXTRA NOTE FOR GAMESPY USERS:

After connecting to a Chaos server and seeing only a blinking cursor 
on the console background for a too long time try to type in "RECONNECT" 
+into the console!!!  :) 



        == DESCRIPTION ==

Ok, here are our goodies...hope you like them! :)

After the name of the item you can see the predefined key
AND the bind-command which you can find in the settings.cfg if you
want to remap that thing to another keystroke.
(First the single weapon and at second place the binding
 for the whole weapon group the single one is placed in!
 The 'X' stands for 'any-key' you want to use for
 this weapon.)

The extra weapons are layed over the original weapons, just press
the corresponing key twice! If you want for example get the Explosive 
SuperShotgun and you're currently using the normal SuperShotgun just
press the '3' a second time!




Let's start the show:



...first the weapons (leaving the original Quake2 ones aside)
=============================================================


 = Bastard Broadsword			'2'	bind X "use bastard sword"
							bind 2 "cmd class2"

 Our first guest here is something for everyone who always wanted to play
a little bit "Conan" in a game like Quake2: It's The Bastard Broadsword!
Your big disadvantage during using this little devil will be that you 
have to get very close to your opponent without getting killed....,
..but once you're close enough you'll be able to get most enemies with 
one single swing! So don't think of the broadsword like a kind of 
"Rambo" weapon....it's more for the thieves and sneakers under us who
like to get their unaware victims from behind! (But of course you can
also use it in a state of attempted suicide running down the hallway
towards a rocket shooter....makes the whole thing even funnier :)


 = Chainsaw					'2'	bind X "use chainsaw"
							bind 2 "cmd class2"

 Like Slade from Telefragged already said: This "will bring back 
memories of Texas chainsaw massacre." :)
 Looks like this baby will get the most extreme close combat
weapon you may have seen in a Quake2 mod till know! Just use
it like the broadsword....it's still more powerfull like the
sword, but also has some disadvantages. First you only cut
in the direction you're pointing too (and not through your
complete field of view like during swinging the broadsword).
And the second: Everyone hears when you walk around with a 
running chainsaw ("pot-pot-pot-pot" :) so it's the best you 
forget quickly your sneak'n'hide tactics!


 = Explosive SuperShotgun		'3'	bind X "use explosive super shotgun" 
							bind 3 "cmd class3"

 Not a new weapon, but a funny enhancement of an old one:
Just look out! This weapon and it's ammo is spread rare in the levels 
so use it wisely! Take the normal Shotgun-Shells and add explosive 
heads...voil�! Very usefull to burn campers out of their holes. I could 
start crying every time I see their confused faces when they realize that 
their dark hideout just started to get an exploding inferno!
 Try it! Like it!

BTW: Just a note for everyone who's wondering what has happened to the old
Shotgun. I made a little opinion poll and it looks like no one is really 
using this weapon. So due to the fact that we want to keep the whole
item and weapon selection of chaos clear and not too overloaded, we just
kicked it! Bye-bye! :)


 = Crossbow with normal arrows	'4'	bind X "use crossbow" 
							bind 4 "cmd class4"

 For those guys who want that little 'ancient' feeling in this 
high-tech game. Don't underestimate this little baby 'cause about
three shots and your unprotected enemy got nailed! Great to use in
combination with the telezoom ! Ever got those panic thoughts after 
hearing an arrow coming from nowhere crushing right above your head into
the wall?


 = Crossbow with poisoned arrows	'4'	bind X "use crossbow" 
							bind 4 "cmd class4"

 The extra kick! Making damage like the normal ones but if the opponent is
hit he also gets poisoned for about 5 seconds making him an easier 
target! 


 = Crossbow with explosive arrows	'4'	bind X "use crossbow" 
							bind 4 "cmd class4"

 Like the name already says they're arrows with nice explosive heads :)
These boys are rare....and extremly valueable! Silent and mighty,..
...the dream of every sniper! Imagine a projectile which is even more
dangerous than a rocket but flies slower and leaves no smoke trail.
I bet everyone who like shoot&hide tactics will love it! ;)


 = Airfist 					'5'	bind X "use airfist" 
							bind 5 "cmd class5"

  (Basic concept and idea by Christopher Bolin)

 The legend returns! It's back, the first passive Quake1 weapon that was 
invented ages ago! Blast players, items and everything else into the air;
lift your opponents up to the ceiling and watch them taking a free flight!
Use it to nudge them from edges or to push that Bfg into the lava your 
enemy just wanted to grab! Try the full defence potential of this weapon by 
sending grenades (even proxies) back to their master.
( A tip: try this baby on a rocket or a green bfg plasma bolt!)
 And for the most reckless of you: point the Airfist to the floor and pull
the trigger...now THIS is repulsion! (In combination with the Antigrav Belt 
a very good substitude to the Jet Pack!) 
 
 = Flash Grenade 				'G'	bind X "use flash grenades" 
							bind G "cmd grenades"

 Throw this thing into the sightline of your opponent and watch him... 
not watching you! ....'cause he doesn't see you and he doesn't see
anything else! ...'cause that's the reason why this is called
a Flash Grenade!! Got it? Another good purpose is to leave it during 
running on the floor as a little present for your chasers. Great to escape!


 = Poison Grenade 			'G'	bind X "use poison grenades" 
							bind G "cmd grenades"

 Maybe we better call them LSD-Grenades! When they explode they pump an huge
amount of poisoned spray into the surrounding air. So don't be near them 
when they detonate! Otherwise the results are fatal: the next fifteen seconds
are like having drunk a bottle green tequilla through a straw!



 = different Grenade Launchers 	'6'	bind X "use Grenade Launcher"
							bind X "use flash grenade launcher"
							bind X "use poison grenade launcher"
							bind G "cmd class6"

 I just want to note that all the grenade types above of course are also
compatible with the standart grenade launcher. This is a little hint for
all those quakers who are wondering the whole time how they can get THIS
damn grenade over THAT damn abyss to THOSE damn other quakers over
there!?!



 = Laser Grenade 				'G'	bind X "use laser grenades" 
							bind G "cmd grenades"

 Pop it onto a wall or on the floor or the ceiling or anything else. One
second later a deadly laser emits out of the Grenade straight through the 
room till it stops on another wall or door. If you'd prepare a room with
them you could see one opponent marching in and two half opponents coming
out! So don't Don't DON'T cross them! Ok?
 Tip: Make them pointing onto a closed door. That's the birthday surprise
for anyone who comes in!  ;)
 Hint: Due to the fact that they don't fit in any grenade launcher they
only can placed by hand!

BTW: Laser grenades cannot be placed on spawn-points anymore and explode
also after the first "victim-touch"...so "laser-cheaters" who only run 
around the level and place a laser on every spawn-point don't have that 
much chances to get any "free frags" anymore! :)


 = Living Proximity Mine (Launcher)	'G'   
						bind X "use proximity grenade launcher" 
							bind G "cmd class6"
						'P' to deactivate/activate
							bind P "togglegrenades"

 NO, these guys aren't the proxy grenades everyone knows! Leave them 
somewhere you know your enemies will hang around soon! So if they see
an opponent they won't just explode, they'll CHASE 'em and explode 
afterwards if they're near enough. If he not just WALKS but RUNS away,
he might be able to escape this devilish smily. And don't forget where
you droped them. They won't hunt their master...but maybe they explode
near you! 

 A special: You can switch your proxis on and of by hitting the 'P' or
typing "toggleproxi" on the console. Try to prepare a room with a whole 
bunch of them in 'deactivated' mode and activate them after you watch 
someone running into your trap! (Very funny to hear 10 "Yieppes" in
combination with one scream of surprise and panic  :)
 Another tip: They now also try to kill enemy turrets! Very nice if that
damn enemy base is guarded by two of them and you only have your blaster
left....and some proxies!! :) Yeah...watch to let 'em have it!!


 NEW: Beware!...the proxies are now THAT dangerous that they sometimes
have a short-circuit and start to also go after their master!!! 


 = Guided Missile Launcher 	'7'	bind X "use homing missile launcher" 
						bind 7 "cmd class7"

 It's some kind of extra ammo for the normal Rocket Launcher easily 
recognizeable by the blue shining stripes. Just added a heat seaking 
rocket head for extra fun! Very good if you want to play flak against
those Jet Pack users!


(Now a short break: everyone who has already played Version 0.3 of
Chaos will maybe miss something at this place! Yep...the Flummyblaster
has gone for a while! Due to the fact that we wanted to make the
so called "Flummylagger" more internet friendly it also got more and 
more equal to the Hyperblaster....but it will return...in a re-designed
way and maybe as a complete new weapon....just wait and see!  :)

 


 = Buzz Saw				'9'	bind X "use buzzsaw" 
						bind 9 "cmd class9"

 Did you ever see this scene in 'Gremlins' where poor Billy meets the 
flying buzzsaw blades? (Wide grin) That's a typical 'Want-To-Have-In-
My-Favourite-Game'! And here it is: the famous Buzz Saw Gun! The best
is that the blades are reflected from walls and doors. But NOT from
other players! They will go straight through them leaving them pretty
confused about this funny sound they heard before saying goddbye. 
So what have we learned? BEWARE of standing in little rooms seeing 
the opponent down the hallway with a buzzsaw in his hands!


 = The Gravity Vortex		'0'	bind X "use gravity vortex"
						bind 0 "cmd class0"

 Now we're coming into the part of "ancient weapons with unrevealed and
unimagineable powers": Here's our new favourite sucker (you can take 
that literally :) These two rings look a kind of unspectacular at first
sight....BUT!! Hmmm...let it tell me this way: throw it and RUN!!!
Two seconds after hitting ground the first time this devil will start
to "vacuum" and compress his whole surroundings into ONE point...
...items, weapons, PLAYERS!! (Anyone who has seen "The Arrival" knows
what I mean) So try the next 15 seconds to stay out of its way!
(That's about 100 feet distance :)


 = The Automatic Sentry Turrets

					'0'	bind X "use automatic defense turret"
					'0'	bind X "use automatic rocket turret"
						bind 0 "cmd class0"

 Here are our second "Helper from Hell": the cute 
Automatic Sentry Turrets! There are two different versions available: 
the Automatic Defense Turret which uses two nice hyperblaster-generators 
and the Automatic Rocket Turret, shooting nasty triple mini-rockets. 
 Both are very rare to find but if you have one of them you are the lucky 
one ....they are ideal e.g. for guarding your base in CTF and they shoot
till they got killed or their ammo is empty ....
BTW: Watch out that you don't accidently hit 'em with a weapon...in this
case their emergency sub-routine will start and fire at their attacker
(..who is you!! :) Got it?
Also a nice feature: they love to hunt enemy Proxy Grenades!� :) 
But beware: due to the fact that Proxy grenades also attack Turrets a
whole bunch of them is the ideal "Anti-Turret-Weapon"!!



..and now the extra items:
==========================



 = Jet Pack			'J'	bind j "use jetpack"

 Now Quakers can get airborne! Pressing the key (e.g. 'J') will 
activate/deactivate this rocket belt. Navigation works like swiming
under water: you fly in the direction where you're looking. 
By the way: water! Not good! Really not good! Don't try out what's
happening when your jet propulsions are getting filled with water!...
....ok, try it, but don't complain afterwards that I haven't warned you!
Just one more thing: if your health drops beneath zero while flying this
thing the fuel tank on your back will ingnite! So to all those Railgun-
Lovers out there: let's perform a little trap-shooting with 
great fireworks!


 = Tech Powerups		'D' to drop it	(bind d "drop tech")

 There are four different Powerups in one level! Each one exists only one
time and you also can carry only one at the same time. They are:
 - the Power Amplifier, which doubles your attack power.
 - the Disruptor Shield, which increases your resistance to enemy attacks.
 - the Time Accelerator. It greatly increases the speed of your weapons.
 - the Auto Doc. This tech pushes your health up to 150 and then 
   regenerates it constantly.
The tech you actually wear can easily be droped by pressind the 'd' key
or typing "drop tech" into the console, but once thown away, the same tech
cannot be taken at once again! 


 = Invisiblity

 Another new feature: we added a new kind of power-up: In addition to 
the Quad Damadge and the Invulnerablility now comes the Invisibility! 
Once found and taken, you get .....invisible! :)
 The only thing that gives away your position is a slight flicker in the
air and some static sounds every few seconds....the whole thing lasts
for about thirty seconds!
Very funny seeing a point on your radar but no one in front of you and 
suddenly a rocket evolves out of the air some feet right in front of 
your face!� :)


 = Grappling Hook		'END'		bind END +hook
							// hook on/off toggle
				'PAGE DOWN' 	bind PGDN +grow
						      // for sliding down the chain
				'PAGE UP'	bind PGUP +shrink
							// for climbing up the chain

 Here it is, the ultimate grappler. We now integrated that you have to 
pick up this nice tool before you can use it.
 Once you have it you need three keys to navigate with this baby.
First, there is your shoot key (in our example 'end'). Point at a wall or
something equal, press this key and watch your hook flying! If you keep
pressing the grappling hook will instantly pull you up. Good for getting
fast out of dangerous areas (e.g. floors filled with lava or just lead).
Pressing again will release you into freedom. (Think twice about this
freedom if you are hanging fourty feet above the ground!!) 
The other two keys (for example 'page up' & 'page down') are used to
release/roll up the cable. So you can navigate up and down the rope once
you are hanging there. Or just stand on an edge, hit the hook in the
ground, release the cable a little bit and then step over the corner!
Great for a little bungee jumping! Or swing around and play Tarzan, 
or, or, or... (this thing is very flexible!)
Tip: If you're out of weapons, use the grappling hook on your enemies.
     These things are pretty sharp!

 						
 = Tele Zoom			'Z'		bind z "zoom 1"
								// to zoom in
					'X'		bind x "zoom 0"
								// the 'BOZZ' key

 Now to something the snipers of you will love: Zoom Binoculars that works
in three steps. Just press the zoom key (e.g. 'Z') to get nearer into
the action! After pressing the third time you should have a size about 1:10.
The other key (e.g. 'X', let's call him the 'Boss' key)(good old Larry)
is to get immidiately back into the 'real' sight! Good if you're geting
under surprise fire and don't want to look like someone who got those
damn binos pined onto his head! ("Where is he? Where is he? WHERE AM I??")
  Tip: Use this together with the Railgun, or even better ('cause of the
flair) with the crossbow! (Explosive arrows and the Telezoom are nice!!!:)


 = Flashlight			'F'		bind f "cmd flashlight"

 Light up those dark areas some campers could hide waiting for you! This
is also your primary survivig tool if the 'lights-off' mode is activated!
But beware!! The others can probably figure out your position after seeing
your light cone, so use it with caution!
   

 = Antigrav Belt			'B'		bind b "cmd belt"
   (the idea was brought to us by Matt Ouimette)

 This helpfull device creates an antigrav field around your lower half
that let you jump up about three times the normal height and prevents
you from drill yourself into earth after you just crossed THAT edge!
(Hmm? What edge? WHAT abyss?? Wha....AAAAAAAaaaaaaarghSPLISH!!
 That hadn't happen with the Antigrav Belt(tm) )
By the way: this thing also swallows one cell all 2 seconds. So don't jump
from the skyscraper before checking if there are enough of them 
remaining!
 Additional hint: this nice tool can get very dangerous in the case you
are standing next to an active gravity vortex. Because of the minimal
grip your feet now have it'll suck you three times easier! So beware! :)


 = Scanner			'S'		bind s "cmd scanner"

 ...to get this extra 'Aliens' feeling. Just pressing e.g. 'S' reveals
a radar in the right corner. If there's someone near you can see his 
signature projected via this H.U.D. onto your screen in his relative
position towards you. (Above the middle of the radar center means BEFORE
you, and so on). Additinal a little white circle means that the other guy is 
on the same level as you. (So if there's a round point slight underneath
your radar center he might stand right behind you!) If your enemy is
standing higher than you, the points color changes to blue, is he lower
then it will become red! 
A little warning: the scanner consumes about 1 cells per 2 seconds to run, 
so don't wonder if you stand in a bunch of enemies finding out that 
your BFG is nonfunctional 'cause you forgot to turn of this thing!
To give your prey a fair chance the scanner emits now an motion tracker
like sound which also reminds you that it's still eating up your cells!
(Underwater you can hear a nice sonar instead :)
 Note:  Due to an quake internal problem the main menu can't be
opened while the scanner is turned on. Just if you already started 
wondering why these guys don't let you out of the game.
      (THAT's a feature for Quake3! NO exit button!)	 

ANOTHER NOTE: Remember the last four items (Zoom, Flashlight,
============  Antigrav Belt & Scanner) are ALWAYS in your inventory. 
	      You don't have to pick them up to use them. They're 
	      right there from the start! 



...and the additional features:
===============================


 = The Faked Death		'A'		bind a "cmd fakedeath"

 Ok, now imagine being pursued by a mad railgun shooter who will 
probably kill you with his next hit! How about acting like dead
at his next narrow shoot? Just press the 'A' key and your player
will go down with a heart-rending scream and look like dead and
you can wait till the other one's gone away.
But if he's one of those people who immidiately tries to "dispose"
his dead opponents with an additional shoot he'll start to wonder
why this damn corpse still cries!? It's also bad luck if your
heart beat's too loud or you just have to sneeze so the others
can hear you....hmmm... time to press 'A' again and keep running!
Tip: If you're climbing around with your grapple and you're using
     this, don't forget to release the hook! Otherwise it look's 
     some kind of funny...a swinging corpse in mid-air! :)
Another hint: It's only human that sometimes a player cannot
     act like a professional actor in the middle of a hot and
     strenuous battle...so don't wonder if they sometimes
     exaggerate their death a little bit (...like a bad 
     Shakespeare actor :)


 = The Personal Teleporter	'O'		bind o "cmd teleport"

This is a custom teleporter field that can be placed anywhere by hiting
the 'o' key (uses up 100 cells) Once placed and you hit 'o' a second
time again you'll be teleported back to that place! Very nice if you want
to get quick out of trouble! 
BTW: CTF players beware! You can only teleport yourself, NOT the flag!
     It just will be dropped at the place you start your back-teleport.


 = The 'Kick' Function		'Insert'    bind kp_ins "cmd kick"

 You now can kick EVERYTHING with your feet around...ammo, gibs, dead bodies,
opponents, ...even rockets which fly past you!  :)  Just place yourself near
enough to the object you want to kick and hit the 'Insert' key (...the one
on the numpad!). Very nice taking pleasure in kicking an opponent who just
faked death into a nearby lava lake :) 
 (or e.g. two CTF-teammates who got bored during guarding their flag 
can start a little soccer game with the skulls of their former enemies :)


 = The Manual Vomit  		'V'		bind v "throwup"

 For those people who can't get enough of the poison grenade:
Just press THIS key (e.g. 'V') and enjoy!        ;) 
New feature: your stomach has to refill itself! You can then 're-vomit'
after something about 3 seconds :)


 = The Kamikaze Mode		'K'		bind k "cmd kamikaze"

 If you've 10 packs of explosive ammo types (e.g. 6 rockets and 4 grenades)
and you prefer to make suicide instead of giving the other one a frag point
you can change into the kamiaze mode...and maybe can take some enemies 
with you!.....your screen wents flashing red and a timer counts down 
from 5 to zero....and together with a loud "BANZAIIIII" you blow up
....and I recommend everyone not to be near you in this moment ( because
it's VERY unhealthy ;)


 = "Normal Life Sounds": 

 We're just in the proccess of adding sounds from everyday life into Chaos
for the general amusement...or didn't you ever miss the feeling of
having to sneeze right in the moment you sneak up from behind at an enemy?
They'll be played randomly, so wait and let yourself surprise!
(If you've any good wav that could also fit in here in our 
 "everyday life section" then please tell me at spa@telefragged.com...
 the five best entries will be added! :)


 = "Hear your Heartbeat!":

 Yep! For the extra thrill you can now hear when your health has fallen
rapidly. If it drops below 40 you can hear your heart beating and as
smaller the amount of the health gets as faster it'll beat!
(...and suddenly, it won't beat at all :)
 Also very funny and usefull: as an opponent you can hear the other one
if you are just standing near enough to him :)



      ==  Havoc Bot v0.1 beta  ==
      ===========================

 The Havoc Bot is a totally new bot written from scratch.
It is NOT based on a source release of an other bot.
I have not had the time to finish the bots node table system for
Chaos DM v1.0. Especially the ladder movement is still missing.
For this reason most parts of the node-table roaming system have been
temporary deactivated for this release. (So don't wonder if they do silly 
things in complex levels) I'm going to release updated versions of the 
bot shortly after the release of Chaos DM v1.0. The missing ladder 
movement is only a matter of one or two days work but
we have not had enough time to finish it for v1.0.

"sv addbots <amount> <skill> <team> <name> <model/skin>"

	is used to add bots to the game. All arguments are optional use just 
	"sv addbots 5" for example to add 5 standard bots or "sv addbots 4 4 1"
	to add 5 level 4 bots to team 1.

"sv killbot <name>"

	is used to disconnect the bot <name> from the game. 
	Use "sv killbot all" to disconnect all bots.

"join_team <team_number>"

	is used to join a certain bot team.
	Team "0" means neutral. Players are in team 0 on startup.

 You can easily write up nice bot config files by building little bot.cfg
files that can be executed in the console. 
Have a lock into b4.cfg as an example for a bot configuration.
Use "exec b4.cfg" to execute a certain bot config in-game.

PLEASE CONSIDER THE HAVOC_BOTS IN CHAIOS DM v1.0 AS A SNEAK PREVIEW!!!



	== The COMPLETE BINDING LIST ==

 ..ok, for all who want to remodificate our whole mod or only want to
have an overview over all the commands: here's our summary:
(Again first the single weapon and at second place the binding
 for the whole weapon group the single one is placed in!
 The 'X' stands for any extra key you want to use for
 this weapon.)
 
 = Bastard Broadsword		'2'	bind X "use bastard sword"
						bind 2 "cmd class2"
 = Chainsaw				'2'	bind X "use chainsaw"
						bind 2 "cmd class2"
 = Explosive SuperShotgun	'3'	bind X "use explosive super shotgun" 
						bind 3 "cmd class3"
 = Crossbow 			'4'	bind X "use crossbow" 
						bind 4 "cmd class4"
 = Airfist 				'5'	bind X "use airfist" 
						bind 5 "cmd class5"
 = Flash Grenade 			'G'	bind X "use flash grenades" 
						bind G "cmd grenades"
 = Laser Grenade 			'G'	bind X "use laser grenades" 
						bind G "cmd grenades"
 = Poison Grenade 		'G'	bind X "use poison grenades" 
						bind G "cmd grenades"
					'P' to deactivate/activate
						bind P "togglegrenades"
 = Flash Grenade Launcher 	'6'	bind X "use flash grenade launcher"
						bind G "cmd class6"
 = Poison Grenade Launcher 	'6'	bind X "use poison grenade launcher"
						bind G "cmd class6"
 = Proximity Grenade Launcher '6'	bind X "use proximity grenade launcher" 
						bind G "cmd class6"
 = Guided Missile Launcher 	'7'	bind X "use homing missile launcher" 
						bind 7 "cmd class7"
 = Buzz Saw				'9'	bind X "use buzzsaw" 
						bind 9 "cmd class9"
 = The Gravity Vortex		'0'	bind X "use gravity vortex"
						bind 0 "cmd class0"
 = The Automatic Sentry Turrets

					'0'	bind X "use automatic defense turret"
					'0'	bind X "use automatic rocket turret"
						bind 0 "cmd class0"
 = Grappling Hook			'END'	
						bind END +hook
						// hook on/off toggle
					'PAGE DOWN' 
						bind PGDN +grow
						// for sliding down the chain
					'PAGE UP'	
						bind PGUP +shrink
						// for climbing up the chain
 = Tele Zoom			'Z'	bind z "zoom 1"
						// to zoom in
					'X'	bind x "zoom 0"
						// the 'BOZZ' key
 = Flashlight			'F'	bind f "cmd flashlight"
 = Antigrav Belt			'B'	bind b "cmd belt"
 = Scanner				'S'	bind s "cmd scanner"
 = The Faked Death		'A'	bind a "cmd fakedeath"
 = Jet Pack				'J'	bind j "use jetpack"
 = Tech Powerups			'D' to drop it	
						bind d "drop tech"
 = The 'Kick' Function		'KP_INS'    
						bind ins "cmd kick"
 = The Manual Vomit  		'V'	bind v "throwup"
 = The Personal Teleporter	'O'	bind o "cmd teleport"
 = The Kamikaze Mode		'K'	bind k "cmd kamikaze"
   
					


... and now something every Quake2 player and server administrator
out there has been waiting for:



	== The CHAOS DEATHMATCH COMMAND CONFIGURATION FILE ==


 You can find it in the root of the CHAOS directory,
named "SETTINGS.CFG". 

This file only works if you have the line "exec settings.cfg" in the
autoexec.cfg of the Chaos directory!

ATTENTION!!:  The whole Chaos-configuration now works with console 
commands! So you don't have to quit Quake2 anymore to e.g. ban a
certain item or want a new startup weapon! Just type the command
you have seen in the 'setting.cfg' directly into the console
(e.g. "set lightsoff 1") and restart the level! That's all! :)

Ok, it contains the following things:

 - all bindings of the Chaos weapons and items...can be changed e.g.
   if you want to place your favourite feature on a different key!

 - the weapon and item banning/startup giving: great to construct
   your own game mode (e.g. I want only explosive weapons but 
   everyone should have the rocket launcher right from the start!
   No problem!)
   More info about this directly in the "settings.cfg" file! Just
   open it with any editor. But PLEASE make a backup copy from
   the original one before you start to mix it up!!!  :)
	
- the Chaos Deathmatch Server Settings

  "set maxclients X": Here you can change the max. numbers of players
  who can join your server game! 
 
  "set poisontime X" and "set blindtime X": Because of the many requests
  we offer here an option to alterate the duration of the poisoning/blinding
  effect of the poison/flash grenades....the number describes the time
  of the duration in seconds!

  "set lightsoff X":
 This simple line of letters provides a full new type of quake gaming!
Just imagine to blast out the fuses in the whole level only leaving
the slight glow of the items, water, lava and sunsets. Welcome to
your 'darkest' nightmare. In this mode of playing, hearing ist essential
and making noice is deadly! Your only friend will be your flashlight
("f" to toggle), but beware! Friends can also become traitors. So use
it wisely, or your light cone might reveal your position.
The settings are: 0 	for normal light mode
			1 	for more dawn-like light conditions
			2	for complete darkness


	


	== CHAOS DEATHMATCH CAPTURE THE FLAG ==

 To get some additional information about playing CTF within Chaos please
read the "chaosctf.txt" which is also in the same directory as this
readme file!

   

	== KNOWN BUGS ==

After first using this Mod, you've to reinstall Win'95 and Quake2,
but then, it should run smooth (if you oversee those systemcrashes
all five minutes)!!!!!!!   ......
:-)   little joke...hope your Windows still lives!

Bugs?? Don't know no bugs! 

So if you should find a bug yourself we aren't aware of or anything else 
or just have some sort of 'wishes':
Don't get shy, we two don't bite (yet) and we would like to hear
ANY comments and suggestions for the further 'evolution' of this MOD!
In other words: PLEASE WRITE US!!!
						spa
			
			...by the way: if you've any remarks or just found
			some language mistakes, please write to 
			spa@telefragged.com 
			('cause my english is not the best one!)


	== ADDITIONAL CREDITS ==

+ Thanks to Perecli Manole for releasing the code for his swinging grappling hook.
  It has helped us a lot with coding our grapple.
  You can find his website at: http://phook.symix.com/hook
+ Also thanx to the Painkeep guys!! (http://www.planetquake.com/skins/painkeep)
  Especially to Christopher Bolin for the basic concept and idea
  of the airfist! A great thing!! (http://www.planetquake.com/skins/airfist)
+ Additional thanx to the guys from the Shot Just Once Development Team!
  (http://www.telefragged.com/sjo) Their first fantastic sound pack inspired me
  half a year ago to start to remix the Quake2 wav files on my own,... and still
  2 or 3 wavs from Chaos are based on theirs!
+ And thanks to the tutorial authors at Qdevels. Your tutorials have helped us
  with creating our Jetpack and Scanner.
+ ...and to all those guys out there in the net who sent us their suggestions
  and oppinions about Chaos!!!

--------------------------------------------------------------------------
SPA    ( spa@telefragged.com )
Flash  ( flash@telefragged.com )