***************************************************
	File	: Q2DMB1.ZIP
	Author	: Taufik Purnomosidi
	Version	: 1.0
	Editor	: Quark 4.07

	Completion Date: March 26, 1998
***************************************************

Instruction:
- Unzip q2dmb1.bsp into \quake2\baseq2\maps.
- If you have Eraser bot, then unzip the q2dmb1_rt.zip to Eraser's
  route directory.
- That's all!

More info about my other levels: members.tripod.com/~TaufikP

Comments, suggestions: taufikp@hotmail.com