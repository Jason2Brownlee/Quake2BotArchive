#ifndef FRED_H
#define FRED_H


int Traces = 0;




#endif