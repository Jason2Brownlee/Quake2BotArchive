
qboolean CheckUserPass(char *PW  ,char *user);
qboolean CheckPassExists(edict_t *ent, char *value);
qboolean CheckUserExists(char *PW  ,char *user);