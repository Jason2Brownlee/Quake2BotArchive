ErrorUltra v0.40s
by Paul Tanner
Actually all the work was done by AnthonyJ


Title			: ErrorUltra
Author			: Paul Tanner  (SubCog@yahoo.com)
Homepage		: www.Geocities.com/SubCog

Description		: Cool fastpaced deathmatch mod for Quake2

Additonal Credits to	: everyone who helped with the code and stuff, especially
			  idsoftware

			  AnthonyJ
		
			  For full credits, read the Readme in the Docs folder



Description:
	ErrorUltra is designed to balance some of the fundamental gameplay issues of id software's Quake2 deathmatch while still retaining the exceptional feel of the game.  ErrorUltra maintains the "grab and go" weapon pickups, while eliminating the worthless starting weapon and replacing it with a weapon that gives the player a fighting chance.  

	ErrorUltra is pretty much the cheapest mod ever, as I ripped off (with permission) all the code from AnthonyJ's EraserUltra.  Actually, it really is EraserUltra (a special unreleased version, not the same as the one available on AnthonyJ's website), and all I did was make my own config file for it.  However, AnthonyJ was kind enough to compile a special version of EraserUltra for me with one additional feature:  The option to change the time it takes for weapons and ammo to respawn.  So really ErrorUltra is a special, previously unreleased version of EraserUltra, with the config that I wrote.

	Oh yeah, EraserUltra is based on the EraserBot which is a mod for Quake2 bla bla bla.  So you can see, the lineage for ErrorUltra is a long line of distinguished royalty.




GamePlay:
	Basic ErrorUltra Deathmatch plays like this:  You spawn with two guns,  the small machinegun and the small shotgun.  Both are relatively weak, but will offer a real fighting chance in the game from the first moment you spawn.  Then, you run around fighting and looking for bigger weapons to fight even better.




Installation: 
	Unzip files with folder pathnames to your Quake2 directory.

Running the Game:
	You can start it with the command lines, but I also included a few batch files that will end up right in your quake2 directory.  These include ErrorDM, ErrorCTF, and ErrorSmasher.




Features:
	Um...  ErrorUltra has all the features that EraserUltra .40 has, so check the docs folder for the readme file and the eraser files there.  

Plus, you can change how long it takes for weapons and ammo to respawn!  Here's the lines.

set item_respawn x
set weapon_respawn x

(x is the number of seconds before it respawns)

ErrorSmasher has a cool smasher I made (actually its just the bfg model), and so everyone starts with a melee weapon.

To get ErrorCTF to work, make sure you put the ctf pak file into the ErrorUltra directory.




LEGAL BIT (ripped from the EraserUltra readme)

   Ridah asks that the following statement be included in the
   docs of any modified version of Eraser. Fine. :-)

	--- BEGIN ---

	The Eraser Bot is a product of Ryan Feltrin, and is available from
	the Eraser Bot homepage, at http://impact.frag.com.

	This program is a modification of the Eraser Bot, and is therefore
	in NO WAY supported by Ryan Feltrin.

	This program MUST NOT be sold in ANY form. If you have paid for 
	this product, you should contact Ryan Feltrin immediately, via
	the Eraser Bot homepage.

	--- END ---

Umm...  Contact me if for some reason you want me to add something to this document or whatever.  Here's my email address:  SubCog@yahoo.com
	