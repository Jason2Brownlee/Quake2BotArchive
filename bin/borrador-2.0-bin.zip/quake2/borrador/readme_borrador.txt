BorrAdor BoT 2.0 is a modification of the Eraser Bot, by Siro (smateosd@nexo.es), aka BJAM.

The Eraser Bot was written by Ryan Feltrin. Please refer to the original documentation "readme_eraser.txt".

You can use BorrAdor directly from this very basic distribution (it will create dinamically route files and so on, but there are some models missing), but the best choice is to use the Eraser distribution route files and models. After installing Eraser, extract the BorrAdor-2.0-bin.zip and move the "borrador" directory into the quake2 one. Copy the "routes" directory from the "eraser" directory into "borrador". Note that to start BorrAdor you should use "+game borrador" instead of using "+game eraser" in the command line (for example: "C:\quake2\quake2.exe +game borrador +map q2dm1 +bot_num 5"). 

In this second -and "definitive"- release 2.0 I have made many important improvements to BorrAdor 1.0:
 * New code for strafing rockets and grenades made generic, so bots now can also strafe laser bolts and crouch, based on CombatSkills settings. This make the game more difficult.
 * Improvements made on jumps, so bots are less prone to do "back flip into the lava". They also fight to leave such a lamentable situation jumping, screaming, shooting... really dramatic.
 * Now proyectile speed is relative to the shooter, for rockets, grenades and blasters. I think this can improve the gaming experience with some falcon-like high-speed-falling rocket shoots.
 * Fixed a compiler bug with random numbers and optimizations.
 * More little changes/fixes, like taunting, "human-like" react time...

This is the list of most of the improvements and fixes on Eraser made for BorrAdor 1.0:
 * Fixed a bug that crashed Eraser when rocket explosions reached many people (in fact, BorrAdor hasn't crashed any more under WinNT).
 * Better ammo collection.
 * High precision (nearly state-of-the-art :-)) grenade launching.
 * More complex aiming method, now depends on relative speeds.
 * Now Aggressiveness and CombatSkills settings are more important in bots' behaviour.
 * Now skill setting is less important.
 * Most of the weapons has been modified, for better and more spectacular fun (now Quad is "really Quad").
 * Now weapons are nearly equal for bots and for humans.
 * A ton of little changes ("better" button handling, source code formatted with GNU indent...).

Have fun, and remember: you are the human...
