___________________________________________________________________
�������������������������������������������������������������������
/* Damage Skins                                 Copyright � EAVY */
___________________________________________________________________
�������������������������������������������������������������������
title    : Damage Skins          author   : Stefan ``EAVY'' Schwarz
filename : dmgskins_cl.zip       homepage : www.planetquake.com/ce/
version  : 1.2                   email    : eavy@planetquake.com
date     : 98/07/24              uin      : 1947083
�������������������������������������������������������������������
Code Exchange #1 ``Damage Skins'' (C) EAVY * www.planetquake.com/ce
___________________________________________________________________

Special Credits
~~~~~~~~~~~~~~~
id Software (Quake2)
	http://www.idsoftware.com/
Rowan 'Sumaleth' Crawford (Crackwhore Skin Pack)
	sumaleth@frag.com, http://impact.frag.com/
grimlock@one.net.au (Cyborg CTF Skins)
Matt Ownby (inspiration to make code more portable)
	bop@planetquake.com, http://www.planetquake.com/bop/
Jacob Navia (LCC-Win32)
	jacob@jacob.remcomp.fr, http://www.cs.virginia.edu/~lcc-win32/

Client Info
~~~~~~~~~~~
You don't have to fully understand how it works, the only thing
that you should know is that your appearance will change when
your health reaches a critical value (by default it's 25 Health,
then your health display turns red, so it's the proper time to
apply the damage skin); if the server doesn't enforce a change,
your normal skin will be the one you selected in Player Setup.
Your damage skin is usually defined within the server-side list
of models, but in case it's not, it will default to "pain" if
the normal skin is named "skin", otherwise your skin won't change
at all. If allowed to, you can override the server settings by
creating a userinfo "pain" cvar: At the console, type this...

/set pain dmgskins u
/set pain <damage_skin_name>

The first command defines the "pain" info, the second one sends
your damage skin to the server, so it will be able to use it...

Intellectual Property Notice and Legal Disclaimers 
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
This software is being provided by the copyright holders under
the following license. By obtaining, using and/or copying this
software, you agree that you have read, understood, and will
comply with the following terms and conditions:

Permission to use, copy, modify, and distribute this software and
its documentation for any purpose and without fee or royalty is
hereby granted, provided that you include the following on ALL
copies of the software and documentation or portions thereof,
including modifications, that you make:

1. A link or URL to the original ce source.
2. Any pre-existing intellectual property disclaimers.
   Also a notice of the form:
   "Copyright � EAVY - All Rights Reserved!"
3. When space permits, inclusion of the full text of this NOTICE
   should be provided. In addition, credit shall be attributed
   to the copyright holders for any software, documents, or
   other items or products that you create pursuant to the
   implementation of the contents of this document, or any
   portion thereof.

THIS SOFTWARE AND DOCUMENTATION IS PROVIDED "AS IS," AND COPYRIGHT
HOLDERS MAKE NO REPRESENTATIONS OR WARRANTIES, EXPRESS OR IMPLIED,
INCLUDING BUT NOT LIMITED TO, WARRANTIES OF MERCHANTABILITY OR
FITNESS FOR ANY PARTICULAR PURPOSE OR THAT THE USE OF THE SOFTWARE
OR DOCUMENTATION WILL NOT INFRINGE ANY THIRD PARTY PATENTS,
COPYRIGHTS, TRADEMARKS OR OTHER RIGHTS.

COPYRIGHT HOLDERS WILL NOT BE LIABLE FOR ANY DIRECT, INDIRECT,
SPECIAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF ANY USE OF THE
SOFTWARE OR DOCUMENTATION.

The name and trademarks of copyright holders may NOT be used in
advertising or publicity pertaining to the software without
specific, written prior permission. Title to copyright in
this software and any associated documentation will at
all times remain with copyright holders.

NOTE: My own code is marked with the "Damage Skins" headers and
footers; other code is probably property of id Software and
governed by their own license! The Player Pack File contains
additional material owned by id Software and other individuals;
it can only be distributed free of charge over the Internet -
you'll have to get specific written permission by all the owners
to be able to distribute it in any other way! The most recent
official versions of code and pack will be available at my site!

Enjoy yourself,
 -- Eavy
mailto:eavy@planetquake.com
http://www.planetquake.com/ce/dmgskins.html
