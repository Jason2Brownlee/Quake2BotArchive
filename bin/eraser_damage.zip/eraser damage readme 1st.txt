This archive contains the Win32 and Linux files for the combined Eraser Bot and Damage Skins.  The
Eraser Bot home page is at impact.frag.com.  The Damage Skins home page is at www.planetquake.com/ce/

The Eraser Bot version that has been incorporated into this release is 0.992 dated 6/18/98 written by Ridah (ridah@frag.com)

The Damage Skins version incorporated is 1.2 dated 7/24/98 written by EAVY (eavy@planetquake.com)

The person that put these two together on 7/29/98 is Rastaf (rastaf@cybernet.com)


There is a wonderful page that describes how to setup the Eraser Bot, and the commands
to use this Mod.  It was written by the Eraser Bot author himself, Ryan Feltrin.  Check
it out at http://www.telefragged.com/epidemic/guides/ebgide.html


Before you extract these files, you have to have done the following:

1)  Have Quake2 patched up to 3.14 or higher.
2)  Setup the Eraser Bot from http://impact.frag.com
3)  Verify that the .pak files in this archive will *not* overwrite one you already have.  If
it will, then just rename one of 'em with a different number.  Quake2 does not care, and they can
even be out of sequence.
4)  If you are running Linux, make sure to strip out the ^M characters
in the eraser/dmgskins.lst file!

Once these are done, then extract the rest of these files to your c:\quake2 directory.  Startup
a game with the command line "c:\quake2\quake2.exe +set game eraser +set deathmatch 1 +map base1".  Once the
game has started, spawn a few bots with the console command "bot_num 5".  They will automatically
zadjust to your skill level after a few minutes.  Lots more info on the bot commands can be found
at http://www.telefragged.com/epidemic/guides/ebgide.html (as mentioned previously).  You can
change the health level that the Damage skins/bleeding happens at from 25 (default) to anything
you want with the console command "dmgskins #", as in "dmgskins 50"

We love the Eraser Bot, Ryan!  Keep it comin'.

Oh yea, don't contact EAVY or Ridah about this mod.  They are busy doing other things, so leave
'em alone!  If you *really* need to, then e-mail Rastaf at rastaf@cybernet.com
