PRO-ERASER 1.0
-------------------------------------------
Ryan Feltrin's EraserBot with Pro-Rocket 1.0 support.

	For more information (and source code) -
	http://www.planetquake.com/pro-rocket


*** you must have the Eraser-Bot v0.991 installed before installing PRO-ERASER ***


To install PRO-ERASER
-------------------------------------------
	1. make a copy of your quake2\eraser directory, and name it quake2\pro-eraser

	2. Unzip this archive (with pathnames) into your quake2\ directory,
	overwriting the existing quake2\pro-eraser\gamex86.dll



To run PRO-ERASER
-------------------------------------------
	Pro-Eraser requires no additional commands or config settings,
	it operates like a normal Eraser-Bot

	example start-up string :
	c:\quake2\quake2 +set game pro-eraser +skill 3 +map q2dm1



To play CTF with PRO-ERASER
-------------------------------------------
	1. copy the pak0.pak file from quake2\ctf to quake2\pro-eraser
	2. load a ctf map, and Ryan's Eraserbot code will detect it.


	For further information on the Eraser, see it's readme.txt, or
	http://impact.frag.com/


Have fun,

--Cardiac

BTW, there's a replacement GIB and ROCKET sound in the pro-eraser/sound directory.
if you don't like em, delete em.