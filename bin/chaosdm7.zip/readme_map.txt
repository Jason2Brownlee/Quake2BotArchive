A MAP FOR THE CHAOS Modification for QUAKE2
-------------------------------------------

PLEASE UN-ZIP DIRECTLY into your

../QUAKE2/CHAOS/ directory, using the pre-set FOLDER NAMES!

HAVE MUCH FRAGGIN' FUN WITH THIS NEW CHAOS MAP!  =)


   SPA
   (spa@planetquake.com)
   http://www.planetquake.com/chaos