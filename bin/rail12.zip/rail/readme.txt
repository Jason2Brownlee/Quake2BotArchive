
RAIL ARENA v1.2 by SumFuka
--------------------------


Installing the mod
------------------
Extract this zip into your c:\quake2 directory (or whatever it is).
The zip will extract the files into the c:\quake2\rail directory.

Running the mod
---------------
This is a SERVER-SIDE-ONLY mod.

To run a server, do :

 quake2.exe +set game rail +set deathmatch 1 +set fraglimit 100 +map q2dm1

To play on a rail arena server, you just connect to it ! Simple huh ?

Docs
----
Documentation is online at http://www.planetquake.com/rail

Credits
-------
Many thanks to :
- PLANETQUAKE for hosting the mod.
- Elvis for the kick ass html and art
- Ridah for the EraserBot
- Clan [MD] (More Dick) for testing it out... Hicks, Blade, Buster, Sinister.

CopyRight
---------
Please feel free to distribute this mod electronically.
Don't stick it on a CD without talking to me first.

Legal
-----
This mod has no malicious intent, but the author cannot
accept ANY responsibility for loss or damage incurred
through it's use. Source available for perusal on request.

SumFuka@planetquake.com - 10 September 1998 (hey, on my birthday !)
