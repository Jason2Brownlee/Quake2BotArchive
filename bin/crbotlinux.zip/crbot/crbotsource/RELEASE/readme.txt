This Build is the debugged version made with Visual Studio 6.0 Enterprise.

(Grieve, 2003)