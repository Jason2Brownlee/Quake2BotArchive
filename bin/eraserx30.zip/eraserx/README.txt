EraserX Documentation

eraserx.txt :
Please read this doc next - it will introduce you to the EraserX
mod, describe its purpose and features, and provide installation
and gameplay instructions.

Since EraserX is a modified Eraser that has been combined with 
various Expert features, the remaining docs below describe in more 
depth and detail, the separate unique features of the two mods -
these should be read to find out more about the features
_that are supported by EraserX_ (because Eraser and Expert duplicate
certain features).

I have indicated wherever possible, references to the Eraser and Expert
docs, but I'm assuming that most EraserX players are already familiar
with both mods and can look up additional info on their own.

eraser.txt :
Documentation for Eraser server operators, including how to get a 
server running using included configurations, and descriptions of
all the features supported by the Eraser server.

expert.txt :
Documentation for Expert server operators, including how to get a 
server running using included configurations, descriptions of
all the features supported by the Expert server, and how to
set up a custom configuration.

user.txt :
Documentation of the behavior of an Expert server from the
player's point of view, for both players and server operators.
Includes detailed descriptions of player-visible features of
Expert servers, and options that players can set.
 
obituary.txt :
Obituary data file, that is, the obituaries used by the Expert
server in text form ready to be edited.  Documentation of how 
to alter obituaries and create additional obituaries is 
included in this file as well.

teams.txt : 
Team specifications, used in teamplay mode.  See expert.txt

motd.txt :
Brief message displayed to clients on initial connect.

ctf, dm, team [directories] :
Directories for files specific to running ctf, dm or basic
teamplay servers respectively.  See the documentation of
the "cycle" cvar and the Level Scripting system in expert.txt
