================================================================
 Dunk!                                                     v1.2a
 by Incubus
................................................................

================================================================
Title                   : Dunk!
Author                  : Incubus
E-mail                  : IncubusOne@hotmail.com
Homepage                : http://fragland.net/ebs

Description             : Front-end for Quake2 BasketBall

Additional Credits to   : id Software for their kick-ass games
                          Ryan Feltrin for the EraserBot
                          Fragland, my wonderful host
                          Matt Shade, who made this wonderful
                          MOD

Build Time              : a few hours
================================================================

DESCRIPTION

   Dunk! is a program which allows you to configure the settings
   Of Q2Basketball without messing with the config files.

   You can find Quake2 BasketBall here:
                 http://www.planetquake.com/bball


INSTALLATION

   Just unzip the files contained in the archive, to a
   folder of your choice.
   If your unzipping a patch/update, you have to overwrite
   all previous files if asked so.


RUNNING Dunk!

   Double-click Dunk!.EXE
   
   Make sure you enter the correct paths when you want to play
   Q2Bball   

   For example:
   if you installed Quake2 in this directory 'c:\quake2\' then
   then enter the following in the 'Quake path' textbox:
   'c:\quake2'
   If q2bball is installed in this directory 'c:\quake2\bball'
   then enter the following in the 'Folder name of Bball' textbox:
   'bball'
  

KNOWN BUGS

   If you start clicking like crazy on the controls, Dunk! hangs.
   To exit, right-click on the button in the taskbar and choose 'Close'


DISCLAIMER

   This is a BETA release, I therefore will not take responsibility
   for your system barfing after playing the game. I can however
   guarantee that I have not purposely added any malicious content
   to this application. If you believe this to be incorrect, then
   I'd be happy to discuss the matter with you.

   You may freely distribute this archive, as long as it remains
   PERFECTLY intact, as distributed on our home page:
   "http://fragland.net/ebs". Thanks.

enjoy,
-Incubus
