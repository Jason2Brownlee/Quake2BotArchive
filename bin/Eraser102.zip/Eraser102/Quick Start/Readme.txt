================================================================
 Quick Start - "Eraser Bot Wizard"              v2.28 Revision 2
 Sloshy Software Inc.
................................................................

================================================================
Title                   : Quick Start - "Eraser Bot Wizard"
Author                  : Sloshy Software Inc. - Josh Holdaway
Homepage                : http://www.frag.com/quickstart/
Email Address           : QuickStart@Frag.Com

Description             : An Eraser Bot launcher, to ease the launching of 
  			  Quake2 games, with the Eraser Bot.

Additional Credits to   : id Software for being id Software.
			  Ryan Feltrin (aka Ridah) for the 
				awesome Eraser Bot. Without, QS would
				be nothing.
			  Shim Manning for Quick Start logo, 
				frame graphics, ideas, beta testing, 
				help with bot code, and help with 
				pak file code, mapname.dll & title of map
   				function routine, extended sample script.qs file.
			  K. Nishita for the pcx, tga dll.
			  Trey Harrison for the Md2Viewer.
			  Wilka for additional PAK file routines, and default/url 
				routine.
			  Wildman for ideas and beta testing.
			  Craig Williams for ideas and beta testing.
			  Kyle "Canon" Hughey for ideas and beta testing.
			  Krycek for ideas and beta testing.
			  Chris "Decimation" Burek for his 
				original artwork.  Used for pic of me
			  Pitbull for ideas and beta testing.
			  Craig "PilotMan" Goodspeed for ideas and
				beta testing.
			  Casey "GoDz" Heckethorn for beta testing and ideas
			  Splock for the mirror and beta testing
		
			  Any anyone else who has contributed in
				any other ways.

Build Time		: ~245 coding. ~304 internal testing
================================================================

DESCRIPTION
	
  Quick Start - "Eraser Bot Wizard," is a program to help
  configure and run the Eraser Bot for Quake2.  Quick Start is 
  developed with skill and compassion, meaning it will ease your 
  life.

REQUIREMENTS

  Quick Start requires the registered version of Quake2, and Ridah's
  Eraser Bot.

INSTALLATION

  WIN95/NT INSTALLER - FULL

  Extract the files from Winzip, then run the setup.exe file that
  you downloaded.
	
  ZIPPED VERSION - PATCH

  Use Winzip, and open the file up, and extract files to a 
  to the Quick Start directory.

RUNNING THE PROGRAM

  Either run the program from the start menu, or open up 
  explorer, and run "Quick Start.exe".

USING THE PROGRAM

  Just run Quick Start before starting Quake2, then choose
  the options you would like to play with, then Quick Start
  will automatically run Quake2 with Eraser Bots, with the
  specified options.

USING MAP INFORMATION {SETTING IT UP}

  Map Information is a nice built-in feature that allows you
  to take screenshots of the map, and view them in QS. You can
  also leave a short description of the map if you would like to.

  To access this feature, just right click on a map to bring 
  this nice built-in feature up.
  
  To view pictures of the map, you must be playing Quake2, then
  while your are playing the board, press F12 to take a screenshot.
  Then after your done making screenshots, copy over the .pcx file 
  from the scrnshot dir. If playing Eraser, it will be under the 
  eraser\scrnshot dir, then rename the screenshot to the format listed
  below. Screenshots must be .pcx files or .tga files.

  You can have as many screenshots as you would like, as long as your 
  follow the format.
 
  ==================================================
     Format = MAPNAME_().EXTENSION
  ==================================================
    MAPNAME = NAME OF THE MAP (i.e base1)
         () = Anything can be in here (i.e 01 or cool)
  Extension = File format must be .pcx or .tga
  
  Examples: base1_01.pcx
            base1_bfg.pcx
            base1_1rainbow.pcx
            base2_010.tga
            base3_funny.tga
  
  For additional help on how this works, you can download the MapExample.zip
  file from http://www.frag.com/quickstart/ and unzip to your QS subdir \MapInfo,
  or feel free to e-mail me.
  **Note: This comes bundled up with Quick Start version's above 2.16**

USING THE CUSTOM OPTIONS

  By using the Custom Options, you may setup up unlimited amount of custom options
  to your likeing. Such options could be to have mip_map or waterwarp. You could even
  have it bind keys, use aliases, and many more.

  After setting up your options, and closing down the Custom Options box, QS automatically
  saves the current data into the file called: SCRIPT.QS located in the QS dir.
 
  You may alter the script.qs file if you choose to, knowing you know how it works. Its
  easier to use the Custom Options box in QS to setup things.

  Using the flags is very easy.  Just add them in by right clicking and choosing either
  Add Flag or Add Sub-Flag. Add Flag & Add Catergory are used to add them to the main
  box. Using Add Sub-Flag & Add Sub-Catergory put these under a Catergory.

  In the New Flag box, name means the title for the flag. Command is the command such as
  bot_num. Checked value means when you turn the flag on, it sends the command in this box
  to the command line. Default means wheter its ON or OFF when you start QS.

  Example: Here's the New Flag pop-up box:
 
  ----------------------------------------
  -          Name: _____________________ -  Bind m for Drop Tech
  -       Command: _____________________ -  bind 	
  - Checked Value: _____________________ -  m "Drop Tech"
  -       Default: ON         OFF        -  OFF
  ----------------------------------------

  If you have done that, and you turn it on, you will end up with
  +SET BIND M "DROP TECH" 
  in the command line. 

  Or you can try this:

  ----------------------------------------
  -          Name: _____________________ -  Turn footsteps Off
  -       Command: _____________________ -  cl_footsteps
  - Checked Value: _____________________ -  0
  -       Default: ON         OFF        -  OFF
  ----------------------------------------

  If you have done that, and you turn it on, you will end up with
  +SET CL_FOOTSTEPS 0
  in the command line. 

  Refer to the sample script.qs on the downloads page of Quick Start.
  This will have sample Custom Options.

  **NOTE:** IF THE FLAG IS OFF, NOTHING IS SENT TO THE COMMAND LINE.
            AND IS PLACED IN THE ASDF.CFG FILE. (Currently)

RELEASING THE QS EASTER EGGS

  Press the tilde key(~) or F12 to bring up the QS console

QUICK RUN {QR}

  Quick run is a utility to run QSD files quickly.  This program resides in
  your QS dir, and once you have used QS, and saved some settings, and you
  don't want to run QS again, or want to start your game quickly, just run
  QR, and select your setting, and click start, then your off!

QS STARTER {QSS}

  A QS plugin, that will start QS apps on the fly.  It runs any apps included with 
  QS. QSS runs in your system tray.

PLUGINS
 
   Plugins have to be ran from QS's Plugins section

   SCREENSHOT VIEWER {SSV}

      A handy utility designed as a QS plugin, to assist you as the user to view
      screenshots taken in Q2.

   QS BOT GENERATOR {QSBG}

      A plugin for QS, that will make a list of bots with random attributes, that you have
      the models/skins, but no bot for that model/skin. Then QSBG will update your bots.cfg
      file if you desire.

   QS ROUTE INFORMER {QSRI}
 
      A plugin for QS, that will tell you maps that you have routes for, and vice-versa.

   PAK EXPLORER {PE}

      Nice plugin that list all available pak files, and then it will list all of the
      contents inside the pak file in a nice GUI interface. You can then listen to 
      any sound file, view .pcx, .tga and .md2 files. You can view any .cfg file. You may
      also extract any file for any other use.

   DEMO STARTER {DS} [Not Available yet]

      Useful plugin that lists all available quake2 demos. Then you can click "Start Demo"
      to run the quake2 demo.

PROBLEMS

  Have problems?  Read below.  This will help 90% of the public.
  If this doesn't help, feel free to e-mail us: QuickStart@Frag.com  

  -----------------------------------------------------------------
  Q: QS couldn't create the ActiveX dll

  A: The QSGraphics.dll needs to be registered within Windows95 
     registry.  The install program will do it automatically for you,
     but if that doesn't work try this,
     Open up "Run" from the Windows95 "Start" button. (This is a sample)
     REGSVR32.EXE "C:\PROGRAM FILES\QUICK START\PLUGINS\QSGRAPHICS.DLL"
     Then if worked, it will say something like...Dll successful.
     Remeber, your directory could be different.
  -----------------------------------------------------------------
  Q: Unexpected Error?

  A: This has to do with QS's required files...Ocx's.  The ocx's are
     ActiveX controls.  To fix this, download the Full Install again
     off our website, then install it.  If it asks you to overwrite any
     file, click yes. If that doesn't help, read the above section
     on how to register ocx's. Then register Picclip.ocx, Tabctl32.ocx,
     richtx32.ocx, comctl32.ocx.    
  -----------------------------------------------------------------
  Q: QS doesn't read my QSD files properly?
 
  A: This error is caused when QS reads an old QSD file.  V2.0 now adds
     the file version in the QSD file, so QS won't read old files anymore.
  -----------------------------------------------------------------
  Q: My bots.cfg file has gotten smaller?

  A: Because when QS reads the bots.cfg file, it looks to make sure you
     have the model & the skin for that bot.  If you don't have, the bot
     will be removed from the list.
  -----------------------------------------------------------------
  Q: The screenshot viewer(SSV) won't display any of my screenshots?

  A: The SSV only reads .pcx files, and .tga files. If you run in GL
     mode, Quake2 creates .tga files rather than .pcx files. 
  -----------------------------------------------------------------
  Q: QS or the QSBG won't read my bots.cfg file?

  A: QS, QSBG & the Eraser doesn't support spaces in the bots name.
     Just go through your skins and make sure they don't have spaces 
     in their name or their skin.
  -----------------------------------------------------------------
  Q: After running the QSBG and adding the bots to the bots.cfg, and 
     then I run QS. Then I save my bots.cfg file in the Bot Editor.
     Then I run QSBG again, and more bots appear. And I didn't delete 
     any bots from the list in the Bot Editor...What's up?

  A: If the bots keep apearing in the QSBG list, then those skins don't
     have the pic of face .pcx file. (If QSBG shows female/green over and
     over, then green_i.pcx file is missing) This is left in this way to 
     find messed up skins.
  -----------------------------------------------------------------
  Q: I can't play CTF with Eraser?

  A: Make sure the 11.5 meg .pak file from your ctf subdir of Quake2
     is in your \baseq2 subdir or the eraser subdir of quake2. Then choose
     a CTF compliant map, such as Q2CTF1.
  -----------------------------------------------------------------
  Q: I can't run any of the programs in the \plugins subdir of QS?
 
  A: These Plugins are not capable anymore of running without running them
     from the QS button "Plugins". To start a plugin, click the "Plugins"
     button on the bottom form of QS, then choose the desired plugin to run.
  -----------------------------------------------------------------
  Q: When Quake2 starts, it says "couldn't exec launcher.cfg", what does 
     that mean?

  A: QS deletes this file if its not going to be used. This is just a 
     warning note from the eraser. It doesn't hurt anything, and don't 
     worry about it.
  -----------------------------------------------------------------

RELEASES - See the Release.txt file included with QS

DISCLAIMER

   This program is FREEWARE, I therefore will not take responsibility
   for your system screwing up after playing the game or after using
   this software. I can however guarantee that I have not purposely 
   added any malicious content to this application. If you believe 
   this to be incorrect, then I'd be happy to discuss the matter with you.

   You may freely distribute this archive, as long as it remains
   PERFECTLY intact, as distributed on our home page:
   "http://www.frag.com/quickstart/". Thanks.  If you wish to sell, 
   or distribute this on any form of media, please contact me first. I'd happy
   to let yeah, as long as I'm aware of it.

   All the included programs layout, code, and other files are � by
   Sloshy Software Inc., All Rights Reserved.
   
   All programs that are included with this package are � by Sloshy Software Inc,
   Josh Holdaway.  The model viewer � by Trey Harrison.

Please send bugs, ideas, to QuickStart@Frag.Com

Donations are welcomed...To donate, send check to:
	Josh Holdaway
	205 East 1230 North	
	Springville, UT 84663

Enjoy,

Josh Holdaway
President & CEO
Sloshy Software Inc.

P.S Wow you read this far into the text file.  For that I think you deserve
    a prize. Okay, I'll give you a bonus surprise.  First enable the QS 
    console, then once inside the console type "viewrealpix", this will change
    my fake pic, to my real pic.