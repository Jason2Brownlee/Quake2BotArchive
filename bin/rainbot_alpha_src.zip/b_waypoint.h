
#define MAX_WAYPOINTS 1024

// comment/uncomment to look inside a bot's brain...
// NOTE: adv_logic will include LOTS of printf's
#define SHOW_LOGIC
//#define SHOW_ADV_LOGIC

typedef struct waypoint_s
{
	vec3_t location; // the origin of the waypoint

	int priority; // will be higher depending on what items are visible from
				// this waypoint

	qboolean inuse; // thx warzone!! - memory stuff
} waypoint_t;

void StartWaypointSystem (edict_t *bot);
void wSpawnPoint (edict_t *bot);
void wCreateWaypoint (vec3_t location, edict_t *bot);

// global waypoint definitions
waypoint_t *waypoints[MAX_WAYPOINTS];
int	num_waypoints;
int nextwaypoint;