URBAN JAIL BREAKE	for Computer Generated Forces
------------------


MENU:
--------------------------------
1.0 Installation
2.0 Information
2.1 Story
3.0 Credits
4.0 Disclaimer
--------------------------------



1.0 INSTALLATION
-----------------

Just unzip this to /quake2/action/ folder with "Use Folder Names"
Modelpack 1 & 2 are required...you can get them from 
http://guild.telefragged.com (Actors Guild)
Then start CGF Launcher and select JAIL.CGF...enjoy!

2.0 INFORMATION
----------------

This mission is in map Urban. Sometimes bots jumps straight down and
because this is urban, they sometimes get stuck (like in every other
urban mission scripts)

Because every people likes different arms, I put all arms in use.
(except Combat Knives and Akimbo)

2.1 Story
----------

You are a Cop who's trying to get escaped prisoner back to the jail.

3.0 CREDITS
------------

Script: Matti Laakso

Base Script: William's Hitman (kill the Sabotage)

4.0 DISCLAIMER
---------------

DON'T TAKE THIS SERIOUSLY AND I DON'T HAVE TO WRITE THIS =)
ALL THE NAMES ARE JUST FROM MY HEAD AND I DO NOT WANT TO
OFFEND ANYONE =)