CGF route + missions pack for monastery 

0. extract these files in your action directory
   with 'Use Folder Names' enabled 
   (so the .srp files end up in action\terrain,
    and the .cgf files end up in action\missions)
1. the Ross Norton CGF Launcher is required to
   use these missions
2. when starting the first mission for downtown,
   CGF will seem to hang for about 5 minutes.
   Instead, CGF is computing the actcity2.dst
   and actcity2.tac files (it does so only once).
   After that, quit Quake, and launch the mission
   again. From now on, you'll be able to
   start any mission on downtown right away.

In case you have troubles, please visit the
CGF website first and read the FAQ (and the
bot release notes) carefully.

Known problems: bots (CGF 0.78) currently have
troubles climbing ramps. Occasional crashes when
patrolling.

CGF website: http://www.botepidemic.com/aid/cgf

William