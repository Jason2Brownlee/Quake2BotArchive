
=======================================================================
	       		     John Woo's
			      Face/Off
	        For Computer Generated Forces(BETA1 v0.77)
			      Starring
		      Castor Troy And Sean Ashton
=======================================================================

Title:		Face/Off Mission Pack v1.0

Game:		Computer Generated Forces For Action Quake 2

Author:		{HBK}RobVanDam(LStorm6973@aol.com)

Web Site:	(SOON!) Guerillas In Action(http://gw.fear.net)

Description:	A 5(or 6, depending on how good you are) Mission Pack
		For The CGF Bots For Action Quake 2 Based On The Hit
		Movie Face/Off. Scripted For One Thing: Difficulty. It
		Is A 1-on-1 Duel. Sound Easy? You wish!

Credits:	id Software for the best FPS in the world!
		The A-Team for the best damn Mod ever made!
		William for the best frickin' Bot ever created!
		{HBK}RobVanDam for scripting, testing, and debugging

=======================================================================

++++Construction++++

Base:		William's Urban Hitman Missions

Build Time:	Uh ... A Couple Hours

Problems:	Bloodshot Eyes, Cramped Fingers, Out Of Mountain Dew, 
		No More Pixie Sticks...
		Hey! You're Actually Reading This?! WOW! There Are 
		People That Read ReadMes! Cool!!

=======================================================================

++++Installation++++

You gotta Zip It, Zip It Good! Huh? Oh, damn forgot, someone's actually 
reading this thing. Simple, unzip the file to your CGF Missions folder.
It should be C:\Quake2\action\missions or something along those lines.
Now, follow these instructions or you may run into problems while going
through the Mission Pack!

-Leave All .cgf mission files in the mission folder! These are:
   	face_off.cgf
   	face_off_0.cgf
   	face_off_2.cgf
	face_off_3.cgf
	face_off_4.cgf
	face_off_5.cgf

-Leave the Documents in the mission folder
	readme.txt

-Move the DOS Batch file and .cfg file to your main Action directory!
	face_off.bat
	face_off.cfg
=======================================================================

++++Story++++

Wow! A FPS Mission thingy with a Story! Now this is an accomplishment!
OK, so this story sucks, so what? Quake 2's story sucked the big one 
and you still bought it, so quit bitchin', will ya'!?

You saw the movie right? Castor Troy has stolen your identity, blah,
blah, blah. Shoot him, blah, blah, blah. Kill him, blah, blah, blah.

I'll give you the short version here. You had your face surgically
replaced(cool, huh?) with Castor Troy's(he's the bad guy) so you could
go undercover and bring down Castor's gang, syndicate, pick you action
movie bad guy gang name. There's a problem though, now Castor is back
and he has your face and he's taking over your life! Now, you could
have your boss explain the whole thing and send out a task force and
everything, but this is an Action movie. A John Woo movie on top of 
that. So you know what that means, right? Yep, you gotta hunt down
Castor and kill him, BY YOURSELF.

It won't be as easy as it seems though. Castor is sitting on top of a
weapons cache and he has more lives than a frickin' cat! It will take a
whole lot of skill to take him down, do you have what it takes?

=======================================================================

++++Starting The Game++++

Go to your Action Quake Directory, click on face_off.bat, cross 
anything you can, maybe a couple prayers, drink a 24-pack of Mountain
Dew, snort some Pixie Sticks if you've got 'em.

I assume you know the rest, so have fun, and remember, no one said it
would be easy. So don't blame me when Castor 0wnz0rs j00r ass!

*NOTE*: Mission 5 is actually more like a Bonus Round, only the best of
the best will be able to win it, and if you lose, you are sent all the
way back to the begining...
=======================================================================

++++Hints And Tips++++
(WARNING: This section contains some Spoilers, use it as a last resort,
cheaters suck.)

-Remember, Castor is happy just roaming the streets, until you shoot 
him, after that, he'll hunt you like you just killed his brother's
friend's half-sister's cousin's neighboor's mistress!(this is a John 
Woo movie...) Until he sees you or you fire he won't know where you are
so take you time and make your first shot count!

-You get Akimbo Pistols from the start, but I suggest switching up to
a single Mk23 and putting it in Semi-Auto, it allows you to move around
more, while still maintaining average aim.

-DON'T STOP MOVING!!!! Castor will only take a split-second before he
inserts a 9mm round into your brain cavity, so keep moving!

-*pst, pst* In Mission 5, Castor will be Sniping from the center roof.

=======================================================================

++++Legal Crap And Disclaimers++++

CGF is still in very early Beta form, if you run into problems with 
this or any other Mission, please keep that in mind.

If this Mission Pack makes your computer explode, it's your fault, not
mine. It has been thoroughly swept and tested.

I am not liable if you injure yourself or anyone else while in a wild
rage after Castor Troy hits you in the head for thr 5000th time.

If you find any spelling errors in this ReadMe please e-mail 
Blow_Me@YouDamnPerfectionist.Com

This Mission Pack is not sponsored or endorsed by William, the A-Team,
or id Software.

None of the people who helped produce Face/Off have any association 
with this mission pack. The name Face/Off, Castor Troy, and Sean Ashton
are all sole property of their creators.

If you are still reading you need to get a life.







Don't you ever give up?






There's nothing here moron.






The ReadMe is over!






God you are hopeless!