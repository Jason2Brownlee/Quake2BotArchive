
You will need to fix some problems with original route files from William. I improved it like this:

- Fixed problems with pipes for NE roof (the one with high stairs): bots couldn�t climb the north
one, and the south one was incorrectly linked from ground level.
- Improved the jump for reaching window of the red room at NW (bots still have problems with this, as I
myself have).
- Improved movement in NW alley, where many boxes are troubles (they
still are, but less now).
- Fixed problem on descending the high stairs.
- More linking on heavy traffic areas (central street, north street)
- One of the public lights had node, I created one over the other light
and linked it for descending from north roof.
- Dropped nodes over fence east of red roof building, with links from
this roof, so bots have new way down.
- AND... now the bots can jump between east high roofs, IN ANY
DIRECTION... !!!!

IF YOU LIKE THESE, I have packed the .srp file that replaces the
original from CGF 0.80. Simply extract the files riot.srp, riot.tac and riot.dsp in your \quake\action\terrain folder and let
it replace your original ones (make a backup first so you can go back if you don�t like it at last).
The .tac and .dsp are 0 bytes, because they are more than 1Mb each (too large for internet downloading), and they will be re-constructed when
first running a riot mission. YOU WILL NOTICE THE 5 MINUTES DELAY
THAT TAKES PLACE THEN, BUT IT WILL NOT HAPPEN AGAIN ON SUCESIVE
MISSIONS.

IF YOU DON�T LIKE the way all this sounds, first know that if William,
the Butler or any other official site allowed me to do this, then you
are sure. Then, if you really don�t like this, simply don�t extract
route files (select only the .cgf and the .txt files and push "extract"
on winzip or whatever).

NOTE ON ROUTE IMPROVEMENT: Bots are still subject to fail the jumps over east high roofs, specially if the bot is given
command "advance", because it tends to stop if seeing some enemy, but
jumps anyway, with the result of low speed -or desviation- and falling. If you script a mission and want the bot to perform these jumps, you must use
"moveup" instruction, so bot simply jumps, without thinking any other thing (cover it with friendly bots, because he is totally exposed).
Even thus, in the longer jump, from NE roof to the red roof, many times bots fall.
I thought to erase this link, but it is funiest when it works (and
works many times). So if you script: "advance to..." any location south of NE roof, bot tends to go by this gap, instead of descending the high
stairs. To use this last one, you need two steps: first for ground level
of the stair, then to whenever you want (for locations south of NE roof).

Kaos(R.A.[I.]).

--------------
Oh, no: (RA) is not a clan, it�s the initials for Rep�blica Argentina,
my country. There�s another K.A.O.S. in UK...

-------------
Edited by The Butler
