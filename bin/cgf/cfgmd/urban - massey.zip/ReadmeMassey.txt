Mr Massey's Legacy Mission Pack For CGF -

Based around the Legend of Mr Massey, the beardy physics teacher, this
mission pack will allow you to infiltrate his world of evil and corruption.
With the help of Nick Davidson, a man who has never met Massey face-to-face
but is repelled by his beard, there are three mission, getting harder and 
looping. Also you are aided by other people who hate Massey.

Build Time - 5 hours?

Thanks:-
God - For everything
id Software for the Q2 engine
The A-Team for the mod that changed the world as we know it
William Van Der Sterren for the most intelligent bots ever created
Big Al Keys for help in debugging and
The Stereophonics for the quality mission making soundtrack

Legal Stuff:

This can be distributed freely to anyone (as long as this readme is with it)
and that anyone can do whatever they please with the code as long as my name 
comes in the credits.

CGF is still in very early Beta form, if you run into problems with 
this or any other Mission, please keep that in mind.

If this Mission Pack makes your computer explode, it's your fault, not
mine. It has been thoroughly swept and tested and it works for me.

I am not liable if you injure yourself or anyone else while in a wild
rage after Mr Massey hits you in the head for thr 5000th time.

This Mission Pack is not sponsored or endorsed by William, the A-Team,
or id Software.

If there are any bugs in this mission - I dont give a shit (You can quoite me
on that)

The events portraid in this mission pack are in no way related to anyone.

All characters are fictional and do not exist.

Regards

^V^Trinity

Do not meddle in the affairs of Vampyres, for you are crunchy and good with Ketchup.

Visit http://come.to/^V^