I have used this skins!

messiah/kindig
messiah/blade
messiah/thecrow
male/blues
male/robber
actionmale/sisko
aqmarine/centurion
oddjob/oddjob
McClane/nakatomi1
sas/saspolice

Download the skins you don't have, the mission is better then!
Tou can download the skins here!

http://guild.telefragged.com/

Mission Made by Ztaffan
