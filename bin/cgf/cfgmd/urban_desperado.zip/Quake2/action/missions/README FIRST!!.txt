
=======================================================================
			      Desperado
	        For Computer Generated Forces(BETA v0.77)
=======================================================================

Title:		Desperado mission v1.0

Game:		Computer Generated Forces For Action Quake 2

Author:		Andrew Law (aka [NCP]Mr. Poon). 
		Email: kickass@btinernet.com
		ICQ: 28189786

Web Site:	NCP Webby: http://clans.barrysworld.com/ncp/

Description:	A mission based on Antonio Banderas's film Desperado
		for The CGF Bots For Action Quake 2. 
		Scripted For One Thing: A damn good laugh (nothing more fun than sending a 		bot flying with a handcannon shot)

Credits:	id Software for the best FPS ever!!
		A-Team for the best mod for Q2 ever!
		William van der Sterren for the CGF bot (good work m8)

=======================================================================

++++Construction++++

Base:		William's Urban Hitman Missions

Build Time:	A Couple Hours

Problems:	Damn hitman skins!  Apart from that, not much, a pretty easy mission to 		script. 

=======================================================================

++++Installation++++

Just point the zip file to the drive where your Quake 2 directory, and it'll unzip everything into the right places.

=======================================================================

++++Story++++

If you've seen the film, you know what it's all about.  Bucho's men killed your girlfriend, and shot through your hand, so now your trying to kill him.  This mission basically follows the battle towards the end of the film, where the Mariachi is joined by his two 'Dudes', y'know, the ones with the rocket launcher/chaingun guitar cases, against five of Bucho's Hitmen.  Bucho is up in the top building, and you have to get past his henchmen to get to him.  You have a handcannon (it's in the film!), Akimbo Pistols, and plenty of ammo.  Your dudes have M4's with 2 spare clips, and Bucho's men have Akimbo Pistols (the bots are too accurate with one pistol).

=======================================================================

++++Starting The Game++++

In your Action directory, just double-click on the desperado.bat file, and the mission will load.  If you have the CGF Mission Launcher, just select the desperado mission, and follow the usual steps.

=======================================================================

++++Hints And Tips++++

*I wouldn't advise charging around with the handcannon, because if you either miss or are too far way to hit them, they will kill you before you get the chance to say 'shit!'.  Your best bet is to go with Akimbo Pistols.

*Give Bucho some respect, and he usually sticks with a single Mk23, although I have given him Akimbo Pistols

=======================================================================

++++Legal Crap And Disclaimers++++

CGF is still in very early Beta form, if you run into problems with 
this or any other Mission, please keep that in mind.

If this Mission Pack makes your computer explode, it's your fault, not
mine. It has been thoroughly swept and tested.

If you find any spelling errors in this ReadMe please e-mail 
kickass@btinternet.com

This Mission Pack is not sponsored or endorsed by William, the A-Team,
or id Software.

None of the people who helped produce Desperado have any association 
with this mission pack. The name Desperado, Mariachi and Bucho are all sole property of their creators.