----------------------------------------------------------------
CGF Mission : Killing Private Ryan                              
----------------------------------------------------------------
Author: FuBaH
Description: This is a very hard mission, very similar to sabotage's
one(Used that one as base). You is a Nazi in the middle of WW2 
encharged to eliminate private Ryan, because the Allied Nations
want him alive. (Based on that movie Saving Private Ryan)

Files: urban_killing_ryan.bat
       urban_killing_ryan.cgf
       urban_killing_ryan.cfg

Help: Just extract the .ZIP file to your action quake 2 directory
and exec the batch.

----------------------------------------------------------------
Wait for more missions coming from me!!
Cheers from Brazil
FuBaH (Brazillians can do this stuff too!)