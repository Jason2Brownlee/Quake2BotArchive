Unzip files in the root of hard drive or wherever it would be convenient, with "use folder names" option checked (in winzip).

"Wherever":
the path included is:

\quake2\action\missions

So if you installed q2 normally, it would be in the root...