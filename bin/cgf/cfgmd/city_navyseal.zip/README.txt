=-------------------=
Navy Seal CGF Mission
^-------------------^


Author     : James Roth   "The_Ripper898"
Email      : Dark_Knight696@hotmail.com
Website    : http://members.tripod.com/~halflifebio
ICQ#       : 21618656
Build Time : 48 Hours
^----------------------------------------------^


=================
Quick Run Through
=================
This is based on Seal Team operations, all
weapons and items were issued to the players
as real time issued weapons like Marines have
M-4's, and Navy Seals are armed with Mp5's.
below you can find out what to expect in each
mission.
^-------------------------------------------^


===============
Missions Layout
===============
Navy Seal 1 :Your plane has crashed you and
your Seal Team are going to have to fight it 
out with hostile Marines.
=------------------------------------------=
Navy Seal 2 :Still in the Marine vs. Navy
Seals battle you are on top of a building 
inside the city and must snipe all hostiles.
=------------------------------------------=
Navy Seal 3 :Your Seal Team has been taken 
and you are low on ammo and weapons all you
have is your Pistol, no extra clip, and a 
Silencer. Kill a Marine Get his M-4 then kill
the rest.
^-------------------------------------------^


====
Bugs
====
None known of but if there is one let me know!
^--------------------------------------------^


===========
Bottom Line
===========
Skins are also included with this mission,
make sure you put them into the proper 
directories also download my new pak9 file
it is full of AQII goodies, new sounds, skins
all kinds of kool stuff check it out!
http://members.tripod.com/~halflifebio/
There will also be addons to the Navy Seal
Series I have started so check my site every
ow and then.
^-------------------------------------------^