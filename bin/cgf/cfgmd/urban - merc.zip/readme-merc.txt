
=======================================================================

     		        MERC : Soldier Of Fortune
	        For Computer Generated Forces(BETA2 v0.78)
		         Starring Chow Yun-Fat

=======================================================================

Title:		MERC: Soldier Of Fortune Pack 1

Game:		Computer Generated Forces For Action Quake 2

Author:		(HBK)RobVanDam(LStorm6973@aol.com)

Web Site:	Guerillas In Action(http://gw.fear.net)

Description:	Designed to be the ultimate of the ultimate challenges.
		This Mission was designed with one idea in mind:
		DIFFICULTY! It's about as hard as it gets, so if you
		are new to AQ2, don't even bother.

Credits:	id Software for the best FPS in the world!
		The A-Team for the best damn Mod ever made!
		William for the best frickin' Bot ever created!
		{HBK}RobVanDam for scripting, testing, and debugging

=======================================================================

++++Construction++++

Base:		William's Urban Hitman Missions

Build Time:	3 Hours

Problems:	Hard as hell, Frustrating as hell, GOD DAMMIT YOU SHOOT
		ME IN THE HEAD ONE MORE TIME...!!!!

=======================================================================

++++Installation++++

You know the deal, Unzip it to your Action directory, preserve 
structure, blah, blah, blah

=======================================================================

++++Story++++

You are the most sought after Hitman in the world, and the most 
expensive. You are that for one reason, you are the best of the best.
You are feared by everyone. 5 Years as a Pro and you are still as stone
cold and heartless as the day you started. You are just about worshiped
as a God in the business.

One of your favorite boss' Jimmy The Fence, he pays good and he's been
good to you, has come up to you with a BIG job. A new Terrorist 
organization has moved into his neighboorhood. Normally he wouldn't 
mind, but these rough-housers are drawing uneeded and unwanted FBI
attention to the area. Jimmy wants you to send 'em a message.

You are a little apprehensive about taking this job, people have told
you that Jimmy is not very happy about you taking jobs from other mob
bosses. But this is Jimmy, you trust Jimmy, he ain't never done you
wrong before.

The day has come, you open up a suitcase that has mysteriously arrived
in your hotel room. Inside is your payment, as well as a few boxes of
Shells for your favorite weapon, your trusty Sawed-Off 12 Guage 
Shotgun. You stand up and splash some water in your face, suddenly you 
hear footsteps on the roof above, like someone scurrying around up 
there. You look in the mirror and in the corner of the mirror spot a
sniper taking aim at your head. You hit the ground, he fires, the 
mirror shatters, but you are OK.

What the hell is going on? How'd they know where you were? Maybe the
people who told you Jimmy wanted you dead were right?

No time to worry about that now! You reach under your bed, grab your
Handcannon, load it, and head out to the streets. You'll worry about
what happened later....

=======================================================================

++++Starting The Game++++
Use one of two methods to start the game:

If you have downloaded the CGF Launcher, start the launcher and select
the mission gang_warz. Launch the game and get ready. That simple.

If you haven't downloaded the CGF Launcher, go to your AQ directory and
click on gang_warz.bat

=======================================================================

++++Legal Crap And Disclaimers++++

CGF is still in very early Beta form, if you run into problems with 
this or any other Mission, please keep that in mind.

If this Mission Pack makes your computer explode, it's your fault, not
mine. It has been thoroughly swept and tested.

If you find any spelling errors in this ReadMe please e-mail 
Blow_Me@YouDamnPerfectionist.Com

This Mission Pack is not sponsored or endorsed by William, the A-Team,
or id Software.