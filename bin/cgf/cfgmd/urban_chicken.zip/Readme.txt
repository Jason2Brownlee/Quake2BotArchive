
=======================================================================
	       		     Brian Smith's
			    Chicken Invasion
	        For Computer Generated Forces(BETA1 v0.77)
=======================================================================

Title:		Chicken Invasion v1.0

Game:		Computer Generated Forces For Action Quake 2

Author:		Brian Smith(apufantom@juno.com)

Web Site:	not at the moment

Description:	A mission with a goofy premise. Chickens have invaded 
		the world and you are the only one that can stop them

Credits:	id Software for the best FPS in the world!
		The A-Team for the best damn Mod ever made!
		William for the best frickin' Bot ever created!
		MrSoft (Matthew Stephen) mrsoft@softhome.net
		for creating the cheesy but usable chicken model
		Me, Brian Smith for having enough free time.
		

=======================================================================

++++Construction++++

Base:		Urban_Gang_1.cgf with modifications

Build Time:	About an hour

Problems:	I originally wanted to add some helpers to help
		you defeat the chickens, but it wouldn't let me
		any suggestions?

=======================================================================

++++Installation++++

unzip the file to your action folder in /quake2
It should be C:\Quake2\action\ or something along those lines.

=======================================================================

++++Story++++

Alien Chickens from another planet want to fornicate with our women! You have to destroy each and every one of them so we don't have those half-chicken people running around. Do it for the sake of humanity. Hell, do it for the women!

=======================================================================

++++Starting The Game++++

Go to your Action Quake Directory, click on chicken.bat
=======================================================================

++++Hints And Tips++++

Make your way to the Coke sign and hide there for a while.. the chickens will be on you in a second, also don't stop moving!
=======================================================================

++++Legal Crap And Disclaimers++++

CGF is still in very early Beta form, if you run into problems with 
this or any other Mission, please keep that in mind.

If this Mission Pack makes your computer explode, it's your fault, not
mine. It has been thoroughly swept and tested.

This Mission Pack is not sponsored or endorsed by William, the A-Team,
or id Software.

The Chicken Model was created by Matthew Stephen and should get all the praise for creating the mod.

