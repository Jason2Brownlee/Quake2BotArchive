Unzip this into your missions directory (usually c:\Quake2\action\missions).

History:

You have finished a robbery to an Army Depot, but the police it�s extremely
efficient that already have surrounded the place with some stupid snipers.
But they will not be alone for much time.

This is a tought campaing just for experts.

