To use these missions you need the BXtrain2 routes - avaiable at http:\\cgfmd.telefragged.com.

To install unzip to your "*.*\Quake2\action\" directory.


GAMEPLAY
There are 6 missions in all.
The mission structure is not like most CGF missions. For instance if you win the first mission
(0) you don't go any further. However if you loose it you unlock the other misions.
Even if you loose one of the next two missions (1&2) you will still be able to progress through
the levels - but if you loose an early mission the next mission will be harder.

For example if you loose mission 0, win missions 1 and 2 you will have an easy 3rd mission.
However if you loose mission 0, win mission 1 but loose mission 2 you will have a slightly 
harder third mission.
Then again if you loose mission 0 and loose mission 1 (you don't get mission 2) you will 
have a very hard mission 3.
Also if you win mission 0 there are no other missions but it is (when the bots don't fall of 
the train) hard to win mission 0.

The reason I've ranted on like this is to let good players know that they might want to 
loose a mission on purpose in order to try a different mission.

KNOWN BUGS
Because of the nature of this map the CGF bots have a tendancy to fall of the train onto the 
tracks and die. I have tried to keep this to a minimum by keeping most of the bots behind 
closed doors but sometimes they open the doors and fall onto the tracks.

Also the bots can't cope with opening the doors (with the exception of the guardvan door for
some bizarre reason) so they do stay where they are put most of the time and there's nothing
I can do about this. However if doors are left open the bots go through them.

On the last missions (3a) there should be more bots but for some reason tehy don't appear - even
if I set the maxclients command to 30 rather than 20. I anyone has a solution please feel free
to e-mail me at james@morriosn.com.
