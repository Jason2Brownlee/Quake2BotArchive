Urban Terrorist Army - CGF mission script for Action Quake 2 bots by MerC[TpZ] and Nuke[TpZ]
You can find more information and missions from http://get.to/tpz

This "missionpack" includes :
+6 missions
+1 Civilian model
+Other skins

Other information about missions :
 You are a swat soldier. You and your friends are fighting against U.T.A
(Urban Terrorist Army) forces in Urban city. There is 6 different missions.
For example : conquering the city back to friend forces, killing evil betrayals..etc...


