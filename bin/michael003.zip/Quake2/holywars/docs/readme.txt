Michael for (Quake II) HolyWars II
====================================

** Current version: 0.03 ** ( 8th November 1999)

Introduction
============

This is the "Michael" bot for HolyWars II (HW2). I will do some more to it, 
see below for contact method.

This bot is built on the 2.21SE HolyWars II source code.

# ** READ THE HolyWars II DOCS!!! ** Don't ask me about HW2, only the bot please.


Getting Started
===============

You NEED -= HolyWars II =- to use this, it will NOT work without it! I am using the simple 
method of replacing the HW2 gamex86.dll with the Michael one to run the game ( ++ make a 
copy of your real holywars/gamex86.dll before you install this one! ++ ) so I start it with:

c:\quake2\quake2.exe +game holywars +deathmatch 1 +maxclients 16 +map hw1

If you don't want to replace your HW2 dll then you must copy your WHOLE HW2 directory to a new
location (eg: drive:/quake2/michael/ )and then unzip the Michael files to that directory MANUALLY!

Useful Commands
===============

sv addbot		[ adds a bot for normal deathmatch ] (0.12 beta - now works for Team games too)
sv removebot <NAME> [ Removes that bot ]
sv removebot all	[Removes all bots]
botversion			[ prints the version number of the bots you are running (v0.12beta+)]

sv acedebug on [lets you see lots of useless information and initiates debug mode]

bot_showpath [0,1]	[Displays bot path information in debug mode]


Sample Config File
==================

The new config file system first looks for <gamedirectory>/bots/LEVELNAME.cfg and then for 
<gamedirectory>/bots/botdata.cfg. This just allows you to select the style of play and bot 
names you want for specific levels.

The first thing in the file must be the file version number after a "!". Currently this is
just 1 - this allows the game to spot bad config files later if we add more options to them
so it can deal with them gracefully if you forget to add the new information that is required.
It will print a warning message and invent some new data to fill in with. You will still need
to manually alter the file at some point.

It would be easy for someone to write a config maker that would do all this for you with
menu or option box selections - I just don't have time, sorry! If anyone does write one, 
let me know and I'll put it up on the Michael site with full links to your other stuff.

Any line starting with a HASH (#) is a comment and will be ignored. Bot data lines
currently consist of:

"NAME", "MODEL/SKIN", TEAM, WEAPON, SAINTHOOD;

Note the punctuation, no commas or quotes and it won't work! Also NO BLANK LINES!

Weapon choice is a number from 1 to 5 and represents:
1 - , 2 - , 3 - , 4 - , 5 - [Not yet implemented fully]
Sainthood:
0 = pretty Heretical play up to 5 = Fully Saintly play.

--------------- start sample file -------------------
!1
# Standard config
# "name", "model/skin", team, weaponchoice, sainthood;
# Weaponchoice [1..5] 
# Sainthood [0..5]
# If teams then this is Team 1
"FatGirl Slim", "female/venus", 1, 1, 5;
"Killer Kombo", "male/sniper", 1, 1, 4;
"Jackie Chan", "male/pointman", 1, 1, 4;
# Team 2 - Mix n Match
"Kim DeVille", "female/jungle", 2, 4, 5;
"Arnie Black", "male/psycho", 2, 3, 0;
"The Sarge", "male/grunt", 2, 5, 4;

--------------- end sample file ---------------------


Useful Information
==================

There is now a website for Michael. - see the contact section

This should be in a FAQ shouldn't it? :)
1) Michael Automatically creates new node files for new levels as you play them.
2) Michael saves and loads those files automatically.
3) The node files are called "<mapname>.HWR" and are saved in "holywars/routes/"

Creating Good Route Files:
==========================

1) Start the level in Deathmatch mode.
2) turn on debug mode (sv acedebug on)
3) Walk round the level visiting every area. Stay in the middle of corridors etc. You will
see coloured nodes being dropped behind you as you walk. If it overflows while routing just 
call up the console and "sv savenodes" then reload the level ("map MAPNAME") and carry on.
4) Make sure you go around each area "both ways". That is, if you jump over a box to get 
somewhere, make sure you jump back over it the other way at some point.
5) Reload the level before testing it with bots.
6) Use "showpath NODENUMBER" to see a path to the node you want to visit. This is useful
for tracking down broken paths. Often walking to and from the node is enough to fix the path.
If you just get a line through the ceiling/wall then the path is broken!
7) Test the level thoroughly with bots in deathmatch. Make sure debug
mode is on and watch the messages about Long Range goals. If they constantly don't find a
long range goal then your route file is broken somewhere.



Future Plans
============

Nothing concrete yet...

Contact
=======

The new "Michael" website is at http://www.planetquake.com/maxtron/michael/


Any Bug Reports should be useful ones, eg:
------------------------------------
System: K6/2-350, 128MB, TNT, SB16
Michael Version: 0.03
HW2 settings: <contents of ini>
Problem:
	Persistent crash on hw3 Level when 8th bot spawns in Teamplay mode, etc..
------------------------------------------------------------------------------
Or something like that!


Credits
=======

Author (HW specific code):	Connor "RiEvEr" Caple
Author ACEBot			  : Steve Yeager (see included ACEBot file)

                        =========
                        HOLY WARS
                        =========

Version  : 2.21 SE (for Quake 2)
Date     : April 26, 1999
Authors  : Paolo "Nusco" Perrotta and Roberto "Taz" Bettazzoni
           additional modification by Chris "Dexter" Davis
Email    : nusco@planetquake.com
WWW page : http://www.planetquake.com/holywars/

// ACEBOT Credits:
//  I also wish to thank and acknowledge the great work of others
//  that has helped me to develop this code.
//
//  John Cricket    - For ideas and swapping code.
//  Ryan Feltrin    - For ideas and swapping code.
//  SABIN           - For showing how to do true client based movement.
//  BotEpidemic     - For keeping us up to date.
//  Telefragged.com - For giving ACE a home.
//  Microsoft       - For giving us such a wonderful crash free OS.
//  id              - Need I say more.
//  
//  And to all the other testers, pathers, and players and people
//  who I can't remember who the heck they were, but helped out.
