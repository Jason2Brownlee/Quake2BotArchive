This is the source code to EraserULTRA - you may find releases of 
this mod at http://ultra.quake2.co.uk/ including future versions
based on this source code release.

If you make a modified version of this mod, please credit myself
(Anthony Jacques) as well as everyone credited in the readme.txt
in the EraserULTRA distributions available from the above URL. 

I would be grateful if you contacted me about any modifications
you make - this way, a centrally updated version may be made 
available, and changes made by various people incorporated into
one, making life easier for the end user. This is not a requiment,
but it would be "nice". Thanks.

This code is, of course, bound by the normal ID Software license
agreement (license.txt).

I hope this source is of use.

AnthonyJ

-----------------------------------------------------------------
anthonyj@jacquesa.freeserve.co.uk
AnthonyJ@btinternet.com

http://ultra.quake2.co.uk