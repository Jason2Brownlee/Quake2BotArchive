/* Menu prototypes */

void ultra_open_creditsmenu(edict_t *ent, pmenu_t *menu);
void ultra_open_dmsettingsmenu(edict_t *ent, pmenu_t *menu);
void ultra_open_banningmenu(edict_t *ent, pmenu_t *menu);
void ultra_open_featuresmenu(edict_t *ent, pmenu_t *menu);
void ultra_open_votingmenu(edict_t *ent, pmenu_t *menu);
void ultra_open_creditsmenu(edict_t *ent, pmenu_t *menu);
void TTCTFOpenJoinMenu(edict_t *ent);
void ultra_openmenu(edict_t *ent, pmenu_t *menu);

