/* LMCTF Radio prototyles */
void lmctf_radio(edict_t *who, char *enabled);
void lmctf_playradio(edict_t *who, char *sound);
void lmctf_radiomenu(edict_t *who);


