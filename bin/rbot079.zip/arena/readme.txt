================================================================
 The Rocket Bot                                 v0.79(Build 94)
 by Manfred Nerurkar (aka Defcon-X)
................................................................
 E-Mail: Defcon-X@Planetquake.com
 ICQ:	 10867038
================================================================
Title                   : Rocket Bot
Version   		: 0.79 ( BUILD 94 )
Author                  : Manfred Nerurkar (aka Defcon-X)
Homepage                : http://www.planetquake.com/arena

Description             : Human-like AI for Simulated Quake2
                           Rocket Arena 2 play.                           

Additional Credits to   : id Software for being id Software,
 			  
			  **Special Thanx to Ridah and CRT**
 				    for the Sources

                          The Info-Zip team for the zip/unzip tools
                            (http://www.cdrom.com/pub/infozip/)
                          Jeremy Mappus (aka DarkTheties) for
                            the MapMod source
                          The SABIN Team for some Client Emulation code
                            (http://www.planetquake.com/botshop/sabin)
			  All people from the QDevels messageboard
			    (http://www.planetquake.com/qdevels)
			  Richard 'Frogman' Pound <frogman@mail.utexas.edu>  					  
			    for Linux compiling help, thanx dude :)
                          Anyone else who has contributed in
                          any way to the development of Rocket Bot
			  Fuxxie, _Twiser and Fastcode - some Friends...
			  SubHuman for the Bots.cfg, and the Launcher RBOT file
Bugfinders & Betatester : SubHuman

Build Time              : ~200 hours of cod'in, lots of Cokes
================================================================

DESCRIPTION

   The Rocketbot is a Bot for Quake 2 to play Rocket Arena 2.
   Without being connected to the I-Net and wasting money!

INSTALLATION

   WIN95/NT INSTALLER

   Double click on the EXE file, then specify your Quake2
   folder and press Unzip.

RUNNING THE GAME

   To run the game, type the following from the DOS Shell
   command line, whilst inside your Quake2 folder:

   quake2 +set game arena +exec arena.cfg
 
   In the game press your Inventory-button to play!
   To instantly play against a bot.
   Go to an arena.
   Then in the Console type:
   bot_name Defcon-X (Will spawn this bot in the arena where you are)

TEAMPLAY

   If you are playing with teamplay on (1) the matches won't end automatically.
   Use MSTOP to end a match.
   Use join <Teamname> to join a team (All bots from the Team will spawn!)
   Use addteam <Teamname> to spawn a team.
   
           THE TEAMS AND BOTS WILL SPAWN IN THE ARENA WHERE YOU ARE!

COMMANDS

   mstart       		 | Starts A Match
   mstop           	         | Starts A Match
   bot_name <name>		 | Spawns a specific bot in the arena where you are
   bot_drop <name>		 | Drops a bot
   toarena <arena#>	         | Moves you to Arena #
   selfdamage (0/1)		 | Activates (1) or Disables (0) the Selfdamage
   view_weapons (0/1)            | Activates (1) or Disables (0) the ViewWeapons Support
   teamdamage (0/1)  		 | Activates (1) or Disables (0) the teamdamage
   linestep (in/out)		 | Steps in / out of the line 
   teams			 | To see a list of the current teams
   join <Teamname>		 | Joins the desired team
   addteam <Teamname>		 | Adds the desired team
   prorocket (0/1)		 | Activates (1) or Disables (0) the Pro-Rocket support  
   skill (1-3)			 | Sets the Skill from the Bots!
   id				 | Activates the Players identification (Default: ON)      
   group			 | Groups your team (Works fine!)
   disperse			 | Disperses your team
   
	       __________________________
CAMERACOMMANDS | DOESN'T WORK CORRECTLY |

   cam on  			 | Activates the Camera
   cam off    			 | Disables the Camera
   cam normal 			 | Normal-Mode
   cam follow 			 | Following-Mode
   cam observer			 | Observer-Mode

STARTINGSEETINGS

   health X			 | Gives X Health on Matchstart
   armor  X			 | Gives X Armor on Matchstart

WEAPONSETTINGS

   shotgun (0/1)                 | Gives the Shotgun (1) on Matchstart
   supershotgun (0/1)            | Gives the Super Shotgun (1) on Matchstart
   machinegun (0/1)              | Gives the Machinegun (1) on Matchstart
   chaingun (0/1)                | Gives the Chaingun (1) on Matchstart
   grenadelauncher (0/1)         | Gives the Grenadelauncher (1) on Matchstart
   rocketlauncher (0/1)          | Gives the Rocketlauncher (1) on Matchstart
   hyperblaster (0/1)            | Gives the Hyperblaster (1) on Matchstart
   railgun (0/1)                 | Gives the Railgun (1) on Matchstart
   bfg (0/1)		         | Gives the BFG10K (1) on Matchstart  :-%

   shells X			 | Gives X Shells on Matchstart
   bullets X			 | Gives X Bullets on Matchstart
   slugs X 			 | Gives X Slugs on Matchstart
   grenades X			 | Gives X Grenades on Matchstart
   rockets X			 | Gives X Rockets on Matchstart
   cells X			 | Gives X Cells on Matchstart

SUPPORTED MAPS

   All Rocket Arena Maps!

KNOWN BUGS

<-- FIXED --> The Telefraggin is still turned on.
<-- FIXED --> The Bots still shoot at you before the counter run out, 
	      but they now don't hurt you!
<-- FIXED --> Please don't change the name of the Bots in the Bots.cfg file.

Have Phun,
	-Defcon-X ;)