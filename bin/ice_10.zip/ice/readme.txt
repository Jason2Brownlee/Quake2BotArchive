================================================================================
File:		Readme.txt/htm
Subject: 	ICE
Author: 	jibe
Email:		jibe@planetquake.com
Web:		http://planetquake.com/ice
Version: 	1.0
Build Time: 	considerable...
If you have any comments, contributions, questions or suggestions, contact 
me via the address above.
The ICE bot and ICER Launcher are original works, written from scratch by 
jibe. Copyright (c) jibe 1998
================================================================================

CONTENTS
What's New in v1.0
What is ICE?
Features
Installation
Requirements
Starting the Game Right Now!
ICE Files and Folders
Maps & ICE
Creating Route Tables
	How to Route a New Map
	Route Building Tips
	Route Table Commands
	Advanced Rote Table Commands
ICE Commands
ICE Bot Personalities
Gameplay
	Deathmatch
		CTF Features in Deathmatch
	Teamplay
	Capture The Flag
		Advanced CTF Settings
		ICE CTF Strategy
Dedicated Server Support
Internet Play
Other ICE Features
	Grapple
	Auto Grapple
	Bot Chat
	Bot Gloating
	Bot Stats
	Bot Velocity
	Modes of Play
	Advanced Information Management (AIM)
	Camera
	ChatCentre
	Welcome Banner
	Client Commands
	Human Invisibility
	Map Cycling
	Pausing the Game
	Radio
	Viewable Weapons
Frequently Asked Questions - FAQ
Credits
Version History
DISCLAIMER
COPYRIGHT
DISTRIBUTION
 
WHAT'S NEW IN VERSION ICE 1.0 - Please see below for detailed commands and info.
================================================================================
    Introducing ICE Modes of Play: 
        Training Mode:    No pain, just information on who's damaging you and 
        how. Improve your game 
                                 without continually chasing health. 
        Challenge Mode: Just how good are you? It's hard to say against human 
        players with inconsistent
                                 play and circumstances. ICE Challenge Mode 
        removes the uncertainty. 
                                 Rate Yourself. 
    Ironed out any remaining bugs (hopefully). Version 1.0 should be pretty 
    stable in all game conditions. 
    AIM: Advanced Information Management
        Increases bot reaction times. 
        Reduces bot route calculation delays. 
        Improves bot perception of techs & flags. 
    Fixed human gibbing/head throwing. No more standing corpses! 
    ICE 1.0 is designed to run on the 'final' version of QuakeII; v3.20. 
================================================================================

Note About ICER - the ICE Bot Launcher

The ICE bot can be setup and run using ICER: the ICE bot Launcher,
which can be found at the web address above. You do not have to use the 
launcher to get ICE up and running, but it might make things simpler...

================================================================================
 
What is ICE?
The ICE Bot is a simulated player, capable of most human player 
behaviour within the Quake2 environment. ICE will play DeathMatch, CTF and it's own blend of Teamplay.
You can use ICER: the ICE Bot Launcher to get ICE up and running quickly.
 
================================================================================
 
FEATURES
	* Human-like roaming ai.
		- Bots move directly between objectives, using only 
		  'realistic' movements
	* Highly customisable, individual skill set:
		- Aggression
		- Agility
		- Accuracy
		- Cunning
		- Favourite Weapon
	* Melee skills include:
		- circle strafing
		- best weapon selection
		- target leading (anticipates enemy motion)
		- rocket dodging
		- crouching
		- rockets aimed at enemy feet
		- may pursue enemy until kill (if possible)
	* Uses all weapons / most items, including Grapple.
	* Create your own route-table for any map.
	* Dynamic skill - ICE bots can adjust their skill to 
	  give you a good game.
	* Map rotations.
	* Follow the bot action with ICE Camera.
	* Globally change bot skills with a single command.
	* Hazard avoidance.
	* Increasingly happy in water. Goes for air if necessary / able.
	* Supports Hentai's Viewable Weapons.
	* Supports Zoid's Threewave CTF 1.02
		- option to use CTF features in Deathmatch 
		  (id, grapple, techs)
	*'Advanced' CTF strategy code includes: 
		- Team ORDERS - available to humans & bots:
			+ coordinated attacks on base
			+ squadron forming, and leading to objective
			+ retreats to base defence
		- Allocate ROLES to your teammembers
			+ command certain players to guard the base
			+ designate players to attack
			+ choose members of the team to roam
		- Alternative team strategy screen which displays your
		  colleagues' plans, actions and status
	* Custom Teamplay mode with:
		- Custom Teamplay scoreboard
		- Custom skins or ICE managed skins
	* Internet Play management:
		- Adjusts bot skills based on your connection quality
		- Configurable features such as
			+ Weapon reload / fire speed
			+ Weapon fire travel speed
			+ Grapple Speed
	* Chat: Bots will threaten, welcome, gloat etc. 
	   All comments are customisable.
	* AutoGrapple
		- Allows use of grapple whilst firing another weapon.
	* ICE Modes of Play
		- Challenge Mode & Training variations on regular play.

 
================================================================================
REQUIREMENTS
The registered version of id software's Quake2.
v3.20 point release upgrade (although ICE should run on 
earlier versions AFTER 3.15).
The ICE Bot currently runs only on the Win95/98/NT platforms.
ICE supports Zoid's CTF and Hentai's Viewable Weapons.
	*If you wish to use ICE's CTF and Viewable Weapons
	features, then you must obtain the appropriate .pak 
	files from their respective authors. See above for 
	URLs.
For info., ICE was written on an AMD K6 200 MHZ with 32 
Meg Ram, and on that platform seems to handle decent 
numbers of bots just fine (ie up to 20 in DM, 14 in CTF)
================================================================================
INSTALLATION
Unzip the files contained in ICE_xxxx.zip into your Quake2 directory.
You MUST RESTORE PATHNAMES.
(Winzip users select the "Use Folder Names" option when extracting.
PKunzip users use the -d option.)
After extracting, confirm successful installation by checking for the 
existence of the "ICE" folder within your Quake2 directory.
================================================================================
STARTING THE GAME RIGHT NOW!
If you aren't using ICER: the ICE bot launcher, then start the ICE Bot by 
creating a shortcut to the file quake2.exe in your Quake2 folder.
The shortcut should read:
	quake2 +set game ICE +set deathmatch 1 +map <mapname>
You may specify other commands as detailed below, but this is 
sufficient to start up the ICE Bot.
Once inside the game, you can type at the console:
	bnum xxx
where xxx is the number of bots you wish ICE to randomly
choose and load (max 32 per command)
*or*
	bload xxx xxx xxx...
where xxx is the name of any bot contained in the file bots.cfg
(bots.cfg is stored in the ICE folder)
================================================================================
MAPS & THE ICE BOT
The ICE Bot can play on any map, once a suitable route table exists to
support it.
Read the section below (ROUTE TABLES) for advice on using the ICE Bot
in any map other than those detailed here.
ROUTE TABLES CONTAINED IN THIS RELEASE
This release of the ICE Bot contains route tables for the following maps:
DM:
	Q2DM1
	Q2DM2
	Q2DM3
	Q2DM4
	Q2DM5
	Q2DM6
	Q2DM7
	Q2DM8
	Evilq2dm
CTF:
	Q2CTF1
	Q2CTF2
	Q2CTF3
	Q2CTF4
	Q2CTF5
	starctf2
Read the section below (CREATING ROUTE TABLES) for advice on using the 
ICE Bot in any map other than those detailed above.
================================================================================
ICE BOT FILES/FOLDERS
Everything used by ICE is contained in the ICE folder within your Quake2
directory.
The .qit and .qrt files in the ROUTES subdirectory are generated by ICE, and
should not be altered manually.
BOTS.CFG
...contains details about all the ICE Bots. You may, of course, add to and adjust
the data in this text file (notepad.exe will do as an editor).
YOU MUST, however, keep to the exact structure as detailed within the file itself.
A replacement copy of BOTS.CFG is available from the ICE homepage.
LOADER.CFG
... is contained within the ICE folder, and CAN be read in each time the
game starts, and each time there is a map change (depending on your run_loader
setting - see below).
You can populate this file with any ICE Bot 'console' commands as detailed in
this file.
Useful for loading bots in teams, etc.
YOU MUST specify whether or not LOADER.CFG should be executed 
(using +set run_loader 0/1) as detailed below.
Default is NOT to execute it.
Remember that the ORDER of commands is important..
 eg you must load a team ('team' command) before you can change it's skin 
('teamskin' command).

================================================================================
ICE BOT PERSONALITIES 
ICE bots have a variety of personality traits, bad habits etc. which can all
be set within BOTS.CFG, or by using ICER. These settings are:
	Aggression		How likely the bot is to start a fight.
	Agility			How well the bot dodges, jumps, strafes, grapples.
	Accuracy			From 'inaccurate' to 'oh so accurate'
	Cunning			Brainpower. eg. Shall I attack, or get health and armour first?
	Favourite Weapon	The weapon the bot will always aim to use first.

Bear in mind that the most aggressive bot won't always win over the cunning bot
who leaves the melee in search of health.
Bear in mind also that the bot with highest aim accuracy and the railgun as a 
favourite weapon will almost ALWAYS win if he sees you first...
================================================================================
COMMANDS
	Note:
	Where applicable, commands are given for console and command line use.
	Where a 0/1 toggle is offered as the command argument, the first of the 
	toggle options is the default if not specified.
	Eg in the case of '+set camera 1/0', camera will be enabled even if the
	variable is never set.
	Some commans MUST be run from the command line (ie before the game starts)
	Some commands are for Dedicated Servers (eg dedicated: sv red) but they usually 
	work on the console in single player games.

command line: 	+set run_loader 0/1
console:	run_loader 0/1
	LOADER.CFG
	... is contained within the ICE folder, and MAY be read in each time
	the game starts, and each time there is a map change. This command tells
	ICE whether or not to load the file. The file can contain any number of
	Console commands, an example might be:
	Bload arc brag chog
	bot_dynamic 1
	map_change 1
	fraglimit 25
	This will load the bots arc, brag & chog. Dynamic skill changing will be 
	enabled, and the map will rotate every 25 frags. Note that map_change
	must be set to 1 or the maps in the maps.cfg file will not be used when
	rotating (instead the same map will just be reloaded).
console: 	bload xxx xxx xxx xxx...
dedicated:	sv bload xxx xxx xxx xxx...
	For loading bots into the game. 
	Where xxx is the name(s) of a bot contained within the bots.cfg file.
	Separate the bot names with a space.
console: 	bremove xxx xxx xxx xxx... [all]
dedicated:	sv bremove xxx xxx xxx xxx... [all]
	For removing bots from the game. 
	Where xxx is the name(s) of each bot you wish to remove.
	'bremove all' will remove every bot.
console: 	bnum xxx
dedicated:	sv bnum xxx
	where xxx is the number of bots you wish ICE to randomly
	choose and load. The maximum *per command* is 32.
	This just limits the loading traffic, you can add 10 lots
	of 32 if you wish (er, and you are running a Kray)
command line: 	+set bot_skill -2 -1 0 1 2
console:	bot_skill -2 -1 0 1 2
	You can alter the skill of all bots using the global bot_skill setting.
	 2 	will INCREASE bot skills quite a lot.
	 1 	will INCREASE all bot skills a little.
	 0 	is normal. Bot skills are unchanged.
	-1 	will DECREASE all bot skills a little.
	-2 	will DECREASE bot skills quite a lot.
	Values outside these ranges will have no effect. The default is 0
command line: 	+set bot_dynamic 0/1
console:	bot_dynamic 0/1
NB: 	DeathMatch ONLY.
	By allowing the bots to adjust their skills dynamically, ICE will
	try to provide the most balanced game for YOU.
	If, on the whole, you're whipping your opponents, the bots will try and
	make life harder for you. Alternatively, they will ease up if your
	score becomes embarrassing.
	If there is more than one human player in the game, bots will try
	to match the average human ability.
================================================================================
DEDICATED SERVER SUPPORT
As of version 0.3, ICE can be run in the dedicated environment (using the
'+set dedicated 1' argument on the quake2.exe command line, or by using 
ICER v0.2 and later)
All bot loading and configuration commands MUST be run with the prefix 'sv '.
Commands are:
	sv bload
	sv bnum
	sv bremove
	sv red
	sv blue
	sv team
	sv teamskin
You ONLY need to use the 'sv ' prefix if you are running a dedicated server, 
but the commands are also valid in the non-dedicated environment. Clients
MUST still use the standard command WITHOUT 'sv ', and client_commands must
be enable for this.
Manually added loader.cfg commands should usually employ 'sv ' format just
in case. (ICER v0.2 and later uses sv format)
TIPS
For maximum server control, run a dedicated server and then connect to it yourself,
 as opposed to running a regular game and having other join your game. Then disable 
 'client_commands' and control all server setting via the dedicated server.
All potentially game damaging commands (like 'showbotroutes') can now ONLY be run 
from the server whilst in dedicated mode.
If using ICER to launch a dedicated server, specify NONE for YOUR TEAM in both 
TEAMPLAY and CTF or you will certainly get error messages like "can't find a bot named xxx"
You can't use the 'join' command for Teamplay when launching a dedicated game.
Bots will now play a dedicated server without any human players in the game.
Maps will Rotate and Reload if a human player clicks their fire button to exit the 
level intermission. If, however, bots are playing and force respawn is set, the level 
will reload without waiting for human click.
================================================================================
GAMEPLAY
ICE supports DEATHMATCH, TEAMPLAY, and CAPTURE THE FLAG.

DEATHMATCH
This is the default mode of play. Every man (bot) for himself.

TEAMPLAY
ICE currently supports up to four teams playing simultaneously, up to 16
players in each. Teamplay is initiated automatically, as soon as there is 1
team containing 1 player.
All team commands start with the same root: team
You can not yet delete a team, you must instead reload the map. (ie type: map x
At the console, where x is the mapname)
console:	team
dedicated:	sv team
	Lists all the current teams.
console:	team xxx
dedicated:	sv team
	Creates a team of name xxx. If the team exists, lists all the players
	in that team.
console:	team xxx yyy yyy yyy yyy...
dedicated:	sv team xxx yyy yyy yyy yyy...
	Creates a team of name xxx (if it doesn't already exist).
	Adds all the players named yyy (separated by a space) to that team.
	If the bot players specified are not already in the game, they will be
	spawned.
	Include human player names in the argument to add them to a team.
	Or use the 'join' command below.
	If any player specified is currently playing in another team, he will
	be removed from that team, and added to the new team as instructed.
console:	teamskin xxx yyy
dedicated:	sv teamskin xxx yyy
	Skins are allocated automatically to teams as they are created. This is
	intended to prevent any potential confusion.
	You can, however, change a team's skin AFTER it has joined the game,
	using the teamskin command.	
	Where xxx is the teamname and yyy is the skin.
	eg. 'teamskin baddudes kw_black'
	If you specify an invalid skin, ICE will allocate the default skin.
	Team members who join after the teamskin command will be allocated
	the new skin you have specified.
console:	join xxx
	For human players only.
	Adds the player who typed the command (ie you) to the team specified
	in xxx. An alternative to including your name with the team command.

	eg. join baddudes
	NB: the team xxx must already exist, so use this command AFTER the 
	appropriate 'team' command.

	To change teams, just change xxx and repeat the command.

	This command does NOT work on a dedicated server!

Scoring in Teamplay
The teamplay scoreboard groups players by team, and places the teams in order of 
highest score first.
Within in each team players are then sorted by score; highest first. The leader 
in each team also appears on the right of the screen as an icon.
If the friendly fire dm flag is not set, then you will lose a point for fragging
your teammates.
================================================================================
CAPTURE THE FLAG
As in regular CTF, ICE CTF supports two teams, red and blue.
ICE also offers a host of bot AI/commands specific to CTF play.
Note:
	You MUST copy Zoid's pak0.pak file (~12 Meg) from your CTF installation
	folder into the ICE folder in your Quake2 directory.
The general bot commands (bload, bremove, bnum) all work in ctf mode, as well 
as the ctf specific commands below.
In ctf, bots loaded using 'bload' or 'bnum' will automatically be assigned
a team (red or blue). ICE will automatically keep the team numbers even
(assuming, that is, that there are an even number of bots to split!).
When a CTF map is loaded, ICE will first try to find a route between the
two flags. If it is unsuccessful, the following message will appear:
	'WARNING: there is no complete route between flags'
This message will therefore appear when you first initialise a new route table for a
CTF map. Ignore it.
If, however, you are not creating a new route-table and you see this, see the notes on 
ROUTE TABLES below. Bear in mind that the bots will not capture many flags until
this is remedied!

command line: 	+set ctf 0/1
	You MUST enable CTF at the command line. It cannot be properly initiated from 
	within the game (console: ctf 1), UNLESS you then reload a CTF map. 

console:	ctfteam red
	Adds YOU to the red team (regular ctf command for this is just team).
console:	ctfteam blue
	Adds YOU to the blue team (regular ctf command for this is just team).
console:	red xxx xxx xxx...
dedicated:	sv red xxx xxx xxx...
	Adds bots to the red team.
	If they aren't playing already, they will be spawned.
console:	blue xxx xxx xxx...
dedicated:	sv blue xxx xxx xxx...
	Adds bots to the blue team.
	If they aren't playing already, they will be spawned.
console:	flagroute
	Ensures there is a route for the bots from one flag to another.
	It is called automatically at startup, but can be called anytime.
	There will ONLY be a response if there is NO route.
	By design, ICE bots will NOT always employ the same route
	from one flag to another.
================================================================================
ADVANCED CTF SETTINGS 
ROLES
console:	role attack yyy
console:	role guard yyy
console:	role roamer yyy
	Where yyy is the name of the bot.
	*ROLES...
	By default, ICE ctf bots are given a role to play in a ctf game.
	This will be one of:
		attack
		guard
		roamer
	Roles are handed out in this order, so if there are 5 bot players
	on a team, two will be in 'attack', two will be on 'guard', and
	only one will be a 'roamer'.
	'Attackers' will consistently arm themselves as necessary, and then
	go for the flag.
	'Baseguards' stay close to their own flag, straying only occasionally
	to find weapons and ammo for defensive purposes.
	'Roamers' will support the other team members, retrieve lost flags,
	divert enemy attention whilst attackers make their bid for the flag.

	As bots players leave and join a team, roles will be adjusted
	accordingly.
	Roles can easily be changed manually, however, to suit a particular
	style of play.
	Note: you can store your favourite settings to a file, and then	execute
	it from the console (use exec xxx where xxx is the name of a file 
	in the ICE directory).
	You CAN, of course, use LOADER.CFG for this purpose, but remember that 
	roles MUST be assigned AFTER the bot has been spawned, and AFTER it has
	joined either the red or blue team.
	As an example content for LOADER.CFG (exact order):
		red arc brag chog
		blue arabella dilla emmie
		role guard arc
		role guard emmie
	Subsequent addition/removal from the team WILL reset any manual changes.
*ADVANCED CTF SETTINGS...ORDERS
Orders can be issued to your teammates at any point during the game (and bots will 
form their own attack formations etc from time to time, informing you of status).
Bots will keep their orders until the objective is completed (eg retreating to base)
or until you dismiss them.
ADVANCED CTF SETTINGS   SOUND
All orders are accompanied by an audio message. For instance, when a bot 
called to group with you arrives, he will say "Reporting".
	
console:	group xxx xxx xxx... []
	Without any arguments, 'group' will instruct any and all of your
	'available' teammates to join you.
	Availability is determined by proximity, existing orders etc. Bots
	currently engaged in melee are unlikely to respond. Bots carrying the flag 
	will NOT respond.
	If you specify a teammate name (xxx), they are much more likely to drop
	what they are doing (unless they are actually returning to the base with
	the flag).
	If you move around, after issuing the command, the bots will adjust to 
	your new position, but will obviously take longer to reach you.
	As each grouping bot arrives, they will get into formation and
	follow you around until you issue a dismiss command (see below).
	If any of your 'followers' becomes engaged in battle, they will rejoin the 
	group when the fight is over (if they die, they will respawn and set about 
	finding you again).
console:	groupvisible
	This command has been substituted for follow_me command below.
	it will behave in exactly the same way as the 'follow_me' command.
console:	attack xxx xxx xxx...[]
	Without any arguments, 'attack' will instruct any and all of your
	'available' teammates to attack the enemy base.
	Availability is determined by proximity, existing orders etc. Bots
	currently engaged in melee are unlikely to respond.
	If you specify a teammate name (xxx), they are much more likely to drop
	what they are doing (unless they are actually returning to the base with
	the flag).
	This command is very effective when used in conjunction with the GROUP 
	command. Call a number of teammates to group with you outside the enemy 
	base. When they have arrived, issue an ATTACK command. This is a good way 
	to ensure that the ATTACK is coordinated with all bots hitting the target 
	at the same time. It may be the only way to overcome a heavily defended 
	base, and it is a strategy that Leading bots will use from time to time.
console:	retreat xxx xxx xxx...[]
	Without any arguments, 'retreat' will instruct any and all of your
	'available' teammates to return immediately to base.
	Availability is determined by proximity, existing orders etc. Bots
	currently engaged in melee are unlikely to respond.
	If you specify a teammate name (xxx), they are much more likely to drop
	what they are doing (unless they are actually returning to the base with
	the flag).
console:	dismiss xxx xxx xxx...[]
	Without any arguments, 'dismiss' will dismiss all teammates who are 
	currently in your command (following one of the above orders). They
	will go about their business as dictated by their roles.	
	Alternatively, specify bots by name.
console:	support_me xxx xxx xxx... []
	WARNING!
	'support_me' is a POWERFUL command which will give you 
	serious control over your teammates. Use with care!
	Without any arguments, 'support_me' will instruct *ALL* of your
	teammates to join you.
	*All* members of your team will drop what they are doing and come to 
	your aid - unless they have existing orders (This prevents humans 
	accidentally stealing each other's recruits!)
	This INCLUDES GUARDS! (but not FLAG CARRIERS)
	If you don't want EVERYONE to come, use the standard GROUP command.
	Recruited bots will NOT engage in melee again until they find you.
	They will not respond to pain caused by enemies either. 
	Nor will they collect items on their way to you. They come direct.
	You are now their priority.	
	If you move around, after issuing the command, the bots will adjust to 
	your new position, but will obviously take longer to reach you.
	As each grouping bot arrives, they will get into formation and
	follow you around until you issue a dismiss command (see below).
	If any of your 'followers' becomes engaged in battle, they will rejoin the 
	group when the fight is over (if they die, they will respawn and set about 
	finding you again).

console:	follow_me
	WARNING!
	'follow_me' is a POWERFUL command which will give you 
	serious control over your teammates. Use with care!
	'support_me' will instruct ANY teammates *under your crosshair* at time of 
	order to join you in a group - unless they have existing orders (This 
	prevents humans accidentally stealing each other's recruits!)	
	*All* applicable recruits will drop what they are doing and come to 
	your aid. 
	This INCLUDES GUARDS AND FLAG CARRIERS!
	If you don't want EVERYONE to come, use the standard GROUP command.	
	As each grouping bot arrives, they will get into formation and
	follow you around until you issue a dismiss command (see below).
	If any of your 'followers' becomes engaged in battle, they will rejoin the 
	group when the fight is over.
	UNLIKE other orders, however, if they die, they will NOT set about 
	finding you again, but will instead dismiss themselves.
console:	arm_me
	WARNING!
	'arm_me' is a POWERFUL command which will give you 
	serious control over your teammates. Use with care!
	Without any arguments, 'arm_me' will instruct any and all available 
	Roamers to bring ammo to you, wherever you are, wherever you go.
	Availability is determined existing orders etc. 
	When an 'arming' ROAMER finds you, he will drop a percentage of his
	ammunition stock, and inform you with the standard 'reporting' sound.
	A message will appear centrescreen, for example:
		DROPPING
		Grenades,
		Cells,
		Rockets,
		Slugs,
		Shells
		for jibe.
	The Roamer will then dismiss himself. If you call him back, he'll drop 
	some more. The premise for the command is that you need the ammo more 
	than he does, so he'll keep dropping it until he runs out. 
	ROAMERS with NO ammo will not be much use as flag run support!
	Bots currently engaged in melee are unlikely to respond. Bots carrying 
	the flag will NOT respond.
	If you specify a teammate name (xxx), they are much more likely to drop
	what they are doing (unless they are actually returning to the base with
	the flag).
	If you move around, after issuing the command, the bots will adjust to 
	your new position, but will obviously take longer to reach you.
	As each grouping bot arrives, they will get into formation and
	follow you around until you issue a dismiss command (see below).
	If any of your 'armers' becomes engaged in battle, they will start 
	searching for you again when the fight is over (if they die, they will 
	respawn and set about finding you again).

console:	strategy
console:	invnext
console:	invprev
	This will call up the 'strategy' screen which shows statistics on all your
	teammates. So called as it is intended to allow a more strategic coordination 
	of your team. It is an alternative to the regular CTF score screen, and the 
	two cannot be shown at the same time. A maximum of six players can be 
	displayed at one time (by default the first six that were loaded - see below
	for scroll commands). The display shows a model icon (mini photo) for each 
	player, and a coloured letter representing their role 
		G for Guard (RED)
		A for Attacker (GREEN)
		R for Roamer (YELLOW)
	Also displayed against each is their name, distance from you (in approximate 
	'virtual' metres), and their most recent message to the rest of the team 
	(if applicable). These messages also appear at the top of the screen as regular 
	chat. The model icon and the role letter will be highlighted with coloured 
	frames at certain times in the game. When bots in your team are recruited by 
	other bots or player (but not you) a RED frame appears around their model icon. 
	If a bod is LEADING a group, the RED frame will be splashed with blue. If the 
	frames are RED, the bots are effectively busy, and will not respond to your 
	general orders unless you call them specifically by name. When you do recruit a
	bot (to attack, retreat or group), a YELLOW frame will appear around their icon.
	This means they have responded to your command. If the order was "Group" then 
	the frame will be YELLOW while they are looking for you, but will change to green 
	when they find you. A small letter will appear in the bottom right corner of 
	each model icon to show its current orders (L, Leading Group, A: Attacking enemy
	base, R: Retreating to home base, G: Grouping with you or another Leader).
	Finally, if the bot is in a melee, a pale blue frame will appear around the ROLE 
	Letter (G, A, or R).
	You can scroll the display using these commands:
	invnext
	-or-
	invprev
	These are the standard Q2 commands for scrolling through your inventory (and are usually
	 bound 
	to [ and ] respectively.
	>> or << will appear over the top and bottom player icons respectively
	if there are more players to display.
 
ICE BOT CTF STRATEGY
The ICE bot is capable of independently issuing any of the commands above.
It will happily lead or join groups, attacks, retreats, as instructed by you, or
by another bot on the team.
You can change a bot's existing orders (ie those given to it by another bot)
by instructing it by name.
ONLY bots with the 'attack' role will actually issue orders to the other members
of the team.
Guards will NOT take orders from other bots.
Attackers and Roamers WILL.
To see the ROLES and ORDERS of all of your teammates, just call up the scores
screen. After each ICE bot's name is a dash, followed by their ROLE, then
another dash, followed by their current ORDER.
	eg. 	Arabella-a-l
	 	Barb-a-g
		Dilla-r-g
		Emmie-g-d
Above, Arabella(attacker) is leading Barb(attacker) and Dilla(roamer) in group
formation. Emmie(baseguard) is dismissed (default if without orders).
By design, ICE bots will NOT always employ the same route from one flag to another.
Scoring operates as in conventional CTF, with points awarded for assists etc.
================================================================================
INTERNET PLAY
ICE contains a number of features intended to assist human clients
who are suffering the effects of high ping and lag during Internet play
with the ICE bot (Inspired by personal experience).
The aim is FAIRNESS. If a number of human players are sitting on the server,
along with the bot clients, players accessing via the Internet are always at 
a disadvantage. ICE INTERNET PLAY seeks to address the imbalance where
it is significant. It's an imperfect alternative to NOT joining the server at all!
NONE of these features are enabled by default. The console commands are ONLY
valid on the server.

*INTERNET PLAY Initialisation...
command line: 	+set internet_play 0/1
console:	internet_play 0/1
	Enables/Disables all the features of Internet Play, for ALL HUMAN PLAYERS.
	YOU MUST ENABLE this for the following features to work.
	If you then enable features such as weapon_travel_speed WITHOUT enabling
	'ping proportional advantage' (below), ALL HUMAN PLAYERS will enjoy
	rockets travelling with the speed of chaingun fire.

command line: 	+set ping_prop_adv 0/1
console:	ping_prop_adv 0/1
	With Internet Play enabled, 'ping proportional advantage' will 
	adjust each player's Internet Play features accordingly, in an attempt to
	assist those human players suffering from sluggish controls and the other 
	side effects of a high ping. The assistance is directly proportional to
	the player's ping.
	Those with normal (low) pings will NOT see any of the effects of the 
	features below. All players will be reminded from time to time if there
	is any 'assistance' in effect.
	
*INTERNET PLAY Features...
command line: 	+set handicap 0-4
console: 	handicap 0-4
	Essentially numbs bots' reaction time, slows their movement etc.
	Influences ALL bots in the game. Reduces the likelihood of bots
	seemingly vanishing, common in games where players have poor Internet
	connections.
command line: 	+set weapon_repeat_speed 1-3
console: 	weapon_repeat_speed 1-3
	Reduces reloading time, firing time, weapon change time etc.
	A useful edge on other players.
	Similar to the Haste tech in CTF, and great with a ping of 400+.
	(amusing with no ping, too)
command line: 	+set weapon_travel_speed 1-3
console: 	weapon_travel_speed 1-3
	Increases weapon fire travel speed.
	Renders the rocket launcher closer to its Quake (1) counterpart.
	Opponents have less time to dodge, and are more likely to be in the same
	place even after high ping has trounced your aiming/firing reaction time.
	A setting of 3 or more effectively converts the blaster into a 
	hyperblaster. You can slow weapons down too (er, why?) by specifying a 
	point value of less than 1, but more than 0.
command line: 	+set grapple_speed 1..4
console: 	grapple_speed 1..4
	Everybody has an opinion about the speed of the grapple. YOU decide!
	NB MAX is 4 or the mechanism goes pear shaped.
================================================================================
CREATING ROUTE TABLES
ICE bots use route tables to find their way around maps. You can create a
route table for any map; DM or CTF (this includes Maps created for such mods 
as Loki's Minions etc).
Route table management is handled automatically by ICE.
If you still have questions about creating a route table after reading this 
section and the FAQ, contact me using the address at the top of the file.
Human players create the tables as they play. You are, however, STRONGLY
advised to create route tables for new maps WITHOUT first loading any bots,
and to make the learning process an end in itself (ie don't play the map until
you have created a good route table). ICE will actually try to prevent bots
from joining the game whilst a new route table is being created.
HOW TO ROUTE A NEW MAP
Load up a map using ICER or an appropriate command line. Remember to include +set ctf 1
on the command line if the map has ctf flags on it.
You will see "Dynamic Learning Enabled" appear at the top of the screen.
The node count will start at 1, unless you are continuing an old route. 
Continuing an old route is not advised - If the total node count ever exceeds 250 I strongly 
recommend that you delete the .qrt and .qit files for the new map from your ice\routes folder. 
Then restart the game and nodes will be reset to 1.
Walk around the whole map. Don't Run. Try to go everywhere once and once only. This will create
an efficient route for ICE. The better the route, the better the game will be.
ICE will disable learning automatically. (You can start it up again if you like, to add to the route 
for instance. See below.)
When you see the "Routemap Complete. Dynamic Learning Disabled" message, you can reload 
the map and spawn some bots. That's all you have to do.
At load time, the statistics for the map will be shown. Based on this
information, ICE will decide whether or not to continue updating the map's
route table as you move around the map. Occasionally ICE will reenable Learning after the
"Routemap Complete. Dynamic Learning Disabled" message has appeared. Just play the game,
ICE will Disable the Learning when the time is right.
After a route table has been successfully stored, you can TWEAK it as little
Or as much as you like. Tweaking is certainly NOT necessary but in some 
circumstances, the realignment of a node or two may ease a bot's progress.
See below for commands.
Read the tips below!
 
ROUTE BUILDING TIPS
DON'T DIE! if you do, bots subsequently using the route table will behave 
strangely...
Check out one of the route demos on the ICE downloads page.
When you've finished creating a route, RELOAD the map before adding any bots.
Every item which CANNOT be reached by the ICE bot will have a bright blue
aura. Once it is accessible, the aura will vanish.
It is NOT necessary to actually touch or pick up ALL the items on a map. If an 
item is glowing, get closer to it. The aura will probably disappear before you
actually touch it anyway. Route 'Learning' will then deactivate automatically 
once a satisfactory table is in place - ie once the ICE Bot is able to find 
its way to NEARLY ALL the items on a map.
The blue glow will only appear on the unreachable items when Dynamic Learning 
is enabled. You can, however, force it on and off using showglow and hideglow.
ICE will stop learning once 90% of a map's items are reachable. Often a few
items remain hidden or hard to reach. The 10% threshold allows learning to be
disabled even if a few items are out of the ICE bot's reach - thereby freeing
up processing power for improved gameplay. Remember that on CTF maps, many 
items may be available only via use of the GRAPPLE. 
ICE bots will probably be able to reach these items - but they will
Still appear as unreachable (blue glow) when the map loads.
If you wish to track down the remaining 10%, simple use the 'learn toggle'
command (detailed below). Doing so DISABLES automatic learning - meaning that
YOU must manually disable learning ('learn toggle' again) if you wish to stop 
the incremental learning. Loading a map, or reloading Quake2 will also
reset automatic learning.
If you don't know where the remaining unreachable nodes are, use the 
'unreachable' command below.
If 90% of items isn't good enough for you, then you can track down the remaining 10%
using the unreachable command. NOT ALL ITEMS ARE NECESSARILY REACHABLE!
and a 90% is normal. For instance some CTF maps have items which can only be 
grappled to. ICE bots will find their own way to these things even if they're not officially
reachable.
If you wish to disable automatic route learning at any time, simple use the
'learn toggle' command (detailed below).
The larger a route table is, the longer it will take ICE to determine its
path. Only VERY large maps should have more than 200 nodes in total. The number
of nodes in each route table is displayed as the map is loaded.
If you don't complete the route table in one go, ICE will continue recording
nodes where it left off the last time it used the current map - but this will 
invariably result in a less efficient route table. RECORDING THE ROUTE IN ONE
SWOOP IS THEREFORE THE PREFERRED OPTION.
Route learning requires some processing power - motion may be a little jerky
during 'learning'.
When stepping on and off platforms/elevators, wait until the machine has 
stopped moving, before you get on or off.
Move on and off ladders cleanly - no jumping. Go UP ladders, NEVER go down
them.
Only jump of ledges if you have to. Always walk down steps or up steps if it's possible.
Bots will jump if they need to , but they need to know how to use the stairs first.
No grappling please! Bots will use the grapple without training.
You can use the tools below to evaluate the status of your current route table.
If a given table is large and therefore inefficient (manifest: bots will 
'think' longer before moving), delete the route table from the quake2\ICE\routes
directory. The route table file will have the same name as the map, and the 
extension .qrt. You can also delete the .qit file but it is not necessary.
When you reload the map in Quake2, a new table will be initiated.
Bots will only go to places that YOU have been. Bear that in mind when creating 
the route table.
ICE will load any existing route table at startup, or whenever a new map is
loaded from within the game.
CTF SPECIFIC...
When a CTF map is loaded, ICE will first try to find a route between the
two flags using the map's route table (since this is an important part of ctf).
If it is unsuccessful, the following message will appear:
	'WARNING: there is no complete route between flags'
This message will therefore appear when you first create a route table for a
new CTF map. Ignore it.
If, however, you are not creating a new route-table and you see this, it means
that the bots are unlikely to capture many flags. SO...
*When creating a route table for a ctf map, the first thing to do is walk from
one flag to the other. The more routes that exist between the flags, the more
'unpredictable' bots will be as they attack the enemy base, so recording several
different routes is also a good idea. One solid route between the flags will do,
however.
*You can force the route learning on (see 'learn toggle' command below) or you
can delete the route table altogether and start again (often the best plan).
You can also test the route quality using the tools below.
     
ROUTE TABLE COMMANDS:
The following commands are available if you wish to override ICE's automatic
settings.
console:	learn toggle
	You can toggle route learning on and off with this command.
console:	loadroute
	Manually loads/reloads a route (specific to the current map).
console:	showallnodes
	Toggle. Will show every node recorded on a map. Nodes will be green
	Unless they must be jumped to, in which case they are red.
	Beware of using this when lots of bots are playing as it is quite
	Demanding on the game.
console:	showroute
	Toggle. First call sets the start point, second call sets the end point.
	Wait a few seconds, and if able, ICE will light up the nodes & route
	between	the two points. Toggle once more to deactivate the highlighted
	route.
console:	show_bot_routes
	Toggle. Shows the route and nodes taken by the bot who most recently
	chose a path somewhere.
console:	evaluateroutestatus
	This is the route table loading mechanism, and is called every time a map 
	is loaded. It provides feedback on the current route table status, and 
	lights up all the map items which cannot be reached by the ICE bot. 
	Remember that having a few unreachable items on a map is normal - 
	especially if it is a CTF map where grapple use may be required. The bots 
	will usually find a way to these "unreachable" items. Regular reloading of 
	the map is advised when making any node changes - and is essential before 
	any bots are loaded.
console:	hideglow
	
		Hides the blue glow on items which indicates that bots will get to
		these items using 'unconventional means'
		By default: The glow is DEACTIVATED at startup on 'complete' routemaps.
console:	showglow
		Shows the blue glow on items which indicates that bots will get to
		these items using 'unconventional means'
		By default: The glow is ACTIVATED at startup on 'incomplete' routemaps.
 
ADVANCED ROUTE COMMANDS
WARNING: ADVANCED USERS ONLY!!!
console:	forcenode
	Will force a node to be recorded at your current position. Used to force
	Bots to take a certain route.
console:	movenode
	For tweaking specific nodes when the route table is complete. This command 
	will select the nearest node to your current position, and transport you 
	to it. The active node will be represented as a red ball, and nodes 
	connected to it will be blue. Using the command a second time will 
	actually move the node. The change is effective immediately. Remember that 
	the red node (the one you are moving) MUST remain in view of the blue 
	nodes. MAKE A BACKUP OF YOUR ROUTE TABLE BEFORE USING THIS COMMAND. 
	It is useful when moving nodes about to activate the "showallnodes" 
	Command - 'movenode' will do this automatically.
	The number of the selected node will be displayed at the top of the screen.
console:	unreachable
	After "evaluateroutestatus" is run (automatically when a map is loaded) 
	the number of items which are unreachable is displayed. To move directly 
	to each of these items in turn, use "unreachable" at the console. Make 
	sure learning is deactivated before using this command (use "learn 
	toggle"). ICE will try to ensure it is disabled automatically.
================================================================================
OTHER ICE FEATURES
VIEWABLE WEAPONS

command line: 	+set view_weapons 0/1
	This MUST be set on the command line.
	ICE fully supports Hentai's Viewable Weapons mod.
	Note:
	You MUST copy the vwep pak2.pak file (~2 Meg) into
	the ICE folder in your Quake2 directory.

MAP CYCLING

command line: 	+set map_change 0/1
console:	map_change 0/1
	You can instruct ICE to cycle through the list of maps contained in
	maps.cfg (in the ICE folder).
	You can store up to 50 maps, in any order, each one on a NEW line.
	When ICE reaches the end of the list, it restarts at the top.

	When the change is triggered (by 'fraglimit' or 'timelimit'	or 'capturelimit')
	then if the "Force Respawn" DM Flag is set, the next map will load 
	immediately. Otherwise, the next map will not load until a human 
	player hits their fire button. This means that if you want the maps to 
	keep cycling on an empty  dedicated server, you must set the "Force 
	Respawn" flag.
	'map_change' is used in conjunction with 'fraglimit' & 'timelimit'
	& 'capturelimit' detailed below.
	NB:	maps in maps.cfg will NOT be used unless 'map_change' is set to 1
command line: 	+set fraglimit xxx
console:	fraglimit xxx
	Map changes when a player gets this many frags.
	NB:	you MUST also set map_change 1
command line: 	+set timelimit xxx
console:	timelimit xxx
	Map changes when this many minutes have passed.
	NB:	you MUST also set map_change 1
command line: 	+set capturelimit xxx
console:	capturelimit xxx
	Map changes after this many captures. CTF ONLY!
	NB:	you MUST also set map_change 1
CAMERA
command line: 	+set camera 1/0
console:	camera 1/0
	To initialise the camera on the server. You must do this in order for the 
	client 'cam' commands to work at all.
console:	cam xxx
console:	cam on
console:	cam off
console:	invnext
console:	invprev
	You may choose WHO to watch, and HOW to watch them*
	WHO:
	Once the camera is initialised by the server, use 'cam' at the console
	with one of these options to choose WHO you want to watch:
	1.	'cam xxx' is the name of the bot you want to follow.
	2 	'cam on' will start the camera in auto mode when you first use it.
		In auto mode, ICE will move the camera from bot to bot depending 
		on a variety of criteria intended to show where the action
		is (eg who is fighting with the biggest weapon, who has the flag etc)
		Typing 'cam on' repeatedly will allow you to manually move the focus 
		from bot to bot, until the last bot is reached, whereupon the 
		camera will deactivate itself.
	3.	Whilst in camera mode, you can also move the display from player to 
		player using the inventory commands,
			invnext
			-or-
			invprev
		These are the standard Q2 commands for scrolling through your 
		inventory (and are usually bound to ] and [ respectively.)
	4.	'cam' without any arguments will instantly deactivate the camera. 
		So will 'cam off'.

	HOW:
	There are three camera modes, and you can scroll through them using your 
	*fire* button:
	1.	Hollywood MODE:
		ICE automatically pans, zooms and follows the action from all angles.
	2.	Eye MODE:
		Gives you the bot's eye view. Full on!
	3.	Freemouse MODE:
		Places you just above the bot, and allows you to control the view 
		angle with your mouse.
	Whenever you use the camera, information will appear in the lower left 
	corner of your screen, detailing who you are watching and how they are doing.
	If you call up the scores screen at anytime (or the strategy screen in CTF)
	the camera info will disappear and not return until you hit *fire* or type
	'cam on' again.
 
GRAPPLE

ICE bots will use the grapple by default. They will use it in DM too,
if enabled (see 'dmgrapple' below)
command line: 	+set bot_grapple 1/0
console:	bot_grapple 1/0
	ICE bots will happily get from a to b using the grapple.
	Or you can stop them doing so.

command line: 	+set bot_spiderman 1/0
console:	bot_spiderman 1/0
	ICE Bots can also swing around the map like Peter Parker (aka Spiderman!).
	This includes using the grapple to:
		...get out of nasty situations
		...get into position or chase an inaccessible enemy
		...show off in general

 
AUTO GRAPPLE
console:	auto_grapple 0/1
console:	auto_grapple_go, auto_grapple_stop (SEE BELOW FOR USAGE INFO)
	auto_grapple allows the grapple to be used concurrently with another 
	weapon (as in LMCTF). In order to do this, you must add some commands to 
	your autoexec.cfg in the ICE folder (as you may have done for Zoid's 
	standard grapple). It should look something like this:
	    bind "shift" +auto_grapple
	    alias +auto_grapple "auto_grapple_go"
	    alias -auto_grapple "auto_grapple_stop"
	The only parts you mustn't change are the words auto_grapple_go and 
	auto_grapple_stop. You can now fire the grapple whilst still using your 
	active weapon (and without actually selecting the grapple as a weapon 
	first). Hold down the auto_grapple key ('shift' in my example above) for 
	as long as you want the grapple activated. Of course you can still make 
	the grapple your active weapon if you like ("use grapple"), and the 
	command above will operate the regular grapple just fine.
	You MUST set the 'auto_grapple 1' server setting to enable this option - 
	or just choose Auto Grapple from the bot options page in ICER (v0.11 and 
	above).	The bots will use auto_grapple themselves and attack you whilst 
	grappling!

 
CTF FEATURES IN DEATHMATCH
command line: 	+set dmgrapple 0/1
	Allows use of the CTF grapple in DM games.
command line: 	+set dmtech 0/1
	Allows use of the four CTF techs in DM games.
command line: 	+set dmtech 1/0
	Adds the handy player identification option to DM games.
 
CHATCENTRE

command line: 	+set chatcentre 1/0
console:	chatcentre 1/0
	To enable/disable the realignment of human chat from the top of the screen
	to the centre of the screen.
	Useful if there are only a few (non-malicious) players who miss each others
	comments during play.

 
RADIO

command line: 	+set radio 1/0
console:	radio 1/0
	Plays 'radio' sound when messages from human (NOT bot) players are received.
 
 
WELCOME BANNER

command line: 	+set show_banner 1/0
console:	show_banner 1/0
	Displays the ICE welcome banner to clients as they connect.

 
CLIENT COMMANDS
command line: 	+set client_commands 1/0
console:	client_commands 1/0
	Determines whether or not clients (rather than just the server)
	can add or remove bots. By default they can.

 
BOT CHAT
The bots will use chat in a variety of circumstances. All the comments are held
in chat.cfg in the ICE folder. See the file for details on creating your own chat
for the bots to use.
command line: 	+set bot_chat 1/0
console:	bot_chat 1/0
	Toggles the bots' verbosity. Useful in CTF if you're not interested
	in hearing about their planned attack on the enemy base etc...
	Shuts them up in DM too.

 
BOT STATS
console:	bot_display_toggle
	With the scores screen *visible* toggles between: 
		*display of player scores
		*statistics of bots currently in the game
		*camera screen if activated
		*ctf strategy screen
 
 
PAUSING the GAME
console:	bot_pause 0/1
	Pauses ALL playing bots - but not human players.
	If you want to use bot_pause or bot_invisibility as toggles (ie 
	press a key once to turn invisibilty or pause on, press the same key again 
	to turn it off) then you need to add an alias/binding to your autoexec.cfg 
	file in the ICE folder. Something like this: 
	alias invis0 "bot_pause 0;echo bot_pause OFF;wait;bind i invis1"
    	alias invis1 "bot_pause 1;echo bot_pause ON;wait;bind i invis0"
    	bind i invis0 
 
 
HUMAN INVISIBILITY
console:	bot_invisibility 0/1
	Makes ALL humans invisible to bots. They won't attack you unless
	you attack them first!
 
 
BOT VELOCITY
console:	bot_velocity 0-3
	
	Where 0 is FASTEST, 3 is SLOWEST.
	Bot Velocity is now configurable using 'bot_velocity'. By default, bots 
	always run flat out (bot_velocity 0), which makes them harder targets but 
	isn't completely realistic.

 
BOT GLOATING
console:	bot_gloat_glow 1/0
	You can prevent ICE bots from flashing blue after they score a kill, using
	this command. Default is 'bot_gloat_glow 1' which is ON.
	This will NOT stop them insulting you!

 
MODES OF PLAY
console:	bot_mode 0-2
console:	challenge
	Additional, custom ICE modes of play exist for Deathmatch Only.
	0 : Normal mode
	Regular DM. No changes applied

	1 : Training Mode
	This is intended to help those who are new to ICE/Q2 or want to improve 
	their game without being repeatedly killed and continually having to respawn
	and collect weapons/armour/health.
	Gameplay ensues as normal in DM, but you receive no pain from bot attacks.
	Instead a warning message appears centrescreen, displaying the damage that 
	would have been done to you in normal mode. You also see who took it. eg:
		"Eskimo takes 25 with a Rocket Launcher"
	If you hurt yourself somehow, then you'll be told about that too.
	2 : Challenge Mode
	Just how good are you? It's hard to say against human players with inconsistent 
	play and circumstances. ICE Challenge Mode removes the uncertainty. The skill 
	level of your competition is determined by ICE and then rated against your 
	peformance. You are on your own. Every ICE bot player is out to get you.
	Factors taken into account:
	-	Number of enemies.
	-	The various skill settings of each enemy.
	-	Time. Your score falls off over time.
	-	Number of human players.

	As such, the better the enemies are, the more points you get for a kill. 
	Likewise the more enemies on the map, the faster your score will grow. 
	If you have human help, your score will reflect this. 
	If you camp or sit around, your score will drop - quickly.

	Scores will be between 0 and 999. Your score will appear in the top right 
	hand corner of the screen.
	
	You can also type 'challenge' at the console (at any time) in order to see 
	the highest score you have had during the game.

	Rate yourself.
		
	
 
ADVANCED INFORMATION MANAGEMENT (AIM)
console:	bot_aim 0/1
        This option will speed up certain key elements of bot behaviour, namely:
        -    Increases bot reaction times.
        -    Reduces bot route calculation delays.
        -    Improves bot perception of techs & flags.
        There is, however, a minor CPU overhead, and on slower processors (less 
than 200MHz)
        there may be some jerkiness or other noticeable slowdown. For this 
reason, bot_aim is not
        enabled by default. Try both settings at the consloe. bot_aim should be 
enabled if possible,
        as it will ultimately render a more challenging ICE opponent.
 
 


================================================================================
VERSION HISTORY
0.2

Much improved obstacle handling (other players, corners ...)
CTF flag carrying bots will try to run backwards and engage the enemy from time to time 
when being pursued. They particularly like dropping pineapples...
CTF Squadron forming is tighter and smarter, bots will get out of your way  if obstructing
 your path.
CTF As well as arming up, Baseguards now roam for other items within the local vicinity
 of their flag (without compromising base defense).
Railgun fire is no longer disproportionately good when used by bots with high accuracy
 skill.
CTF Bots won't mess about with grapple near enemy base when they have the flag 
(unless really necessary!) but will return to home base directly.
CTF Baseguards won't grapple too much around the flag area.
CTF Bots drop from grapple when hurt by another player - instead of resisting pain.
CTF map rotations now complete properly. Bots reload automatically.ICE performs more
 rigorous check on map type (DM or CTF) and switches game  mode accordingly 
(ie CTF or not CTF)
'bot_pause' and 'bot_invisibility' are now regular server commands (not  toggles) which 
allows them to be disabled for client use with the  client_commands server setting. 
New Auto Grapple. ICE already supports variable grapple fire speed. It now 
 allows the grapple to be used concurrently with another weapon (as in LMCTF).
 Optionally fire the grapple whilst still using your active weapon (and without 
 actually selecting the grapple as a weapon first). 
 The bots will use auto_grapple themselves and attack you whilst grappling!
Bot Velocity (running speed) is now configurable using 'bot_velocity'.
 
0.3
ICE bots go to Hollywood with the all new ICE CAMERA. 3 modes of viewing: Hollywood, Eye
& FreeMouse
Use fire button and inventory keys to move through the bots. See 'cam' command below.
Dedicated Server Support: With prefix 'sv ', key bot commands can now 
 be called from a dedicated setup. Loader.cfg commands set by ICER will also
 run properly now, also employing 'sv ' format (see Dedicated Server section below to
 see which commands now have dedicated alternatives)
NEW CTF commands - these are *POWERFUL* and give you serious control of your 
 team. Please read the detailed section on each command! They are:
  - arm_me:	All available Roamers will bring ammo to you, wherever you are,
                  	wherever you go.
  - follow_me:	Anyone under your crosshair will be recruited to follow you 
	          	immediately. Includes the flag carrier!
  - support_me:	*All* members of your team will drop what they are doing
                                and come to your aid.
Fixed sound support for non-standard models (PPMs) (NB as ever, PPMs must 
 have their own sound files in the appropriate folder)
Removed Bot Weapon Limit, refined it to a true Weapon Preference so ALL bots
 will now use ALL weapons (with degrees of skill ranging from 'clueless' 
 to 'frightening') Renders a more dynamic game...
CTF skin/model support fixed.
Moderated ICE aiming of HyperBlaster, ChainGun, and RailGun (again!).
Dead bot bodies can now be gibbed!
Fixed Hyperblaster fire which was actually a fastblaster!
Scroll CTF 'strategy' screen using inventory keys when you have more than 
 6 teammates. See below.
Fixed "Gun" sounds.
Improved 'incoming' projectile avoidance.
There is no longer an overflow limit on Obituary messages - so they should
 ALL appear. Any problem with overflow? Let me know...
You can now add unlimited messages to the chat.cfg file - all categories.
Capturelimit will now rotate maps as well as fraglimit and timelimit.
 Set it in ICER.
Bots crouch in low headroom areas.
Reporting bots salute more conservatively!
New commands 'hideglow' and 'showglow'. The blue glow on certain items which 
 indicates that bots will get to these items using 'unconventional means'
 can be hidden or displayed with console commands 'hideglow' and 'showglow' 
 respectively. in 0.3 the glow is now DEACTIVATED on 'complete' routemaps.
New command 'bot_gloat_glow'. You can prevent ICE bots from flashing blue 
 after they score a kill, using 'bot_gloat_glow'. 
 Default is 'bot_gloat_glow 1' which is ON.
Fixed shallow water handling. Only applies to routes created using ICE 0.3 
 and later. Applies to all routes included as part of ICE 0.3 complete
 download.
Improved bot handling of doors.
Important CTF 'order' messages are now printed centrescreen.
Converted documentation to much nicer HTML format. Thanks Jinx.
Bot names in bots.cfg can be UPPERCASE and lower case (or AnY cOmbinAtioN)
In fact you could always do this, though the notes said you shouldn't!
Added Teamplay 'join' command to simplify joining and changing teams for 
human player.
 
================================================================================
FAQ
Q:    ICE just doesn't work. Why not?
-or-
Q:    When I type bnum or bload in the console, nothing happens.
A:    Firstly, check to see if there is a gamex86.dll file in your quake2 
folder. If there is, remove it, 
       rename it or delete it.
       If that doesn't apply, check your folder structure. The ICE folder must 
be in the QUAKE2 folder.
       ICER should be in the ICE folder (if you are using it) eg 
c:\quake2\ice\icer
       Finally, what version of Quake2 are you running. Make sure that you have 
the v3.19 point
       release installed BEFORE you install ICE. If you've upgraded Q2 after 
installing ICE, reinstall the 
       ICE zips.
Q:    The bots seem to carry a large white diamond shaped object instead of a 
weapon. Why?
A:    You have enabled Viewable Weapons, but haven't copied the viewable weapons 
.pak file
        to your ICE folder. If you are using custom models (eg. not Male/Female 
or Cyborg) then 
        they must have their own viewable weapons models in their own model 
folder (see previous Q)
Q:    When I start the game, it stops, and gives me the message: 
            "ERROR: Game is version 3.xx not 3.yy"
       Why is this?
A:    See above. You must have version 3.19 of Quake2 for ICE to run properly.
Q:    None of my custom models appear in the game. Instead the are all bald, 
male players.
A:    Have you installed the models in the quake2\baseq2\players\<modelname> 
folder? Each model
       must have its own folder, and the folder must also contain the sounds for 
that model,
       or they will use the default male sounds.
Q:    What are these kw_ skins?
A:    I am distributing Grimlock's Coloured Skin Pack with ICE so that teams of 
ICE players can each
       sport the same clothing in a Teamplay game. The kw_ files (eg. kw_blue, 
kw_green) are all
       copied to your quake2\baseq2\players\<male/female/cyborg> folders when 
you install ICE.
       This means that you can compose teams of Males, Females and Cyborgs and 
they can all
       have the same skin colour. This is not possible with the basic skins like 
Viper and Sniper 
       that come with Quake2.

Q:    I started the game, but where are the ICE bots?
A:    Use bnum <number of bots> -or- bload <bot name> to load some bots from the 
console. Read
       about these commands above.

Q:    The game is a bit jerky for the first few seconds. Why?
A:    This is normal. When Quake2 starts, ICE loads the route table for the map 
you chose,
       and then loads any bots in loader.cfg. This is demanding stuff. The 
jerkiness will pass in 
       a minute.

Q:    When I load a CTF map, no flags appear. Why not?
A:    You must add +set ctf 1 to the command line, or designate the map you are 
loading as a CTF type
       map in ICER.
       ICE will try and determine the gametype automatically when the map is 
loaded (ie CTF or not) 
       but it is best to use the correct command line/ICER setup. If you are 
creating a route for a new CTF
       map, then when the route is complete, you should reload the map before 
playing it.

Q:    My friend wants to join me in my ICE game. Can he do this over the 
Internet?
A:    Every time you play a standard ICE Quake2 game on your pc, you are 
actually running your
       own server. If you are connected to the internet whilst running the game, 
you will have an
       IP address - something like 198.162.166.222
       If your friend knows this IP, he can connect to your game with a shortcut 
that looks something
       like this:
            quake2.exe +set game ice +set game deathmatch +connect 
198.162.166.222
        Both players must be online for this to work. You can also use the 
connect option in ICER 0.2
Q:    I want to play a map that isn't yet supported in the ICE download. Where 
can I get routes from?
A:    There are a number of sites dedicated to providing routes for bots. Check 
them out. Or create 
       your own. Check out the instructions above.

Q:    Can I use routes from other bots with ICE.
A:    Nope. ICE navigation is unique, the routes have to be created from new.

Q:    When I use ICER, I get the message "Can't find [BOTS] header". Why?
A:    The bots.cfg file MUST contain this exact line BEFORE the list of bots 
starts:
            [BOTS]
        Reinstall the file if you have to.

Q:    When I use ICER, I get the message "Can't find file or file in use". Why? 
A:    Make sure that the following files are in your ICE folder:
            bots.cfg
            chat.cfg
            maps.cfg

Q:    Sometimes the screen freezes and the message "SZ_getspace" appears. What 
does it mean?
-or-
Q:    The game is crashing with the error: "No more free edicts". Why?
A:    This should only appear if Quake2 is low on memory (shut down ALL other 
apps when running ICE)
        -or- there are just too many bots loaded for the game to cope with. To 
give some idea of what is 
        reasonable, my AMD K6 200MHz with 32MB RAM will play 20 DM bot no 
problem.
        It could also happen on a very large map containing lots of items. But 
I've never seen it...

Q:    When I connect to an Internet server, I can't load any ICE bots. Why not? 
I used ICER.
A:    You can't load ICE bots on a server that isn't running the ICE mod itself. 
Contact
        the server administrator, or run your own ICE server and have your 
friends connect to it.
        (see above for details)

Q:    When I set fraglimit/timelimit/capturelimit, I don't see any ICE bots. 
When the map changes.
        Why not?
A:    You MUST set map_change 1 (see above for details)

Q:    This long list of Q and As still hasn't fixed my problem. What should I 
do?
A:    Write to me at the email address above. Provide as much detail as you can 
about
       what you tried, what your setup is, what has worked and, of course what 
hasn't.
       I reply to all constructive messages.



================================================================================
CREDITS
id Software - of course: 
    http://www.idsoftware.com/ 
PlanetQuake - The ICE Hosts: 
    http://www.planetquake.com/ 
Dave 'Zoid' Kirsch - top CTF: 
    ftp://ftp.idsoftware.com/idstuff/quake2/ctf/ 
Hentai - nice Viewable Weapons:
    http://www.telefragged.com/tsunami/ 
Quake Devels - lots of useful info.:
    http://www.planetquake.com/qdevels/
Quake2 DLLs - lots of useful info.:
    http://www.quake2.com/dll/
Jinx - hours of beta testing, html documentation, chat.cfg & creative input.
Grimlock's essential Coloured Skin Pack.
ALL the other BOT authors out there - for inspiration and some cool ideas - 
especially Ryan 'Ridah' Feltrin.
The ICE Beta Testers - thanks guys.
-&-
Everyone who has emailed ideas & bug reports, especially:
Terry Tor, Darkseid-D, Viper, Adam Ripley, Darrell Bynum
================================================================================

DISCLAIMER

THIS SOFTWARE IS MADE AVAILABLE "AS IS" AND WITHOUT WARRANTIES AS TO 
PERFORMANCE OR MERCHANTABILITY OR ANY OTHER WARRANTIES WHETHER 
EXPRESSED OR IMPLIED. 
NO WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE IS OFFERED. 
THE USER MUST ASSUME THE ENTIRE RISK OF USING THE PROGRAM.
Please bear in mind that this is a beta release, and is therefore in a 
continuous state of development. It may be unstable, though I am working 
hard to ensure that it is not.
I accept no responsibility for any effect, detrimental or otherwise, which 
the ICE Bot or the ICER Launcher may have on your system, life, etc.
Other than that, enjoy.

================================================================================
COPYRIGHT

The ICE bot and ICER: the ICE bot Launcher are Copyright (c) jibe 1998.

================================================================================
DISTRIBUTION

Feel free to distribute this archive subject to the following
conditions:
1. it remains PERFECTLY intact, as distributed on my web page:
   http://planetquake.com/ice
2. no money exchanges hands as part of the process.
3. any subsequent transfer of this software to another party must include
   their acceptance of the conditions stated under the disclaimer above.


















