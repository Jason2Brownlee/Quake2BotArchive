ACE (Artificial Control Experiment) 
A Quake2 BOT
----------------------------------------------

Current Version:
----------------
Preview Version 0.05


Instructions:
-------------

Extract all files to a directory beneath your quake2 installation named "ace" and 
then run quake2 with the command line:

quake2 +set game ace +set deathmatch 1


ACE Commands:
-------------

cmd addbot <skill> - add a bot skill = 1 to 3 (3 highest)
cmd removebot <name> - remove a bot.
cmd savenodes - save the nodes to a file. (will fix this later to automatically save)
cmd learn <on|off> - turn dynamic learning on or off.
cmd botbrain <on|off> - replace player control with bot control.
	

Major Changes:
--------------

Version 0.05 (released)
	- New updated "vision" code (almost correct, still needs tweaking)
	- Skill Levels added.
	- Stubbed out decision making logic "What to do next?" (simple for now)
	- Dynamic Learning (bots will get better the more they play a map)
	- Updated to 3.13 (used patch not ID src, come on ID release it already!)

Version 0.04 (never released)
	- Dynamic pathing.
	- Load/Save pathing information.

Version 0.03 (never released)
	- Node logic added.
	- Respawning after level changed fixed (delayed re-entry)

Version 0.02 (released)
	- First preview release


Future Goals:
-------------

The dynamic learning code is quite simple now. It will require a bit of work
to get right, so expect a few version changes.

I am also planning on releasing this bot as a .lib file so that other mod
authors can use this bot with their mods. Or even combine it with another
bot mod like Oak (John C. and I have talked about this)

The .nod files that are written with the "cmd savenodes" command will
include the current state of the bots knowledge of a level. This will 
allow you to train the bots specifically for each level. The more they
train, the smarter they will get (given certain limitations of course!).
This links in with the dynamic learning routines, that will constantly 
optimize the bot's "intelligence". For the next couple of releases
do not assume that the format of the file will remain constant. I may
need to add or remove from it (you have been warned). 

Limitations:
------------

Currently there are some limitations of this bot. Swimming, ladders,
elevators, transporters and lava are the current limiations. Hopefully 
I'll get these fixed in future versions. I also have not added name/skin 
functionality yet. I plan ondoing that with my next release. 


Background on ACE:
------------------

This bot is basically a testbed for some AI code I wanted to write.
Currently it is a server side bot, using the client movement controls. 

There are many things that are still hardcoded into the dll, such as name,
skin choice, skill level, etc that will be user configurable at a later
date.  The bots currently use all weapons and do try to use the right weapon
for the job. They are basically client-command controlled, so they all move,
show up on the scoreboard and move between levels in dm games similar to
normal players, they even have varied pings.

There is a special "Botbrain" function that will take over player control.
Turn it on and watch the bot in action. (Even your buds can log into a
server and use this function for autonomous play). But be warned, you might
get a little motion sick until I dampen the bots movements in a later
release.

Skill Levels:
-------------

In version 0.05 I have added skill levels, skill level 1 is basically just a good
target. It will still rack up some gibs, but does not use dynamic learning, or 
pathing, and can miss a few shots every so often. Skill level 2 does use dynamic
learning, but not pathing, and is more accurate with its shots. Skill level 3 is
the most advanced, it uses dynamic learning, pathing and is a crack shot. These
skill levels are subject to change in the future. I plan on adding a few more
skill levels, so as I make the bots smarter, the skill levels will get higher. 

Contacting Me:
--------------

Steve "aka Meat"
stevey@jps.net


Finding ACE on the web:
-----------------------

web site:	www.quake2.com/oak/ace.html


Legal Info:
-----------

I = Steve Yeager (stevey@jps.net)

NO WARRANTIES. I am providing this software as is, without
warranty of any kind. I and all my suppliers disclaim all warranties,
either express or implied, including, but not limited to, implied warranties
of merchantability and fitness for a particular purpose, with regard to the
ACE Bot and any other software included in the distribution
package or archive.

NO LIABILITIES FOR CONSEQUENTIAL DAMAGES.  To the maximum amount permitted
by applicable law, in no event shall I or its suppliers be liable
for any damages whatsoever (including, without limitation, damages for loss
of business profits, business interruption, loss of business information, or
any other loss) arising out of the use of or inability to use this 
product, even if I have been advised of the possibility of
such damages.  Because some states/jurisdictions do not allow for the
exclusion or limitation of liability for consequential or incidental
damages, the above limitation may not apply to you.
