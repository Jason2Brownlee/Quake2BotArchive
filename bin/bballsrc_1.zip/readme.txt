Here's the source code for Quake 2 Basketball, by Matt Shade.
This is the code from version 1.00.

Do with this code as you wish, but it would be nice to give me
credit if you use my code and ideas.

s_cam.c was done by Stonelance and whoever he got it from.
	I did make a few changes to it though.

q_devels.c and q_devels.h were done by people at qdevels, at
		http:\\www.planetquake.com\qdevels
	I think I modified these files some too.

Read license.txt and follow the rules please.

Quake 2 Basketball is in no way associated with Id Software, and
is not supported by them.