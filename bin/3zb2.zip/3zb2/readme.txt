Unzip this archive to your 3ZB2 folder, or to whatever folder you run 3ZB2 in.

DO NOT UNZIP THIS TO YOUR BASEQ2 FOLDER!!!



One new feature has been added to this DLL- a modified extra gibs option, based on code by Octavian Briceag.

To enable this option, set mega_gibs to 1.
