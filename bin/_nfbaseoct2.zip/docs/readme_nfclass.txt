This is a readme that tries to explain how the nfclass files 
work. It is here to make it easier for you to modify the
existing classes and even add new ones. 
If anybody creates a new and unique class file just send it
to us. We might use it as the original one. 
The current Classes are based on the classic TF classes.

The first class is always used for DM / Singleplayer and it 
will be ignored in Teamplay games. The last class has to be
either the hunted (SEALs) or the VIP (TANGOS).

To start a class you have to open it with { and close it 
with }. These brackets have to be added. They seperate the
classes from each other.

Every field has to be followed by a value or a string.
I will explain every single field from the top:


classname
---------
This is the name the class has. 

underwaterair 
-------------
How long the Class can stay underwater (in seconds). The 
default is 10.

speed
-----
The Class Speed. WE recommend not using values greater than 1.
This causes some really wierd bugs.

resistance 
----------
The armor of that class has special resistance to (FIRE, NONE or
EXPLOSIVE). FIre means that that class takes less damage from
flames and can't be set on fire. EXPLOSIVE reduces the amount
of damage taken from blast weapons.

jump 
----
How high the class can jump. 1 is the default.

classabilities  
--------------
Classabilities, are defined like Spawnflags. To give a class more 
specials simply add all the following values together and type 
them in after "classabilities" 
The "CAN BE ??" Values have to be added to the same field. They are
important for some game-modes. 
Default is 0

These are the possible Abilities:
	NO SPECIAL ABILITY	0	
	CAN ZOOM WITH AT4	1
	CAN USE SCANNER		2	
	CAN THROW CALTROPS	4	
	CAN USE LASERGUIDED ROX	8
	CAN THROW KNIFES	16
	CAN PLACE SENTRYGUNS	32
	CAN PLACE HEALDEPOTS	64
	CAN PLACE AMMODEPOTS	128
	CAN PLACE DETPACKS	256
	CAN DISGUISE SKIN	512	
	CAN FEIGN DEATH		1024	
	R E S E R V E D		2048
	NIGHTVISION GOGGLES	4096
	AUTO ZOOM WITH SNIPER	8192
	CAN USE TURRETS		16384
	CAN ZOOM WITH SNIPER	32768
	LASER SIGHT ON SNIPER	65536
	HEAL OTHER PLAYERS	131072
	ABLE TO DISARM DETPACKS	262144

	CLASS CAN BE A HUNTED	524288	
				- SEALS ONLY - This class will be the Hunted
	CLASS CAN BE BODYGUARD  1048576	
				- This class can be selected as bodyguard
				   if Seal, then in Hunted mode,
				   if Tango, then in PTV Mode
	CLASS CAN BE AN ASSASIN 2097152	
				- This class can be selected as Assassin
				   if Seal, then in PTV mode,
				   if Tango, then in Hunted Mode
	CLASS CAN BE A VIP	4194304	
				- TANGOS ONLY - This class will be the VIP

health  
------
Defines the health that class starts with. Default is 100

max_health 
----------	
Maximum Health the Playerclass can have. Default is 100

max_inventory
-------------
The following fields are all possible ammo maximums.

max_shells 		<---Shells
max_rockets    		<---Rockets
max_grenades   		<---All types added up (including 40mm)
max_cells		<---Flamer Canisters
max_357cal 		<---Magnum Bullets
max_45cal 		<---Pistol Mags
max_9cal 		<---Submachinegun Mags
max_556cal		<---Assault Rifle Mags
max_308cal 		<---Sniper Rifle Mags
max_762bb 		<---Machinegun Bullet Belts

armor
-----
The following fields are all the amount of armor one location has.

kevlar_trouser 
kevlar_vest 
combat_helmet 
	
inventory 
---------
To give a certain class a certain item you have to enter the following
line:

inventory <classname of the item given> <how many items>

starting_weapon 
---------------
Enter the classname of one of the weapons possesed by that class. It
starts with this weapon in its hands.



if you've got questions / bugs mail me here using this address:

Defcon-X@Planetquake.com

-defconX