Navy Fortress Class Creator
---------------------------
   unofficial version

This is an utility created by defcon-x for use by team-mirage members only. 
But for your comfort, we decided to put it in every _nfbaseXXX.zip file. 
It might have a few bugs and you will need a Win9x / Win NT Machine with 
the Microsoft Foundation Class Runtime DLLs installed. 
Sorry but there is NO Linux Port!


The Utility is pretty self expanatory, but some functions are explained here.

Save to Memory           -       Means that it will save the current class to memory. 
				 (will be done automatically when you change the class)
Write Out                -       Will save your current classes [nfclass_seals.cfg _tangos.cfg]
About                    -       Will display the Aboutbox and Additional Programm information
Load Config              -       Will load the config. The default is seals.
				 To load in the Tangos you have to change the config over menu!
Quit                     -       well... quit. YOu have to do it that way because for some odd 
				 reason the small "x" doesen't work.

Load Config              -       See the Buttons Section
Change active Config 	 -       Changes the Active config [default: Seals]
Write Out                -       See the Buttons Section
Quit                     -       well... quit.

Known Bugs:
The Small [X] in the Top Left Corner doesn't work... Don't ask me why... 
Maybe I'll fix it sometimes, but I don't think that it is important.

Additional Important Information:
This is Gift-Ware! You could support me (the author) by sending some money to me. 

For more Informations contact: Defcon-X@Planetquake.com. 
I'm spending lots of time on Navy Fortress. So you could do me a small favor and send me 
your old PC stuff or some Money in order to keep me motivated :)


-Manfred 'Defcon-X' Nerurkar