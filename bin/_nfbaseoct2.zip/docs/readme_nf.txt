 Navy Fortress v0.98
------------[by Team Mirage]---
  	    
First off:

UNZIP ALL FILES YOU EVER GET FROM TEAM MIRAGE (THAT ARE ABOUT NAVY FORTRESS)
TO YOUR QUAKE2/FORTRESS DIRECTORY NOT TO QUAKE2/ !

If you want to play Navy Fortress on your PC you need a completly installed and running copy of Quake II from id software. Your Quake II has to be version 3.20. If you don't know where to get an update to 3.20 from try www.idsoftware.com or the fileplanet. 
If you fulfill these conditions you can properly install Navy Fortress. 

Navy Fortress comes in sets of three different zip-files: 

There is one zip-file containing the heart of our mod (the game86.dll) as well as all configs, this file is called _nfbaseoct.zip. The document you are reading belongs to this file.

Then there is a zip-file containing all graphics (models of the weapons and items as well as the little pics in the lower left corner etc.) which is called _nfgfxbase.zip. 

Then there is _nfsndbase.zip, this file contains all sounds (weapons, radio etc.). 

And finally (I know i said there were only three... but) there is an optional file called _nfvwepbase.zip. This file includes all PPMs (Plugin Player Models: the guys you play) as well as full View Weapons support. 

To install NF you will need a programm to extract a valid zip-archive. The most famous of these programs is Winzip. All of these files have to be extracted using the given paths into your Quake2 folder, so that there is a "fortress" folder under your normal Quake2 folder. 

In the end there have to be a lot of sub-folders under "fortress" which should be "models" / "sounds" / "docs" / "config" / "pics" / "route" / "sprites"... If i have not forgot anything these directories should have been created by your zip-extractor.


Following you will find a list of the most important commands.
To take a look at all commands that you are able to use reade the manual.

reload - Reloads the current weapon with the appropriate ammo type. This may take some time, depending
	 on the weapon reloading. If a weapon using clips has some ammo left while reloading, then this
	 ammo is lost, as the used clip is thrown away and replaced. You can even throw out full clips,
	 if you want to.Some Reload phases (like putting shells into the shotgun) can be interrupted by
	 firing. 
	 [default Key: R ]

door - Opens the door in front of you. After using the comand you have to wait soe time in front of
	 the door until it opens. Doors never squish you. 
  	 [default Key: SPACE ]

bandage - Let's you bandage your wounds. Although it does not give back health (only the Combat Medic
	 can do this) it removes bad side effects such a bleeding or hurt legs. While you bandage
	 yourself, which takes X seconds, you can only move at slow speed and you can't fire any weapons.
	 [default Key: Q ] 
	
weaponmode - Some kind of all-in-one-command. Depending on the weapon you are holding in your hands
	 it uses another command. If you are holding a Submachinegun or an Assault-Rifle it uses the 
	 command <firemode> to toggle between full-auto and 3-round-bursts. If you are holding the at-4 
	 you will toggle between laserguided rockets and normal ones by using <rocketmode>. If you are 
	 holding the knife, it will use <knifemode> to toggle between stabbing and throwing. Holding a 
	 snipergun while using this command will scope as if you used the <scope> command. Some of these
  	 sub-commands can only be used by certain classes. This command is very useful for Deathmatch.
	 [default Key: CTRL]
 
flare - Drop a flare, normally you've got 2 flares but you can configure that server-side. 
	 [default Key: Y ]

medic - Lets you call for medical attention. You will flash up red for 2 seconds, and you will call for
	 a medic using a sound and all members of your team will see that appearing on their screen. 
	 [default Key: V ]

compass - Toggles the compass on and off. The compass automatically aligns itself to the upper left
	 corner of the screen. 
	 
mradio <Message> - Broadcasts a Radiomessage to your team mates (use: <mradio lets kick ass>) For a list
	 of all possible words take a look at the fortress/sound/radio/male folder. 

wounds - Displays your current wounds (Leg damage, stomach-damage etc.). This command is built in to be
	 used in software mode, in which the little green man for your health dissapears. 

changeclass - Brings up the Class-selection-menu which allows you to change your class. You will be the
	 new class upon resapwning. 

team - Teamname can be either: "seals" or "tangos". This command will let you suicicde (-1 Frag) and
	 respawn as a member of the chosen Team, though you will remain the same class as before. If you
	 wish to change class and team, then use the <Changeclass> command before using the <Team>
	 command. 
