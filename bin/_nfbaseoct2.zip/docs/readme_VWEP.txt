      the View Weapons pack for Navy Fortress
      --------------------[by Democritus]----


So you are reading this? cool. 
But let's get to the point:

This pack includes View weapon support for the 6 different
PPMs (Plugin PLayer Model) used by Navy Fortress, which are:

male     - The Original Quake 2 Male by Id Software 
female   - The Original Quake 2 Female by Id Software
amber    - A great female model by EvIlBastArD
terror   - A simple but well-known model by Gooseman
Nightops - Also known as SAS. Done by Hitman DAZ
Civi	 - The Hunted / PTV PPM (Defcon called him "Special")

This .pak-file includes all necessary files to support full
VWEP. This means that there are a lot of weapons and a lot of
animations. I tried to keep the poly count low, but as I used 
the original weapons instead of some really simplified ones, 
the Poly-count may be rather high on some weapons (The PKM for
example) but as you all are already upgrading your PCs for Q3
this shouldn't be that much of a problem.

This .pak also includes the PPMs with the skins required for
NF Teamplay. They are called "nf_seal" or "nf_terror" for the
normal PPMs and "hunted" and "VIP" for the special/civi-PPM.
I also have included two skins for amber, which I did some 
time ago. They are called "Quicksilver" and "Quicksilversexy"
and I did them after a Shadowrun Character of me. I hope you
like them. 

I have removed some detail from the weapons but they are all
linked to the original skins (the g_ variants.) which also
reduces the size of this .pak-file. There are no death 
animations (No 173-197 I think) because in these frames the 
Weapon dissapears. This should also decrease the size a bit.

I took me quite some time to finish this Vwep set and I hope
you like it. Some animations (especially the idle of male and
terror) are a bit "fudgy" but I don't think this is that much
of a problem (Dej� vu). 

Well that's all. If you have any questions, then just e-mail me
at [Democritus@planetquake.com]

and for all those greenhorns out there: 
 To activate VWEP type <set view_weapons 1> in the console.


Credit whom Credit is due:

Male 	- Id Software
Female 	- Id Software
Amber 	- Brian 'Evilbastard' Collins
Terror 	- Gooseman
SAS 	- Darren 'Hitman Daz' Patternden
Civi 	- Stecki

Weapons - Rattler, Serial Killer and me
Skins   - and me 
Anims	- uh, and of course me again ;-)


And a list of all NF weapons included:

g_grenades.md2	- Used for all grenade types + the lasertraps
w_knife.md2	
w_pistol.md2	- Used for mk23, mk23sd and mk23 akimbo
w_pisol2.md2	- Used for 92f, 92fsd and 92f akimbo
w_colt.md2	- Used for the S&W 586 and the S&W 66
w_mp5.md2	
w_uzi.md2	
w_ump.md2	
w_mac10.md2	
w_m16.md2	- Used for the M4 and the M4+M203
w_ak47.md2	- Used for the Ak47 and the Ak47gl
w_druganov.md2	
w_sniper.md2	
w_m60.md2	- Used for the M60 and the PKM
w_model37.md2 	
w_moss.md2	
w_flamer.md2	
w_glaunch.md2	
w_at4.md2	
