//===========================================================================
//
// Name:         bl_cmd.h
// Function:     bot commands
// Programmer:   Mr Elusive (MrElusive@demigod.demon.nl)
// Last update:  1999-02-10
// Tab Size:     3
//===========================================================================

qboolean BotCmd(char *cmd, edict_t *ent, int server);

