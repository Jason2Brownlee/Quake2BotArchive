BorrAdor BoT 2.1 is a modification of the Eraser Bot, by Siro (smateosd@nexo.es), aka BJAM.

The Eraser Bot was written by Ryan Feltrin. Please refer to the original documentation "readme_eraser.txt".

I've been very busy since the last release 2.0, so I decided to stop development for BorrAdor, and publish the 2.1 as the "last version", in which I fixed a bug with maps converted from QuakeI and make a more convenient standalone distribution, which does not depend on the original Eraser distribution. If I recieve enough requests, I will also release the source code (it's pretty messy at the moment).

The installation is quite simple: just unpack the .zip over your quake2 directory (it will write some quake2\baseq2\players files and create the quake2\borrador subdirectory), and edit the quake2\BorrAdor shortcut to match the correct quake2.exe path and start directory. The command line should be something like "X:\quake2\quake2.exe +set game borrador +map base1 +bot_num 5". It have been tested with Quake2 3.20, but it should work with version 3.14 or higer.

The route files are in BorrAdor2.1-routes.zip. The zip includes routes for the best maps for BorrAdor. Eraser routes are completely compatible.

Improvements made on BorrAdor 1.0 for BorrAdor 2.0:
 * New code for strafing rockets and grenades made generic, so bots now can also strafe laser bolts and crouch, based on CombatSkills settings. This make the game more difficult.
 * Improvements made on jumps, so bots are less prone to do "back flip into the lava". They also fight to leave such a lamentable situation jumping, screaming, shooting... really dramatic.
 * Now proyectile speed is relative to the shooter, for rockets, grenades and blasters. I think this can improve the gaming experience with some falcon-like high-speed-falling rocket shoots.
 * Fixed a compiler bug with random numbers and optimizations.
 * More little changes/fixes, like taunting, "human-like" react time...

This is the list of most of the improvements and fixes on Eraser made for BorrAdor 1.0:
 * Fixed a bug that crashed Eraser when rocket explosions reached many people (in fact, BorrAdor hasn't crashed any more under WinNT).
 * Better ammo collection.
 * High precision (nearly state-of-the-art :-)) grenade launching.
 * More complex aiming method, now depends on relative speeds.
 * Now Aggressiveness and CombatSkills settings are more important in bots' behaviour.
 * Now skill setting is less important.
 * Most of the weapons has been modified, for better and more spectacular fun (now Quad is "really Quad").
 * Now weapons are nearly equal for bots and for humans.
 * A ton of little changes ("better" button handling, source code formatted with GNU indent...).

Have fun, and remember: you are the human...
