// ******************************************************************** //
// *                                                                  * //
// * Tangential Quake II Module                                       * //
// *                                                                  * //
// ******************************************************************** //


===============
= Information =
===============

File       : Tangential_100.zip
Version    : 1.00
Date       : 01 Feb 1998
Author     : Tangent-
Email      : yuen@ug.cs.dal.ca
             ayuen@fastlanetech.com
Web site   : http://www.geocities.com/SiliconValley/Lab/3733/tangential.html


===============
= Development =
===============

Time       : [1.00]   1 hour
             ---------------
             Total:   1 hour

Tool(s)    : Visual C++ 5.0 Professional Edition

OS         : Windows95
             WindowsNT 4.0 SP3

Feature(s) : 1. [1.00] Swinging grappling hook

===========
= Content =
===========
        Readme.txt              - This file
        gamex86.dll             - The game DLL
        Tangential.cfg          - The default configuration file

        /sound
        GrappleHook_Attach.wav  - GrappleHook sound file
        GrappleHook_Detach.wav  - GrappleHook sound file
        GrappleHook_Damage.wav  - GrappleHook sound file
        GrappleHook_Grow.wav    - GrappleHook sound file
        GrappleHook_Shrink.wav  - GrappleHook sound file

        /models/items
        GrappleHook_Chain.pcx   - GrappleHook skin
        tris.md2                - GrappleHook model


================
= Installation =
================

        Unzip the ZIP file _with subdirectory names_ in your Quake II directory.
e.g. If you installed Quake2 into C:\Quake2, then unzip into C:\Quake2 and
you will get a subdirectory called "C:\Quake2\Tangential".


===========
= Running =
===========

        To run Quake II with Tangential, do:

            quake2 +set game "Tangential" +exec Tangential.cfg

        in your Quake II directory or create a shortcut.


============
= Commands =
============

1. cmd grapplehook <action>

        <action> :  activate   - fire the grappling hook
                    deactivate - disable the grappling hook
                    grow       - extend the length of the chain
                    shrink     - reduce the length of the chain


========================
= Copyright/Disclaimer =
========================

This module was created for my own enjoyment of Quake II.   It is distributed
AS IS and I hope you enjoy it.  I will not take any responsibility whatsoever
for your system crashes, any damage or loss of data due to the use of this
module.  But I guarantee that I have not intentionally added any malicious
content to this module.

This module is in no way associated with id Software.

You may freely distribute this archive, as long as it remains intact.

For commercial distributions or distribution on CDs, please contact me and
get my written permission first.

Enjoy.

Tangent- (yuen@ug.cs.dal.ca, ayuen@fastlanetech.com)

