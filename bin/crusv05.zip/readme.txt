Name of Mod : The Crusader bot, for Quake II
File Name   : crusbot.zip
Version     : 0.51
Date        : December 29, 1997
E-mail      : fcc_ova@arsystem.cz
Web Site    : http://www.quake.czt/bot/default.html

AUTHOR INFO
-----------
My name's Mark Rabas and working as programmer in MSVC 5.0 (NT4.0) on real-time-software.

TYPE OF MOD 
-----------
DLL      : Sure thing.
Sound    : Not yet.
MDL      : Not yet.
Maps     : Not yet.
Graphics : Not yet.

FORMAT
------
I compiled this with MSVC 5.0.

INSTALLATION
------------
Copy the gamex86.dll file over your existing one, or create a new directory
off of your Q2 dir, put the gamex86.dll file into that directory and add
"+set game <dir name>" to your Quake II command line.

COMMANDS
--------
Type deathmatch 1 then map <mapname> at the console, then type "cmd bot" at the
console to add a bot. You can add 6 bots. Example:

deathmatch 1
map dm6
cmd bot
cmd bot

COPYRIGHT/PERMISSIONS
----------------------
If you somehow get a hold of the source code for this mod and decide you're
going to do something with it, like make your own mod off of it, I don't
mind, but please give me credit for it in some way, and ask me first. Thanks.
This mod is in no way associated with id Software. E-mail fcc_ova@arsystem.cz 
with comments and questions. This mod may be distributed on CD, but only after
you've gotten my permission. You may not distribute this mod without including 
this text file.

