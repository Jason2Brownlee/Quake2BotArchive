// HOLYWARS II
// load map list

int     CNF_MAP_LoadMapList(void);      // loads the list from the file
char   *CNF_MAP_LoadNextMapName(char *current_map, int client_num, int med_ping, int n_map);
char   *CNF_MAP_LoadMap(char *current_map, int client_num, int med_ping);





