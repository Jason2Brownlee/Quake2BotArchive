/*---------------
 * Holy Wars II (the revenge !)
 ----------------
 */

// HERESY CALC. externally called functions

void HW_Heresy_MainCalc(edict_t *dead, edict_t *killer, int mod);
void HW_Heresy_SaintKilled(edict_t *killer);


