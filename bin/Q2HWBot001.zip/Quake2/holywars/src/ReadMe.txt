Quake 2 HolyWars ACE Bot release notes
======================================

	$Author:$
	  $Date:$
   $Version:$

This is a quick and dirty port of the ACE008 source code into the 2.21 HolyWars for Q2 source. I have made all the prints in the game "bot safe", taught the bots to collect the halo, removed the CTF stuff from the bot AI and taught them the HolyWars rules.

They play a pretty good game and as the mod is so much fun, I really enjoy running this mod. The full source code is included. To use the mod you need to download the 2.21 HolyWars files from their site (http://www.planetquake.com/holywars/) to get all the special maps, etc., that make the game so much fun.

You can play it on the normal Quake 2 DM maps, but it's not as good since the HolyWars maps are designed for maximum mayhem!

RiEvEr..
http://www.planetquake.com/redemption/


Improvements as they are added will be logged below this line so if you find that sort of stuff boring just don't read it :)
-----------------------------------------------------------------------------------------------

$Log:$

