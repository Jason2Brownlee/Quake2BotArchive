Name of Mod : DroneBot
Author      : XoXus
File Name   : dronebot.zip
Version     : Gamma 21
Date        : April 24, 1998
E-mail      : xoxus@usa.net
Web Site    : None.


TYPE OF MOD
-----------
DLL      : Yes.
Sound    : Grappling Hook only.
MDL      : Grappling Hook only.
Maps     : No.
Graphics : Console background.


CREDITS
-------
id Software     - Who else could make the 3 most historic games in gaming
                  history? (I'm talking about Wolf3D, Doom and Quake)
Yaya (-*-)      - Scanner code and graphics
John Crickett   - Inspiration for the bot
Jagasian        - Helping me fix the bot solidity problem


INTRO
-----
The DroneBot is a simulated deathmatch opponent for Quake2. Unlike other
available bots it will not simply copy the player's movement around a level,
but will use its own vision to navigate and attack the player. Some consider
copying the player's movements to be "cheating". This is not my opinion, but
I feel that it is probably a little less than honest.


INSTALLATION
------------
Put dronebot.exe into your quake2 directory (e.g. "c:\quake2"). Run it, and
it will create a directory called "dronebot". Just add "+set game dronebot"
to your Quake II command line to run it.


CONSOLE COMMANDS
----------------
"botmenu" -     This will pop up a menu allowing you to change settings and
                do things with the bots.

"scanner" -     Toggle the scanner

"botcam"  -     Toggle the BotCam


This mod is in no way associated with id Software. E-mail xoxus@usa.net
with comments, questions and suggestions. 


SUPPORTED PLUG-IN MODELS (number of skins in "[]" brackets)
------------------------ (alphabetical order)

* AstroBoy (Jonn Gorden) [2]
* Bananas In Pyjamas (GaratJax[B5]) [1]
* Boba Fett (Dan Bickell) [3]
* Cereal (Dave "HotFat" Biggs) [5]
* Crackwhore (Paul Steed) [3]
* Dalek (Ryan Dobson) [4]
* Dire Avenger (ALPHAwolf) [2]
* Doom Marine (Treponema "Malekyth" Pallidum) [1]
* Dumb Fighter (Brian Yee) [6]
* Eric Cartman (Brian Yee) [5]
* Garfield (Lars Jensen) [2]
* Kenny (ThargerUS@aol.com) [1]
* Little Grey alien (richb@jarsys.demon.co.uk) [1]
* LegoMan (Paul Burslem) [1]
* Morbo (Rowan "Sumaleth" Crawford) [1]
* QuakeGuy (Rikki "Phukyumoto" Knight) [1]
* R2D2 (osx) [4]
* Raptor (Conor O'Kane) [5]
* Sheep (Richard "GiB" Clark) [3]
* Sideswipe (Jason Seip/Rikki Knight) [3]
* Snork (Kray-Zee) [7]
* Starscream (Rikki "Phukyumoto" Knight) [4]
* Teenage Mutant Ninja Turtle (Henry Yau) [1]
* Winter's Faerie (Brian "EvilBastard" Collins) [4]
* Xenoid (Dan Bickell) [3]
* Zumlin (Rowan "Sumaleth" Crawford) [1]


[ If you have made a plug-in model that is not listed on the above list,
  e-mail me the URL of a download site. Please, DO NOT e-mail me the actual
  model! Thank you for your consideration. ]


KNOWN BUGS (In order of priority)
----------

 (1) The dead player models sometimes sink into the ground.....
 (2) When a bot dies, then later disconnects, the bot's bodies revert to
     the male/claymore model+skin (grrrrrr.....)


UNKNOWN BUGS
------------
If you find any bugs that aren't in the above section, and it's a bug, or you
have a suggestion, PLEASE e-mail me. If it's a bug, include plenty of
information about your computer, it's setup, and what Quake2 settings you've
tried. (E-mail me at xoxus@usa.net)


REVISION HISTORY  (* = release, + = addition, - = other)
----------------
Gamma 21 - STARTED MAJOR REWRITE OF CORE FUNCTIONS
           (Gamma 20 was just WAY too buggy, and badly written)

Gamma 20 * FIRST PUBLIC RELEASE!
         + Added some more plug-in models
         - Fixed up problem of not being able to hit a crouching player
         - The AddBot menu list is generated during InitGame, not every time
           the menu is called (also, the list is now sorted)
         - Made rockets vulnerable, and bots will try to shoot them down %-^

Gamma 19 * Third private release
         + Added support for plug-in models with multiple skins
         + Added a LOT more plug-in models (from Q2PMP1)
         - Fixed the bot solidity problem (no more walking through them!)

Gamma 18 - Rewrote plug-in model support
           (MUCH easier for me to add new models)
         - Finally fixed the RemoveBot menu item
         + Added more plug-in models

Gamma 17 * Second private release
         - Fixed up more vision problems
         + Implemented some nice chatting routines
         + Added the grappling hook
         + Started working on the BotCam

Gamma 16 - Extended the AddBot menu to include plug-in models
         - Fixed the problem of multiple bots having the same name
Gamma 15 + Weapon changing implemented
         - Fixed broken corner avoidance
Gamma 14 * First private release
Gamma 13 + Implemented corner avoidance
Gamma 10 - Weapon pickup works
Gamma 7 - Movement working (runs towards you)
Gamma 5 + Bot_Vision subsystem implemented
Gamma 2 - Respawning working
Gamma 1 + Bot spins and looks for you
        + Will shoot at you, but can't move


Omega 3 - Fixed 'sinking-into-ground' bug
Omega 2 + Bot spawning
Omega 1 + Client emulation up and running


LEGAL MUMBO-JUMBO
----------------------
I, XoXus, am in no way responsible for any harm caused to you, your computer,
or anything else, by your installation and/or use of DroneBot. Use at your
own risk.
