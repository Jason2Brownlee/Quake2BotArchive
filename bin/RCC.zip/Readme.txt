---------------------------------
RCC - Rat-Clan-Center 
---------------------------------


(! Sorry for my school- english)

RCC is a free Quake 2 Server Administration Utility.


Features :

- Shows the ping between Client/Server
- Scans IP's out of every AscII- File
- Launches Quake
- Displays all Models in 3D with OpenGL
- Launches RatBot (Quake 2 Proxy-AutoAim-Bot)

---------------------------------
[RAT] - Clan
members.tripod.com/Rat_HQ
---------------------------------