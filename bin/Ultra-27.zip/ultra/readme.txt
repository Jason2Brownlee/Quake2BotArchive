
 Eraser ULTRA                                v0.27 (Public Beta)
 by Anthony Jacques (aka AnthonyJ)
................................................................

================================================================
Title                   : Eraser ULTRA
Author                  : Anthony Jacques (aka AnthonyJ)
Homepage                : http://ultra.quake2.co.uk/

Description             : Lithium-like game with CTF and Eraser
                          Bot Support, for practice.

Additional Credits to   : id Software. 
                          Ryan Feltrin (aka Ridah) for the 
                          excelent Eraser Bot (and source).

                          Matt "WhiteFang" Ayres for writing Lithium
                          (shame you dont release your source).

                          Charles Kendrick, Rich Tollerton
                          Tim Adamec, Michael Buttrey and Nelson Hicks
                          for ExpertCTF (ie. the grapple code)

                          Nathan O'Sullivan for Zbot detector code.

                          Richard Jacques (Swelter[SLH]), Shryqe,
                          Subhuman and Bong for ideas/testing/encouragement.

                          Credits from the Eraser, which carry through:
                             Jeremy Mappus (aka DarkTheties)
                                for the MapMod source
                             The SABIN Team for some Client Emulation code
                             Steve Yeager (author of the ACE bot) for tips
                                on creating a static library for the nav
                                code (stevey@jps.net)
                             Paul Jordan for the Camera mode
                                (http://www.prismnet.com/~jordan/q2cam)

Build Time              : unknown... 
================================================================

DESCRIPTION

   The Eraser Bot is a simulated multiplayer opponent, for
   use with id Software's Quake2. Lithium II is a very configurable
   server side deathmatch modification for Quake II.
   Eraser ULTRA provides the a similar set of configurable options, 
   however with the added bonus of CTF (Capture the Flag) and 
   Eraser Bot support.

   Unlike Lithium, EraserULTRA is intended for PLAYERS - it is
   not designed for server admins, but is simply for practicing.
   EraserULTRA is not in competition with Lithium because of this.

INSTALLATION

   Just unzip the files contained in the archive, to your
   Quake2 folder, RESTORING PATHNAMES. This means
   that if you're using Winzip, you must enable the
   "Use Folder Names" option when extracting. Pkunzip
   users should use the -d option.

   To install routes tables, after unzipping them put the .RTZ
   files into the quake2\ultra\routes\ directory.

   Linux users should unzip the .rtz files to get a .rt3 file
   before placing into the quake2/ultra/routes/ directory.

RUNNING THE GAME

   As of version 0.27, there are two ways of running the game.
   If "config cycling" is to be used (see below), then use
   a command line such as the one below at either the DOS
   prompt, or in a shortcut to quake2:

   quake2 +set game ultra +exec cycle.cfg

   As with previous versions, a command line such as the
   one below may be used:

   quake2 +set game ultra +exec ultra.cfg

   The ultra.cfg file defines all the many options which
   are available - on standard Lithium servers these options
   are not visible to the client, so you may be suprised at
   the number of options. Because of this, a number of
   preset .cfg's are supplied, with common setups - read
   the options.txt for details.

   The from within the game, type "bot_num X" to spawn X 
   number of bots.

   If you are having problems getting bots to work, I
   recommend that you read the Eraser Bot documentation
   (supplied), or perhaps use a front-end such as Bot Johnny
   or EBS - see the FAQ below for details. 

CONFIG CYCLING

   EraserULTRA is very flexible - you can create configs
   to cover many of the major playing styles, and game
   variants. Because of this, it might be that you want to
   switch between them so that you get to practice all of
   them.

   To allow this flexibility, EraserULTRA comes with a 
   number of pre-built configs (in the configs directory), 
   and a start-up config called "cycle.cfg" which can be
   put on the command line to start a config cycle. This
   will cause EraserULTRA to change config every map to
   the next one in the file "config.lst".

KEY BINDINGS

   It is recommended that you bind a key to the following:
      +hook
         (this fires the off-hand grapple)
      drop tech
         (these drops tech/rune/artifacts)
      drop rune
         (identical to drop tech, so not required)
      drop flag
         (drop a CTF flag, if allow_flagdrop set to 1)
      menu
         (brings up the in-game menu - recommend key is TAB)

SUPPORTED MAPS

   The Eraser is capable of dynamically learning maps, from
   humans whilst playing the game. It is advised that 
   instead of the user teaching the bots routes for all
   the levels, the "route tables" are downloaded - they 
   can be obtained as part of the standard EraserBot
   distribution, and also available for download from the
   following WWW sites:

     http://users.milliways.mg-net.de/fredmr/rfd/
     http://phil.online-kdc.de/philsera.htm 

   To install route tables, after unzipping them put the .RTZ
   files into the quake2\ultra\routes\ directory.

   Producing a good route is an art - a poorly created route
   will suffer from bots being unable to handle some parts of
   the map correctly, or taking unusual routes across the
   level. Ridah made some notes on how to create a good route
   in the Eraser docs, although this wont instantly make you
   able to create the "perfect" route.

   Note that although route tables designed for standard Eraser
   will work with EraserULTRA, bots will not make full use of
   the grapple unless it was built with the grapple enabled.

NEW TO THIS VERSION!

0.27
   Fixed grapple usage - "use_hook" enables a CTF style grapple, "hook_offhand" enables 
   the offhand grapple. Note that you can have both at once! (bots prefer offhand).
   Implemented anti-Zbot code (thanks Nathan O'Sullivan)
   Removed dm/ctf_config - replaced by "ctffraglimit" cvar for CTF mode
   Implemented config cycling - new file config.lst
   Implemented "start_rune" which gives players a rune on startup
   Implemented "allow_runedrop" - if 0, cannot drop runes
   Implemented command "bot_drop_all" to kick all bots (if bot_num set, they reconnect)
   Bugfix: replace_list is now cleared when reloading the list
   Bugfix: vampire rune no longer LOWERS health if above rune_vampire_max
   Bugfix: bot_hyperblaster_damage now works correctly
   rune_flags now implemented
   Picking up the flag now cancels safety mode
   Runes (again) spawn throught the level, rather than just at DM restarts
   Implemented "allow_pickuprune" cvar to allow LMCTF/Lithium style ability to pickup 
   runes/tech's previously dropped.
   Implemented "allow_flagdrop" cvar to allow LMCTF style "drop flag" commands
0.26
   Started work on some Xatrix (The Reckoning) features.
   Fixed yellow shells (haste rune, and safety mode) for 3.19
   Implemented yellow shell when in safety mode
   Implemented bot_railtime to tweak lag on bot railgun aiming
   Implemented use_lasers to allow target_laser entities to be disabled to lower suicides
   Implemented bot_lava_mod and bot_slime_mod to reduce damage caused by lava/slime 
   Implemented *_speed variables (bot and normal weapon balancing)
   Bugfix: bots now use their starting weapons, even on their first spawn
   Bugfix: HUD resetting to 0 on respawn reduced
   Bugfix: FPH counter now stops at the end of the game
   Bugfix: onegun will force the starting weapon to the chosen weapon
   Bugfix: if start_weapon has no ammo, it is still used
   Bugfix: offhand grapple now drops nodes in the same way as on-hand grapple.
   Bugfix: Correct "Navlib" now used, so hopefully no incompatibility with 1.01 routes
   The "ammo hud" (def_hud 3) is now implemented
   Item replacement now configured via a separate config file
   Onegun mode forces Weapons-Stay (dmflags) to OFF, as it makes no sense
   Item/weapon banning is disabled when bot_calc_nodes is set, because it will
   cause problems when using the route when items are not banned.
   Linux version working
0.25
   Bugfix: fixed replace/onegun (broken during migration to Eraser 1.0)
   Bugfix: fixed haste rune sound (broken during migration to Eraser 1.0)
   Bugfix: +hook should now work on all clients in a multiplayer game
   Bugfix: observers can no longer use off-hand grapple to hurt other players
   Bugfix: lag command now affects offhand grapple (it is still wrong though!!)
   Config files for LMCTF and ExpertCTF style setups supplied.
   New cvar (rune_regen_armor) enables/disables CTF style armor regeneration
   when using the regen rune.
   New Cvar's for bot weapon balancing
   Bots no longer use CTF grapple, so it works without a CTF pak file
   Migrated across to Eraser 1.01 source code
   Further optimisation to spawn/init code

0.24
   Migrated across to Eraser 1.0 source code
   Bugfix: intermission nolonger aborts immediately
   Bugfix: vwep now works properly
   Bugfix: weapon balancing is implemented for bots as well as humans
   Bugfix: real players are now visable in multiplayer games
   Bugfix: clients are no-longer silent (no footsteps)
   Optimisation to spawn/init code - should be smoother now.

0.21
   Bugfix: now WILL switch to blaster (if you have it) when no ammo
   Bugfix: def_id is working again.
   changed the directory name from eraser\ to ultra\ to save existing configs.

0.20
   "One-gun" implemented
   Item Replacement
   Bugfix: number of players
   Bugfix: blaster working when no ammo when start_blaster 0
   Many other bits I cannot remember.   

0.10 (private beta)
   Everything, as its new!


FREQUENTLY ASKED QUESTIONS

   Q: The grapple isn't identical the the Lithium one, why?

		I have used the grapple from Expert-CTF, as I think that
                this is a better grapple, as it causes less lag, and looks
                better. If there are enough requests, I may attempt to
                code a red-laser grapple, but personally, I like this one.

   Q: Why is this an unofficial Lithium Clone?

		Because the Lithium author has not released his source
		code, thus making him the only ones able to make a real
		version of Lithium for Eraser. This much requested option
                has yet to be implemented in Lithium, and I decided that
                *I* wanted to play Lithium against Eraser-bots, so I wrote
                it from scratch myself.

                Since then, Matt has asked me not to release this, but
                I have continued to see requests for Erasers playing Lithium,
                and still no support... so, I have decided to release this.
                However, this mod is NOT optimised for servers, and does
                NOT include any of the features which server admins are
                looking for (IP banning, chat-flood protection, lmaster-server
                support etc), and therefore is not competing with Lithium.

   Q: So will Eraser ULTRA source code be released?

                Only in a limited way. Anyone can request it, and I may
                send it - eg. Matt (Whitefang) Ayres is welcome to use my 
                source.

   Q: Will it be updated to support new versions of Quake2/Eraser/Lithium?

		If possible, I will keep this up to date with any changes
		(and will add new features myself), however I cannot be
		certain that I will have the time to implement everything
                that I want to... 

   Q: Will Linux/other UNIX's be supported?

		Yes. Linux is now supported. I dont have direct access to
                any other UNIX implementations, so I cannot compile for others
                - if you give me an account, I can maybe compile...

   Q: Will [xxx MOD] be supported?
  
                Just implementing Lithium was quite a bit of work - however
                because a lot of the mods are effectively doing the same
                thing, it is quite possible that with only a small(ish)
                amount of work, I can implement other mods. I will not
                say that any mod will definately be supported, but I am
                looking at a few that I may attempt to implement.

   Q: What front-ends support EraserULTRA?

                BotJonnie 1.72 has basic support for ULTRA, and v2 (beta)
                has full support. See http://bj.quake2.co.uk/
      
                EBS (Eraser Bot Shell) supports most EraserULTRA settings. 
                See http://www.altern.org/incubus/
             
                EBL can launcher ULTRA by changing the mod directory, but
                cannot edit ULTRA options. 

                Other launchers may or may not support EraserULTRA. 
                [details, anyone?]

DISCLAIMER

   This is a BETA release, I therefore will not take responsibility
   for your system barfing after playing the game. I can however
   guarantee that I have not purposely added any malicious content
   to this application. If you believe this to be incorrect, then
   I'd be happy to discuss the matter with you.

   You may freely distribute this archive, as long as it remains
   PERFECTLY intact, as distributed on my home page:
      http://w3.to/EraserULTRA

LEGAL BIT

   Ridah asks that the following statement be included in the
   docs of any modified version of Eraser. Fine. :-)

	--- BEGIN ---

	The Eraser Bot is a product of Ryan Feltrin, and is available from
	the Eraser Bot homepage, at http://impact.frag.com.

	This program is a modification of the Eraser Bot, and is therefore
	in NO WAY supported by Ryan Feltrin.

	This program MUST NOT be sold in ANY form. If you have paid for 
	this product, you should contact Ryan Feltrin immediately, via
	the Eraser Bot homepage.

	--- END ---

KNOWN BUGS

 - Spectacular deaths cause the netchan-transmit error.
 - Only 1 rune of each type is ever spawned, unlike Lithium where related 
   to number of players.
 - Rune sounds are screwed for strength and haste. 
 - OneGun set to random isn't very random, and never picks the BFG.
 - OneGun doesn't respect weapon banning.
 - OneGun has problems choosing an ammo/weapon type not found on the current map.
 - Some issues exist with safety-mode shells on bots.
 - Scoreboard sometimes has problems when returning to DM mode after a CTF game
 - Ammo HUD causes small number of "pic not found" error messages.
 - Autodownload causes dodgy files to be created in the PLAYERS directory
 - When MAX_CLIENTS is set to high values (eg 128) strings within the game are overwritten.


Please report bugs to: jacquesa@zetnet.co.uk

enjoy,
-Anthony Jacques
