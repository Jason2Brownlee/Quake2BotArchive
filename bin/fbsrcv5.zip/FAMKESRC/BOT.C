//===================================
//BOT.C - Main bot source code
//===================================
//FIXME: Make coop/team bots use spawner's model instead of index 255?

//Credit for code snippets not by me goes where credit is due. I can't remember where I got
//most of the stuff, so forgive me if I forgot to mention you. If I forgot and you feel you
//should be mentioned, please e-mail me and tell me what code it is that you wrote and where
//it's used. Also, make SURE you wrote it, as it IS possible I just happened to write some
//code that looks like something you wrote (I did quite a few very generic things). Also,
//please note that there is some incomplete code in here in places from stuff I was working
//on and never got around to finishing (e.g. bot_explore cvar... I believe stuff for that is
// in g_ai.c under ai_run).

//Code for the bot is spread out through lots of the .c and .h files, I can't remember a lot
//of the things I did. Don't e-mail me asking about it, please, as I'm sure if I allowed that
//I'd get way too much mail. If you're planning on using this bot as a base and are COMPLETELY
//stuck on something, you can e-mail me, but please try to figure it out on your own first.

//Thanks.

//--------------------------------------------------------------------------------------------

#include "g_local.h"
#include "m_player.h"
void ai_stand (edict_t *self, float dist);
void ai_move (edict_t *self, float dist);
void bot_run (edict_t *self);
void bot_stand (edict_t *self);
void Respawn (edict_t *self);
void Respawn2 (edict_t *self);
void RespawnTeam (edict_t *self);
void RespawnCoop (edict_t *self);
void soldier_attack1_refire1 (edict_t *self);
void soldier_attack1_refire2 (edict_t *self);
void	SelectBotSpawnPoint (vec3_t origin, vec3_t angles);
void CopyToBodyQue (edict_t *ent);
mmove_t bot_move_stand1;
mmove_t bot_move_duck2;
mmove_t bot_move_attack1;
qboolean CheckItemPriority (edict_t *self, edict_t *ent);
void CheckWeap (edict_t *self);
void bot_touch_team(edict_t *self, edict_t *other, cplane_t *plane, csurface_t *surf);
void bot_touch_coop(edict_t *self, edict_t *other, cplane_t *plane, csurface_t *surf);
void Coopcam (edict_t *self);
void SelectRealWeapon (edict_t *self);
void SelectRealWeaponClose (edict_t *self);

void soldier_fire (edict_t *self, int flash_number);

void Globalremove (edict_t *self) {
if (bot1 == self)
bot1 = NULL;
if (bot2 == self)
bot2 = NULL;
if (bot3 == self)
bot3 = NULL;
if (bot4 == self)
bot4 = NULL;
if (bot5 == self)
bot5 = NULL;
if (bot6 == self)
bot6 = NULL;
if (bot7 == self)
bot7 = NULL;
if (bot8 == self)
bot8 = NULL;
if (bot9 == self)
bot9 = NULL;
if (bot10 == self)
bot10 = NULL;
if (bot11 == self)
bot11 = NULL;
if (bot12 == self)
bot12 = NULL;
if (bot13 == self)
bot13 = NULL;
if (bot14 == self)
bot14 = NULL;
if (bot15 == self)
bot15 = NULL;
if (bot16 == self)
bot16 = NULL;
if (bot17 == self)
bot17 = NULL;
if (bot18 == self)
bot18 = NULL;
if (bot19 == self)
bot19 = NULL;
if (bot20 == self)
bot20 = NULL;
}

void BotDisconnect (edict_t *self) {
if (self->spawner == NULL) {
return;
}
if (self->spawner->cament == self) {
Coopcam (self->spawner);
}
Globalremove (self);
	gi.bprintf (PRINT_HIGH, "%s disconnected\n", self->client->pers.netname);
	gi.WriteByte (svc_muzzleflash);
	gi.WriteShort (self-g_edicts);
	gi.WriteByte (MZ_LOGOUT);
	gi.multicast (self->s.origin, MULTICAST_PVS);

	gi.unlinkentity (self);
	self->s.modelindex = 0;
	self->solid = SOLID_NOT;
	self->inuse = false;
	self->classname = "disconnected";
botnumtotal--;
if (strcmp(self->teambot, "botteam") == 0)
botnum--;
else if (strcmp(self->teambot, "playerteam") == 0)
botnumteam--;
else
botnumcoop--;
if (self->spawner->lastbot == self) {
if (self->lastbot)
self->spawner->lastbot = self->lastbot;
else
self->spawner->lastbot = NULL;
}
//self->think = G_FreeEdict;
//self->nextthink = level.time;
G_FreeEdict (self);
}

void Removebot (edict_t *self) {
if (!self->lastbot || self->lastbot == NULL) {
gi.cprintf (self, PRINT_MEDIUM, "You have not created any bots to remove.\n");
return;
}
if (self->cament == self->lastbot) {
gi.cprintf (self, PRINT_MEDIUM, "Switch out of bot-view mode before removing a bot.\n");
return;
}
if (self->addremovetime > level.time)
return;
self->addremovetime = level.time + 1;
self->lastbot->think = BotDisconnect;
self->lastbot->nextthink = level.time;
}

edict_t *FindNode (edict_t *self) {
	edict_t	*ent = NULL;
	edict_t	*best = NULL;

	while ((ent = findradius(ent, self->s.origin, 256)) != NULL)
	{
		if (strcmp(ent->classname, "follownode") != 0)
		continue;
//		if (ent->nodenum != 1)
//		continue;
            if (!gi.inPVS(self->s.origin, ent->s.origin))
		continue;
		if (!visible(self, ent))
		continue;
		if (!best)
		{
			best = ent;
			continue;
		}
		best = ent;
	}
	return best;

}

edict_t *FindNextNode (edict_t *self) {
	edict_t	*ent = NULL;
	edict_t	*best = NULL;
	int		nextnode;

	while ((ent = findradius(ent, self->s.origin, 1024)) != NULL)
	{
		if (ent == self)
		continue;
		if (strcmp(ent->classname, "follownode") != 0)
		continue;
//		if (strcmp(ent->isabot, "bot") != 0)
//		continue;
		if (self->currnode == ent)
		continue;
		if (self->touchednode == ent)
		continue;
		nextnode = ent->nodenum + 1;
		if (self->currnode->nodenum != nextnode)
		continue;
		if (ent->nodenum == 100)
		continue;
//          if (!gi.inPVS(self->s.origin, ent->s.origin))
//		continue;
//		if (!visible(self, ent))
//		continue;
		if (!best)
		{
			best = ent;
			continue;
		}
		best = ent;
	}
	return best;
}

void ChaseNode (edict_t *self) {
vec3_t itemdest;
vec3_t v;
vec3_t v2;

//if (!gi.inPVS(self->s.origin, self->currnode->s.origin))
//{
//self->currnode = NULL;
//return;
//}
//if (!visible(self, self->currnode))
//{
//self->currnode = NULL;
//return;
//}
if (self->currnode == NULL)
return;
	VectorSubtract (self->currnode->s.origin, self->s.origin, v2);
	vectoangles(v2, self->s.angles);
self->s.angles[0] = 0;
	VectorSubtract (self->currnode->s.origin, self->s.origin, v);
//	self->ideal_yaw = vectoyaw(v);

//        if ( (rand()&3)==1 || !SV_StepDirection (self, self->ideal_yaw, dist))
//        {
//                        SV_NewChaseDir (self, self->currnode, dist);
//        }

VectorSubtract(self->currnode->s.origin, self->s.origin, itemdest);
//self->velocity[0] = 0;
//self->velocity[1] = 0;
self->velocity[2] = 0;
VectorScale (itemdest, 9, self->velocity);
self->velocity[2] = 0;
//if (self->itemwant->s.origin[2] > self->s.origin[2] && self->itemjump < level.time)
//{
//if (self->groundentity) {
//self->monsterinfo.currentmove = &bot_move_jump;
//self->itemjump = level.time + 3.5;
//}
//}


}


void Commentonthing (edict_t *self, edict_t *strogg) {

if (bottalk->value)
{
return;
}

if (strcmp(strogg->classname, "monster_gunner") == 0)
gi.bprintf (PRINT_CHAT, "%s: EAT IT, GUNBOY!\n", self->client->pers.netname);
else if (strcmp(strogg->classname, "monster_tank") == 0)
gi.bprintf (PRINT_CHAT, "%s: umm... h... he looks kinda tough...\n", self->client->pers.netname);
else if (strcmp(strogg->classname, "monster_tank_commander") == 0)
gi.bprintf (PRINT_CHAT, "%s: MOMMY!\n", self->client->pers.netname);
else if (strcmp(strogg->classname, "monster_supertank") == 0)
gi.bprintf (PRINT_CHAT, "%s: I... think I might need some help here\n", self->client->pers.netname);
else if (strcmp(strogg->classname, "monster_soldier_ss") == 0)
gi.bprintf (PRINT_CHAT, "%s: OOOH! HE'S MINE!\n", self->client->pers.netname);
else if (strcmp(strogg->classname, "monster_soldier") == 0)
gi.bprintf (PRINT_CHAT, "%s: Ahhh, another easy kill\n", self->client->pers.netname);
else if (strcmp(strogg->classname, "monster_parasite") == 0)
gi.bprintf (PRINT_CHAT, "%s: I'll give YOU something to suck on, heh heh...\n", self->client->pers.netname);
else if (strcmp(strogg->classname, "monster_mutant") == 0)
gi.bprintf (PRINT_CHAT, "%s: I don't think he's had a shower lately\n", self->client->pers.netname);
else if (strcmp(strogg->classname, "monster_medic") == 0)
gi.bprintf (PRINT_CHAT, "%s: We don't take a likin' ta doctors 'round these parts.\n", self->client->pers.netname);
else if (strcmp(strogg->classname, "monster_insane") == 0)
gi.bprintf (PRINT_CHAT, "%s: I guess he didn't get help at Charter... or anywhere.\n", self->client->pers.netname);
else if (strcmp(strogg->classname, "monster_infantry") == 0)
gi.bprintf (PRINT_CHAT, "%s: DON'T GIB HIM! I WANT THE LEFTOVERS!\n", self->client->pers.netname);
else if (strcmp(strogg->classname, "monster_hover") == 0)
gi.bprintf (PRINT_CHAT, "%s: C'mere, you pesky little critter...\n", self->client->pers.netname);
else if (strcmp(strogg->classname, "monster_gladiator") == 0)
gi.bprintf (PRINT_CHAT, "%s: Uh oh\n", self->client->pers.netname);
else if (strcmp(strogg->classname, "monster_flyer") == 0)
gi.bprintf (PRINT_CHAT, "%s: I've got 'im covered... I think\n", self->client->pers.netname);
else if (strcmp(strogg->classname, "monster_floater") == 0)
gi.bprintf (PRINT_CHAT, "%s: He looks like an interesting fellow\n", self->client->pers.netname);
else if (strcmp(strogg->classname, "monster_flipper") == 0)
gi.bprintf (PRINT_CHAT, "%s: They call him Flipper, Flipper, f--err... yeah\n", self->client->pers.netname);
else if (strcmp(strogg->classname, "monster_chick") == 0)
gi.bprintf (PRINT_CHAT, "%s: Oh girlfriend, what HAVE you done to your hair?!\n", self->client->pers.netname);
else if (strcmp(strogg->classname, "monster_brain") == 0)
gi.bprintf (PRINT_CHAT, "%s: Oh look, a giant brain. How... nice.\n", self->client->pers.netname);
else if (strcmp(strogg->classname, "monster_makron") == 0)
gi.bprintf (PRINT_CHAT, "%s: I guess we all have to go some time...\n", self->client->pers.netname);
else if (strcmp(strogg->classname, "monster_jorg") == 0)
gi.bprintf (PRINT_CHAT, "%s: huh...huh...\n", self->client->pers.netname);
else if (strcmp(strogg->classname, "monster_boss3_stand") == 0)
gi.bprintf (PRINT_CHAT, "%s: HE'S GONNA GET AWAY! Not that I really mind that...\n", self->client->pers.netname);
else if (strcmp(strogg->classname, "monster_boss2") == 0)
gi.bprintf (PRINT_CHAT, "%s: OH SH-- I mean F-- I mean... nevermind\n", self->client->pers.netname);
else if (strcmp(strogg->classname, "monster_berserk") == 0)
gi.bprintf (PRINT_CHAT, "%s: He doesn't look like a happy fellow\n", self->client->pers.netname);
else
gi.bprintf (PRINT_CHAT, "%s: What IS that?\n", self->client->pers.netname);
}

void CheckBotPowerups (edict_t *self)
{
char heldmodel[128];
int len;
vec3_t v2;
float dist;

//----------------------------------------
if (self->shittyquadhacktime > level.time)
self->s.effects |= EF_QUAD;
else
self->s.effects &= ~EF_QUAD;
//----------------------------------------
if (self->shittypenthacktime > level.time)
self->s.effects |= EF_PENT;
else
self->s.effects &= ~EF_PENT;
//----------------------------------------
if (self->shittyenvihacktime > level.time)
{
self->air_finished = level.time + 10;
}
//----------------------------------------
if (self->shittybreahacktime > level.time)
{
self->air_finished = level.time + 10;
}
//----------------------------------------

if (roam->value) {
if (self->currnode) {
//gi.bprintf (PRINT_HIGH, "Bot is after node %d\n", self->currnode->nodenum);
VectorSubtract (self->s.origin, self->currnode->s.origin, v2);
dist = VectorLength (v2);

if (dist > 400)
{
VectorCopy (self->currnode->s.origin, self->s.origin);
self->s.origin[2] += 2;
}
if (self->botcrouch == 1) {
//self->s.origin[2] += 3;
//self->maxs[2] -= 32;
VectorSet (self->maxs, 16, 16, 16);
}
else
{
VectorSet (self->maxs, 16, 16, 32);
}

}
}

if (vwep->value != 1)
return;
if (self->spawner == NULL)
return;
if (self->health < 1) {
self->s.modelindex2 = 0;
return;
}
if (self->deadflag == DEAD_DEAD) {
self->s.modelindex2 = 0;
return;
}

//	enemyrange = range(self, self->enemy);

if (coop->value || strcmp(self->teambot, "playerteam") == 0) {
	if(!self->client->pers.weapon)
	{
		self->client->pers.weapon = FindItem("Blaster");
//		return;
	}
//	if (enemyrange == RANGE_MELEE)
//	SelectRealWeaponClose (self);
//	else
//	SelectRealWeapon (self);

	strcpy(heldmodel, "players/");
	strcat(heldmodel, Info_ValueForKey (self->spawner->client->pers.userinfo, "skin"));
	for(len = 8; heldmodel[len]; len++)
	{
		if(heldmodel[len] == '/')
			heldmodel[++len] = '\0';
	}
	strcat(heldmodel, self->client->pers.weapon->icon);	
	strcat(heldmodel, ".md2");
	//gi.dprintf ("%s\n", heldmodel);
	if (self->insanity == 1)
	{
	strcpy(heldmodel, "players/");
	strcat(heldmodel, Info_ValueForKey (self->spawner->client->pers.userinfo, "skin"));
	for(len = 8; heldmodel[len]; len++)
	{
		if(heldmodel[len] == '/')
			heldmodel[++len] = '\0';
	}
	strcat(heldmodel, "a_grenades");	
	strcat(heldmodel, ".md2");
	
	self->s.modelindex2 = gi.modelindex(heldmodel);
	}
	else
	self->s.modelindex2 = gi.modelindex(heldmodel);	// Hentai's custom gun models
}
else {
	if(!self->client->pers.weapon)
	{
		self->client->pers.weapon = FindItem("Blaster");
//		return;
	}
//	if (enemyrange == RANGE_MELEE)
//	SelectRealWeaponClose (self);
//	else
//	SelectRealWeapon (self);

	strcpy(heldmodel, "players/");
//	strcat(heldmodel, Info_ValueForKey (self->spawner->client->pers.userinfo, "skin"));
	if (strcmp(self->botsex, "male") == 0)
	strcat(heldmodel, "male/");
	else
	strcat(heldmodel, "female/");

	for(len = 8; heldmodel[len]; len++)
	{
		if(heldmodel[len] == '/')
			heldmodel[++len] = '\0';
	}
	strcat(heldmodel, self->client->pers.weapon->icon);	
	strcat(heldmodel, ".md2");
	//gi.dprintf ("%s\n", heldmodel);
	self->s.modelindex2 = gi.modelindex(heldmodel);	// Hentai's custom gun models
}

}

mmove_t bot_move_jump;

void AfterItem (edict_t *self, float dist)
{
vec3_t itemdest;
vec3_t v;
int		quantity;

if (strcmp(self->itemwant->classname, "freed") == 0)
{
self->itemwant = NULL;
return;
}
if (self->itemwant->nextthink > level.time + 1)
{
self->itemwant = NULL;
return;
}
if (strcmp(self->itemwant->classname, "player_noise") == 0)
{
self->itemwant = NULL;
return;
}
if (!gi.inPVS(self->s.origin, self->itemwant->s.origin))
{
self->itemwant = NULL;
return;
}
if (!visible(self, self->itemwant))
{
self->itemwant = NULL;
return;
}
//if (self->itemwant->s.origin[2] > self->s.origin[2] + 30)
//{
//self->itemwant = NULL;
//return;
//}
if (self->itemwant == NULL)
return;
quantity = self->client->pers.inventory[ITEM_INDEX(self->itemwant->item)];
if ((coop->value) && (self->itemwant->item->flags & IT_STAY_COOP) && (quantity > 0))
{
self->itemwant = NULL;
return;
}
if (self->itemwant == NULL)
return;

if (coop->value && bot_explore->value)
return;

	VectorSubtract (self->itemwant->s.origin, self->s.origin, v);
	self->ideal_yaw = vectoyaw(v);

	if ( (rand()&3)==1 || !SV_StepDirection (self, self->ideal_yaw, dist))
	{
			SV_NewChaseDir (self, self->itemwant, dist);
	}

VectorSubtract(self->itemwant->s.origin, self->s.origin, itemdest);
self->velocity[0] = 0;
self->velocity[1] = 0;
self->velocity[2] = 0;
VectorScale (itemdest, 9, self->velocity);
self->velocity[2] = 0;
if (self->itemwant->s.origin[2] > self->s.origin[2] && self->itemjump < level.time)
{
if (self->groundentity) {
self->monsterinfo.currentmove = &bot_move_jump;
self->itemjump = level.time + 3.5;
}
}
}

void dodgeitnow (edict_t *self)
{
vec3_t fleeobject;

if (strcmp(self->backoff->classname, "freed") == 0)
{
self->backoff = NULL;
return;
}
if (strcmp(self->backoff->classname, "player_noise") == 0)
{
self->backoff = NULL;
return;
}
if (!gi.inPVS(self->s.origin, self->backoff->s.origin))
{
self->backoff = NULL;
return;
}
if (!visible(self, self->backoff))
{
self->backoff = NULL;
return;
}

if (self->backoff == NULL)
return;

VectorSubtract(self->s.origin, self->backoff->s.origin, fleeobject);
self->velocity[0] = 0;
self->velocity[1] = 0;
self->velocity[2] = 0;
VectorScale (fleeobject, 9, self->velocity);
self->velocity[2] = 0;
return;
}

edict_t *avoidproj (edict_t *self)
{
	edict_t	*ent = NULL;
	edict_t	*best = NULL;
	float itemnow = 0.0;
	float itemwant = 1.0;

      while ((ent = findradius(ent, self->s.origin, bot_projfind->value)) != NULL)
	{
		if (ent == self)
		continue;
		if (self->itemwant == ent)
		continue;
	 	if (coop->value)
		continue;
            if (!gi.inPVS(self->s.origin, ent->s.origin))
		continue;
		if (!visible(self, ent))
		continue;
		if (((Q_stricmp(ent->classname, "hgrenade") != 0) && (Q_stricmp(ent->classname, "rocket") != 0) && (Q_stricmp(ent->classname, "grenade") != 0)))
		continue;
		if (!best)
		{
			best = ent;
			continue;
		}
		best = ent;
	}
	return best;
        }


edict_t *searcharea (edict_t *self)
{
	edict_t	*ent = NULL;
	edict_t	*best = NULL;
	float itemnow = 0.0;
	float itemwant = 1.0;

	while ((ent = findradius(ent, self->s.origin, bot_itemfind->value)) != NULL)
	{
		if (ent == self)
		continue;
		if (self->itemwant == ent)
		continue;
		if (ent->spawnflags & DROPPED_ITEM)
		continue; 
		if (ent->spawnflags & DROPPED_PLAYER_ITEM)
		continue; 
            if (!gi.inPVS(self->s.origin, ent->s.origin))
		continue;
		if (!visible(self, ent))
		continue;
		itemnow = CheckItemPriority (self, ent);
		if (itemnow != itemwant)
		continue;
		if (!best)
		{
			best = ent;
			continue;
		}
		best = ent;
	}
	return best;
        }

edict_t *killothers (edict_t *self)
{
	edict_t	*ent = NULL;
	edict_t	*best = NULL;

	while ((ent = findradius(ent, self->s.origin, bot_botsfind->value)) != NULL)
	{
		if (ent == self)
		continue;
		if (strcmp(ent->classname, "player") != 0)
		continue;
		if (strcmp(ent->isabot, "bot") != 0)
		continue;
		if (self->enemy == ent)
		continue;
		if (teamplaybots->value) {
		if (self->team == ent->team)
		continue;
		}
            if (!gi.inPVS(self->s.origin, ent->s.origin))
		continue;
		if (!visible(self, ent))
		continue;
		if (!ent->health > 0)
		continue;
		if (ent->deadflag == DEAD_DEAD)
		continue;
		if (!best)
		{
			best = ent;
			continue;
		}
		best = ent;
	}
	return best;
        }

edict_t *killothersroam (edict_t *self)
{
	edict_t	*ent = NULL;
	edict_t	*best = NULL;

	while ((ent = findradius(ent, self->s.origin, bot_botsfind->value)) != NULL)
	{
		if (ent == self)
		continue;
		if (strcmp(ent->classname, "player") != 0)
		continue;
//		if (strcmp(ent->isabot, "bot") != 0)
//		continue;
		if (self->enemy == ent)
		continue;
		if (teamplaybots->value) {
		if (self->team == ent->team)
		continue;
		}
            if (!gi.inPVS(self->s.origin, ent->s.origin))
		continue;
		if (!visible(self, ent))
		continue;
		if (!ent->health > 0)
		continue;
		if (ent->deadflag == DEAD_DEAD)
		continue;
		if (!best)
		{
			best = ent;
			continue;
		}
		best = ent;
	}
	return best;
        }

edict_t *killotherscoop (edict_t *self)
{
	edict_t	*ent = NULL;
	edict_t	*best = NULL;

	while ((ent = findradius(ent, self->s.origin, bot_botsfind->value)) != NULL)
	{
		if (ent == self)
		continue;
		if (ent == self->spawner)
		continue;
		if (self->enemy != self->spawner)
		continue;
		if (strcmp(ent->classname, "player") == 0)
		continue;
	 	if (ent->takedamage != DAMAGE_AIM)
		continue;
		if (!gi.inPVS(self->s.origin, ent->s.origin))
		continue;
		if (!visible(self, ent))
		continue;
		if (!ent->health > 0)
		continue;
		if (ent->deadflag == DEAD_DEAD)
		continue;
		if (!best)
		{
			best = ent;
			continue;
		}
		best = ent;
	}
	return best;
        }

qboolean CheckItemPriority (edict_t *self, edict_t *ent)
{
float itemget = 1.0;
float itembad = 0.0;

//if (ent->s.origin[2] > self->s.origin[2] + 30)
//return itembad;

if (strcmp(ent->classname, "weapon_shotgun") == 0)
{
if (coop->value) {
if (self->client->pers.inventory[ITEM_INDEX(FindItem("shotgun"))])
return itembad;
}

if ((self->client->pers.inventory[ITEM_INDEX(FindItem("shells"))] >= self->client->pers.max_shells)
	&&  (self->client->pers.inventory[ITEM_INDEX(FindItem("shotgun"))] ))
return itembad;
else
return itemget;
}
if (strcmp(ent->classname, "weapon_supershotgun") == 0)
{
if (coop->value) {
if (self->client->pers.inventory[ITEM_INDEX(FindItem("super shotgun"))])
return itembad;
}

if ((self->client->pers.inventory[ITEM_INDEX(FindItem("shells"))] >= self->client->pers.max_shells)
	&&  (self->client->pers.inventory[ITEM_INDEX(FindItem("super shotgun"))] ))
return itembad;
else
return itemget;
}
if (strcmp(ent->classname, "weapon_machinegun") == 0)
{
if (coop->value) {
if (self->client->pers.inventory[ITEM_INDEX(FindItem("machinegun"))])
return itembad;
}

if ((self->client->pers.inventory[ITEM_INDEX(FindItem("bullets"))] >= self->client->pers.max_bullets)
	&&  (self->client->pers.inventory[ITEM_INDEX(FindItem("machinegun"))] ))
return itembad;
else
return itemget;
}
if (strcmp(ent->classname, "weapon_chaingun") == 0)
{
if (coop->value) {
if (self->client->pers.inventory[ITEM_INDEX(FindItem("chaingun"))])
return itembad;
}

if ((self->client->pers.inventory[ITEM_INDEX(FindItem("bullets"))] >= self->client->pers.max_bullets)
	&&  (self->client->pers.inventory[ITEM_INDEX(FindItem("chaingun"))] ))
return itembad;
else
return itemget;
}
if (strcmp(ent->classname, "weapon_grenadelauncher") == 0)
{
if (coop->value) {
if (self->client->pers.inventory[ITEM_INDEX(FindItem("grenade launcher"))])
return itembad;
}

if ((self->client->pers.inventory[ITEM_INDEX(FindItem("grenades"))] >= self->client->pers.max_grenades)
	&&  (self->client->pers.inventory[ITEM_INDEX(FindItem("grenade launcher"))] ))
return itembad;
else
return itemget;
}
if (strcmp(ent->classname, "weapon_rocketlauncher") == 0)
{
if (coop->value) {
if (self->client->pers.inventory[ITEM_INDEX(FindItem("rocket launcher"))])
return itembad;
}

if ((self->client->pers.inventory[ITEM_INDEX(FindItem("rockets"))] >= self->client->pers.max_rockets)
	&&  (self->client->pers.inventory[ITEM_INDEX(FindItem("rocket launcher"))] ))
return itembad;
else
return itemget;
}
if (strcmp(ent->classname, "weapon_hyperblaster") == 0)
{
if (coop->value) {
if (self->client->pers.inventory[ITEM_INDEX(FindItem("hyperblaster"))])
return itembad;
}

if ((self->client->pers.inventory[ITEM_INDEX(FindItem("cells"))] >= self->client->pers.max_cells)
	&&  (self->client->pers.inventory[ITEM_INDEX(FindItem("hyperblaster"))] ))
return itembad;
else
return itemget;
}
if (strcmp(ent->classname, "weapon_railgun") == 0)
{
if (coop->value) {
if (self->client->pers.inventory[ITEM_INDEX(FindItem("railgun"))])
return itembad;
}

if ((self->client->pers.inventory[ITEM_INDEX(FindItem("slugs"))] >= self->client->pers.max_slugs)
	&&  (self->client->pers.inventory[ITEM_INDEX(FindItem("railgun"))] ))
return itembad;
else
return itemget;
}
if (strcmp(ent->classname, "weapon_bfg") == 0)
{
if (coop->value) {
if (self->client->pers.inventory[ITEM_INDEX(FindItem("BFG10K"))])
return itembad;
}

if ((self->client->pers.inventory[ITEM_INDEX(FindItem("cells"))] >= self->client->pers.max_cells)
	&&  (self->client->pers.inventory[ITEM_INDEX(FindItem("BFG10K"))] ))
return itembad;
else
return itemget;
}
if (strcmp(ent->classname, "ammo_grenades") == 0)
{
if (self->client->pers.inventory[ITEM_INDEX(FindItem("grenades"))] >= self->client->pers.max_grenades)
return itembad;
else
return itemget;
}
if (strcmp(ent->classname, "ammo_cells") == 0)
{
if (self->client->pers.inventory[ITEM_INDEX(FindItem("cells"))] >= self->client->pers.max_cells)
return itembad;
else
return itemget;
}
if (strcmp(ent->classname, "ammo_shells") == 0)
{
if (self->client->pers.inventory[ITEM_INDEX(FindItem("shells"))] >= self->client->pers.max_shells)
return itembad;
else
return itemget;
}
if (strcmp(ent->classname, "ammo_bullets") == 0)
{
if (self->client->pers.inventory[ITEM_INDEX(FindItem("bullets"))] >= self->client->pers.max_bullets)
return itembad;
else
return itemget;
}
if (strcmp(ent->classname, "ammo_rockets") == 0)
{
if (self->client->pers.inventory[ITEM_INDEX(FindItem("rockets"))] >= self->client->pers.max_rockets)
return itembad;
else
return itemget;
}
if (strcmp(ent->classname, "ammo_slugs") == 0)
{
if (self->client->pers.inventory[ITEM_INDEX(FindItem("slugs"))] >= self->client->pers.max_slugs)
return itembad;
else
return itemget;
}
if (strcmp(ent->classname, "item_quad") == 0)
{
return itemget;
}
if (strcmp(ent->classname, "item_invulnerability") == 0)
{
return itemget;
}
if (strcmp(ent->classname, "item_quad") == 0)
{
return itemget;
}
if (strcmp(ent->classname, "item_silencer") == 0)
{
return itemget;
}
if (strcmp(ent->classname, "item_breather") == 0)
{
return itemget;
}
if (strcmp(ent->classname, "item_enviro") == 0)
{
return itemget;
}
if (strcmp(ent->classname, "item_ancient_head") == 0)
{
return itemget;
}
if (strcmp(ent->classname, "item_adrenaline") == 0)
{
return itemget;
}
if (strcmp(ent->classname, "item_bandolier") == 0)
{
return itemget;
}
if (strcmp(ent->classname, "item_pack") == 0)
{
return itemget;
}
if (strcmp(ent->classname, "item_health") == 0)
{
if (self->health < 100)
return itemget;
else
return itembad;
}
if (strcmp(ent->classname, "item_health_small") == 0)
{
if (self->health < 100)
return itemget;
else
return itembad;
}
if (strcmp(ent->classname, "item_health_large") == 0)
{
if (self->health < 100)
return itemget;
else
return itembad;
}
if (strcmp(ent->classname, "item_health_mega") == 0)
{
if (self->health < 250)
return itemget;
else
return itembad;
}
if (strcmp(ent->classname, "item_quad") == 0)
{
return itemget;
}
if (strcmp(ent->classname, "item_armor_body") == 0)
{
return itemget;
}
if (strcmp(ent->classname, "item_armor_combat") == 0)
{
return itemget;
}
if (strcmp(ent->classname, "item_armor_jacket") == 0)
{
return itemget;
}
if (strcmp(ent->classname, "item_armor_shard") == 0)
{
return itemget;
}
else
return itembad;
}

void botenvhurt (edict_t *self) {
        int                     waterlevel;
	waterlevel = self->waterlevel;

	if (waterlevel == 3)
	{
		if (self->air_finished < level.time)
		{	
			if (self->client->next_drown_time < level.time 
				&& self->health > 0)
			{
				self->client->next_drown_time = level.time + 1;

				self->dmg += 2;
				if (self->dmg > 15)
					self->dmg = 15;

				if (self->health <= self->dmg)
					gi.sound (self, CHAN_VOICE, gi.soundindex("player/drown1.wav"), 1, ATTN_NORM, 0);
				else if (rand()&1)
					gi.sound (self, CHAN_VOICE, gi.soundindex("*gurp1.wav"), 1, ATTN_NORM, 0);
				else
					gi.sound (self, CHAN_VOICE, gi.soundindex("*gurp2.wav"), 1, ATTN_NORM, 0);

				self->pain_debounce_time = level.time;

				T_Damage (self, world, world, vec3_origin, self->s.origin, vec3_origin, self->dmg, 0, DAMAGE_NO_ARMOR, MOD_WATER);
			}
		}

}
	else
	{
		self->air_finished = level.time + 12;
		self->dmg = 2;
	}

	if (waterlevel && (self->watertype&(CONTENTS_LAVA|CONTENTS_SLIME)) )
	{
		if (self->watertype & CONTENTS_LAVA)
		{
				if (rand()&1)
					gi.sound (self, CHAN_VOICE, gi.soundindex("player/burn1.wav"), 1, ATTN_NORM, 0);
				else
					gi.sound (self, CHAN_VOICE, gi.soundindex("player/burn2.wav"), 1, ATTN_NORM, 0);
				self->pain_debounce_time = level.time + 1;

				T_Damage (self, world, world, vec3_origin, self->s.origin, vec3_origin, 3*waterlevel, 0, 0, MOD_LAVA);
		}

		if (self->watertype & CONTENTS_SLIME)
		{
				if (self->shittyenvihacktime < level.time)
				T_Damage (self, world, world, vec3_origin, self->s.origin, vec3_origin, 1*waterlevel, 0, 0, MOD_SLIME);
		}
}
}

mframe_t bot_frames_start_run [] =
{
	ai_run, 7,  NULL,
	ai_run, 5,  NULL
};
mmove_t bot_move_start_run = {FRAME_run1, FRAME_run2, bot_frames_start_run, bot_run};

void ai_chargebad (edict_t *self, float dist);

mframe_t bot_frames_run [] =
{
	ai_chargebad, 10, NULL,
	ai_run, 11, NULL,
	ai_run, 11, NULL,
	ai_run, 16, NULL,
	ai_run, 10, NULL,
	ai_chargebad, 15, NULL
};
mmove_t bot_move_run = {FRAME_run1, FRAME_run6, bot_frames_run, NULL};

mframe_t bot_frames_crawl [] =
{
	ai_run, 10, NULL,
	ai_run, 11, NULL,
	ai_run, 11, NULL,
	ai_run, 16, NULL,
	ai_run, 10, NULL,
	ai_run, 15, NULL
};
mmove_t bot_move_crawl = {FRAME_crwalk1, FRAME_crwalk6, bot_frames_crawl, NULL};

mmove_t bot_move_jump;

edict_t *FindNewNode (edict_t *self) {
edict_t *ent;
edict_t *narf;

	while ((ent = findradius(ent, self->s.origin, 512)) != NULL)
	{
	if (self == ent)
	continue;
//	if (strcmp(ent->classname, "follownode") != 0)
//	continue;
	if (!ent->nodenum > 0)
	continue;
	narf = ent;
	}
if (!narf)
narf = ent;

return narf;
}

void TravelToNode (edict_t *self) {
vec3_t nodeloc;
edict_t		*goal;
float dist;
vec3_t v;
vec3_t v2;

if (self->currnode == NULL)
return;

//if (!gi.inPVS(self->s.origin, self->currnode->s.origin) && !visible(self, self->currnode))
//{
//self->currnode = NULL;
//return;
//}

//if (!M_walkmove (self, 0, 0))
//{
//if (self->currnode) {
//VectorCopy (self->currnode->s.origin, self->s.origin);
//self->s.origin[2] += 2;
//}
//else
//self->s.origin[2] += 5;
//}

VectorSubtract (self->currnode->s.origin, self->s.origin, v);
self->ideal_yaw = vectoyaw(v);
VectorSubtract (self->s.origin, self->currnode->s.origin, v2);
dist = VectorLength (v2);
goal = self->currnode;

//if (dist > 200)
//{
//VectorCopy (self->currnode->s.origin, self->s.origin);
//self->s.origin[2] += 2;
//}

	if ( (rand()&3)==1 || !SV_StepDirection (self, self->ideal_yaw, dist))
	{
		if (self->inuse)
			SV_NewChaseDir (self, goal, dist);
	}

//gi.bprintf (PRINT_HIGH, "Bot is after node %d\n", self->currnode->nodenum);
	M_walkmove (self, self->s.angles[YAW], 1);

VectorSubtract(self->currnode->s.origin, self->s.origin, nodeloc);
VectorScale (nodeloc, 4, self->velocity);
vectoangles(nodeloc, self->s.angles);
self->s.angles[0] = 0;
if (self->velocity[2] < -200)
self->velocity[2] = -200;
if (self->velocity[2] > 350)
self->velocity[2] = 350;
if (self->currnode->s.origin[2] > self->s.origin[2])
self->monsterinfo.currentmove = &bot_move_jump;

}

void AI_Botroam (edict_t *self) {
//WORN
//edict_t *checkareaforgoods;
edict_t *newvict;
//if (!self->currnode) {
//return;
//}

if (self->footsteptime < level.time) {
	if (self->groundentity) {
		if (!nofootsteps->value) {
		gi.sound (self, CHAN_BODY, gi.soundindex(va("player/step%i.wav", (rand()%4)+1)), 1, ATTN_NORM, 0);
		self->footsteptime = level.time + 0.3;
		}
	}
}

CheckBotPowerups (self);

if (self->spawner == NULL)
return;

if (strcmp(self->enemy->classname, "player") == 0 && coop->value && self->enemy != self->spawner) {
self->enemy = self->spawner;
self->goalentity = self->spawner;
FoundTarget (self);
return;
}

if (!self->enemy && coop->value) {
self->enemy = self->spawner;
self->goalentity = self->spawner;
FoundTarget (self);
return;
}


if (strcmp(self->teambot, "coopteam") == 0)
{
	newvict = killotherscoop (self);
	if (newvict)
	{
	Commentonthing (self, newvict);
	self->enemy = newvict;
	self->goalentity = newvict;
//	self->enemy = checkareaforgoods;
//	self->goalentity = checkareaforgoods;
	FoundTarget (self);
return;
	}
}
else {
	newvict = killothersroam (self);
	if (newvict)
//	checkareaforgoods = searcharea (self);
//	if (checkareaforgoods)
	{
	self->enemy = newvict;
	self->goalentity = newvict;
//	self->enemy = checkareaforgoods;
//	self->goalentity = checkareaforgoods;
	FoundTarget (self);
return;
	}
}

//	if (!self->itemwant) {
//	checkareaforgoods = searcharea (self);
//	if (checkareaforgoods)
//	{
//	self->itemwant = checkareaforgoods;
//	return;
//	}
//	}

if (self->currnode && self->currnode->nodenum == 99 || self->currnode->nodenum == 100)
{
self->nodelook = level.time + 999999;
self->currnode = NULL;
self->touchednode = NULL;
return;
}

if (self->currnode && self->currnode->nodenum == 100)
{
//gi.bprintf (PRINT_HIGH, "Bot reached end of node chain\n");
//self->nodeorder = 1;
self->nodelook = level.time + 1;
//self->currnode = NULL;
return;
//self->currnode = self->currnode->preventnode;
}
//else if (self->currnode && self->currnode->nodenum == 1)
//{
//gi.bprintf (PRINT_HIGH, "Bot reached beginning again\n");
//self->nodeorder = 0;
//}

//if (self->currnode) {
//gi.bprintf (PRINT_HIGH, "Bot found node %d\n", self->currnode->nodenum);
TravelToNode (self);
//gi.bprintf (PRINT_HIGH, "Well, this works\n");
//return;
if (self->currnode == NULL)
return;

if (!self->touchednode)
{
//gi.bprintf (PRINT_HIGH, "Delaying for not touched yet node %d\n", self->currnode->nodenum);

self->nodelook = level.time + 1;
return;
}
if (!self->touchednode->nextentnode)
{
//gi.bprintf (PRINT_HIGH, "Delaying for touched node not yet have next node %d\n", self->currnode->nodenum);

self->nodelook = level.time + 1;
return;
}
if ((self->currnode->nodenum + 1) != self->currnode->nextentnode->nodenum)
{
//gi.bprintf (PRINT_HIGH, "Numbers on nodes don't equal currnode plus 1 %d\n", self->currnode->nodenum);

self->nodelook = level.time + 1;
return;
}
if (strcmp(self->currnode->nextentnode->classname, "follownode") != 0)
{
//gi.bprintf (PRINT_HIGH, "Next node is not a follownode %d\n", self->currnode->nodenum);

self->nodelook = level.time + 1;
return;
}

if (self->touchednode == self->currnode && self->nodeorder != 1)
self->currnode = self->currnode->nextentnode;
else if (self->touchednode == self->currnode)
self->currnode = self->currnode->preventnode;
//}
}

void AI_Botback (edict_t *self) {
vec3_t forward, right, up;

CheckBotPowerups (self);

if (coop->value)
return;

if (self->enemy == NULL)
return;

if (self->enemy->deadflag == DEAD_DEAD)
return;

if (self->enemy->health < 1)
return;

if (teamplaybots->value) {
if (self->team == self->enemy->team)
return;
}

	self->groundentity = NULL;

	AngleVectors (self->s.angles, forward, right, up);
	self->s.origin[2] += 1;
	VectorScale (forward, -175, self->velocity);
	self->velocity[2] = 1;
}

void AI_BotRocket (edict_t *self) {
vec3_t forward, right, up;
vec3_t v;
vec3_t v2;
float len;
edict_t *newvict;

CheckBotPowerups (self);
if (self->footsteptime < level.time) {
	if (self->groundentity) {
		if (!nofootsteps->value) {
		gi.sound (self, CHAN_BODY, gi.soundindex(va("player/step%i.wav", (rand()%4)+1)), 1, ATTN_NORM, 0);
		self->footsteptime = level.time + 0.3;
		}
	}
}

if (coop->value)
return;

if (self->enemy == NULL)
return;

if (self->enemy->deadflag == DEAD_DEAD)
return;

if (self->enemy->health < 1)
return;

if (teamplaybots->value) {
if (self->team == self->enemy->team)
return;
}

VectorSubtract (self->enemy->s.origin, self->s.origin, v);
vectoangles(v, self->s.angles);
self->s.angles[0] = 0;

if (strcmp(self->enemy->isabot, "NOTbot") == 0)
{
	newvict = killothers (self);
	if (newvict)
	{
	self->enemy = newvict;
	self->goalentity = newvict;
	FoundTarget (self);
	}
}

if (random() < .2)
{
if (self->groundentity)
self->monsterinfo.currentmove = &bot_move_jump;
}

VectorSubtract (self->s.origin, self->enemy->s.origin, v2);
len = VectorLength (v2);

if (self->strafedir == 0) {
	self->groundentity = NULL;

	AngleVectors (self->s.angles, forward, right, up);
	self->s.origin[2] += 1;
	VectorScale (right, -200, self->velocity);
	self->velocity[2] = 1;
}
else if (self->strafedir == 1) {
	self->groundentity = NULL;

	AngleVectors (self->s.angles, forward, right, up);
	self->s.origin[2] += 1;
	VectorScale (right, 200, self->velocity);
	self->velocity[2] = 1;
}


if (self->strafetime < level.time && self->strafedir == 1) {
self->strafedir = 0;
self->strafetime = level.time + 1 + ((rand()%2)+1);
	self->groundentity = NULL;

	AngleVectors (self->s.angles, forward, right, up);
	self->s.origin[2] += 1;
	VectorScale (right, 200, self->velocity);
	self->velocity[2] = 1;
}
else if (self->strafetime < level.time) {
self->strafedir = 1;
self->strafetime = level.time + 1 + ((rand()%2)+1);
	self->groundentity = NULL;

	AngleVectors (self->s.angles, forward, right, up);
	self->s.origin[2] += 1;
	VectorScale (right, -200, self->velocity);
	self->velocity[2] = 1;
}

//if (self->backtime < level.time && len < 600)
//{
//self->backtime = level.time + 2;
//}
//
//if (self->backtime > level.time) {
//	self->groundentity = NULL;
//
//	AngleVectors (self->s.angles, forward, right, up);
//	self->s.origin[2] += 1;
//	VectorScale (forward, -175, self->velocity);
//	self->velocity[2] = 1;
//}
//else
//{
//	self->groundentity = NULL;
//
//	AngleVectors (self->s.angles, forward, right, up);
//	self->s.origin[2] += 1;
//	VectorScale (forward, 175, self->velocity);
//	self->velocity[2] = 1;
//}

}

void PainCheckWeap (edict_t *self)
{
CheckWeap (self);
}

void Precalcpos2 (edict_t *self)
{
if (coop->value)
return;

if (skill->value < 3) {
if (random() < .1)
{
self->s.angles[1] = self->s.angles[1] - 10;
}

else if (random() < .1)
{
self->s.angles[1] = self->s.angles[1] - 10;
}
}
else if (skill->value < 2) {
if (random() < .2)
{
self->s.angles[1] = self->s.angles[1] - 10;
}

else if (random() < .2)
{
self->s.angles[1] = self->s.angles[1] - 10;
}
}
else if (skill->value < 1) {
if (random() < .3)
{
self->s.angles[1] = self->s.angles[1] - 10;
}

else if (random() < .5)
{
self->s.angles[1] = self->s.angles[1] - 10;
}
}
}


void Precalcpos (edict_t *self)
{
        vec3_t  forward, right, up;

if (coop->value)
return;

AngleVectors (self->s.angles, forward, right, up);
if (skill->value < 3) {
if (random() < .2)
{
self->s.angles[1] = self->s.angles[1] - 5;
}

else if (random() < .3)
{
self->s.angles[1] = self->s.angles[1] - 5;
}

}

}


void bot_touch (edict_t *self, edict_t *other) {
if (strcmp(other->classname, "player") == 0) {
	  gi.unlinkentity (self);
	  if (!KillBox (self))
		{
		}
        gi.linkentity (self);
}
}

void SelectRealWeapon (edict_t *self) {
if ( self->client->pers.inventory[ITEM_INDEX(FindItem("cells"))] > 49
	 &&  self->client->pers.inventory[ITEM_INDEX(FindItem("BFG10K"))] )
{
self->client->pers.weapon = FindItem("BFG10K");
}
else if ( self->client->pers.inventory[ITEM_INDEX(FindItem("slugs"))]
	 &&  self->client->pers.inventory[ITEM_INDEX(FindItem("railgun"))] )
{
self->client->pers.weapon = FindItem("railgun");
}
else if ( self->client->pers.inventory[ITEM_INDEX(FindItem("cells"))]
	&&  self->client->pers.inventory[ITEM_INDEX(FindItem("hyperblaster"))] )
{
self->client->pers.weapon = FindItem("hyperblaster");
}
else if ( self->client->pers.inventory[ITEM_INDEX(FindItem("rockets"))]
	&&  self->client->pers.inventory[ITEM_INDEX(FindItem("rocket launcher"))] )
{
self->client->pers.weapon = FindItem("rocket launcher");
}
else if ( self->client->pers.inventory[ITEM_INDEX(FindItem("grenades"))]
	&&  self->client->pers.inventory[ITEM_INDEX(FindItem("grenade launcher"))] )
{
self->client->pers.weapon = FindItem("grenade launcher");
}
else if ( self->client->pers.inventory[ITEM_INDEX(FindItem("grenades"))] )
{
self->client->pers.weapon = FindItem("grenades");
}
else if ( self->client->pers.inventory[ITEM_INDEX(FindItem("bullets"))]
	&&  self->client->pers.inventory[ITEM_INDEX(FindItem("chaingun"))] )
{
self->client->pers.weapon = FindItem("chaingun");
}
else if ( self->client->pers.inventory[ITEM_INDEX(FindItem("bullets"))]
	&&  self->client->pers.inventory[ITEM_INDEX(FindItem("machinegun"))] )
{
self->client->pers.weapon = FindItem("machinegun");
}
else if ( self->client->pers.inventory[ITEM_INDEX(FindItem("shells"))] > 1
	&&  self->client->pers.inventory[ITEM_INDEX(FindItem("super shotgun"))] )

{
self->client->pers.weapon = FindItem("super shotgun");
}
else if ( self->client->pers.inventory[ITEM_INDEX(FindItem("shells"))]
	&&  self->client->pers.inventory[ITEM_INDEX(FindItem("shotgun"))] )
{
self->client->pers.weapon = FindItem("Shotgun");
}
else
{
self->client->pers.weapon = FindItem("Blaster");
}
}

void SelectRealWeaponClose (edict_t *self) {
if ( self->client->pers.inventory[ITEM_INDEX(FindItem("slugs"))]
	 &&  self->client->pers.inventory[ITEM_INDEX(FindItem("railgun"))] )
{
self->client->pers.weapon = FindItem("railgun");
}
else if ( self->client->pers.inventory[ITEM_INDEX(FindItem("cells"))]
	&&  self->client->pers.inventory[ITEM_INDEX(FindItem("hyperblaster"))] )
{
self->client->pers.weapon = FindItem("hyperblaster");
}
else if ( self->client->pers.inventory[ITEM_INDEX(FindItem("bullets"))]
	&&  self->client->pers.inventory[ITEM_INDEX(FindItem("chaingun"))] )
{
self->client->pers.weapon = FindItem("chaingun");
}
else if ( self->client->pers.inventory[ITEM_INDEX(FindItem("bullets"))]
	&&  self->client->pers.inventory[ITEM_INDEX(FindItem("machinegun"))] )
{
self->client->pers.weapon = FindItem("machinegun");
}
else if ( self->client->pers.inventory[ITEM_INDEX(FindItem("shells"))] > 1
	&&  self->client->pers.inventory[ITEM_INDEX(FindItem("super shotgun"))] )

{
self->client->pers.weapon = FindItem("super shotgun");
}
else if ( self->client->pers.inventory[ITEM_INDEX(FindItem("shells"))]
	&&  self->client->pers.inventory[ITEM_INDEX(FindItem("shotgun"))] )
{
self->client->pers.weapon = FindItem("Shotgun");
}
else
{
self->client->pers.weapon = FindItem("Blaster");
}
}

void CheckWeap (edict_t *self)
{
		vec3_t	v;
edict_t *rlent;
edict_t *crent;

if (level.time < self->fly_sound_debounce_time)
{
self->monsterinfo.currentmove = &bot_move_run;
return;
}

if (self->enemy == NULL) {
self->monsterinfo.currentmove = &bot_move_run;
return;
}

if (self->enemy->health < 1) {
self->monsterinfo.currentmove = &bot_move_run;
return;
}

if (self->shittyquadhacktime > level.time) {
gi.sound(self, CHAN_ITEM, gi.soundindex("items/damage3.wav"), 1, ATTN_NORM, 0);
}

	VectorSubtract (self->enemy->s.origin, self->s.origin, v);
	vectoangles(v, self->s.angles);

if (strcmp(self->enemy->classname, "player") == 0 && self->enemy->client->ps.pmove.pm_flags & PMF_DUCKED)
{
crent = G_Spawn();
VectorCopy (self->enemy->s.origin, crent->s.origin);
crent->s.origin[2] = crent->s.origin[2] - 20;
VectorSubtract (crent->s.origin, self->s.origin, v);
vectoangles(v, self->s.angles);
crent->think = G_FreeEdict;
crent->nextthink = level.time;
}

NoAmmoWeaponChange (self);
SelectRealWeapon (self);

if ( self->client->pers.inventory[ITEM_INDEX(FindItem("cells"))] > 49
	 &&  self->client->pers.inventory[ITEM_INDEX(FindItem("BFG10K"))] )
{
//self->client->pers.weapon = FindItem("BFG10K");
weapon_bfg_fire (self);
if (!practice->value)
self->client->pers.inventory[ITEM_INDEX(FindItem("cells"))] = self->client->pers.inventory[ITEM_INDEX(FindItem("cells"))] - 50;
self->fly_sound_debounce_time = level.time + 5.0;
}
else if ( self->client->pers.inventory[ITEM_INDEX(FindItem("slugs"))]
	 &&  self->client->pers.inventory[ITEM_INDEX(FindItem("railgun"))] )
{
Precalcpos2 (self);
//self->client->pers.weapon = FindItem("railgun");
weapon_railgun_fire (self);
if (!practice->value)
self->client->pers.inventory[ITEM_INDEX(FindItem("slugs"))] = self->client->pers.inventory[ITEM_INDEX(FindItem("slugs"))] - 1;
self->fly_sound_debounce_time = level.time + 2.0;
}
else if ( self->client->pers.inventory[ITEM_INDEX(FindItem("cells"))]
	&&  self->client->pers.inventory[ITEM_INDEX(FindItem("hyperblaster"))] )
{
Precalcpos (self);
//self->client->pers.weapon = FindItem("hyperblaster");
Weapon_HyperBlaster_Fire (self);
if (!practice->value)
self->client->pers.inventory[ITEM_INDEX(FindItem("cells"))] = self->client->pers.inventory[ITEM_INDEX(FindItem("cells"))] - 1;
self->fly_sound_debounce_time = level.time + 0.0;
}
else if ( self->client->pers.inventory[ITEM_INDEX(FindItem("rockets"))]
	&&  self->client->pers.inventory[ITEM_INDEX(FindItem("rocket launcher"))] )
{
if (skill->value != 0 && self->enemy->s.origin[2] < self->s.origin[2] + 30) {
rlent = G_Spawn ();
VectorCopy (self->enemy->s.origin, rlent->s.origin);
rlent->s.origin[2] = rlent->s.origin[2] - 30;
//M_droptofloor (rlent);
rlent->think = G_FreeEdict;
rlent->nextthink = level.time + 0.1;
VectorSubtract (rlent->s.origin, self->s.origin, v);
vectoangles(v, self->s.angles);
}
else
{
VectorSubtract (self->enemy->s.origin, self->s.origin, v);
vectoangles(v, self->s.angles);
}
//self->client->pers.weapon = FindItem("rocket launcher");
Weapon_RocketLauncher_Fire (self);
if (!practice->value)
self->client->pers.inventory[ITEM_INDEX(FindItem("rockets"))] = self->client->pers.inventory[ITEM_INDEX(FindItem("rockets"))] - 1;
if (skill->value > 2)
self->fly_sound_debounce_time = level.time + 0.7;
else
self->fly_sound_debounce_time = level.time + 2.0;
}
else if ( self->client->pers.inventory[ITEM_INDEX(FindItem("grenades"))]
	&&  self->client->pers.inventory[ITEM_INDEX(FindItem("grenade launcher"))] )
{
//self->client->pers.weapon = FindItem("grenade launcher");
weapon_grenadelauncher_fire (self);
if (!practice->value)
self->client->pers.inventory[ITEM_INDEX(FindItem("grenades"))] = self->client->pers.inventory[ITEM_INDEX(FindItem("grenades"))] - 1;
self->fly_sound_debounce_time = level.time + 2.0;
}
else if ( self->client->pers.inventory[ITEM_INDEX(FindItem("grenades"))] )
{
//self->client->pers.weapon = FindItem("grenades");
self->client->grenade_time = level.time + 2.0;
weapon_grenade_fire (self, 5);
if (!practice->value)
self->client->pers.inventory[ITEM_INDEX(FindItem("grenades"))] = self->client->pers.inventory[ITEM_INDEX(FindItem("grenades"))] - 1;
self->fly_sound_debounce_time = level.time + 2.0;
}
else if ( self->client->pers.inventory[ITEM_INDEX(FindItem("bullets"))]
	&&  self->client->pers.inventory[ITEM_INDEX(FindItem("chaingun"))] )
{
Precalcpos (self);
//self->client->pers.weapon = FindItem("chaingun");
Chaingun_Fire (self);
if (!practice->value)
self->client->pers.inventory[ITEM_INDEX(FindItem("bullets"))] = self->client->pers.inventory[ITEM_INDEX(FindItem("bullets"))] - 1;
self->fly_sound_debounce_time = level.time + 0.0;
}
else if ( self->client->pers.inventory[ITEM_INDEX(FindItem("bullets"))]
	&&  self->client->pers.inventory[ITEM_INDEX(FindItem("machinegun"))] )
{
Precalcpos (self);
//self->client->pers.weapon = FindItem("machinegun");
Machinegun_Fire (self);
if (!practice->value)
self->client->pers.inventory[ITEM_INDEX(FindItem("bullets"))] = self->client->pers.inventory[ITEM_INDEX(FindItem("bullets"))] - 1;
self->fly_sound_debounce_time = level.time + 0.1;
}
else if ( self->client->pers.inventory[ITEM_INDEX(FindItem("shells"))] > 1
	&&  self->client->pers.inventory[ITEM_INDEX(FindItem("super shotgun"))] )

{
Precalcpos2 (self);
//self->client->pers.weapon = FindItem("super shotgun");
weapon_supershotgun_fire (self);
if (!practice->value)
self->client->pers.inventory[ITEM_INDEX(FindItem("shells"))] = self->client->pers.inventory[ITEM_INDEX(FindItem("shells"))] - 2;
self->fly_sound_debounce_time = level.time + 1.0;
}
else if ( self->client->pers.inventory[ITEM_INDEX(FindItem("shells"))]
	&&  self->client->pers.inventory[ITEM_INDEX(FindItem("shotgun"))] )
{
Precalcpos2 (self);
//self->client->pers.weapon = FindItem("Shotgun");
weapon_shotgun_fire (self);
if (!practice->value)
self->client->pers.inventory[ITEM_INDEX(FindItem("shells"))] = self->client->pers.inventory[ITEM_INDEX(FindItem("shells"))] - 1;
self->fly_sound_debounce_time = level.time + 0.5;
}
else
{
//self->client->pers.weapon = FindItem("Blaster");
Weapon_Blaster_Fire (self);
self->fly_sound_debounce_time = level.time + 0.3;
}
self->s.angles[0] = 0;
}

void CheckWeapClose (edict_t *self)
{
		vec3_t	v;
edict_t *crent;

if (level.time < self->fly_sound_debounce_time)
{
self->monsterinfo.currentmove = &bot_move_run;
return;
}

if (self->enemy == NULL) {
self->monsterinfo.currentmove = &bot_move_run;
return;
}

if (self->enemy->health < 1) {
self->monsterinfo.currentmove = &bot_move_run;
return;
}

	VectorSubtract (self->enemy->s.origin, self->s.origin, v);
	vectoangles(v, self->s.angles);
if (strcmp(self->enemy->classname, "player") == 0 && self->enemy->client->ps.pmove.pm_flags & PMF_DUCKED)
{
crent = G_Spawn();
VectorCopy (self->enemy->s.origin, crent->s.origin);
crent->s.origin[2] = crent->s.origin[2] - 20;
VectorSubtract (crent->s.origin, self->s.origin, v);
vectoangles(v, self->s.angles);
crent->think = G_FreeEdict;
crent->nextthink = level.time;
}

if (self->shittyquadhacktime > level.time) {
gi.sound(self, CHAN_ITEM, gi.soundindex("items/damage3.wav"), 1, ATTN_NORM, 0);
}

NoAmmoWeaponChange (self);
SelectRealWeaponClose (self);

if ( self->client->pers.inventory[ITEM_INDEX(FindItem("slugs"))]
	 &&  self->client->pers.inventory[ITEM_INDEX(FindItem("railgun"))] )
{
Precalcpos2 (self);
//self->client->pers.weapon = FindItem("railgun");
weapon_railgun_fire (self);
self->client->pers.inventory[ITEM_INDEX(FindItem("slugs"))] = self->client->pers.inventory[ITEM_INDEX(FindItem("slugs"))] - 1;
self->fly_sound_debounce_time = level.time + 2.0;
}
else if ( self->client->pers.inventory[ITEM_INDEX(FindItem("cells"))]
	&&  self->client->pers.inventory[ITEM_INDEX(FindItem("hyperblaster"))] )
{
Precalcpos (self);
//self->client->pers.weapon = FindItem("hyperblaster");
Weapon_HyperBlaster_Fire (self);
self->client->pers.inventory[ITEM_INDEX(FindItem("cells"))] = self->client->pers.inventory[ITEM_INDEX(FindItem("cells"))] - 1;
self->fly_sound_debounce_time = level.time + 0.0;
}
else if ( self->client->pers.inventory[ITEM_INDEX(FindItem("bullets"))]
	&&  self->client->pers.inventory[ITEM_INDEX(FindItem("chaingun"))] )
{
Precalcpos (self);
//self->client->pers.weapon = FindItem("chaingun");
Chaingun_Fire (self);
self->client->pers.inventory[ITEM_INDEX(FindItem("bullets"))] = self->client->pers.inventory[ITEM_INDEX(FindItem("bullets"))] - 1;
self->fly_sound_debounce_time = level.time + 0.0;
}
else if ( self->client->pers.inventory[ITEM_INDEX(FindItem("bullets"))]
	&&  self->client->pers.inventory[ITEM_INDEX(FindItem("machinegun"))] )
{
Precalcpos (self);
//self->client->pers.weapon = FindItem("machinegun");
Machinegun_Fire (self);
self->client->pers.inventory[ITEM_INDEX(FindItem("bullets"))] = self->client->pers.inventory[ITEM_INDEX(FindItem("bullets"))] - 1;
self->fly_sound_debounce_time = level.time + 0.1;
}
else if ( self->client->pers.inventory[ITEM_INDEX(FindItem("shells"))] > 1
	&&  self->client->pers.inventory[ITEM_INDEX(FindItem("super shotgun"))] )

{
Precalcpos2 (self);
//self->client->pers.weapon = FindItem("super shotgun");
weapon_supershotgun_fire (self);
self->client->pers.inventory[ITEM_INDEX(FindItem("shells"))] = self->client->pers.inventory[ITEM_INDEX(FindItem("shells"))] - 2;
self->fly_sound_debounce_time = level.time + 1.0;
}
else if ( self->client->pers.inventory[ITEM_INDEX(FindItem("shells"))]
	&&  self->client->pers.inventory[ITEM_INDEX(FindItem("shotgun"))] )
{
Precalcpos2 (self);
//self->client->pers.weapon = FindItem("Shotgun");
weapon_shotgun_fire (self);
self->client->pers.inventory[ITEM_INDEX(FindItem("shells"))] = self->client->pers.inventory[ITEM_INDEX(FindItem("shells"))] - 1;
self->fly_sound_debounce_time = level.time + 0.5;
}
else
{
//self->client->pers.weapon = FindItem("Blaster");
Weapon_Blaster_Fire (self);
self->fly_sound_debounce_time = level.time + 0.3;
}
self->s.angles[0] = 0;
}


void bot_fire (edict_t *self)
{
	if (level.time >= self->monsterinfo.pausetime)
		self->monsterinfo.aiflags &= ~AI_HOLD_FRAME;
	else
		self->monsterinfo.aiflags |= AI_HOLD_FRAME;
CheckWeap (self);

}

void bot_fireclose (edict_t *self)
{
	if (level.time >= self->monsterinfo.pausetime)
		self->monsterinfo.aiflags &= ~AI_HOLD_FRAME;
	else
		self->monsterinfo.aiflags |= AI_HOLD_FRAME;
CheckWeapClose (self);

}

void bot_painfire (edict_t *self)
{
	if (level.time >= self->monsterinfo.pausetime)
		self->monsterinfo.aiflags &= ~AI_HOLD_FRAME;
	else
		self->monsterinfo.aiflags |= AI_HOLD_FRAME;
PainCheckWeap (self);

}



void bot_sight (edict_t *self, edict_t *other)
{
}

void bot_duck_down (edict_t *self)
{
self->s.origin[2] += 3;

	if (self->monsterinfo.aiflags & AI_DUCKED)
		return;
	self->monsterinfo.aiflags |= AI_DUCKED;
	self->maxs[2] -= 32;
	self->viewheight = 11;
	gi.linkentity (self);
}

void bot_duck_hold (edict_t *self)
{
	if (level.time >= self->monsterinfo.pausetime)
		self->monsterinfo.aiflags &= ~AI_HOLD_FRAME;
	else
		self->monsterinfo.aiflags |= AI_HOLD_FRAME;
}

void blah (edict_t *self)
{
	self->maxs[2] += 32;
	self->viewheight = 22;
}

void bot_duck_up (edict_t *self)
{
self->s.origin[2] += 3;	

	self->monsterinfo.aiflags &= ~AI_DUCKED;
	self->maxs[2] += 32;
	self->viewheight = 22;
	gi.linkentity (self);
}
mframe_t bot_frames_duck [] =
{
	ai_move, 0, bot_duck_down,
	ai_move, 0, CheckWeap,
	ai_move, 0, bot_duck_up,
	ai_run, 0,  NULL,
	ai_run, 0,  NULL
};
mmove_t bot_move_duck = {FRAME_crstnd01, FRAME_crstnd05, bot_frames_duck, bot_run};

mframe_t bot_frames_duckclose [] =
{
	ai_move, 0, bot_duck_down,
        ai_move, 0, CheckWeapClose,
	ai_move, 0,  bot_duck_up,
	ai_run, 0,  NULL,
	ai_run, 0,  NULL
};
mmove_t bot_move_duckclose = {FRAME_crstnd01, FRAME_crstnd05, bot_frames_duckclose, bot_run};


mframe_t bot_frames_duck2 [] =
{
	ai_move, 0, CheckWeap,
	ai_move, 0,  bot_duck_up
};
mmove_t bot_move_duck2 = {FRAME_crstnd04, FRAME_crstnd05, bot_frames_duck, bot_run};

void bot_jump (edict_t *self) {
vec3_t forward;
vec3_t v;

	AngleVectors (self->s.angles, forward, NULL, NULL);
	self->velocity[2] = 320;
if (gi.inPVS(self->s.origin, self->enemy->s.origin))
{
if (visible(self, self->enemy))
{
	VectorSubtract (self->enemy->s.origin, self->s.origin, v);
	vectoangles(v, self->s.angles);
}
}

if (strcmp(self->teambot, "botteam") == 0 && strcmp(self->botsex, "female") == 0)
	gi.sound (self, CHAN_VOICE, gi.soundindex ("player/female/jump1.wav"), 1, ATTN_IDLE, 0);
else if (strcmp(self->teambot, "botteam") == 0 && strcmp(self->botsex, "male") == 0)
	gi.sound (self, CHAN_VOICE, gi.soundindex ("player/male/jump1.wav"), 1, ATTN_IDLE, 0);

	self->groundentity = NULL;
}

mframe_t bot_frames_jump [] =
{
	ai_run, 0, bot_jump,
	ai_run, 0, NULL,
	ai_run, 0,  NULL,
	ai_run, 0,  NULL,
	ai_run, 0,  NULL,
	ai_run, 0,  NULL
};
mmove_t bot_move_jump = {FRAME_jump1, FRAME_jump6, bot_frames_jump, bot_run};

void bot_dodge (edict_t *self, edict_t *attacker, float eta)
{
	if (random() > 0.25)
		return;

	if (!self->enemy)
		self->enemy = attacker;

	self->monsterinfo.currentmove = &bot_move_duck;
}

void checkrefire (edict_t *self) {
if (self->enemy->health < 1) {
self->enemy = world;
self->monsterinfo.currentmove = &bot_move_stand1;
return;
}
//SelectRealWeapon (self);
//if (self->client->pers.weapon == FindItem("hyperblaster")) {
//self->monsterinfo.currentmove = &bot_move_attack1;
//return;
//}
//if (self->client->pers.weapon == FindItem("machinegun")) {
//self->monsterinfo.currentmove = &bot_move_attack1;
//return;
//}
//if (self->client->pers.weapon == FindItem("chaingun")) {
//self->monsterinfo.currentmove = &bot_move_attack1;
//return;
//}
}

void ai_chargebad (edict_t *self, float dist)
{
vec3_t forward, right, up;

if (self->enemy == NULL)
return;

if (self->enemy->deadflag == DEAD_DEAD)
return;

if (self->enemy->health < 1)
return;


if (skill->value == 0)
return;

if (!gi.inPVS(self->s.origin, self->enemy->s.origin))
{
ai_run (self, dist);
return;
}

if (!visible(self, self->enemy))
{
ai_run (self, dist);
return;
}

if (self->footsteptime < level.time) {
	if (self->groundentity) {
		if (!nofootsteps->value) {
		gi.sound (self, CHAN_BODY, gi.soundindex(va("player/step%i.wav", (rand()%4)+1)), 1, ATTN_NORM, 0);
		self->footsteptime = level.time + 0.3;
		}
	}
}

CheckBotPowerups (self);

if (random() < .2) {
	self->groundentity = NULL;

	AngleVectors (self->s.angles, forward, right, up);
	self->s.origin[2] += 1;
	VectorScale (right, 175, self->velocity);
	self->velocity[2] = 1;
}
else if (random() < .4) {
	self->groundentity = NULL;

	AngleVectors (self->s.angles, forward, right, up);
	self->s.origin[2] += 1;
	VectorScale (right, -175, self->velocity);
	self->velocity[2] = 1;
}
else {
	self->groundentity = NULL;

	AngleVectors (self->s.angles, forward, right, up);
	self->s.origin[2] += 1;
	VectorScale (forward, 175, self->velocity);
	self->velocity[2] = 1;
}

}

mframe_t bot_frames_attack1 [] =
{
	ai_run, 0,  NULL,
	ai_run, 0,  NULL,
	ai_chargebad, 0,  bot_fire,
	ai_run, 0,  checkrefire,
	ai_run, 0,  checkrefire,
	ai_run, 0,  checkrefire,
	ai_run, 0,  checkrefire,
	ai_run, 0,  checkrefire,
	ai_run, 0,  checkrefire,
	ai_run, 0,  checkrefire,
	ai_run, 0,  checkrefire,
	ai_run, 0,  checkrefire
};

mframe_t bot_frames_attackclose1 [] =
{
	ai_run, 0,  NULL,
	ai_run, 0,  NULL,
	ai_chargebad, 0,  bot_fireclose,
	ai_run, 0,  NULL,
	ai_run, 0,  NULL,
	ai_run, 0,  NULL,
	ai_run, 0,  NULL,
	ai_run, 0,  NULL,
	ai_run, 0,  NULL,
	ai_run, 0,  NULL,
	ai_run, 0,  NULL,
	ai_run, 0,  NULL
};

mframe_t bot_frames_painattack1 [] =
{
	ai_charge, 0,  NULL,
	ai_charge, 0,  NULL,
	ai_charge, 0,  bot_painfire,
	ai_charge, 0,  NULL,
	ai_charge, 0,  NULL,
	ai_charge, 0,  NULL,
	ai_charge, 0,  NULL,
	ai_charge, 0,  NULL,
	ai_charge, 0,  NULL,
	ai_charge, 0,  NULL,
	ai_charge, 0,  NULL,
	ai_charge, 0,  NULL
};

mframe_t bot_frames_coopattackclose1 [] =
{
	ai_run, 0,  NULL,
	ai_run, 0,  NULL,
	ai_chargebad, 0,  bot_fire,
	ai_run, 0,  NULL,
	ai_run, 0,  NULL,
	ai_run, 0,  NULL,
	ai_run, 0,  NULL,
	ai_run, 0,  NULL,
	ai_run, 0,  NULL,
	ai_run, 0,  NULL,
	ai_run, 0,  NULL,
	ai_run, 0,  NULL
};

mmove_t bot_move_coopattackclose1 = {FRAME_attack1, FRAME_attack8, bot_frames_coopattackclose1, bot_run};

mmove_t bot_move_attack1 = {FRAME_attack1, FRAME_attack8, bot_frames_attack1, bot_run};
mmove_t bot_move_attackclose1 = {FRAME_attack1, FRAME_attack8, bot_frames_attackclose1, bot_run};

mmove_t bot_move_painattack1 = {FRAME_attack1, FRAME_attack8, bot_frames_painattack1, bot_run};

void bot_painattack(edict_t *self)
{
		self->monsterinfo.currentmove = &bot_move_painattack1;
}

void bot_attack(edict_t *self)
{
vec3_t v;
float len;

if (level.time < self->fly_sound_debounce_time)
{
self->monsterinfo.currentmove = &bot_move_run;
return;
}
if (teamplaybots->value) {
if (self->enemy->team == self->team)
return;
}

if (coop->value) {
if (strcmp(self->enemy->classname, "player") == 0)
return;
}
	VectorSubtract (self->s.origin, self->enemy->s.origin, v);
	len = VectorLength (v);
	if (len < MELEE_DISTANCE)
	SelectRealWeaponClose (self);
else
SelectRealWeapon (self);

self->monsterinfo.currentmove = &bot_move_attack1;
}

void bot_attackclose(edict_t *self)
{
if (practice->value) {
bot_attack(self);
return;
}

if (level.time < self->fly_sound_debounce_time)
{
self->monsterinfo.currentmove = &bot_move_run;
return;
}
if (teamplaybots->value) {
if (self->enemy->team == self->team)
return;
}

if (coop->value) {
if (strcmp(self->enemy->classname, "player") == 0)
return;
}

SelectRealWeaponClose (self);

self->monsterinfo.currentmove = &bot_move_attackclose1;
}


void ai_coop (edict_t *self, float dist)
{
float 	len;
vec3_t	v2;

if (self->spawner == NULL) {
self->enemy = world;
self->goalentity = world;
self->monsterinfo.currentmove = &bot_move_stand1;
return;
}
CheckBotPowerups (self);

VectorSubtract (self->s.origin, self->spawner->s.origin, v2);
len = VectorLength (v2);

if (self->spawner->velocity[0] > 0 || self->spawner->velocity[0] < 0) {
if (len > 99) {
self->monsterinfo.currentmove = &bot_move_run;
return;
}
}
if (self->spawner->velocity[1] > 0 || self->spawner->velocity[1] < 0) {
if (len > 399) {
self->monsterinfo.currentmove = &bot_move_run;
return;
}
}

}

void ai_team (edict_t *self, float dist)
{
edict_t *newvict;

CheckBotPowerups (self);

	newvict = killothers (self);
	if (newvict)
	{
	self->enemy = newvict;
	self->goalentity = newvict;
	FoundTarget (self);
	self->monsterinfo.currentmove = &bot_move_run;
	return;
	}

if (self->spawner == NULL) {
self->enemy = world;
self->goalentity = world;
self->monsterinfo.currentmove = &bot_move_stand1;
return;
}

if (self->spawner->velocity[0] > 0 || self->spawner->velocity[0] < 0) {
self->monsterinfo.currentmove = &bot_move_run;
return;
}
if (self->spawner->velocity[1] > 0 || self->spawner->velocity[1] < 0) {
self->monsterinfo.currentmove = &bot_move_run;
return;
}

}

void Insult (edict_t *self, edict_t *loser)
{
if (self->client->resp.score < loser->client->resp.score) {
if (self->client->resp.score < loser->client->resp.score - 20)
{
if (random() < .1)
gi.bprintf (PRINT_CHAT, "%s: Heh... I'm all luck, %s\n", self->client->pers.netname, loser->client->pers.netname);
else if (random() < .2)
gi.bprintf (PRINT_CHAT, "%s: WHEW! Finally got ya, %s!\n", self->client->pers.netname, loser->client->pers.netname);
else if (random() < .3)
gi.bprintf (PRINT_CHAT, "%s: I...I killed %s? I...don't remember... it all happened so fast!\n", self->client->pers.netname, loser->client->pers.netname);
else if (random() < .4)
gi.bprintf (PRINT_CHAT, "%s: Well, %s, maybe I DON'T suck afterall, eh? Oh well, I probably do.\n", self->client->pers.netname, loser->client->pers.netname);
else if (random() < .5)
gi.bprintf (PRINT_CHAT, "%s: Sure, I'm losing by a ton, but does that mean I suck? Probably.\n", self->client->pers.netname);
else
gi.bprintf (PRINT_CHAT, "%s: Not bad for a beginner, eh %s?\n", self->client->pers.netname, loser->client->pers.netname);
}
else if (self->client->resp.score < loser->client->resp.score - 10)
{
if (random() < .1)
gi.bprintf (PRINT_CHAT, "%s: Well, %s, what can I say? You're good... but not good enough\n", self->client->pers.netname, loser->client->pers.netname);
else if (random() < .2)
gi.bprintf (PRINT_CHAT, "%s: I'll get you %s, and your little dog, too\n", self->client->pers.netname, loser->client->pers.netname);
else if (random() < .3)
gi.bprintf (PRINT_CHAT, "%s: Oh, I get how you play now, %s... you're mine.\n", self->client->pers.netname, loser->client->pers.netname);
else if (random() < .4)
gi.bprintf (PRINT_CHAT, "%s: What's that, %s? Do I smell smoke?\n", self->client->pers.netname, loser->client->pers.netname);
else if (random() < .5)
gi.bprintf (PRINT_CHAT, "%s: Oops! Sorry %s, I thought my weapon was loaded with paintballs! Honest!\n", self->client->pers.netname, loser->client->pers.netname);
else
gi.bprintf (PRINT_CHAT, "%s: YEAH BABY, YEAH!\n", self->client->pers.netname);
}
else if (self->client->resp.score < loser->client->resp.score - 5)
{
if (random() < .1)
gi.bprintf (PRINT_CHAT, "%s: Ok, %s, I'm back on track now\n", self->client->pers.netname, loser->client->pers.netname);
else if (random() < .2)
gi.bprintf (PRINT_CHAT, "%s: You aren't gonna win THAT easy, %s.\n", self->client->pers.netname, loser->client->pers.netname);
else if (random() < .3)
gi.bprintf (PRINT_CHAT, "%s: Umm, ok %s, I'd appreciate it if you could not bleed on my clothes next time.\n", self->client->pers.netname, loser->client->pers.netname);
else if (random() < .4)
gi.bprintf (PRINT_CHAT, "%s: You might wanna get that fixed, %s\n", self->client->pers.netname, loser->client->pers.netname);
else if (random() < .5)
gi.bprintf (PRINT_CHAT, "%s: Uh oh... BRB, I have to clean this %s off my shirt before it sets in.\n", self->client->pers.netname, loser->client->pers.netname);
else
gi.bprintf (PRINT_CHAT, "%s: Is that a %s hair in my coke?\n", self->client->pers.netname, loser->client->pers.netname);
}
else
{
if (random() < .1)
gi.bprintf (PRINT_CHAT, "%s: I can still catch up with you, %s, don't get cocky\n", self->client->pers.netname, loser->client->pers.netname);
else if (random() < .2)
gi.bprintf (PRINT_CHAT, "%s: You're alllll mine, %s.\n", self->client->pers.netname, loser->client->pers.netname);
else if (random() < .3)
gi.bprintf (PRINT_CHAT, "%s: Come on, %s, just you and me.\n", self->client->pers.netname, loser->client->pers.netname);
else if (random() < .4)
gi.bprintf (PRINT_CHAT, "%s: The best part of wakin' uuup is %s gibs in your cuuup!\n", self->client->pers.netname, loser->client->pers.netname);
else if (random() < .5)
gi.bprintf (PRINT_CHAT, "%s: Oh my, %s, that didn't look like it felt very nice.\n", self->client->pers.netname, loser->client->pers.netname);
else
gi.bprintf (PRINT_CHAT, "%s: Well, %s, looks like things might even up.\n", self->client->pers.netname, loser->client->pers.netname);
}

}
else if (self->client->resp.score > loser->client->resp.score) {
if (self->client->resp.score > loser->client->resp.score + 10)
{
if (random() < .1)
gi.bprintf (PRINT_CHAT, "%s: You're never going to catch up to me, %s. Just give up.\n", self->client->pers.netname, loser->client->pers.netname);
else if (random() < .2)
gi.bprintf (PRINT_CHAT, "%s: Hey %s, have you tried reading one of those ""DeathMatch for Dummies"" books?\n", self->client->pers.netname, loser->client->pers.netname);
else if (random() < .3)
gi.bprintf (PRINT_CHAT, "%s: Oh %s, you make me feel so... alive!\n", self->client->pers.netname, loser->client->pers.netname);
else if (random() < .4)
gi.bprintf (PRINT_CHAT, "%s: Me? Using a bot? No way %s, I'm all skill!\n", self->client->pers.netname, loser->client->pers.netname);
else if (random() < .5)
gi.bprintf (PRINT_CHAT, "%s: Hey %s, are you letting your mom play again?\n", self->client->pers.netname, loser->client->pers.netname);
else
gi.bprintf (PRINT_CHAT, "%s: You do know there's an autorun option, don't you?\n", self->client->pers.netname, loser->client->pers.netname);
}
else if (self->client->resp.score > loser->client->resp.score + 5)
{
if (random() < .1)
gi.bprintf (PRINT_CHAT, "%s: ahh... yep. I'm good.\n", self->client->pers.netname);
else if (random() < .2)
gi.bprintf (PRINT_CHAT, "%s: Don't feel bad %s, you just aren't gifted like me\n", self->client->pers.netname, loser->client->pers.netname);
else if (random() < .3)
gi.bprintf (PRINT_CHAT, "%s: Come on %s, don't give up now!\n", self->client->pers.netname, loser->client->pers.netname);
else if (random() < .4)
gi.bprintf (PRINT_CHAT, "%s: I think you just need to practice more, %s.\n", self->client->pers.netname, loser->client->pers.netname);
else if (random() < .5)
gi.bprintf (PRINT_CHAT, "%s: I just want you to know that I think you're taking this beating very well, %s\n", self->client->pers.netname, loser->client->pers.netname);
else
gi.bprintf (PRINT_CHAT, "%s: Is that freshly cooked whupass I smell, %s?\n", self->client->pers.netname, loser->client->pers.netname);

}
else
{
if (random() < .1)
gi.bprintf (PRINT_CHAT, "%s: Come on, %s, I can take you\n", self->client->pers.netname, loser->client->pers.netname);
else if (random() < .2)
gi.bprintf (PRINT_CHAT, "%s: You're goin' down, %s.\n", self->client->pers.netname, loser->client->pers.netname);
else if (random() < .3)
gi.bprintf (PRINT_CHAT, "%s: Oh, so %s, you want some?\n", self->client->pers.netname, loser->client->pers.netname);
else if (random() < .4)
gi.bprintf (PRINT_CHAT, "%s: That's right %s, you know who yo daddy is\n", self->client->pers.netname, loser->client->pers.netname);
else if (random() < .5)
gi.bprintf (PRINT_CHAT, "%s: Better get that taken care of, %s. It could get infected.\n", self->client->pers.netname, loser->client->pers.netname);
else
gi.bprintf (PRINT_CHAT, "%s: It's ok, %s, just lay back and close your eyes. It won't hurt as much that way.\n", self->client->pers.netname, loser->client->pers.netname);

}

}
else
{
if (random() < .1)
gi.bprintf (PRINT_CHAT, "%s: Oh look, a tie! Well %s, we'll just have to fix that!\n", self->client->pers.netname, loser->client->pers.netname);
else if (random() < .2)
gi.bprintf (PRINT_CHAT, "%s: Time to pay your pimp, %s\n", self->client->pers.netname, loser->client->pers.netname);
else if (random() < .3)
gi.bprintf (PRINT_CHAT, "%s: Come on %s, it's time to ride daddy's rocket\n", self->client->pers.netname, loser->client->pers.netname);
else if (random() < .4)
gi.bprintf (PRINT_CHAT, "%s: Look %s, we're tied... want me to fix that? Ok then!\n", self->client->pers.netname, loser->client->pers.netname);
else if (random() < .5)
gi.bprintf (PRINT_CHAT, "%s: Damn %s, I thought you were better than this\n", self->client->pers.netname, loser->client->pers.netname);
else
gi.bprintf (PRINT_CHAT, "%s: Alright, %s, I'm not showing any mercy this time.\n", self->client->pers.netname, loser->client->pers.netname);

}

}

void ai_type (edict_t *self, float dist)
{
CheckBotPowerups (self);

if (self->spawner == NULL) {
self->enemy = world;
self->goalentity = world;
self->monsterinfo.currentmove = &bot_move_stand1;
return;
}

if (self->health < 1)
return;

if (self->deadflag == DEAD_DEAD)
return;

if (gi.inPVS(self->s.origin, self->spawner->s.origin))
{
if (visible(self, self->spawner))
{
if (self->spawner->health > 0)
{
self->monsterinfo.currentmove = &bot_move_run;
}
}
}

if (self->talkthink < level.time) {
Insult (self, self->whotoinsult);
self->monsterinfo.currentmove = &bot_move_run;
}

}

mmove_t bot_move_standcoop;

void bot_standcoop (edict_t *self)
{
		self->monsterinfo.currentmove = &bot_move_standcoop;
}

mmove_t bot_move_standteam;

void bot_standteam (edict_t *self)
{
		self->monsterinfo.currentmove = &bot_move_standteam;
}

mmove_t bot_move_standtype;

void bot_standtype (edict_t *self)
{
		self->monsterinfo.currentmove = &bot_move_standtype;
}

mframe_t bot_frames_standcoop [] =
{
	ai_coop, 0, NULL,
	ai_coop, 0, NULL,
	ai_coop, 0, NULL,
	ai_coop, 0, NULL,
	ai_coop, 0, NULL,
	ai_coop, 0, NULL,
	ai_coop, 0, NULL,
	ai_coop, 0, NULL,
	ai_coop, 0, NULL,
	ai_coop, 0, NULL,

	ai_coop, 0, NULL,
	ai_coop, 0, NULL,
	ai_coop, 0, NULL,
	ai_coop, 0, NULL,
	ai_coop, 0, NULL,
	ai_coop, 0, NULL,
	ai_coop, 0, NULL,
	ai_coop, 0, NULL,
	ai_coop, 0, NULL,
	ai_coop, 0, NULL,

	ai_coop, 0, NULL,
	ai_coop, 0, NULL,
	ai_coop, 0, NULL,
	ai_coop, 0, NULL,
	ai_coop, 0, NULL,
	ai_coop, 0, NULL,
	ai_coop, 0, NULL,
	ai_coop, 0, NULL,
	ai_coop, 0, NULL,
	ai_coop, 0, NULL,

	ai_coop, 0, NULL,
	ai_coop, 0, NULL,
	ai_coop, 0, NULL,
	ai_coop, 0, NULL,
	ai_coop, 0, NULL,
	ai_coop, 0, NULL,
	ai_coop, 0, NULL,
	ai_coop, 0, NULL,
	ai_coop, 0, NULL,
	ai_coop, 0, NULL,


};
mmove_t bot_move_standcoop = {FRAME_stand01, FRAME_stand40, bot_frames_standcoop, bot_standcoop};

mframe_t bot_frames_standtype [] =
{
	ai_type, 0, NULL,
	ai_type, 0, NULL,
	ai_type, 0, NULL,
	ai_type, 0, NULL,
	ai_type, 0, NULL,
	ai_type, 0, NULL,
	ai_type, 0, NULL,
	ai_type, 0, NULL,
	ai_type, 0, NULL,
	ai_type, 0, NULL,

	ai_type, 0, NULL,
	ai_type, 0, NULL,
	ai_type, 0, NULL,
	ai_type, 0, NULL,
	ai_type, 0, NULL,
	ai_type, 0, NULL,
	ai_type, 0, NULL,
	ai_type, 0, NULL,
	ai_type, 0, NULL,
	ai_type, 0, NULL,

	ai_type, 0, NULL,
	ai_type, 0, NULL,
	ai_type, 0, NULL,
	ai_type, 0, NULL,
	ai_type, 0, NULL,
	ai_type, 0, NULL,
	ai_type, 0, NULL,
	ai_type, 0, NULL,
	ai_type, 0, NULL,
	ai_type, 0, NULL,

	ai_type, 0, NULL,
	ai_type, 0, NULL,
	ai_type, 0, NULL,
	ai_type, 0, NULL,
	ai_type, 0, NULL,
	ai_type, 0, NULL,
	ai_type, 0, NULL,
	ai_type, 0, NULL,
	ai_type, 0, NULL,
	ai_type, 0, NULL,


};
mmove_t bot_move_standtype = {FRAME_stand01, FRAME_stand40, bot_frames_standtype, bot_standtype};


mframe_t bot_frames_standteam [] =
{
	ai_team, 0, NULL,
	ai_team, 0, NULL,
	ai_team, 0, NULL,
	ai_team, 0, NULL,
	ai_team, 0, NULL,
	ai_team, 0, NULL,
	ai_team, 0, NULL,
	ai_team, 0, NULL,
	ai_team, 0, NULL,
	ai_team, 0, NULL,

	ai_team, 0, NULL,
	ai_team, 0, NULL,
	ai_team, 0, NULL,
	ai_team, 0, NULL,
	ai_team, 0, NULL,
	ai_team, 0, NULL,
	ai_team, 0, NULL,
	ai_team, 0, NULL,
	ai_team, 0, NULL,
	ai_team, 0, NULL,

	ai_team, 0, NULL,
	ai_team, 0, NULL,
	ai_team, 0, NULL,
	ai_team, 0, NULL,
	ai_team, 0, NULL,
	ai_team, 0, NULL,
	ai_team, 0, NULL,
	ai_team, 0, NULL,
	ai_team, 0, NULL,
	ai_team, 0, NULL,

	ai_team, 0, NULL,
	ai_team, 0, NULL,
	ai_team, 0, NULL,
	ai_team, 0, NULL,
	ai_team, 0, NULL,
	ai_team, 0, NULL,
	ai_team, 0, NULL,
	ai_team, 0, NULL,
	ai_team, 0, NULL,
	ai_team, 0, NULL,


};
mmove_t bot_move_standteam = {FRAME_stand01, FRAME_stand40, bot_frames_standteam, bot_standteam};

mframe_t bot_frames_stand1 [] =
{
	ai_stand, 0, NULL,
	ai_stand, 0, NULL,
	ai_stand, 0, NULL,
	ai_stand, 0, NULL,
	ai_stand, 0, NULL,
	ai_stand, 0, NULL,
	ai_stand, 0, NULL,
	ai_stand, 0, NULL,
	ai_stand, 0, NULL,
	ai_stand, 0, NULL,

	ai_stand, 0, NULL,
	ai_stand, 0, NULL,
	ai_stand, 0, NULL,
	ai_stand, 0, NULL,
	ai_stand, 0, NULL,
	ai_stand, 0, NULL,
	ai_stand, 0, NULL,
	ai_stand, 0, NULL,
	ai_stand, 0, NULL,
	ai_stand, 0, NULL,

	ai_stand, 0, NULL,
	ai_stand, 0, NULL,
	ai_stand, 0, NULL,
	ai_stand, 0, NULL,
	ai_stand, 0, NULL,
	ai_stand, 0, NULL,
	ai_stand, 0, NULL,
	ai_stand, 0, NULL,
	ai_stand, 0, NULL,
	ai_stand, 0, NULL


};
mmove_t bot_move_stand1 = {FRAME_stand01, FRAME_stand30, bot_frames_stand1, bot_stand};

void bot_stand (edict_t *self)
{
		self->monsterinfo.currentmove = &bot_move_stand1;
}

mframe_t bot_frames_walk1 [] =
{
	ai_walk, 3,  NULL,
	ai_walk, 6,  NULL,
	ai_walk, 2,  NULL,
	ai_walk, 2,  NULL,
	ai_walk, 2,  NULL,
	ai_walk, 1,  NULL,
	ai_walk, 6,  NULL,
	ai_walk, 5,  NULL,
	ai_walk, 3,  NULL,
	ai_walk, 0,  NULL,
	ai_walk, 0,  NULL,
	ai_walk, 0,  NULL,
	ai_walk, 0,  NULL,
	ai_walk, 0,  NULL,
	ai_walk, 0,  NULL,
	ai_walk, 0,  NULL,
	ai_walk, 0,  NULL,
	ai_walk, 0,  NULL,
	ai_walk, 0,  NULL,
	ai_walk, 0,  NULL,
	ai_walk, 0,  NULL,
	ai_walk, 0,  NULL,
	ai_walk, 0,  NULL,
	ai_walk, 0,  NULL,
	ai_walk, 0,  NULL,
	ai_walk, 0,  NULL,
	ai_walk, 0,  NULL,
	ai_walk, 0,  NULL,
	ai_walk, 0,  NULL,
	ai_walk, 0,  NULL,
	ai_walk, 0,  NULL,
	ai_walk, 0,  NULL,
	ai_walk, 0,  NULL
};
mmove_t bot_move_walk1 = {FRAME_run1, FRAME_run6, bot_frames_walk1, NULL};

void bot_walk (edict_t *self)
{
		self->monsterinfo.currentmove = &bot_move_walk1;
}

void bot_run (edict_t *self)
{
	if (self->monsterinfo.aiflags & AI_STAND_GROUND)
	{
		self->monsterinfo.currentmove = &bot_move_stand1;
		return;
	}

        if (self->monsterinfo.currentmove == &bot_move_walk1 ||
		self->monsterinfo.currentmove == &bot_move_walk1 ||
		self->monsterinfo.currentmove == &bot_move_start_run)
	{
		self->monsterinfo.currentmove = &bot_move_run;
	}
	else
	{
		self->monsterinfo.currentmove = &bot_move_start_run;
	}
}

void bot_crawl (edict_t *self)
{
		self->monsterinfo.currentmove = &bot_move_crawl;
}

void bot_dead (edict_t *self)
{
self->think = Respawn;
self->nextthink = level.time + 4.0;
}

mframe_t bot_frames_pain1 [] =
{
	ai_move, -3, NULL,
	ai_move, -2, NULL,
	ai_move, -1, NULL,
	ai_move, -2, NULL,
	ai_move, -1, NULL,
	ai_move, 1,  NULL,
	ai_move, -1, NULL,
	ai_move, 1,  NULL,
	ai_move, 6,  NULL,
	ai_move, 2,  NULL
};
mmove_t bot_move_pain1 = {FRAME_pain101, FRAME_pain104, bot_frames_pain1, bot_run};


mframe_t bot_frames_death1 [] =
{
	ai_move, 0,   NULL,
	ai_move, 0, NULL,
	ai_move, 0, NULL,
	ai_move, 0, NULL,
	ai_move, 0,  NULL,
	ai_move, 0,   NULL,
	ai_move, 0,   NULL,
	ai_move, 0,   NULL,
	ai_move, 0,   NULL,
	ai_move, 0,   NULL,

	ai_move, 0,   NULL,
	ai_move, 0,   NULL,
	ai_move, 0,   NULL,
	ai_move, 0,   NULL,
	ai_move, 0,   NULL,
	ai_move, 0,   NULL,
	ai_move, 0,   NULL,
	ai_move, 0,   NULL,
	ai_move, 0,   NULL,
	ai_move, 0,   NULL,

	ai_move, 0,   NULL,
	ai_move, 0,   NULL,
	ai_move, 0,   NULL,
	ai_move, 0,   NULL,
	ai_move, 0,   NULL,
	ai_move, 0,   NULL,
	ai_move, 0,   NULL,
	ai_move, 0,   NULL,
	ai_move, 0,   NULL,
	ai_move, 0,   NULL,

	ai_move, 0,   NULL,
	ai_move, 0,   NULL,
	ai_move, 0,   NULL,
	ai_move, 0,   NULL,
	ai_move, 0,   NULL,
	ai_move, 0,   NULL
};
mmove_t bot_move_death1 = {FRAME_death101, FRAME_death106, bot_frames_death1, bot_dead};
mmove_t bot_move_death2 = {FRAME_death201, FRAME_death206, bot_frames_death1, bot_dead};
mmove_t bot_move_death3 = {FRAME_death301, FRAME_death308, bot_frames_death1, bot_dead};

void tempentthink (edict_t *self)
{
if (self->owner->deadflag != DEAD_DEAD) {
self->owner->deathent = NULL;
self->think = G_FreeEdict;
self->nextthink = level.time;
return;
}
if (self->owner->health > 0) {
self->owner->deathent = NULL;
self->think = G_FreeEdict;
self->nextthink = level.time;
return;
}

   VectorCopy (self->owner->s.origin, self->s.origin);
   VectorCopy (self->owner->s.angles, self->s.angles);
   self->s.frame = self->owner->s.frame;
   self->think = tempentthink;
   self->nextthink = level.time;
}

void TossBotQuad (edict_t *self)
{
//	gitem_t		*item;
	edict_t		*drop;
	qboolean	quad;
	float		spread;

	if (!((int)(dmflags->value) & DF_QUAD_DROP))
		quad = false;
	else if (self->shittyquadhacktime > level.time)
		quad = (self->shittyquadhacktime - level.time);
	else
		quad = false;
//gi.bprintf (PRINT_HIGH, "Bot had %d sec left on quad\n", (self->shittyquadhacktime - level.time));
if (quad && quad != false) {
spread = 22.5;
//quad = level.time + 10;
self->client->v_angle[YAW] += spread;
drop = Drop_Item (self, FindItemByClassname ("item_quad"));
self->client->v_angle[YAW] -= spread;
drop->spawnflags |= DROPPED_PLAYER_ITEM;
drop->touch = Touch_Item;
drop->nextthink = (self->shittyquadhacktime - level.time);
drop->think = G_FreeEdict;
}

}

void bot_die (edict_t *self, edict_t *inflictor, edict_t *attacker, int damage, vec3_t point)
{
	int		n;
	edict_t	*tempent;
	static int i;

if (strcmp(self->teambot, "botteam") == 0 && !self->deathent) {
	tempent = G_Spawn();
	tempent->s.modelindex2 = self->s.modelindex2;
	tempent->s.modelindex = self->s.modelindex;
//	tempent->classname = self->botsex;
	strcpy (tempent->classname, self->botsex);
	self->deathent = tempent;
	tempent->owner = self;
	tempent->think = tempentthink;
	tempent->nextthink = level.time;
}
	VectorClear (self->avelocity);

	self->currnode = NULL;
	self->touchednode = NULL;
	self->takedamage = DAMAGE_YES;
	self->movetype = MOVETYPE_TOSS;

	self->s.modelindex2 = 0;	

	self->s.effects &= ~EF_QUAD;
	self->s.effects &= ~EF_PENT;
//	self->shittyquadhacktime = level.time;
	self->shittypenthacktime = level.time;
	self->nodelook = level.time + 0.5;

	self->s.angles[0] = 0;
	self->s.angles[2] = 0;

	self->s.sound = 0;
	self->client->weapon_sound = 0;

	self->maxs[2] = -8;

	self->svflags |= SVF_DEADMONSTER;

	self->insanity = 0;

	if (self->deadflag == DEAD_DEAD)
		return;

            self->s.modelindex2 = 0;
		ClientObituary (self, self->enemy, self->enemy);
//		SelectRealWeapon (self);
		TossClientWeapon (self);
		TossBotQuad (self);
		self->shittyquadhacktime = level.time;
		memset(self->client->pers.inventory, 0, sizeof(self->client->pers.inventory));
		self->enemy = NULL;
		self->itemwant = NULL;
		self->backoff = NULL;

	if (self->health <= self->gib_health)
	{
		gi.sound (self, CHAN_VOICE, gi.soundindex ("misc/udeath.wav"), 1, ATTN_NORM, 0);
		for (n= 0; n < 4; n++)
		ThrowGib (self, "models/objects/gibs/sm_meat/tris.md2", damage, GIB_ORGANIC);
		ThrowClientHead (self, damage);

		self->takedamage = DAMAGE_NO;
	self->deadflag = DEAD_DEAD;
	gi.linkentity (self);
	self->think = Respawn;
	self->nextthink = level.time + 4.0;
return;
	}
	else {
if (strcmp(self->teambot, "botteam") == 0 && strcmp(self->botsex, "female") == 0)
		gi.sound (self, CHAN_VOICE, gi.soundindex(va("player/female/death%i.wav", (rand()%4)+1)), 1, ATTN_NORM, 0);
else if (strcmp(self->teambot, "botteam") == 0 && strcmp(self->botsex, "male") == 0)
		gi.sound (self, CHAN_VOICE, gi.soundindex(va("player/male/death%i.wav", (rand()%4)+1)), 1, ATTN_NORM, 0);
//RANDOM DEATH ANIM
			i = (i+1)%3;
			// start a death animation
			switch (i)
			{
			case 0:
				self->monsterinfo.currentmove = &bot_move_death1;
				break;
			case 1:
				self->monsterinfo.currentmove = &bot_move_death2;
				break;
			case 2:
				self->monsterinfo.currentmove = &bot_move_death3;
				break;
			}

//RANDOM DEATH ANIM
	}
	self->deadflag = DEAD_DEAD;
	gi.linkentity (self);
}

void BotExplode (edict_t *self) {
int mod;
vec3_t origin;
edict_t *blow;

mod = MOD_HELD_GRENADE;

blow = G_Spawn();
blow->dmg_radius = 250;
blow->dmg = 100;
VectorCopy (self->s.origin, blow->s.origin);
blow->owner = self;
blow->enemy = self->spawner;
//T_RadiusDamage(blow, blow->owner, blow->dmg, blow->enemy, blow->dmg_radius, mod);
T_RadiusDamage(blow, blow->owner, blow->dmg, blow, blow->dmg_radius, mod);
blow->think = G_FreeEdict;
blow->nextthink = level.time + 0.1;
VectorMA (self->s.origin, -0.02, self->velocity, origin);
gi.WriteByte (svc_temp_entity);
gi.WriteByte (TE_GRENADE_EXPLOSION);
gi.WritePosition (origin);
gi.multicast (self->s.origin, MULTICAST_PHS);
self->insanity = 0;
}

void ai_mad (edict_t *self, float dist) {
vec3_t v;
vec3_t v2;
edict_t *goal;
vec3_t sloc;
float len;

CheckBotPowerups (self);
if (self->footsteptime < level.time) {
	if (self->groundentity) {
		if (!nofootsteps->value) {
		gi.sound (self, CHAN_BODY, gi.soundindex(va("player/step%i.wav", (rand()%4)+1)), 1, ATTN_NORM, 0);
		self->footsteptime = level.time + 0.3;
		}
	}
}

self->insanity = 1;
self->client->pers.weapon = FindItem("grenades");
VectorSubtract (self->spawner->s.origin, self->s.origin, v);
self->ideal_yaw = vectoyaw(v);
VectorSubtract (self->s.origin, self->spawner->s.origin, v2);
len = VectorLength (v2);
goal = self->currnode;

if (len < 50)
{
//gi.bprintf (PRINT_HIGH, "Bot would explode in insane rage\n");
BotExplode (self);
return;
}

	if ( (rand()&3)==1 || !SV_StepDirection (self, self->ideal_yaw, dist))
	{
		if (self->inuse)
			SV_NewChaseDir (self, goal, dist);
	}

//gi.bprintf (PRINT_HIGH, "Bot is after node %d\n", self->currnode->nodenum);
	M_walkmove (self, self->s.angles[YAW], 1);

VectorSubtract(self->spawner->s.origin, self->s.origin, sloc);
VectorScale (sloc, 4, self->velocity);
vectoangles(sloc, self->s.angles);
self->s.angles[0] = 0;
if (self->velocity[2] < -200)
self->velocity[2] = -200;
if (self->velocity[2] > 350)
self->velocity[2] = 350;
//if (self->spawner->s.origin[2] > self->s.origin[2])
//self->monsterinfo.currentmove = &bot_move_jump;

}

mmove_t bot_move_insane;

void bot_mad (edict_t *self) {
self->monsterinfo.currentmove = &bot_move_insane;
}

mframe_t bot_frames_insane [] =
{
	ai_mad, 10, NULL,
	ai_mad, 11, NULL,
	ai_mad, 11, NULL,
	ai_mad, 16, NULL,
	ai_mad, 10, NULL,
	ai_mad, 15, NULL
};
mmove_t bot_move_insane = {FRAME_run1, FRAME_run6, bot_frames_insane, bot_mad};

void bot_pain(edict_t *self, edict_t *other, float kick, int damage)
{
	int		r, l;

if (self->health < 1)
return;

if (self->deadflag == DEAD_DEAD)
return;

if (coop->value && self->spawner != NULL && other == self->spawner && !bottalk->value && self->paintalktime < level.time) {
self->paintalktime = level.time + 1;
if (self->health < 15) {
gi.bprintf (PRINT_CHAT, "%s: TRAITOR! YOU'RE ONE OF THEEEEM!\n", self->client->pers.netname);
//gi.bprintf (PRINT_HIGH, "Bot would go insane with grenade\n");
self->monsterinfo.currentmove = &bot_move_insane;
}
else if (self->health < 30) {
gi.bprintf (PRINT_CHAT, "%s: If you do that again... well... I don't know WHAT I'll do!\n", self->client->pers.netname);
}
else if (self->health < 50) {
gi.bprintf (PRINT_CHAT, "%s: OUCH! YOU #$^@!\n", self->client->pers.netname);
}
else if (self->health < 75) {
gi.bprintf (PRINT_CHAT, "%s: Ow... stop that.\n", self->client->pers.netname);
}
else if (self->health < 100) {
gi.bprintf (PRINT_CHAT, "%s: I know that was an honest mistake, but please don't do it again.\n", self->client->pers.netname);
}
}

if (self->watertype & CONTENTS_LAVA)
return;
if (self->watertype & CONTENTS_SLIME)
return;

if (level.time > self->pain_debounce_time)
{
r = 1 + (rand()&1);
self->pain_debounce_time = level.time + 0.7;
if (self->health < 25)
	l = 25;
else if (self->health < 50)
	l = 50;
else if (self->health < 75)
	l = 75;
else
	l = 100;

if (strcmp(self->teambot, "botteam") == 0 && strcmp(self->botsex, "female") == 0)
gi.sound (self, CHAN_VOICE, gi.soundindex(va("player/female/pain%i_%i.wav", l, r)), 1, ATTN_NORM, 0);
else if (strcmp(self->teambot, "botteam") == 0 && strcmp(self->botsex, "male") == 0)
gi.sound (self, CHAN_VOICE, gi.soundindex(va("player/male/pain%i_%i.wav", l, r)), 1, ATTN_NORM, 0);

}
}

void Laughat (edict_t *self)
{
gi.bprintf (PRINT_CHAT, "%s: I've got horrible AI and I can STILL kill you!\n", self->client->pers.netname);
self->monsterinfo.currentmove = &bot_move_stand1;
bot_stand (self);
}

void TossBotWeapon (edict_t *self)
{
	gitem_t		*item;
	edict_t		*drop;
	qboolean	quad;
	float		spread;

	if (!deathmatch->value)
		return;

	item = self->client->pers.weapon;
	if (item && (strcmp (item->pickup_name, "Blaster") == 0))
		item = NULL;

	if (!((int)(dmflags->value) & DF_QUAD_DROP))
		quad = false;
	else
		quad = (self->client->quad_framenum > (level.framenum + 10));

	if (item && quad)
		spread = 22.5;
	else
		spread = 0.0;

	if (item)
	{
		self->client->v_angle[YAW] -= spread;
		drop = Drop_Item (self, item);
		self->client->v_angle[YAW] += spread;
		drop->spawnflags = DROPPED_PLAYER_ITEM;
	}

	if (quad)
	{
		self->client->v_angle[YAW] += spread;
		drop = Drop_Item (self, FindItemByClassname ("item_quad"));
		self->client->v_angle[YAW] -= spread;
		drop->spawnflags |= DROPPED_PLAYER_ITEM;

		drop->touch = Touch_Item;
		drop->nextthink = level.time + (self->client->quad_framenum - level.framenum) * FRAMETIME;
		drop->think = G_FreeEdict;
	}
}

void Respawn (edict_t *self)
{
if (strcmp(self->teambot, "botteam") == 0)
Respawn2 (self);
else if (strcmp(self->teambot, "playerteam") == 0)
RespawnTeam (self);
else
RespawnCoop (self);
}

void BotCommentOld (edict_t *self)
{
	FILE *f;
	char filestr[25];

if (bottalk->value)
{
return;
}
f = fopen ("C:\\GAMES\\QUAKE2\\BOT\\IOEX.TXT", "r");

if (!f)
gi.cprintf (self->spawner, PRINT_MEDIUM, "Couldn't find bot-talk file\n");
else {
fread (filestr, sizeof(filestr), 1, f);
}

gi.bprintf (PRINT_CHAT, "%s: %s\n", self->client->pers.netname, filestr);

fclose (f);
}

void BotComment (edict_t *self)
{
if (bottalk->value)
{
return;
}
if (random() < .1)
{
gi.bprintf (PRINT_CHAT, "%s: I really can't say this makes me very happy.\n", self->client->pers.netname);
}
else if (random() < .2)
{
gi.bprintf (PRINT_CHAT, "%s: that's... just... lovely.\n", self->client->pers.netname);
}
else if (random() < .3)
{
gi.bprintf (PRINT_CHAT, "%s: I won't mess up next time... maybe.. I mean.. well.. nevermind.\n", self->client->pers.netname);
}
else if (random() < .4)
{
gi.bprintf (PRINT_CHAT, "%s: ahh... darn.\n", self->client->pers.netname);
}
else if (random() < .5)
{
gi.bprintf (PRINT_CHAT, "%s: d...doh...\n", self->client->pers.netname);
}
else
{
gi.bprintf (PRINT_CHAT, "%s: Ok, it's time to break out the ol' can of whupass.\n", self->client->pers.netname);
}

}

void dostuff(edict_t *self)
{
self->solid = SOLID_BBOX;
self->takedamage = DAMAGE_AIM;
walkmonster_start (self);
}

void Respawn2 (edict_t *self)
{
        vec3_t  spawn_origin, spawn_angles;
	client_respawn_t	resp;
		char		userinfo[16];
//char *themodel;
//char *theweapon;
//themodel = self->client->pers.modelstring;
//theweapon = self->client->pers.weaponstring;
	  strcpy(userinfo, self->client->pers.netname);

	  self->inuse = true;
        SelectSpawnPoint (self, spawn_origin, spawn_angles);
	  CopyToBodyQue (self);
		resp = self->client->resp;
        self->client = gi.TagMalloc(sizeof(gclient_t), TAG_GAME);

		InitClientPersistant (self->client);
		strcpy(self->client->pers.netname, userinfo);
		self->client->resp.score = resp.score;

        VectorCopy (spawn_origin, self->s.origin);
	  VectorCopy (spawn_angles, self->s.angles);
	  self->s.origin[2] += 1;
        self->classname = "player";
	  self->isabot = "bot";
        self->takedamage = DAMAGE_AIM;
        self->movetype = MOVETYPE_STEP;
        self->mass = 200;
        self->solid = SOLID_BBOX;
        self->deadflag = DEAD_NO;
        self->clipmask = MASK_PLAYERSOLID;
//	  self->model = "famke/female/tris.md2";
	  self->s.modelindex = self->deathent->s.modelindex;
//	  self->s.skinnum = 0;
	  self->s.modelindex2 = self->deathent->s.modelindex2;
//	  self->botsex = self->deathent->classname;

//gi.bprintf (PRINT_HIGH, "%s is a %s\n", self->client->pers.netname, self->botsex);
//self->modelstring = self->modelstring;
//self->weaponstring = self->weaponstring;
//gi.bprintf (PRINT_HIGH, "Model is %s\nWeapon is %s\n", self->client->pers.modelstring, self->client->pers.weaponstring);
	  self->s.effects = 0;
        self->s.frame = 0;
        self->waterlevel = 0;
        self->watertype = 0;
        self->health = 100;
	  self->gib_health = -40;
	  self->viewheight = 22;
        self->pain = bot_pain;
        self->die = bot_die;
	  self->monsterinfo.stand = bot_stand;
	  self->monsterinfo.walk = bot_walk;
	  self->monsterinfo.run = bot_run;
	  self->monsterinfo.attack = bot_attack;
	  self->monsterinfo.melee = bot_attackclose;
	  self->monsterinfo.sight = bot_sight;
	  self->monsterinfo.currentmove = &bot_move_jump;
	  self->monsterinfo.scale = MODEL_SCALE;

        VectorSet (self->mins, -16, -16, -24);
        VectorSet (self->maxs, 16, 16, 32);
        VectorClear (self->velocity);
	  self->s.origin[2] += 1;
	  walkmonster_start (self);
	  bot_stand (self);
	  gi.WriteByte (svc_muzzleflash);
	  gi.WriteShort (self-g_edicts);
	  gi.WriteByte (MZ_LOGIN);
	  gi.multicast (self->s.origin, MULTICAST_PVS);
        BotComment (self);
	  gi.unlinkentity (self);
	  if (!KillBox (self))
		  {
		  }

        gi.linkentity (self);
	self->touch_debounce_time = level.time + 1.5;
}

void RespawnTeam (edict_t *self)
{
        vec3_t  spawn_origin, spawn_angles;
	client_respawn_t	resp;
		char		userinfo[16];

	  strcpy(userinfo, self->client->pers.netname);
	  self->inuse = true;
        SelectSpawnPoint (self, spawn_origin, spawn_angles);
	  CopyToBodyQue (self);
	resp = self->client->resp;
        self->client = gi.TagMalloc(sizeof(gclient_t), TAG_GAME);

		resp = self->client->resp;
		InitClientPersistant (self->client);
		strcpy(self->client->pers.netname, userinfo);
		self->client->resp.score = resp.score;
        VectorCopy (spawn_origin, self->s.origin);
	  VectorCopy (spawn_angles, self->s.angles);
	  self->s.origin[2] += 1;
        self->classname = "player";
	  self->isabot = "bot";
        self->takedamage = DAMAGE_AIM;
        self->movetype = MOVETYPE_STEP;
        self->mass = 200;
        self->solid = SOLID_BBOX;
        self->deadflag = DEAD_NO;
        self->clipmask = MASK_PLAYERSOLID;
	  self->model = "famke/female/tris.md2";
	  self->s.modelindex = 255;
        self->s.modelindex2 = 255;
	  self->s.effects = 0;
        self->s.frame = 0;
        self->waterlevel = 0;
        self->watertype = 0;
        self->health = 100;
	  self->gib_health = -40;
	  self->viewheight = 22;
        self->pain = bot_pain;
        self->die = bot_die;
	  self->touch = bot_touch_team;
	  self->monsterinfo.stand = bot_stand;
	  self->monsterinfo.walk = bot_walk;
	  self->monsterinfo.run = bot_run;
	  self->monsterinfo.attack = bot_attack;
	  self->monsterinfo.melee = bot_attackclose;
	  self->monsterinfo.sight = bot_sight;
	  self->monsterinfo.currentmove = &bot_move_jump;
	  self->monsterinfo.scale = MODEL_SCALE;

        VectorSet (self->mins, -16, -16, -24);
        VectorSet (self->maxs, 16, 16, 32);
        VectorClear (self->velocity);
	  self->s.origin[2] += 1;
	  walkmonster_start (self);
	  bot_stand (self);
	  gi.WriteByte (svc_muzzleflash);
	  gi.WriteShort (self-g_edicts);
	  gi.WriteByte (MZ_LOGIN);
	  gi.multicast (self->s.origin, MULTICAST_PVS);
        BotComment (self);
	  gi.unlinkentity (self);
	  if (!KillBox (self))
		  {
		  }

        gi.linkentity (self);
	self->touch_debounce_time = level.time + 1.5;
}

void RespawnCoop (edict_t *self)
{
        vec3_t  spawn_origin, spawn_angles;
	client_respawn_t	resp;
		char		userinfo[16];

	  strcpy(userinfo, self->client->pers.netname);
	  self->inuse = true;
        SelectSpawnPoint (self, spawn_origin, spawn_angles);
	  CopyToBodyQue (self);
        self->client = gi.TagMalloc(sizeof(gclient_t), TAG_GAME);

		resp = self->client->resp;
		InitClientPersistant (self->client);
		strcpy(self->client->pers.netname, userinfo);

        VectorCopy (spawn_origin, self->s.origin);
	  VectorCopy (spawn_angles, self->s.angles);
	  self->s.origin[2] += 1;
        self->classname = "player";
	  self->isabot = "bot";
        self->takedamage = DAMAGE_AIM;
        self->movetype = MOVETYPE_STEP;
        self->mass = 200;
        self->solid = SOLID_BBOX;
        self->deadflag = DEAD_NO;
        self->clipmask = MASK_PLAYERSOLID;
	  self->model = "famke/female/tris.md2";
	  self->s.modelindex = 255;
        self->s.modelindex2 = 255;
	  self->s.effects = 0;
        self->s.frame = 0;
        self->waterlevel = 0;
        self->watertype = 0;
        self->health = 100;
	  self->gib_health = -40;
	  self->viewheight = 22;
        self->pain = bot_pain;
        self->die = bot_die;
	  self->touch = bot_touch_coop;
	  self->monsterinfo.stand = bot_stand;
	  self->monsterinfo.walk = bot_walk;
	  self->monsterinfo.run = bot_run;
	  self->monsterinfo.attack = bot_attack;
	  self->monsterinfo.melee = bot_attackclose;
	  self->monsterinfo.sight = bot_sight;
	  self->monsterinfo.currentmove = &bot_move_jump;
	  self->monsterinfo.scale = MODEL_SCALE;

        VectorSet (self->mins, -16, -16, -24);
        VectorSet (self->maxs, 16, 16, 32);
        VectorClear (self->velocity);
	  self->s.origin[2] += 1;
	  walkmonster_start (self);
	  bot_stand (self);
	  gi.WriteByte (svc_muzzleflash);
	  gi.WriteShort (self-g_edicts);
	  gi.WriteByte (MZ_LOGIN);
	  gi.multicast (self->s.origin, MULTICAST_PVS);
        BotComment (self);
	  gi.unlinkentity (self);
	  if (!KillBox (self))
		  {
		  }

        gi.linkentity (self);
	self->touch_debounce_time = level.time + 1.5;
}

void ClientUserinfoChangedNo2 (edict_t *ent, char *userinfo)
{
	char	*s;
	int		playernum;

	strncpy (ent->client->pers.netname, "Famke", sizeof(ent->client->pers.netname)-1);


	playernum = ent-g_edicts-1;

	gi.configstring (CS_PLAYERSKINS+playernum, va("%s\\%s", ent->client->pers.netname, "Famke") );


	s = Info_ValueForKey (userinfo, "hand");
	if (strlen(s))
	{
		ent->client->pers.hand = atoi(s);
	}

	strncpy (ent->client->pers.userinfo, userinfo, sizeof(ent->client->pers.userinfo)-1);
}


void Botscores (edict_t *ent)
{
char fin[1024];
char fragval[2];
int best;
edict_t *bestbot;

if (!deathmatch->value) {
gi.cprintf (ent, PRINT_HIGH, "There is no reason to use the scoreboard in non-DM mode.\n");
return;
}
if (bot1 == NULL)
{
gi.cprintf (ent, PRINT_HIGH, "No bots have been added yet.\n");
return;
}
if (practice->value) {

if (bot1 != NULL)
{
sprintf (fin, "%s - %d\n", bot1->client->pers.netname, bot1->damagescore);
best = bot1->damagescore;
bestbot = bot1;
}
if (bot2 != NULL)
{
sprintf (fin, "%s%s - %d\n", fin, bot2->client->pers.netname, bot2->damagescore);
if (bot2->damagescore > best)
{
best = bot2->damagescore;
bestbot = bot2;
}
}
if (bot3 != NULL)
{
sprintf (fin, "%s%s - %d\n", fin, bot3->client->pers.netname, bot3->damagescore);
if (bot3->damagescore > best)
{
best = bot3->damagescore;
bestbot = bot3;
}
}
if (bot4 != NULL)
{
sprintf (fin, "%s%s - %d\n", fin, bot4->client->pers.netname, bot4->damagescore);
if (bot4->damagescore > best)
{
best = bot4->damagescore;
bestbot = bot4;
}
}
if (bot5 != NULL)
{
sprintf (fin, "%s%s - %d\n", fin, bot5->client->pers.netname, bot5->damagescore);
if (bot5->damagescore > best)
{
best = bot5->damagescore;
bestbot = bot5;
}
}
if (bot6 != NULL)
{
sprintf (fin, "%s%s - %d\n", fin, bot6->client->pers.netname, bot6->damagescore);
if (bot6->damagescore > best)
{
best = bot6->damagescore;
bestbot = bot6;
}
}
if (bot7 != NULL)
{
sprintf (fin, "%s%s - %d\n", fin, bot7->client->pers.netname, bot7->damagescore);
if (bot7->damagescore > best)
{
best = bot7->damagescore;
bestbot = bot7;
}
}
if (bot8 != NULL)
{
sprintf (fin, "%s%s - %d\n", fin, bot8->client->pers.netname, bot8->damagescore);
if (bot8->damagescore > best)
{
best = bot8->damagescore;
bestbot = bot8;
}
}
if (bot9 != NULL)
{
sprintf (fin, "%s%s - %d\n", fin, bot9->client->pers.netname, bot9->damagescore);
if (bot9->damagescore > best)
{
best = bot9->damagescore;
bestbot = bot9;
}
}
if (bot10 != NULL)
{
sprintf (fin, "%s%s - %d\n", fin, bot10->client->pers.netname, bot10->damagescore);
if (bot10->damagescore > best)
{
best = bot10->damagescore;
bestbot = bot10;
}
}
if (bot11 != NULL)
{
sprintf (fin, "%s%s - %d\n", fin, bot11->client->pers.netname, bot11->damagescore);
if (bot11->damagescore > best)
{
best = bot11->damagescore;
bestbot = bot11;
}
}
if (bot12 != NULL)
{
sprintf (fin, "%s%s - %d\n", fin, bot12->client->pers.netname, bot12->damagescore);
if (bot12->damagescore > best)
{
best = bot12->damagescore;
bestbot = bot12;
}
}
if (bot13 != NULL)
{
sprintf (fin, "%s%s - %d\n", fin, bot13->client->pers.netname, bot13->damagescore);
if (bot13->damagescore > best)
{
best = bot13->damagescore;
bestbot = bot13;
}
}
if (bot14 != NULL)
{
sprintf (fin, "%s%s - %d\n", fin, bot14->client->pers.netname, bot14->damagescore);
if (bot14->damagescore > best)
{
best = bot14->damagescore;
bestbot = bot14;
}
}
if (bot15 != NULL)
{
sprintf (fin, "%s%s - %d\n", fin, bot15->client->pers.netname, bot15->damagescore);
if (bot15->damagescore > best)
{
best = bot15->damagescore;
bestbot = bot15;
}
}
if (bot16 != NULL)
{
sprintf (fin, "%s%s - %d\n", fin, bot16->client->pers.netname, bot16->damagescore);
if (bot16->damagescore > best)
{
best = bot16->damagescore;
bestbot = bot16;
}
}
if (bot17 != NULL)
{
sprintf (fin, "%s%s - %d\n", fin, bot17->client->pers.netname, bot17->damagescore);
if (bot17->damagescore > best)
{
best = bot17->damagescore;
bestbot = bot17;
}
}
if (bot18 != NULL)
{
sprintf (fin, "%s%s - %d\n", fin, bot18->client->pers.netname, bot18->damagescore);
if (bot18->damagescore > best)
{
best = bot18->damagescore;
bestbot = bot18;
}
}
if (bot19 != NULL)
{
sprintf (fin, "%s%s - %d\n", fin, bot19->client->pers.netname, bot19->damagescore);
if (bot19->damagescore > best)
{
best = bot19->damagescore;
bestbot = bot19;
}
}
if (bot20 != NULL)
{
sprintf (fin, "%s%s - %d\n", fin, bot20->client->pers.netname, bot20->damagescore);
if (bot20->damagescore > best)
{
best = bot20->damagescore;
bestbot = bot20;
}
}
if (best == 1)
sprintf (fragval, "");
else if (best == -1)
sprintf (fragval, "");
else
sprintf (fragval, "s");

sprintf (fin, "%s\nBot with best score is:\n%s who has done %d DP", fin, bestbot->client->pers.netname, bestbot->damagescore, fragval);


}
else {
if (bot1 != NULL)
{
sprintf (fin, "%s - %d\n", bot1->client->pers.netname, bot1->client->resp.score);
best = bot1->client->resp.score;
bestbot = bot1;
}
if (bot2 != NULL)
{
sprintf (fin, "%s%s - %d\n", fin, bot2->client->pers.netname, bot2->client->resp.score);
if (bot2->client->resp.score > best)
{
best = bot2->client->resp.score;
bestbot = bot2;
}
}
if (bot3 != NULL)
{
sprintf (fin, "%s%s - %d\n", fin, bot3->client->pers.netname, bot3->client->resp.score);
if (bot3->client->resp.score > best)
{
best = bot3->client->resp.score;
bestbot = bot3;
}
}
if (bot4 != NULL)
{
sprintf (fin, "%s%s - %d\n", fin, bot4->client->pers.netname, bot4->client->resp.score);
if (bot4->client->resp.score > best)
{
best = bot4->client->resp.score;
bestbot = bot4;
}
}
if (bot5 != NULL)
{
sprintf (fin, "%s%s - %d\n", fin, bot5->client->pers.netname, bot5->client->resp.score);
if (bot5->client->resp.score > best)
{
best = bot5->client->resp.score;
bestbot = bot5;
}
}
if (bot6 != NULL)
{
sprintf (fin, "%s%s - %d\n", fin, bot6->client->pers.netname, bot6->client->resp.score);
if (bot6->client->resp.score > best)
{
best = bot6->client->resp.score;
bestbot = bot6;
}
}
if (bot7 != NULL)
{
sprintf (fin, "%s%s - %d\n", fin, bot7->client->pers.netname, bot7->client->resp.score);
if (bot7->client->resp.score > best)
{
best = bot7->client->resp.score;
bestbot = bot7;
}
}
if (bot8 != NULL)
{
sprintf (fin, "%s%s - %d\n", fin, bot8->client->pers.netname, bot8->client->resp.score);
if (bot8->client->resp.score > best)
{
best = bot8->client->resp.score;
bestbot = bot8;
}
}
if (bot9 != NULL)
{
sprintf (fin, "%s%s - %d\n", fin, bot9->client->pers.netname, bot9->client->resp.score);
if (bot9->client->resp.score > best)
{
best = bot9->client->resp.score;
bestbot = bot9;
}
}
if (bot10 != NULL)
{
sprintf (fin, "%s%s - %d\n", fin, bot10->client->pers.netname, bot10->client->resp.score);
if (bot10->client->resp.score > best)
{
best = bot10->client->resp.score;
bestbot = bot10;
}
}
if (bot11 != NULL)
{
sprintf (fin, "%s%s - %d\n", fin, bot11->client->pers.netname, bot11->client->resp.score);
if (bot11->client->resp.score > best)
{
best = bot11->client->resp.score;
bestbot = bot11;
}
}
if (bot12 != NULL)
{
sprintf (fin, "%s%s - %d\n", fin, bot12->client->pers.netname, bot12->client->resp.score);
if (bot12->client->resp.score > best)
{
best = bot12->client->resp.score;
bestbot = bot12;
}
}
if (bot13 != NULL)
{
sprintf (fin, "%s%s - %d\n", fin, bot13->client->pers.netname, bot13->client->resp.score);
if (bot13->client->resp.score > best)
{
best = bot13->client->resp.score;
bestbot = bot13;
}
}
if (bot14 != NULL)
{
sprintf (fin, "%s%s - %d\n", fin, bot14->client->pers.netname, bot14->client->resp.score);
if (bot14->client->resp.score > best)
{
best = bot14->client->resp.score;
bestbot = bot14;
}
}
if (bot15 != NULL)
{
sprintf (fin, "%s%s - %d\n", fin, bot15->client->pers.netname, bot15->client->resp.score);
if (bot15->client->resp.score > best)
{
best = bot15->client->resp.score;
bestbot = bot15;
}
}
if (bot16 != NULL)
{
sprintf (fin, "%s%s - %d\n", fin, bot16->client->pers.netname, bot16->client->resp.score);
if (bot16->client->resp.score > best)
{
best = bot16->client->resp.score;
bestbot = bot16;
}
}
if (bot17 != NULL)
{
sprintf (fin, "%s%s - %d\n", fin, bot17->client->pers.netname, bot17->client->resp.score);
if (bot17->client->resp.score > best)
{
best = bot17->client->resp.score;
bestbot = bot17;
}
}
if (bot18 != NULL)
{
sprintf (fin, "%s%s - %d\n", fin, bot18->client->pers.netname, bot18->client->resp.score);
if (bot18->client->resp.score > best)
{
best = bot18->client->resp.score;
bestbot = bot18;
}
}
if (bot19 != NULL)
{
sprintf (fin, "%s%s - %d\n", fin, bot19->client->pers.netname, bot19->client->resp.score);
if (bot19->client->resp.score > best)
{
best = bot19->client->resp.score;
bestbot = bot19;
}
}
if (bot20 != NULL)
{
sprintf (fin, "%s%s - %d\n", fin, bot20->client->pers.netname, bot20->client->resp.score);
if (bot20->client->resp.score > best)
{
best = bot20->client->resp.score;
bestbot = bot20;
}
}
if (best == 1)
sprintf (fragval, "");
else if (best == -1)
sprintf (fragval, "");
else
sprintf (fragval, "s");

sprintf (fin, "%s\nBot with best score is:\n%s with %d frag%s", fin, bestbot->client->pers.netname, bestbot->client->resp.score, fragval);
}
gi.centerprintf (ent, fin);
sprintf (fin, "");
}

void Botnumcheck (edict_t *self)
{
if (!bot1)
{
bot1 = self;
return;
}
if (!bot2)
{
bot2 = self;
return;
}
if (!bot3)
{
bot3 = self;
return;
}
if (!bot4)
{
bot4 = self;
return;
}
if (!bot5)
{
bot5 = self;
return;
}
if (!bot6)
{
bot6 = self;
return;
}
if (!bot7)
{
bot7 = self;
return;
}
if (!bot8)
{
bot8 = self;
return;
}
if (!bot9)
{
bot9 = self;
return;
}
if (!bot10)
{
bot10 = self;
return;
}
if (!bot11)
{
bot11 = self;
return;
}
if (!bot12)
{
bot12 = self;
return;
}
if (!bot13)
{
bot13 = self;
return;
}
if (!bot14)
{
bot14 = self;
return;
}
if (!bot15)
{
bot15 = self;
return;
}
if (!bot16)
{
bot16 = self;
return;
}
if (!bot17)
{
bot17 = self;
return;
}
if (!bot18)
{
bot18 = self;
return;
}
if (!bot19)
{
bot19 = self;
return;
}
if (!bot20)
{
bot20 = self;
return;
}

}

void Actlikeplayer (edict_t *self) {
if (self->spawner == NULL) {
gi.unlinkentity (self);
self->think = G_FreeEdict;
self->nextthink = level.time;
self->spawner->cament = NULL;
return;
}
if (self->spawner->cament == NULL) {
gi.unlinkentity (self);
self->think = G_FreeEdict;
self->nextthink = level.time;
self->spawner->cament = NULL;
return;
}
   VectorCopy (self->spawner->s.origin, self->s.origin);
   VectorCopy (self->spawner->s.angles, self->s.angles);
   self->s.frame = self->spawner->s.frame;
   self->s.modelindex = self->spawner->s.modelindex;
   self->s.modelindex2 = self->spawner->s.modelindex2;
self->think = Actlikeplayer;
self->nextthink = level.time;
}

void Spawnselfentity (edict_t *self) {
edict_t *a;

  a = G_Spawn();

   VectorCopy (self->s.origin, a->s.origin);
   VectorCopy (self->s.angles, a->s.angles);
//   a->s.origin[0] = a->s.origin[0] + 40;

//   VectorSet (a->mins, -16, -16, -24);
//   VectorSet (a->maxs, 16, 16, 32);
VectorCopy (a->mins, self->mins);
VectorCopy (a->maxs, self->maxs);
   a->s.frame = self->s.frame;
   a->solid = SOLID_NOT;
   a->spawner = self;
   a->movetype = MOVETYPE_NONE;
//   a->mass = 200;
//   a->monsterinfo.scale = MODEL_SCALE;
//   a->s.modelindex = 255;
   a->s.modelindex = self->s.modelindex;
   a->s.modelindex2 = self->s.modelindex2;
   gi.linkentity (a);

a->think = Actlikeplayer;
a->nextthink = level.time;
}

void Coopcam (edict_t *self) {

if (!coop->value) {
gi.cprintf (self, PRINT_MEDIUM, "This feature is only for coop\n");
return;
}
if (!self->lastbot) {
gi.cprintf (self, PRINT_MEDIUM, "You haven't added any bots yet\n");
return;
}
if (self->health < 1) {
gi.cprintf (self, PRINT_MEDIUM, "You can't switch your view - you're dead.\n");
return;
}
if (self->deadflag == DEAD_DEAD) {
gi.cprintf (self, PRINT_MEDIUM, "You can't switch your view - you're dead.\n");
return;
}

if (self->cament != NULL && strcmp(self->lastbot->classname, "player") == 0) {
if (self->cament->lastbot != NULL && strcmp(self->cament->lastbot->classname, "player") == 0) {
self->cament = self->cament->lastbot;
gi.cprintf (self, PRINT_MEDIUM, "Now viewing from: %s\n", self->cament->client->pers.netname);
return;
}
else {
self->cament = NULL;
gi.cprintf (self, PRINT_MEDIUM, "Bot view disabled\n");
self->client->ps.gunindex = gi.modelindex(self->client->pers.weapon->view_model);
return;
}
//self->client->ps.gunindex = 255;
}
else {
self->cament = self->lastbot;
Spawnselfentity (self);
//gi.cprintf (self, PRINT_MEDIUM, "Bot view enabled\n");
gi.cprintf (self, PRINT_MEDIUM, "Now viewing from: %s\n", self->cament->client->pers.netname);
self->client->ps.gunindex = 0;
}

}

void CheckIt (edict_t *self) {
if (!M_walkmove (self, 0, 0)) {
gi.cprintf (self->spawner, PRINT_MEDIUM, "There's not enough room here for the bot\n");
}
else {
   VectorCopy (self->s.origin, self->spawner->lastbot->s.origin);
   VectorCopy (self->s.angles, self->spawner->lastbot->s.angles);
	  gi.unlinkentity (self->spawner->lastbot);
	  self->spawner->lastbot->s.event = EV_PLAYER_TELEPORT;
	  if (!KillBox (self->spawner->lastbot))
		{
		}
        gi.linkentity (self->spawner->lastbot);
}
gi.unlinkentity (self);
self->think = G_FreeEdict;
self->nextthink = level.time;
}

void Botsetthrowammo (edict_t *self, gitem_t *item)
{
if (item && (strcmp (item->pickup_name, "Blaster") == 0))
return;

if (item && (strcmp (item->pickup_name, "Shotgun") == 0))
{
self->client->pers.inventory[ITEM_INDEX(FindItem("shells"))] = self->client->pers.inventory[ITEM_INDEX(FindItem("shells"))] - 10;
if (self->client->pers.inventory[ITEM_INDEX(FindItem("shells"))] < 0)
self->client->pers.inventory[ITEM_INDEX(FindItem("shells"))] = 0;
self->client->pers.inventory[ITEM_INDEX(FindItem("shotgun"))] = self->client->pers.inventory[ITEM_INDEX(FindItem("shotgun"))] - self->client->pers.inventory[ITEM_INDEX(FindItem("shotgun"))];
}
if (item && (strcmp (item->pickup_name, "Super Shotgun") == 0))
{
self->client->pers.inventory[ITEM_INDEX(FindItem("shells"))] = self->client->pers.inventory[ITEM_INDEX(FindItem("shells"))] - 10;
if (self->client->pers.inventory[ITEM_INDEX(FindItem("shells"))] < 0)
self->client->pers.inventory[ITEM_INDEX(FindItem("shells"))] = 0;
self->client->pers.inventory[ITEM_INDEX(FindItem("super shotgun"))] = self->client->pers.inventory[ITEM_INDEX(FindItem("super shotgun"))] - self->client->pers.inventory[ITEM_INDEX(FindItem("super shotgun"))];
}
if (item && (strcmp (item->pickup_name, "Machinegun") == 0))
{
self->client->pers.inventory[ITEM_INDEX(FindItem("bullets"))] = self->client->pers.inventory[ITEM_INDEX(FindItem("bullets"))] - 50;
if (self->client->pers.inventory[ITEM_INDEX(FindItem("bullets"))] < 0)
self->client->pers.inventory[ITEM_INDEX(FindItem("bullets"))] = 0;
self->client->pers.inventory[ITEM_INDEX(FindItem("machinegun"))] = self->client->pers.inventory[ITEM_INDEX(FindItem("machinegun"))] - self->client->pers.inventory[ITEM_INDEX(FindItem("machinegun"))];
}
if (item && (strcmp (item->pickup_name, "Chaingun") == 0))
{
self->client->pers.inventory[ITEM_INDEX(FindItem("bullets"))] = self->client->pers.inventory[ITEM_INDEX(FindItem("bullets"))] - 50;
if (self->client->pers.inventory[ITEM_INDEX(FindItem("bullets"))] < 0)
self->client->pers.inventory[ITEM_INDEX(FindItem("bullets"))] = 0;
self->client->pers.inventory[ITEM_INDEX(FindItem("chaingun"))] = self->client->pers.inventory[ITEM_INDEX(FindItem("chaingun"))] - self->client->pers.inventory[ITEM_INDEX(FindItem("chaingun"))];
}
if (item && (strcmp (item->pickup_name, "Grenade Launcher") == 0))
{
self->client->pers.inventory[ITEM_INDEX(FindItem("grenades"))] = self->client->pers.inventory[ITEM_INDEX(FindItem("grenades"))] - 5;
if (self->client->pers.inventory[ITEM_INDEX(FindItem("grenades"))] < 0)
self->client->pers.inventory[ITEM_INDEX(FindItem("grenades"))] = 0;
self->client->pers.inventory[ITEM_INDEX(FindItem("grenade launcher"))] = self->client->pers.inventory[ITEM_INDEX(FindItem("grenade launcher"))] - self->client->pers.inventory[ITEM_INDEX(FindItem("grenade launcher"))];
}
if (item && (strcmp (item->pickup_name, "Grenades") == 0))
{
self->client->pers.inventory[ITEM_INDEX(FindItem("grenades"))] = self->client->pers.inventory[ITEM_INDEX(FindItem("grenades"))] - 5;
if (self->client->pers.inventory[ITEM_INDEX(FindItem("grenades"))] < 0)
self->client->pers.inventory[ITEM_INDEX(FindItem("grenades"))] = 0;
}
if (item && (strcmp (item->pickup_name, "Rocket Launcher") == 0))
{
self->client->pers.inventory[ITEM_INDEX(FindItem("rockets"))] = self->client->pers.inventory[ITEM_INDEX(FindItem("rockets"))] - 5;
if (self->client->pers.inventory[ITEM_INDEX(FindItem("rockets"))] < 0)
self->client->pers.inventory[ITEM_INDEX(FindItem("rockets"))] = 0;
self->client->pers.inventory[ITEM_INDEX(FindItem("rocket launcher"))] = self->client->pers.inventory[ITEM_INDEX(FindItem("rocket launcher"))] - self->client->pers.inventory[ITEM_INDEX(FindItem("rocket launcher"))];
}
if (item && (strcmp (item->pickup_name, "HyperBlaster") == 0))
{
self->client->pers.inventory[ITEM_INDEX(FindItem("cells"))] = self->client->pers.inventory[ITEM_INDEX(FindItem("cells"))] - 50;
if (self->client->pers.inventory[ITEM_INDEX(FindItem("cells"))] < 0)
self->client->pers.inventory[ITEM_INDEX(FindItem("cells"))] = 0;
self->client->pers.inventory[ITEM_INDEX(FindItem("hyperblaster"))] = self->client->pers.inventory[ITEM_INDEX(FindItem("hyperblaster"))] - self->client->pers.inventory[ITEM_INDEX(FindItem("hyperblaster"))];
}
if (item && (strcmp (item->pickup_name, "Railgun") == 0))
{
self->client->pers.inventory[ITEM_INDEX(FindItem("slugs"))] = self->client->pers.inventory[ITEM_INDEX(FindItem("slugs"))] - 10;
if (self->client->pers.inventory[ITEM_INDEX(FindItem("slugs"))] < 0)
self->client->pers.inventory[ITEM_INDEX(FindItem("slugs"))] = 0;
self->client->pers.inventory[ITEM_INDEX(FindItem("railgun"))] = self->client->pers.inventory[ITEM_INDEX(FindItem("railgun"))] - self->client->pers.inventory[ITEM_INDEX(FindItem("railgun"))];
}
if (item && (strcmp (item->pickup_name, "BFG10K") == 0))
{
self->client->pers.inventory[ITEM_INDEX(FindItem("cells"))] = self->client->pers.inventory[ITEM_INDEX(FindItem("cells"))] - 50;
if (self->client->pers.inventory[ITEM_INDEX(FindItem("cells"))] < 0)
self->client->pers.inventory[ITEM_INDEX(FindItem("cells"))] = 0;
self->client->pers.inventory[ITEM_INDEX(FindItem("BFG10K"))] = self->client->pers.inventory[ITEM_INDEX(FindItem("BFG10K"))] - self->client->pers.inventory[ITEM_INDEX(FindItem("BFG10K"))];
}

}

void TossClientWeapon2 (edict_t *self)
{
	gitem_t		*item;
	edict_t		*drop;
	float		spread;

	item = self->client->pers.weapon;

if (strcmp(self->isabot, "bot") != 0) {
	if (! self->client->pers.inventory[self->client->ammo_index] )
		item = NULL;
}
	if (item && (strcmp (item->pickup_name, "Blaster") == 0))
		item = NULL;

		spread = 0.0;

	if (item)
	{
		self->client->v_angle[YAW] -= spread;
		drop = Drop_Item (self, item);
		self->client->v_angle[YAW] += spread;
		drop->spawnflags = DROPPED_PLAYER_ITEM;

		Botsetthrowammo(self, item);

if (strcmp(self->isabot, "bot") != 0)
		NoAmmoWeaponChange (self);
	}
}

void Jet_player (edict_t *self) {
if (self->throwweapontime > level.time)
return;
if (!coop->value) {
gi.cprintf (self, PRINT_MEDIUM, "This feature is only for coop\n");
return;
}
if (self->health < 1) {
gi.cprintf (self, PRINT_MEDIUM, "You can't throw your weapon - you're dead.\n");
return;
}
if (self->deadflag == DEAD_DEAD) {
gi.cprintf (self, PRINT_MEDIUM, "You can't throw your weapon - you're dead.\n");
return;
}
TossClientWeapon2 (self);
self->throwweapontime = level.time + 2;
}

void Jettison (edict_t *self) {
if (self->throwweapontime > level.time)
return;
if (!coop->value) {
gi.cprintf (self, PRINT_MEDIUM, "Can't give bot instructions unless in coop\n");
return;
}
if (!self->lastbot) {
gi.cprintf (self, PRINT_MEDIUM, "You haven't created any bots yet\n");
return;
}
if (self->lastbot->health < 1) {
gi.cprintf (self, PRINT_MEDIUM, "Last created bot is currently dead. Wait until it respawns.\n");
return;
}
if (self->lastbot->deadflag == DEAD_DEAD) {
gi.cprintf (self, PRINT_MEDIUM, "Last created bot is currently dead. Wait until it respawns.\n");
return;
}
if (self->deadflag == DEAD_DEAD) {
gi.cprintf (self, PRINT_MEDIUM, "You can't give the bot instructions - you're dead.\n");
return;
}
SelectRealWeapon (self->lastbot);
if (strcmp (self->lastbot->client->pers.weapon->pickup_name, "Blaster") == 0)
{
gi.bprintf (PRINT_CHAT, "%s: You ARE NOT getting my blaster, %s!\n", self->lastbot->client->pers.netname, self->client->pers.netname);
return;
}
TossClientWeapon2 (self->lastbot);
self->throwweapontime = level.time + 2;
}

void Itemlose (edict_t *self) {
if (!coop->value) {
gi.cprintf (self, PRINT_MEDIUM, "Can't give bot instructions unless in coop\n");
return;
}
if (!self->lastbot) {
gi.cprintf (self, PRINT_MEDIUM, "You haven't created any bots yet\n");
return;
}
if (self->lastbot->health < 1) {
gi.cprintf (self, PRINT_MEDIUM, "Last created bot is currently dead. Wait until it respawns.\n");
return;
}
if (self->lastbot->deadflag == DEAD_DEAD) {
gi.cprintf (self, PRINT_MEDIUM, "Last created bot is currently dead. Wait until it respawns.\n");
return;
}
if (self->deadflag == DEAD_DEAD) {
gi.cprintf (self, PRINT_MEDIUM, "You can't give the bot instructions - you're dead.\n");
return;
}

if (self->lastbot->itemwant == NULL)
return;

self->lastbot->itemwant = NULL;
}

void Enemylose (edict_t *self) {
if (!coop->value) {
gi.cprintf (self, PRINT_MEDIUM, "Can't give bot instructions unless in coop\n");
return;
}
if (!self->lastbot) {
gi.cprintf (self, PRINT_MEDIUM, "You haven't created any bots yet\n");
return;
}
if (self->lastbot->health < 1) {
gi.cprintf (self, PRINT_MEDIUM, "Last created bot is currently dead. Wait until it respawns.\n");
return;
}
if (self->lastbot->deadflag == DEAD_DEAD) {
gi.cprintf (self, PRINT_MEDIUM, "Last created bot is currently dead. Wait until it respawns.\n");
return;
}
if (self->deadflag == DEAD_DEAD) {
gi.cprintf (self, PRINT_MEDIUM, "You can't give the bot instructions - you're dead.\n");
return;
}
if (self->lastbot->enemy == self)
return;

if (self->lastbot->enemy == NULL)
return;

if (self->lastbot->enemy == world)
return;

self->lastbot->enemy = self;
}

void Movecoop (edict_t *self) {
edict_t *a;

if (!coop->value) {
gi.cprintf (self, PRINT_MEDIUM, "Can't teleport last created bot unless in coop\n");
return;
}
if (!self->lastbot) {
gi.cprintf (self, PRINT_MEDIUM, "You haven't created any bots yet\n");
return;
}
if (self->lastbot->health < 1) {
gi.cprintf (self, PRINT_MEDIUM, "Last created bot is currently dead. Wait until it respawns.\n");
return;
}
if (self->lastbot->deadflag == DEAD_DEAD) {
gi.cprintf (self, PRINT_MEDIUM, "Last created bot is currently dead. Wait until it respawns.\n");
return;
}
if (self->deadflag == DEAD_DEAD) {
gi.cprintf (self, PRINT_MEDIUM, "You can't teleport the bot - you're dead.\n");
return;
}

  a = G_Spawn();

   VectorCopy (self->s.origin, a->s.origin);
   VectorCopy (self->s.angles, a->s.angles);
   a->s.origin[0] = a->s.origin[0] + 40;
   VectorSet (a->mins, -16, -16, -24);
   VectorSet (a->maxs, 16, 16, 32);
   a->solid = SOLID_BBOX;
   a->spawner = self;
   a->movetype = MOVETYPE_STEP;
   a->mass = 200;
   a->monsterinfo.scale = MODEL_SCALE;
   gi.linkentity (a);

   M_droptofloor (a);

a->think = CheckIt;
a->nextthink = level.time;
}

void Addbot(edict_t *self)
{
      edict_t *bot;
        char *namestr;
char *optname;
      vec3_t  spawn_origin, spawn_angles;
char *modelname;
char *weapname;
//optname = gi.args();
optname = gi.argv(1);
modelname = gi.argv(2);
weapname = gi.argv(3);
self->sexbot = gi.argv(4);

if (!deathmatch->value) {
gi.cprintf (self, PRINT_MEDIUM, "You must restart the level in DeathMatch mode before adding a bot\n");
return;
}
if (coop->value) {
gi.cprintf (self, PRINT_MEDIUM, "You must restart the level with coop set to 0 before adding a bot\n");
return;
}
if (botnumtotal >= maxbots->value) {
gi.cprintf (self, PRINT_MEDIUM, "There are already too many bots. Type maxbots <limit> and restart the level to change the limit\n");
return;
}
if (self->addremovetime > level.time)
return;
self->addremovetime = level.time + 1;
botnumtotal++;
        bot = G_Spawn();
        SelectSpawnPoint (bot, spawn_origin, spawn_angles);

        bot->client = gi.TagMalloc(sizeof(gclient_t), TAG_GAME);
          InitClientResp (bot->client);
        InitClientPersistant(bot->client);
botnum++;
if (botnum == 0)
botnum = 1;
namestr = "Famke";
sprintf (namestr, "Famke%d", botnum);
        strcpy(bot->client->pers.netname, namestr);
if (optname && strcmp(optname, "") != 0)
strcpy(bot->client->pers.netname, optname);

Botnumcheck (bot);
if (!gi.argv(4))
{
bot->botsex = "female";
}
if (strcmp(gi.argv(4), "") == 0)
{
bot->botsex = "female";
}
else
{
//bot->botsex = gi.argv(4);
self->sexbot = gi.argv(4);
strcpy (self->sexbot, self->sexbot);
if (strcmp(self->sexbot, "male") == 0)
bot->botsex = "male";
else if (strcmp(self->sexbot, "female") == 0)
bot->botsex = "female";
}

	  bot->s.origin[2] += 1;
        bot->classname = "player";
	  bot->isabot = "bot";
	  bot->teambot = "botteam";
       bot->takedamage = DAMAGE_AIM;
        bot->movetype = MOVETYPE_STEP;
        bot->mass = 200;
        bot->solid = SOLID_BBOX;
        bot->deadflag = DEAD_NO;
        bot->clipmask = MASK_PLAYERSOLID;
if (!gi.argv(2))
{
//gi.cprintf (self, PRINT_MEDIUM, "No model stuff detected\n");
	  bot->s.modelindex = gi.modelindex ("famke/female/tris.md2");
bot->client->pers.modelstring = "famke/female/tris.md2";
//	  bot->s.modelindex2 = gi.modelindex ("players/female/weapon.md2");
}
if (strcmp(gi.argv(2), "") == 0)
{
//gi.cprintf (self, PRINT_MEDIUM, "No model stuff detected\n");
	  bot->s.modelindex = gi.modelindex ("famke/female/tris.md2");
bot->client->pers.modelstring = "famke/female/tris.md2";
//	  bot->s.modelindex2 = gi.modelindex ("players/female/weapon.md2");
}
else
{
//gi.cprintf (self, PRINT_MEDIUM, "Model would be %s\n", gi.argv(2));
	  bot->s.modelindex = gi.modelindex (gi.argv(2));
//bot->modelstring = modelname;
//bot->modelstring = bot->s.modelindex;
//sprintf (bot->modelstring, "%s", modelname);
//strcpy (bot->client->pers.modelstring, modelname);

//	  bot->s.modelindex2 = gi.modelindex ("players/female/weapon.md2");
}
//	  bot->s.modelindex = gi.modelindex ("famke/female/tris.md2");
	  bot->s.skinnum = 0;
if (!gi.argv(3))
{
	  bot->s.modelindex2 = gi.modelindex ("players/female/weapon.md2");
bot->client->pers.weaponstring = "players/female/weapon.md2";
}
if (strcmp(gi.argv(3), "") == 0)
{
	  bot->s.modelindex2 = gi.modelindex ("players/female/weapon.md2");
bot->client->pers.weaponstring = "players/female/weapon.md2";
}
else
{
	  bot->s.modelindex2 = gi.modelindex (gi.argv(3));
//bot->weaponstring = weapname;
//bot->weaponstring = bot->s.modelindex2;
//sprintf (bot->weaponstring, "%s", weapname);
//strcpy (bot->client->pers.weaponstring, weapname);
}
//	  bot->s.modelindex2 = gi.modelindex ("players/female/weapon.md2");

        bot->s.frame = 0;
        bot->waterlevel = 0;
        bot->watertype = 0;
        bot->health = 100;
	  bot->gib_health = -40;
	  bot->viewheight = 22;
        bot->pain = bot_pain;
        bot->die = bot_die;
	  bot->inuse = true;
	  bot->monsterinfo.stand = bot_stand;
	  bot->monsterinfo.walk = bot_walk;
	  bot->monsterinfo.run = bot_run;
	  bot->monsterinfo.attack = bot_attack;
	  bot->monsterinfo.melee = bot_attackclose;
	  bot->monsterinfo.sight = bot_sight;
	  bot->monsterinfo.currentmove = &bot_move_jump;
	  bot->monsterinfo.scale = MODEL_SCALE;
        VectorSet (bot->mins, -16, -16, -24);
        VectorSet (bot->maxs, 16, 16, 32);
        VectorClear (bot->velocity);
	  VectorCopy (spawn_origin, bot->s.origin);
	  VectorCopy (spawn_angles, bot->s.angles);
	  bot->s.origin[2] += 1;
        gi.linkentity (bot);
	  gi.bprintf (PRINT_MEDIUM, "%s entered the game\n", bot->client->pers.netname);
	  walkmonster_start (bot);
	  bot->spawner = globalspawner;
	  gi.WriteByte (svc_muzzleflash);
	  gi.WriteShort (bot-g_edicts);
	  gi.WriteByte (MZ_LOGIN);
	  gi.multicast (bot->s.origin, MULTICAST_PVS);
	  gi.unlinkentity (bot);
	  if (!KillBox (bot))
		{
		}
        gi.linkentity (bot);
	bot->touch_debounce_time = level.time + 1.5;
	if (self->lastbot)
	bot->lastbot = self->lastbot;
	self->lastbot = bot;
	bot->team = "badbots";
}

void bot_touch_team(edict_t *self, edict_t *other, cplane_t *plane, csurface_t *surf) {
if (self->spawner == NULL)
return;

if (teamplaybots->value) {
if (deathmatch->value) {
if (self->team != other->team)
return;
}
}

if (other == self->spawner) {
if (self->enemy == self->spawner) {
if (self->spawner->velocity[0] == 0 && self->spawner->velocity[1] == 0) {
self->monsterinfo.currentmove = &bot_move_standteam;
}
}
}

}

void Addbot2(edict_t *self)
{
      edict_t *bot;
        char *namestr;
char *optname;
      vec3_t  spawn_origin, spawn_angles;
optname = gi.args();

if (!deathmatch->value) {
gi.cprintf (self, PRINT_MEDIUM, "You must restart the level in DeathMatch mode before adding a bot\n");
return;
}
if (coop->value) {
gi.cprintf (self, PRINT_MEDIUM, "You must restart the level with coop set to 0 before adding a bot\n");
return;
}
if (!teamplaybots->value) {
gi.cprintf (self, PRINT_MEDIUM, "You must restart the level with teamplaybots set to 1 before adding a bot\n");
return;
}
if (botnumtotal >= maxbots->value) {
gi.cprintf (self, PRINT_MEDIUM, "There are already too many bots. Type maxbots <limit> and restart the level to change the limit\n");
return;
}
if (self->addremovetime > level.time)
return;
self->addremovetime = level.time + 1;
botnumtotal++;
        bot = G_Spawn();
        SelectSpawnPoint (bot, spawn_origin, spawn_angles);

        bot->client = gi.TagMalloc(sizeof(gclient_t), TAG_GAME);
          InitClientResp (bot->client);
        InitClientPersistant(bot->client);

botnumteam++;
if (botnumteam == 0)
botnumteam = 1;
namestr = "TeamFamke";
sprintf (namestr, "TeamFamke%d", botnumteam);
        strcpy(bot->client->pers.netname, namestr);
if (optname && strcmp(optname, "") != 0)
strcpy(bot->client->pers.netname, optname);

Botnumcheck (bot);


	  bot->s.origin[2] += 1;
        bot->classname = "player";
	  bot->isabot = "bot";
	  bot->teambot = "playerteam";
       bot->takedamage = DAMAGE_AIM;
        bot->movetype = MOVETYPE_STEP;
        bot->mass = 200;
        bot->solid = SOLID_BBOX;
        bot->deadflag = DEAD_NO;
        bot->clipmask = MASK_PLAYERSOLID;
	  bot->s.skinnum = 0;
  	  bot->s.modelindex = 255;
        bot->s.modelindex2 = 255;
        bot->s.frame = 0;
        bot->waterlevel = 0;
        bot->watertype = 0;
        bot->health = 100;
	  bot->gib_health = -40;
	  bot->viewheight = 22;
        bot->pain = bot_pain;
        bot->die = bot_die;
	  bot->inuse = true;
	  bot->touch = bot_touch_coop;
	  bot->monsterinfo.stand = bot_stand;
	  bot->monsterinfo.walk = bot_walk;
	  bot->monsterinfo.run = bot_run;
	  bot->monsterinfo.attack = bot_attack;
	  bot->monsterinfo.melee = bot_attackclose;
	  bot->monsterinfo.sight = bot_sight;
	  bot->monsterinfo.currentmove = &bot_move_jump;
	  bot->monsterinfo.scale = MODEL_SCALE;
	  bot->team = self->team;
        VectorSet (bot->mins, -16, -16, -24);
        VectorSet (bot->maxs, 16, 16, 32);
        VectorClear (bot->velocity);
	  VectorCopy (spawn_origin, bot->s.origin);
	  VectorCopy (spawn_angles, bot->s.angles);
	  bot->s.origin[2] += 1;
        gi.linkentity (bot);
	  gi.bprintf (PRINT_MEDIUM, "%s entered the game\n", bot->client->pers.netname);
	  walkmonster_start (bot);
	  bot->spawner = globalspawner;
	  gi.WriteByte (svc_muzzleflash);
	  gi.WriteShort (bot-g_edicts);
	  gi.WriteByte (MZ_LOGIN);
	  gi.multicast (bot->s.origin, MULTICAST_PVS);
	  gi.unlinkentity (bot);
	  if (!KillBox (bot))
		{
		}
        gi.linkentity (bot);
	bot->touch_debounce_time = level.time + 1.5;
	if (self->lastbot)
	bot->lastbot = self->lastbot;
	self->lastbot = bot;
}

void bot_touch_coop(edict_t *self, edict_t *other, cplane_t *plane, csurface_t *surf) {
if (self->spawner == NULL)
return;

if (self->insanity == 1)
return;

if (other == self->spawner) {
if (self->enemy == self->spawner) {
if (self->spawner->velocity[0] == 0 && self->spawner->velocity[1] == 0) {
self->monsterinfo.currentmove = &bot_move_standcoop;
}
}
}

}

void Addbot3(edict_t *self)
{
      edict_t *bot;
        char *namestr;
char *optname;
      vec3_t  spawn_origin, spawn_angles;
optname = gi.args();

if (!coop->value) {
gi.cprintf (self, PRINT_MEDIUM, "You must restart the level in cooperative mode before adding a coop bot\n");
return;
}
if (deathmatch->value) {
gi.cprintf (self, PRINT_MEDIUM, "Type deathmatch 0 in the console and restart the level before adding a coop bot\n");
}
if (botnumtotal >= maxbots->value) {
gi.cprintf (self, PRINT_MEDIUM, "There are already too many bots. Type maxbots <limit> and restart the level to change the limit\n");
return;
}
if (self->cament != NULL) {
gi.cprintf (self, PRINT_MEDIUM, "Switch out of bot-view mode before adding a bot.\n");
return;
}
botnumtotal++;
        bot = G_Spawn();
        SelectSpawnPoint (bot, spawn_origin, spawn_angles);

        bot->client = gi.TagMalloc(sizeof(gclient_t), TAG_GAME);
          InitClientResp (bot->client);
        InitClientPersistant(bot->client);
botnumcoop++;
if (botnumcoop == 0)
botnumcoop = 1;
namestr = "Cooperative Famke";
sprintf (namestr, "Co-op Famke %d", botnumcoop);
        strcpy(bot->client->pers.netname, namestr);
if (optname && strcmp(optname, "") != 0)
strcpy(bot->client->pers.netname, optname);

//
//bot->currnode = NULL;
//bot->touchednode = NULL;
//
	  bot->s.origin[2] += 1;
        bot->classname = "player";
	  bot->isabot = "bot";
	  bot->teambot = "coopteam";
       bot->takedamage = DAMAGE_AIM;
        bot->movetype = MOVETYPE_STEP;
        bot->mass = 200;
        bot->solid = SOLID_BBOX;
        bot->deadflag = DEAD_NO;
        bot->clipmask = MASK_PLAYERSOLID;
	  bot->s.skinnum = 0;
  	  bot->s.modelindex = 255;
        bot->s.modelindex2 = 255;
        bot->s.frame = 0;
        bot->waterlevel = 0;
        bot->watertype = 0;
        bot->health = 100;
	  bot->gib_health = -40;
	  bot->viewheight = 22;
        bot->pain = bot_pain;
        bot->die = bot_die;
	  bot->inuse = true;
	  bot->touch = bot_touch_coop;
	  bot->monsterinfo.stand = bot_stand;
	  bot->monsterinfo.walk = bot_walk;
	  bot->monsterinfo.run = bot_run;
	  bot->monsterinfo.attack = bot_attack;
	  bot->monsterinfo.melee = bot_attackclose;
	  bot->monsterinfo.sight = bot_sight;
	  bot->monsterinfo.currentmove = &bot_move_jump;
	  bot->monsterinfo.scale = MODEL_SCALE;
	  bot->team = self->team;
        VectorSet (bot->mins, -16, -16, -24);
        VectorSet (bot->maxs, 16, 16, 32);
        VectorClear (bot->velocity);
	  VectorCopy (spawn_origin, bot->s.origin);
	  VectorCopy (spawn_angles, bot->s.angles);
	  bot->s.origin[2] += 1;
        gi.linkentity (bot);
	  gi.bprintf (PRINT_MEDIUM, "%s entered the game\n", bot->client->pers.netname);
	  walkmonster_start (bot);
	  bot->spawner = globalspawner;
	  gi.WriteByte (svc_muzzleflash);
	  gi.WriteShort (bot-g_edicts);
	  gi.WriteByte (MZ_LOGIN);
	  gi.multicast (bot->s.origin, MULTICAST_PVS);
	  gi.unlinkentity (bot);
	  if (!KillBox (bot))
		{
		}
        gi.linkentity (bot);
	bot->touch_debounce_time = level.time + 1.5;
	if (self->lastbot)
	bot->lastbot = self->lastbot;
	self->lastbot = bot;
}
