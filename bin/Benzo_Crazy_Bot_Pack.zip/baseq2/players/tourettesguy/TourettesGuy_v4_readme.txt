TOURETTES GUY (v4) by BenzoSt

It's the basic male player model with a new Tourettes Guy skin plus sounds collected and fine-tuned with loving care. I improved the skin a bit more and adjusted sound volume a bit in this version. I added the Frosted Flakes slogan to the back of his shirt, but the constraints of Q2 skins prohibited more than one 'R'. It's still better than a blank shirt back, though.

View the LEGENDARY Tourettes Guy videos by searching for Tourettes Guy on Youtube!

INSTALLATION:
Extract to your Quake 2 folder. This should place the TourettesGuy folder into the Quake 2\baseq2\players folder, so that it's parallel to the crakhor, cyborg, female, and male folders.

PROGRAMS USED:
GIMP
Md2 Viewer
Audacity

