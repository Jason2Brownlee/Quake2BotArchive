EL NAKEDO (v2) by BenzoSt

This skin and soundpack is in belated honor of the animated masterpiece "El Nakedo" by Mike Houser. It is based on the Supermale model by Paolo Piselli, which I have included. However, since there are so many skins available, I have packed them into a separate folder titled "more supermale skins", so you don't have to bother with them unless you want to - more on that in INSTALLATION section. 

I touched up his mask a bit for this version. I also switched his sound set. Since I don't know how to edit models, I didn't bother making him... morphologically accurate.

INSTALLATION:
Extract to your Quake 2 folder. This should place the supermale folder into the Quake 2\baseq2\players folder, so that it's parallel to the crakhor, cyborg, female, and male folders.

To use the other Supermale skins, cut the files in the "more supermale skins" folder and paste them into your Quake 2\base12\players\supermale folder.



PROGRAMS USED:
GIMP
Audacity