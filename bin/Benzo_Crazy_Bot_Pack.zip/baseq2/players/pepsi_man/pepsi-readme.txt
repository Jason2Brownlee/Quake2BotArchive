heres some skins i did for a little known japanese 
pepsi icon(well at least an america). i didnt have much to refer too
but i saw him in a book somewhere and he looked easy so i made some skins
there are 4, 3 are original and the fourth is my invention.
just put these in your supermale folder.

thanks much michael withers aka oldbean
jmmk@bellsouth.net

and....POLYCOUNT ROCKS!!!!! 