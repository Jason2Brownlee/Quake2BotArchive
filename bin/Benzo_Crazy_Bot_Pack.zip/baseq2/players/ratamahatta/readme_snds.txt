I hope these sounds do justice for this model....thanxx to Evil Bastard for the great models..
More sounds to come.....requests are considered

any bugs? felixx1@home.com

install: just unzip these to your ratamahatta folder and your set!!

-------------------------------
major sore adams apple after making these...

ENJOY!!

SuperflexX