
================================================================
Model Name              : Ratamatta
installation directory  : c:\quake2\baseq2\players\Ratamatta
Author                  : Kurt 'Apocalypse" Cadogan
Email Address           : turbo911@datatone.com

Additional Credits to   : the Creator:Brian "EvilBastard" Collins
			 
================================================================
* Play Information *

New Sounds              : <NO>
CTF Skins               : <NO>
VWEP Support            : <YES>

I really have to thank Brian for having that tricks and tips on his cool 
web page,I would not have been able to create this and other vwep's without
his help...And also thanks for letting make a vwep for this great model.
 
* How to use this model *

place it into your  models dir and then load q2 normaly.
 

Again..Thanks Brian...Keep up the good work...

Any questions or if you dont like it please let me know people..
turbo911@datatone.com