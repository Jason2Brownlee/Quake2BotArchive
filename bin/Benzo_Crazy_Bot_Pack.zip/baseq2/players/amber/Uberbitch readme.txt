UBERBITCH (v2) by BenzoSt

Uberbitch consists of a few skins plus a sound pack for the Amber model by Brian "EvilBastard" Collins. I have included the Amber model with this download.

Uberbitch combines features of two of my previous uploads to Moddb; she features the potty mouth of TourettesGuy and the nudity (PG-13 like nudity, that is) of El Nakedo. Her potty mouth comes from a variety of custom sound files, mostly derived from pyro13djt at freesound.org. Version 2 features some improvements to the skin, like distinct toes, the option of wearing shorts, and changes to the sound pack to make it even sillier.

I also included GIMP projects for those interested in editing her skin and tatoos. Another thing I found out was that you can convert skins from the Sydney model to Amber simply by scaling the Sydney skin to 256x256 pixels, then adding paint to the canvas in the right spot to fill out her braid. Why would you want to bother with this? Because the Amber model has vwep support (you can see what weapon she is carrying), but Sydney doesn't.

INSTALLATION:
Extract to your Quake 2 folder. This should place the amber folder into the Quake 2\baseq2\players folder, so that it's parallel to the crakhor, cyborg, female, and male folders.

PROGRAMS USED:
GIMP
Audacity
