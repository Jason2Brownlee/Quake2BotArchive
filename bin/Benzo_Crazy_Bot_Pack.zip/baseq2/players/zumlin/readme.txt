Custom PPM "Zumlin" Ver 2.20 for Quake II

The Vwep is finally fixed.  There should be no problems with it whatsoever.
Please consult the other text files for instructions on installation and 
credits.  If you have any questions regarding the fixed Vwep, email me at:

lordsatorious@mediaone.net

Thanks go to Sumaleth for making the model and adding the Vwep (though not 
quite linked correctly ;)), and to id Software for making such a cool game.

-Ron Ferrara (Lord_Satorious)