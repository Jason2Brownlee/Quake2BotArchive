QUAKE2 PROFANITIES SOUNDPACK (v2) by BenzoSt

This pack just adds a few profanities to Quake 2, for comedy's sake. The changes I made in v2 was to correct an issue with the Iron Maiden and also to essentially revert a few sounds I didn't like from the Q2HM sound pack to default Quake 2 sounds.

Wait, what's Q2HM? It's the Quake 2 Heavy Metal mod, which I think is very good. To use my Profanities soundpack along with Q2HM, you can rename Q2HM.pak as pak8.pak and put it into the Quake 2/baseq2 folder, then add my profanities pack to Quake 2/baseq2 as pak9.pak.

INSTALLATION:
Extract to your Quake 2 folder. If this would cause you to overwrite pak9.pak (which you may have due to installing another mod), you will have to rename that pak before performing this extraction.

PROGRAMS USED:
PakExplorer
Audacity