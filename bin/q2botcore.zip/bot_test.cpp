/*	bot_test.cpp
 *	11/6/98 Ben Swartzlander
 *
 *	This is an example of a very simple bot, using
 *	q2bot.dll and q2map.dll.
 *	There is no error detection or handling here,
 *	so take care when compiling/running it.
 */

#include <stdio.h>
#include "q2bot.h"
#include "q2map.h"

/*
 *	This is the print function to pass to the bot core
 *	All of the output will come to this function, so
 *	you can redirect it wherever.
 */

void print(char *s) {
	printf("%s",s);
}

int main(int argc, char **argv) {
	int i;
	vec3_t angles,velocity;
	char mapname[64];
	gamestate_t gs;

	if(argc!=2) {
		printf("Usage:\n  bot_test <hostname>\n");
		return 0;
	}

	// These functions check to make sure the DLL's are the
	// same version as our .h files
	if(qbGetAPIVersion()!=Q2BOT_API_VERSION) {
		printf("Error: q2bot.dll is wrong version\n");
		return 0;
	}
	if(qmGetAPIVersion()!=Q2MAP_API_VERSION) {
		printf("Error: q2map.dll is wrong version\n");
		return 0;
	}

	// First startup the bot core, passing it the print function
	qbStartup(print,print);
	
	// Give ourself a rockin' name
	qbUpdateUserinfo("name","Llamaw00d[Bot]");
	
	// Uncomment the line below to record a demo.
	// THIS MUST BE CALLED BEFORE qbConnect()!!
//	qbRecordDemo("mydemo.dm2");
	
	// Then connect to the server listed on the command line
	qbConnect(argv[1],27910);


	// Get the map filename (model #1)
	qbGetModelString(1,mapname);

	// Print map filename
	printf("Map: %s\n",mapname);
	
	// LoapMap requires some directory names, the map filename and
	// the print functions that qbStartup uses
	qmLoadMap("d:/quake2/","",mapname,print,print);

	// NEW IN 3.17:
	// Now that we've loaded everything, tell the server to start
	// sending packets.
	qbBegin();
	
	// Zero out direction vector
	angles[0]=0.0;
	angles[1]=0.0;
	angles[2]=0.0;
	
	// Set speed vector to full speed ahead
	velocity[0]=400.0;
	velocity[1]=0.0;
	velocity[2]=0.0;

	// Run for 200 "frames"
	for(i=0;i<200;i++) {
	
		// Copy the gamestate
		qbGetGameState(&gs);

		// Print out frame number and player location
		printf("Frame #%d (%.2f,%.2f,%.2f) %s\n",i,gs.player.origin[0],gs.player.origin[1],gs.player.origin[2],gs.player.weapon_model);
		
		// Set our direction to inrease with the frame number
		angles[1]=(float)i/50.0;

		// Send a movement command with the angle and speed, and
		// the attack button held down
		qbMovementOrder(angles,velocity,1);

		// Say something at the 200th frame		
		if(i==100) {
			qbSynchConsole("say I'm alive!");
		}
	}

	// When we're done, disconnect
	qbDisconnect();
	
	// Shut down to release resources
	qbShutdown();

	// Remove the map from memory
	qmUnloadMap();
	
	return 0;
}