Q2BotCore v0.96 BUILD 83
11/6/98 Ben Swartzlander


Bugs:
I appreciate bug reports from people who use
Q2BotCore. There are still some known bugs,
and others that should be fixed, but that I
may have not tested. Please do me a favor and
tell me what version of the library you are
using when you send me bug reports. Thanks!


LCC Users:
For all of you LCC users I've added .lib and
.h files that work with LCC. They are included
in the lcc.zip file inside the archive.


--11/6/98--
* Restructured the way console messaged are
  handled. Now you can send console messages
  with garaunteed delivery, without blocking
  until the delivery is acknowldged.

* Optimized reliable packet delivery.
  qbConsoleCommand/qbSynchConsole/
  qbUpdateUserinfo now return up to 10 times
  faster (depending on lag).

* Found and fixed a small bug in q2map that
  was causing crashes on qbUnloadMap().

* Improved the logon sequence so it only
  spawns 1 thread instead of the 10 or more
  it was spawning before.

* I have determined that the infamous hanging
  during precache is a server problem. I need
  to verify the behavior of a normal Quake2
  client in this situation in order to write
  a fix. Expect this soon.

* There are still some problems with
  qmFindPath(), and I am working on them.


--10/22/98--
* Changed qmTraceLine to accept a contents
  mask as a parameter.

* Added a function to intercept text messages
  from the server, useful to analyze player
  speech.

* Fixed a bug in qmTraceLine that would cause
  it to return randomly incorrect values in
  rare circumstances.

* Added some experimental functions to the
  API. They will be used in future releases,
  and I wanted to put them in the header
  files now.

* Added profiling info to the q2map functions.


--10/19/98--
* Added function to get ping times. This is
  useful for predictive aiming.

* Fixed a fatal error in the qmFindPath
  function.

* Fixed demo recording so it no longer creates
  demo files that are read-only.

* Fixed a bug in player prediction that made
  it look like you are way ahead of where you
  really are. In the next version player
  prediction will be totally changed to be
  much more accurate.


--9/22/98--
* Changed protocol to match Quake2 3.19. This
  means that it won't work with versions before
  3.19.


--9/7/98--
* Added modelindex2, modelindex3, modelindex4,
  and renderfx flags to the entity_t struct

* Fixed a fatal bug in the hostname resolving
  function (it only happened very rarely)

* Greatly improved client-side prediction (this
  means that the velocity field in entity_t
  should be much more accurate now)


--7/19/98--
* Changed the way that functions are exported in
  the DLL. This will require all applications
  written on top of Q2BotCore to be recompiled.

* Changed MAX_ENTITIES from 512 to 1024. This
  was an artifact from the old QW code.

* Removed all "bool" types from the header
  files. All bools are now unsigned chars.


--7/4/98--
This version *IS* compatible with Quake2 3.17!
There have been some small changes in the login
sequence, check the example. Also some things
were made more rubust internally.


Here's what you get:
q2bot.dll - the compiled code for the Q2BotCore
q2bot.lib - the MSVC5 import lib you will link with
q2bot.h - the function declarations and documentation
          for Q2BotCore
q2map.dll - the compiled code fot the map handler
q2map.lib - the MSVC5 import lib you will link with
q2map.h - the function declarations and documentation
          for the map handler
readme.txt - this file
bot_test.dsp - MSVC5 project (optional)
bot_test.dsw - MSVC5 workspace (optional)
bot_test.cpp - an example bot source code
bot_test.exe - a compiled version of the bot_test.cpp
lcc.zip - .h and .lib files for LCC


The comments in the .h and .cpp files should be
enough to get you started. The example bot has no AI
and if you are interested in smart bots check out
my BastardBot, which uses Q2BotCore.


The Q2BotCore webpage is at:
http://www.telefragged.com/Q2BotCore/

My email address is: <swartz@rice.edu>
