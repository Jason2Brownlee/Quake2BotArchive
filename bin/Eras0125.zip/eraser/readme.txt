================================================================
 The Eraser Bot                                    v0.4 (Beta)
 by Ryan Feltrin (aka Ridah)              email: ridah@frag.com
................................................................

================================================================
Title                   : Eraser Bot v0.4 Beta
Author                  : Ryan Feltrin (aka Ridah)
Email Address           : ridah@frag.com

Description             : Human-like AI for Simulated Quake2
                           Deathmatch play

Additional Credits to   : id Software for being id Software
                          Rowan "Sumaleth" Crawford, for
                           playtesting and suggestions
                          Brett "B-MonEy" McMahon, for his
                           support and ideas
                          ??? "rkm" ??? for the linux port
                          To everyone who has supported my
                           work over the last year or so

Build Time              : ~380 hours
================================================================

DESCRIPTION

   The Eraser Bot is a simulated multiplayer opponent, for
   use with id Software's Quake2. It has been developed with
   speed and accuracy in mind, so that you can play with more
   bots, with higher intelligence.


INSTALLATION

   SELF-EXTRACTING VERSION (Win95/NT only)

   Double click on the EXE file, and select your Quake2 directory

   -OR-

   ZIPPED VERSION (Win95/NT & Linux users)

   Just unzip the files contained in the archive, to your
   Quake2 folder, RESTORING PATHNAMES. This means
   that if you're using Winzip, you must enable the
   "Use Folder Names" option when extracting. For
   pkunzip users (bless their souls), make sure
   you use the -d option.


RUNNING THE GAME

   To run the game, type the following from the DOS Shell
   command line, whilst inside your Quake2 folder:

   quake2 +set game eraser +deathmatch 1 +map <mapname>
   (please read below to find out which maps are supported)

   The from within the game, follow the on-screen
   instructions to spawn some bots.


SUPPORTED MAPS

   The Eraser is capable of dynamically learning maps, from
   humans whilst playing the game. However, maps that aren't
   supported by the release (and hence will require dynamic
   learning), will suffer from less intelligent behaviour,
   until the map has been played for a while (usually 10-15 mins).

   The following is a list of the standard Quake2 maps that
   are currently supported:

   base1
   base2
   mintro
   power1

   I have also added support for a few select user-made maps
   for Quake2:

   <mapname>         <url>

   crdm1             ftp://ftp.cdrom.com/pub/idgames2/quake2/levels/deathmatch/a-c/crdm1.zip
   ikdm1             ftp://ftp.cdrom.com/pub/idgames2/quake2/levels/deathmatch/g-i/ikdm1.zip
   mpq1              ftp://ftp.cdrom.com/pub/idgames2/quake2/levels/deathmatch/m-o/mpq1.zip

   These maps are highly recommended, for their suitability to
   deathmatch play. Many thanks to their respective authors.

   Follow the installation instructions for each map, they can be installed
   as usual, to your quake2\baseq2\maps directory, and will work fine with
   the Eraser.


GAMEPLAY SETTINGS

   Skill Levels

   You can increase or decrease the level of the opponents, using
   the "skill" setting. The default being "1", if you set this
   to "2", then the general skill levels of all bots will be raised.
   They will still maintain their individuality, just some will
   be slightly better in areas they may not have been on skill "1".

   Values: 0 (beginner) through 3 (advanced)


   Deathmatch Variations

   Using the "dmflags" setting (accessed via the Multiplayer Menu),
   you can enable a disable certain rules. Currently, all settings,
   other than "Teamplay" and "Infinite Ammo" are supported.

   "Weapons Stay" means that weapons will remain after being picked
   up, unless they were dropped by another player. This is a
   personal favourite of mine, and I think makes the game much
   more exciting, if less strategic.

   Please see your Quake2 manual for descriptions of the other
   settings.

   Values: Use the Multiplayer->Start Network Server->Deeathmatch Flags
            to set the flags you want to play with


SERVER ADMINS

   The Eraser now provide a range of customization commands and settings,
   which enable you to populate your server with Bots, when not
   many humans are playing. This means people are more likely
   to come to your server, since there is more chance of finding
   opponents (human or not).

   You can edit the names of the bots, by editing BOTS.CFG, located
   in the Eraser directory.

   The following commands are available to the server only:

   bot_num <n>

      defines the maximum number of bots

   bot_name <name>

      spawns a specific bot

   bot_allow_client_commands 0/1

      disable/enable client-side bot spawning via "cmd bots <n>"

   bot_free_clients <n>

      specifies the number of client positions to keep vacant
      at all times, whilst there are bots playing. So if
      you have set "maxclients 32", and there are 20 bots
      playing, set this value to 3, so that if the total
      number of clients (players + bots) exceeds 29, a bot will
      be kicked from the game.

      The lowest scoring bot is kicked first, in this circumstance.

      As soon as more than 3 slots become vacant, a new bot will
      be automatically brought into the game, assuming the current
      number of bots is less than the current value of bot_num.

   bot_show_connect_info 0/1

      Disables/Enables the banner that's shown to clients upon
      connecting, indicating that the server is running the
      Eraser bot patch.

   bot_calc_nodes 0/1

      Disables/Enables dynamic node calculation. If you are
      sure that this map has been played enough times, that
      it is unnecessary for the bot to continue learning the
      environment from the humans, just set this to 0. This
      frees up some CPU time, which should make things run
      a bit smoother if lots of humans are playing.


NEW TO THIS VERSION!

   See the todo list, at http://impact.frag.com for the
   latest list of bug fixes, and features added.

   New features/Bug fixes added to version 0.4:

   +  Added a SERVER ADMIN section, see below. This version has
      been worked on heavily, to enable servers to run the
      Eraser bot patch, to automatically spawn more bots
      to make the game more enjoyable.

   + Increase reaction time for bots after sighting a player (say, 0.8 seconds)
   + Limited FOV for sighting players
   + Need some way of saving which platforms/teleporters have been routed

   !! Linux port functioning !! .. was an optimization flag causing wierd behaviour

   + Fixed bug that prevented intelligent abort attack from functioning

   !! MSVC SUCKS MAGGOTS !! (lost an entire nights work, due to a WACK-ASS compiler malfunction)

   + created "bot_calc_nodes" to enable/disable dynamic node-table calculation
   + Bots should avoid danger, like grenades, BFG and rockets

   + further optimized .rt2 filesize by rounding off the route distances and scaling
      down to one byte
   + considered deleting all source code, but was convinced by a grass-hopper
      that someday my hard work will not result in getting stabbed in the back

   + re-worked all consol commands, added lots of server settings:
      bot_num - maximum number of bots in game at once
      bot_name - spawn a specific bot
      bot_allow_client_commands - enable/disable client bot commands
      bot_free_clients - make sure <n> client spots are open at all times
      bot_show_connect_info - enable/disable the Eraser specific banner shown upon connecting to the server

     So it's now possible to run a server, that constantly spawns and drops Eraser bot's,
     to keep the game interesting :)

   + Fixed more AI stuff

   + implemented "fuzzy" portals to speed up "nearest node" determination
   + increased MAX_NODES from 512 to 1400 as a result of new portal tech

   + time/fraglimit crashes game
   + Update weapon attributes to match latest Q2 codebase
   + Aiming still too good in skill 1
   + Chaingun build up like real players
   + "cmd botname <name>" then "cmd bots 2", second command only spawns one bot, and first bot loses all forms of intelligence

   + Added dynamic route-table generation (deathmatch 99) (!!!)
   = Showstopper: SZ_Getspace overflow without allowoverflow set.
   + Skins/Bot names with spaces in them don't work
   = Bots disappear after some time

   New features/Bug fixes added to version 0.3:

   + Some bots become transparent after death
   + Loads of AI fixes
   + Weapon selection based on circumstances (used to use each weapon until out of ammo)
   + Bots lose intelligence over time
   = Bot's get stuck in sloped (downwards) walls when jumping
   + Added support for custom skins, and client play via network, without installing the Eraser on clients
   + Restored the original Q2 scoreboard
   + Fixed timelimit
   + "cmd botname <name>" no longer case-sensitive
   + Fixed various AI stuff

   New features/Bug fixes added to version 0.2:

   + NODES: Add support for ladders
   + NODES: Add support for teleporters
   = NODES: Add support for lifts/plats
   + Fix some jumping problems in MINTRO
   + Bots now avoid falling in lava/slime more intelligently
   + Increase accuracy of CanMove()
   = Bots occasionally get stuck at top of ladder in MINTRO
   = Bots fire grenades too high when enemy is up-close
   + Bots should go for any weapon when visible, if not attacking enemy
   + Remove unlimited ammo, do weapon change checking when out of ammo
   + NODES: When jumping, check best route is less than jump_distance * 2, rather than a hard coded value
   + Support for skill levels
   + External file support for Bot names, skins and skill levels (skills are adjusted according to the consol "skill" setting)
   + Distributive thinking, so bots out of the client's view are processed between server frames
   + Lots of optimizations
   + Bots with a high "Combat" rating can crouch while attacking


FREQUENTLY ASKED QUESTIONS

   Q: When the game starts, it says "ERROR: Game is version 2, not 1"?

      You need the latest version of Quake2 in order to play the
      Eraser bot. Goto one of the following sites to get the latest
      version upgrade:

      http://www.bluesnews.com/
      http://redwood.stomped.com/
      http://www.planetquake.com/


   Q: The game starts, but I don't see any bots?

      To spawn some bots, type "cmd bots <n>", where <n> is
      a number from 1 to 12. They will then enter game at 2 second
      intervals (to try and reduce telefrags).

      You can also spawn a specific bot using "cmd botname <name>",
      where <name> is the bot's name. You can get the list of bots
      from bots.cfg, which you'll find in your Eraser directory.


   Q: The bots sometimes stand around looking bored?

      There are still some glitches in the bot decision-making that can result
      in bots getting stuck. Also it is possible that some bots will
      disappear. These problems will obviously be fixed in the near future.


DISCLAIMER

   This is a BETA release, I therefore will not take responsibility
   for your system barfing after playing the game. I can however
   guarantee that I have not purposely added any malicious content
   to this application. If you believe this to be incorrect, then
   I'd be happy to discuss the matter with you.

   You may freely distribute this archive, as long as it remains
   PERFECTLY intact, as distributed on our home page:
   "http://impact.frag.com/". Thanks.


Please report show-stopper bugs to: ridah@frag.com

enjoy,
-Ryan Feltrin