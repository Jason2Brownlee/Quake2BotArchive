BastardBot v0.47 BUILD 67
11/6/98 Ben Swartzlander


--11/6/98--
* Recompiled for new Q2BotCore libs.


--10/23/98--
* Totally restructured event loop. Added an
  extra thread to manage "quests". Massively
  increased performance on some maps.

* Fixed some more bugs (bot wouldn't go after
  ammo...don't ask)


--10/22/98--
* Fixed some bugs 

* Recompiled for new Q2BotCore libs again.


--10/19/98--
* Recompiled for new Q2BotCore libs. *sigh*


--9/22/98--
* Recompiled for new Q2BotCore libs.


--9/7/98--
* Recompiled for new Q2BotCore libs.


--7/19/98--
* Increased MAX_ENTITES to 1024. This was an old
  artifact from the QW code.

* Recompiled against new Q2BotCore libs

* Fixed a small bug in item detection


--7/7/98--
* Fixed command line options under glbastard


--7/6/98-- HOTFIXES:
* Added command lime options so you can set what
  directory your Quake2 is installed in.
  NOTE: glbastard does not have this fix.

* Fixed maps with capital letters (Q2DM?)


--7/4/98--
BastardBot is a highly advanced client side bot
based on Q2BotCore, a library I wrote for Quake2
client side bots. This is the very first release,
and I'm still working out zillions of bugs, so
bear with me. The main problem is that BastardBot
does not compensate for lag very well at all. I
recommend playing against him on a LAN.

Files:
q2bot.dll - the compiled code for the Q2BotCore
q2map.dll - the compiled code fot the map handler
bastard.exe - the BastardBot program
glbastard.exe - a graphical version of BastardBot

I included the graphical version of BastardBot
as a novelty. It is most likely less stable than
the console version. I use it only for debugging,
and I have an OpenGL accelerator. It does not
require an OpenGL accelerator, but I highly
recommend one. If you have a Voodoo card, for
example, get 3dfxogl.dll from the 3Dfx webpage,
and rename it to opengl32.dll in the same
directory as glbastard.exe.


The Q2BotCore webpage is at:
http://www.telefragged.com/Q2BotCore/

My email address is: <swartz@rice.edu>
