Oak II Build Release Notes:
===========================

Version 	0.40 (Public Beta)

Author: 	John Crickett
Web Page: 	www.telefragged.com/oak
Email: 		oak@telefragged.com


This document contains:
-----------------------

Credits
Instructions
Legal Info

Additional Instruction
Command List
Advanced Instructions
Information on Pathing Levels


Credits and Thanks:
===================

Web Site and Ideas:		Krunch-X (new) Neil Henderson aka Hendo (old)

Additional Coding:		Marcus Davies aka Ithacus

Help with Zip Code:		Ryan Feltrin aka Ridah 		(impact.frag.com)

Testing:			Bot Epidemic Crew 		(www.telefragged.com/epidemic)
				Krunch-X			(www.krunch-x.co.uk)
				Legion				(www.inside3d.com)

VWeps models:			Hentai				(http://www.telefragged.com/tsunami)

Quake2:				id Software


Instructions:
=============

1. Unzip the dll to a dir named "oak" beneath you installation of Quake2 i.e. c:\quake2\oak. NOTE it MUST be in this 
   directory, for bot config and path files to work.

   IF IT DOES NOT exist, create a dir called "memory" beneath the quake2\oak dir, the bot path data will be stored here as 
   .pth files.

   You will also need the dirs \bots\male and \bots\female which should contaion the tris.md2, from the zip.

   If you wish to use Vweps you`ll need the pak file in your baseq2 dir. You can donwload it from:

	http://www.telefragged.com/tsunami

2. There are two ways of using Oak II either:

a) run OakLaunch.exe - I STRONGLY reckonmend everyone use's this frontend. It should be kept in you Oak dir.

b) FOR ADVANCED USERS ONLY: Add "+set deathmatch 1 +set game oak +map q2dm1" to you command line when starting quake2. 
   Start Quake2 bring down the console (press ~) type: "oak" to add a bot.


Additional Instructions:
========================

Cofiguring Bots:
----------------

At the moment only bot names can be configured via the botnames.cfg file. All names must be less than 20 characters and must
NOT include any spaces.

Bots learning your playing style:
---------------------------------

Bots now learn you favourite weapons.

Learning Levels:
----------------

The bots will improve as they learn a level, hence if you wish them to remember the level you must save it (oak_save)
before exiting a level. However the path data is saved automatically when a frag/timelimit is hit.

Custom Models:
--------------

To use othe models you will need to place the original model in your player\<model name> dir and the Oak II adapted version
in you oak\bots\<model name> dir i.e. for the cyborg model. Skins should be in the same place as for a player.

quake2\baseq2\players\cyborg
quake2\oak\bots\cyborg

The only difference between the normal player models and the bots version is that the bots version contains skin info, you
can set this yourself using a program such as: NST.

Team Play:
----------

This is based around teams working as groups of partners. Bots will attempt to pair up and hunt together, if they are 
getting hurt they will often call for help just like a player.


Command List:
=============

Normal:
-------

* oak		- Add a bot.


Teamplay:
---------

* oak_join	- This command MUST be preceeded by "cmd", it allows the player to specify their team. i.e. 
                  "cmd oak_join QUTA"

* oak_help	- Calls for help, the nearest 2 bots will attempt to come and help you. 

* oak_stay	- Instructs your partner to stay here and cover the area.

* oak_come	- Calls your partner to you.


Advanced:
---------

* oak_load	- Loads the path data file for this level, if any. NOTE the path data is loaded on startup already.

* oak_save	- Save the path data to file. NOTE this is done automatically when the map changes.


Variable List:
==============

oak_path	- Enables (1) or Disables (0) dynamic pathing of the levels. It defaults to 1 when starting the game.

oak_fastweaps	- Enables (1) or Disables (0) fast weapons switching. It defaults to 0 when starting a game.

oak_teamplay	- Enables (1) or Disables (0) teamplay. It defaults to 0 when starting a game. 

oak_viewweaps	- Enables (1) or Disables (0) viewable weapons for bots NOTE you must have the vweps models for this to work.
		  It defaults to 0 when starting a game. 

oak_careful	- Enables (1) or Disables (0) careful bots. It defaults to 0 when starting the game.


Advanced Instructions:
======================

Bot Config Files:
-----------------

The file named "botnames.cfg" contains a list of the 12 bots you can spawn, you can configure this file to suit your needs.
ALL the fields must contain a value. the fields are:

Name, Sex, Skill, Team, Skin Number, Min Health, Model

i.e.

OakII male 3 SR 0 40 male

Names, Team Names, and Model names must be at most 20 letters.

Skin number referes to the number of the skin within the model.

Model refers to the model name, it assumes you have installed the plug in player model correctly for use with a player,
you also need to copy the tris.md2 file to the oak\bots\<model name> dir, i.e. oak\bots\male\. The model should also
contain a set of skins otherwise it`ll appear to be red and black in quake2. I suggest you use NST to set the skins within 
the model.

Min Health is the value above which the bots will try to maintain their health, set high the bots will be somewhat cautious,
low and they`ll ignore health. The default setting is 40.

Skill levels affect the YAW SPEED of the bots, and the following attributes:

ATTRIBUTE:         |     SKILL LEVEL REQUIRED:
----------------------------------------------

Strafing			1 +
Jumping in combat		2 +

Different yaw speeds result in different aiming accuracies, higher skill bots aim better.



Hints for creating good path files for Oak II
=============================================

How does pathing work:
----------------------

Oak II navigates a level by wall following and/or using path files. When a level is mapped
a series of nodes are place around the map, and information about the links between each
pair of nodes is stored. When a map is "mapped" no paths are created, simply a list of nodes
and a list of which nodes are reachable from each node.

The paths are determined on the fly when bots require to get from node a to node b, once a 
path is known the bot saves it in the path file. It is also possibly to pre-calculate all the
paths on a level, which can take some time, but results in the bots being able to find a 
path around a level VERY quickly (in CPU terms).


How to create path files:
-------------------------

Most of the path nodes used by Oak II are placed based on information from the player,
hence it is possible to path a level without having any bots in the game (assuming you are 
running the Oak II mod in deathmatch).

When pathing try to run around all of the level sticking to the center of corridors, and not
running along edges. Try not to fall, or worse jump into lava/slime.  Try to cover all of 
the level, running over all the items, if you can get there, the bot will know how to.

Once a level is mapped, you can then precalculate all the paths through it.


Precalculating a path file:
---------------------------

This can be done either in quake2 using the command "oak_precalc" or preferably via the seperate program
Optimise. Optimise should be run from you oak dir as Optimise <level> i.e.

Optimise q2dm1

This program can take some time to run, however the resultant path files will cause NO slowdown
in quake2. The entire process of finding a path is a single if statement.

NOTE: it is by NO means necessary to optimise paths.


Legal Notice:
=============

Distribution:

This bot is Copyright John Crickett 1998. It is being developed solely for my own amusement and as such is provided as is.
You may NOT distribute in any way shape or form, any version of this bot which states it is a private build. i.e the 
intro messages states "Build x.x Private". If you are given a private build by anyone other than myself (J. Crickett), 
please do not accept it and email me details of the distributer.

You may distribute any public i.e. states "Public Version x.x" in the intro message, via the internet so long as the 
zip/installation remains totally intact (intact being defined as containing the same files as the identical zip/installer
on the official web site). You may ONLY distribute this bot on permenant media (i.e. CD/floppy disk etc) if above conditions
are satisfied, and NO charge is made for the ENTIRE CD. A exception is made for regular magazine cover disk/CD's, in which 
case it may be included, though I`d ask any magazines that do to let me know about it, though its  not compulsory to do so.

Disclaimer:

You use the enclosed files entirely at your own risk, I accept NO liability for any damage or loss of data resulting
from the use of this bot.

