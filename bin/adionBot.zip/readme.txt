=============
adionBot v0.15
=============

WhaT? : A Deathmatch/Teamplay bot for Quake2

Author : Adion Coolman <adion@geocities.com>

Thanks To : 
The Author of the Tangential Bot Tutorials. (spawning code)
Ridah for releasing his Eraser source. (some things)
Tom Conder for releasing the Happyfun source. (walking/rotating)
Mr. Elusive for releasing the Gladiator source. (jumping/crouching)
People on the Quake2 editing newsgroups.
id Software for creating such great games.
All of you testing this bot.
=============

About
=====
I've created this bot mostly to test some AI ideas I had, and to get more
experience in C++. It is also meant as a bot that I hope will one day
be pretty good.
The most difficult thing about it is that I don't want to use any node navigation,
which makes the navigation code a bit harder and currently not really great.

Included 
========
This readme.txt
The gamex86.dll Win32 game file
A map I created once, originally done for Capture The Chicken
A recammed demo (by myself) featuring a three team deathmatch in the ctc1 level
showing off some off the AI.

Usage
=====
Extract the zip in a directory under your quake directory called adionBot
ex. c:\quake2\adionBot

Start Quake2 like this :

Teamplay :
	quake2 +set game adionBot +dmflags 336 +map base1
	Or just add Teams by Skin to the dmflags

Deathmatch :
	quake2 +set game adionBot +dmflags 272 +map base1
	Or just remove Teams by Skin from the dmflags

To add a bot, open up the console (~) and type :

sv bot spawn
	to add a Voodoobot (Team VoodooBot) = Female/Voodoo

sv bot spawnAdion
	to add a Adion (Team Adion) = Male/Red

sv bot spawnTRex
	to add a TRex (Team TRex) = Male/Blue

to join team Adion :

skin male/red
name Adion

to join team TRex :

skin male/blue
name TRex

to join team VoodooBot :

skin female/voodoo
name VoodooBot

Bugs
====
-The game crashes and returns to the desktop after you press an
unbound key or try to execute a non-existing command.
-The first time the bots spawn, they might get stuck against a wall, once
they respawn, their navigation code works correctly.
If anyone can help me, please mail me.

Contact
=======
E-Mail : adion@geocities.com
WWW : http://www.geocities.com/TelevisionCity/Set/1894/quake.htm

What's New? v0.1 -> v0.15
-----------
-Strafing works
-They can choose weapons
-They will go for air if needed
-Jumping and Crouching works
-They can miss you when shooting

What's New? v0.1
-----------
-They can walk around
-They can pickup items
-They can group in teamplay
-They can shoot at you
