// ItemSpec.h: interface for the CItemSpec class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ITEMSPEC_H__E1210268_DE14_11D1_AF21_0060080A5FD2__INCLUDED_)
#define AFX_ITEMSPEC_H__E1210268_DE14_11D1_AF21_0060080A5FD2__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CItemSpec  
{
public:
	CItemSpec();
	virtual ~CItemSpec();

};

#endif // !defined(AFX_ITEMSPEC_H__E1210268_DE14_11D1_AF21_0060080A5FD2__INCLUDED_)
