// NewMove.h: interface for the CNewMove class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_NEWMOVE_H__56D8D832_EF41_11D1_AF23_0060080A5FD2__INCLUDED_)
#define AFX_NEWMOVE_H__56D8D832_EF41_11D1_AF23_0060080A5FD2__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CNewMove  
{
public:
	CNewMove();
	virtual ~CNewMove();

};

#endif // !defined(AFX_NEWMOVE_H__56D8D832_EF41_11D1_AF23_0060080A5FD2__INCLUDED_)
