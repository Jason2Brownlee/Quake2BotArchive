
                     D_R_O_N_E   B_O_T
  
================================================================
								
Name of Mod 		: DroneBot
Author      		: XoXus
Assistant		: ReKTeK 

Filename   		: db_g21.zip
Version     		: Gamma 21
Date                    : May 3, 1998

XoXus
Email      		: xoxus@usa.net
URL     		: http://dronebot.vortexq.com

ReKTeK
E-mail	    		: bilbe@iinet.net.au
URL			: http://www.iinet.net.au/~bilbe

Description             :The DroneBot is a simulated deathmatch opponent
                         for Quake2. Unlike other available bots it will
                         not simply copy the player's movement around a
                         level, but will use its own vision to navigate
                         and attack the player. Some consider copying the
                         player's movements to be "cheating". This is not
                         our opinion, but we feel that it is probably a
                         little less than honest.

===============================================================

TYPE OF MOD
-----------
DLL      : Yes.
Sound    : Grappling Hook only.
MDL      : Grappling Hook only.
Maps     : No.
Graphics : Console background.


CREDITS
-------
id Software     - Who else could make the 3 most historic games in gaming
                  history? (I'm talking about Wolf3D, Doom and Quake)
David Wright    - Releasing the source code to his menu system
Yaya (-*-)      - Scanner code and graphics
John Crickett   - Inspiration for the bot
Jagasian        - Helping me fix the bot solidity problem
ReKTeK          - Helping out with so many things ;-)

===============================================================

		/=========\
              -< Main Menu >-
		\=========/
				
	
	1.	Installation
	2.	Console Commands
	3.	Menu System
	4.	Supported Skins / Models
	5.	Known Bugs
	6.	Unknown Bugs
	7.	Copyright / Permissions


	1.	INSTALLATION
	-	^^^^^^^^^^^^


Once you have installed it to a directory in quake2, then to run it, just add

        "+set game dronebot"

to your Quake II command line to run it.



	2.	CONSOLE COMMANDS
	-	^^^^^^^^^^^^^^^^


"botmenu" -     This will pop up a menu allowing you to change settings and
                do things with the bots.


"scanner" -     Toggle the scanner


"botcam"  -     Toggle the BotCam


This mod is in no way associated with id Software. 
E-MAIL -  xoxus@usa.net  OR  bilbe@iinet.net.au 
with comments, questions and suggestions. 


	3.	ABOUT THE MENU SYSTEM
	-	^^^^^^^^^^^^^^^^^^^^^


The intrinsic menu system acts just like the standard inventory. Use your
inventory navigation keys (usually "[" and "]") to move up and down the menu,
and use Enter to select an option. The menu cycles around, so that moving up
from the top option will go to the bottom option, and vice versa.


	4.	SUPPORTED PLUG-IN MODELS (number of skins in "[]" brackets)
	-	^^^^^^^^^^^^^^^^^^^^^^^^ (alphabetical order)


* AstroBoy (Jonn Gorden) [2]
* Bananas In Pyjamas (GaratJax[B5]) [1]
* Boba Fett (Dan Bickell) [3]
* Cereal (Dave "HotFat" Biggs) [5]
* Crackwhore (Paul Steed) [3]
* Dalek (Ryan Dobson) [4]
* Dire Avenger (ALPHAwolf) [2]
* Doom Marine (Treponema "Malekyth" Pallidum) [1]
* Dumb Fighter (Brian Yee) [6]
* Eric Cartman (Brian Yee) [5]
* Garfield (Lars Jensen) [2]
* Kenny (ThargerUS@aol.com) [1]
* Little Grey alien (richb@jarsys.demon.co.uk) [1]
* LegoMan (Paul Burslem) [1]
* Morbo (Rowan "Sumaleth" Crawford) [1]
* Optimus Prime (Felonyboy & Lavo) [1]
* QuakeGuy (Rikki "Phukyumoto" Knight) [1]
* R2D2 (osx) [4]
* Raptor (Conor O'Kane) [5]
* Sheep (Richard "GiB" Clark) [3]
* Sideswipe (Jason Seip/Rikki Knight) [3]
* Snork (Kray-Zee) [7]
* Starscream (Rikki "Phukyumoto" Knight) [4]
* Sydney (Brian 'EvilBastard' Collins) [2]
* Teenage Mutant Ninja Turtle (Henry Yau) [1]
* Winter's Faerie (Brian "EvilBastard" Collins) [4]
* Xenoid (Dan Bickell) [3]
* Zumlin (Rowan "Sumaleth" Crawford) [1]


[ If you have made a plug-in model that is not listed on the above list,
  e-mail me the URL of a download site. Please, DO NOT e-mail me the actual
  model! Thank you for your consideration. ]


	5.	KNOWN BUGS (In order of priority)
	-	^^^^^^^^^^


 (1) The dead player models sometimes sink into the ground.....
 (2) When a bot dies, then later disconnects, the bot's bodies revert to
     the male/claymore model+skin (grrrrrr.....)


	6.	UNKNOWN BUGS
	-	^^^^^^^^^^^^

Before contacting me, check the ToDo.txt file for the problem.
If you find any bugs that aren't in the above section, and it's a bug, or you
have a suggestion, PLEASE e-mail me. If it's a bug, include plenty of
information about your computer, it's setup, and what Quake2 settings you've
tried. (E-mail me at xoxus@usa.net)



	7.	* Copyright / Permissions *
	-         ^^^^^^^^^^^^^^^^^^^^^^^

Copyright (c) 1998 XoXus.  All rights reserved.
This level may be electronically distributed only at no charge to
the recipient, and may not be modified in any way.  This text file
must be included in zip file.

This level may not be distributed on any CD-ROM without the prior,
explicit consent of XoXus.
