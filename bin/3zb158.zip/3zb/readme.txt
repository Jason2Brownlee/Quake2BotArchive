Title       : 3rd-Zigock Bot 1.58 For Quake2 Deathmatch
			CTF Chaining Route Pack

File Name   : 3zb158.zip
Date        : June 26, 1998
Author      : ponpoko
E-mail add. : ponpoko@exa.co.jp
Web Site    : http://users.jp.tri6.net/~ponpoko/stupid.html
Build time  : a lot of days


Type of mod 
-----------
DLL      : Yes
Sound    : No
MDL      : No
Maps     : No
Graphics : No


Setup and run
-------------
Unzip file and directory under your Quake2 diretory,and run Quake2 like below

Quake2 +set game 3zb

When you want to play CTF
1.put the "chn" file under \3zb\chain 
2.copy CTF's pak0.pak to 3zb's dir
3.set the value of "ctf" and start the game.

Console commands
----------------
impulse 101-109		Spawn 1-9 bots(Red team when CTF mode)
impulse 111-119		Spawn 1-9 BLue team's bots 
impulse 201-209		Remove 1-9 bots
skill 0-2,3,4		Set Bot's skill
			When store "3",refer to config setting
			When store "4",do the test mode
			(activated when restart)

vwep			Viewable weapon on/off (default = 1)
			(activated when restart)

About Bot's config
------------------
If you want front-end.

Bot Johnny
http://jb.quake2.co.uk/

3ZB Front End
http://www.cgrillo.demon.co.uk

AUTO BOT
http://www.telefragged.com/autobot/


Current Playable CTF MAP
------------------------
=== id's map ===

q2ctf1
q2ctf2
q2ctf3
q2ctf4
q2ctf5
base1
base2
base3
bunk1
ware1
ware2
jail1
jail2
jail3
jail4
jail5


=== Star CTF map === 
http://www.captured.com/starctf/

starctf1
starctf2

=== StroggCTF map === 
ftp://ftp.cdrom.com/pub/quake2/levels/ctf/s-u/stroggctf.zip

sctf1
sctf2
sctf3


other .chn files are here

SubHuman's Bot Outpost
http://www.planetquake.com/outpost/

if you want to create chn file yourself,please read chedit.txt
