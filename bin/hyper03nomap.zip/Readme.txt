////////////////////////////////////////////////////////////////////
//#                 -World's Fastest Deathmatch-                 #//
////////////////////////////////////////////////////////////////////
//################################################################//
//#                                ,   ,                         #//
//#   _   _                       /|   |\             _          #//
//#  | | | |_   _ _ __   ___ _ __| |___| |_   _  __ _| | _____   #//
//#  | |_| | | | | '_ \ / _ \ '__| |_ _| | | | |/ _` | |/ / _ \  #//
//#  |  _  | |_| | |_) |  __/ |  | \| |/ | |_| | (_| |   <  __/  #//
//#  |_| |_|\__, | .__/ \___|_|   \_   _/ \__,_|\__,_|_|\_\___|  #//
//#         |___/|_|TM              | |     1998 HyperTeam       #//
//#                                 | |                          #//
//#                                 \ /                          #//
//#                                  '                           #//
//################################################################//
////////////////////////////////////////////////////////////////////

Name of Mod : HyperQuake for Quake2
  File Name : Hyper02.zip
	 Version : 0.2 Beta (a real release :-)
		 Date : June, 1998
	  E-mail : Anozireth@Yahoo.com, Rognstad@USit.net, aNGeLoRD@PlanetC.com, dupeq
	Web Site : http://hyper.telefragged.com
	  Thanks : id Software, for being who they are and doing what they do;
			 : Ridah and everyone who contributed, for the great Eraser bot.
			 : Mark Davies for the stdlogging
			 : QDevels and everyone who subbmitted all their helpful tutorials;
			 : Tim Ellis aka. HaShRaBiT, for many suggestions and some playtesting;
			 : Jordan Boss for blabbering out the BFG suit idea one day in Anozireth's
			   ceramics class and for testing;
			 : Hentai for vwep
			 : Our Beta testers and their support;
			 : Paul Driver, for TONS of help testing, getting our server up,
			   all the feedback and more;
			 : Rick Kranz for playtesting, feedback

 Build Time : Uh oh. Bad thought. The word 'life' comes to mind...


AUTHOR INFO - ALL MEMBERS EQUAL
-------------------------------
	aNGeLoRD : Justin Sherfey
   Anozireth : Tom Nicholson
	  Hunter : Hunter Rognstad
	   Dupeq : Andrezj Lach


TYPE OF MOD
-----------
		  DLL : Yes
		Sound : No
		  MDL : Yes
		 Maps : Yes, full map pack
     Graphics : Yes
	   Source : No, Sections might be given upon Request.  BFG-Suit tutorial is included.


COMPILE INFO
------------
Compiled with MSVC 5.
It was based on Zoid's 1.02 Quake 2 CTF source and the 3.14 Quake2 dll source,
and later intergrated with the Eraser bot.

*********************
Eraser bot disclaimer
*********************
	The Eraser Bot is a product of Ryan Feltrin, and is available from
	the Eraser Bot homepage, at http://impact.frag.com.

	This program is a modification of the Eraser Bot, and is therefore
	in NO WAY supported by Ryan Feltrin.

	This program MUST NOT be sold in ANY form. If you have paid for 
	this product, you should contact Ryan Feltrin immediately, via
	the Eraser Bot homepage.

***************************************************************************
INSTALLATION - REALLY IMPORTANT STUFF
NOTE:  You must carefully follow these instructions, or you will
probably get errors.  An installer may be included with the next release.
***************************************************************************
First, you must have installed the Eraser bot.  Then, you must rename the 'eraser'
dir to 'hyper'.  NOTE: Be sure to back up any inportant files in the eraser
dir.  You will need to re-install the Eraser bot to use it by itself.

Now, unzip this file with the -d extension into C:\Quake2\Hyper
 (or wherever your Quake2 directory is located + \Hyper)

Then, copy your Pak0.pak from the \CTF directory to \Hyper
**** NOTE ****: You MUST copy this file or you will get sound and graphic errors
 when playing CTF.

 id Software's Quake2 CTF Version 1.02 can be downloaded at:
  ftp://ftp.idsoftware.com/idstuff/quake2/ctf/q2ctf102.exe

Now make sure you have installed Hentai's Visible Weapons patch (included in the 3.15
 point release), which can be obtained at:
  http://www.telefragged.com/vwep/

Finally, Run Quake2 with the '+set game Hyper' extension
 (without the '' thingies)

***************************************************************
A SERVER!!!!!!!!
Ok, it's at games.vegasnet.net It's located in Las Vegas(duh!) and is on a T1 connection.
This server will always be running the latest version, and may occasionally be closed
for private testing (not very often or very long though).
***************************************************************

LIST OF CURRENT FEATURES:
-------------------------
(* designates new since last release)

*- ERASER BOT!!  Bots will use: Napalm Cannon,Sniper Rifle and
   Poison Gun. Poison gun will poison bots and they will go for the
   mega health or the Adrenaline.  Note that flash grenades and pepper
   spray have no effect on the bots yet.  Unfourtunealy, bots will not
   yet go for water when set on fire.  I am working on this, but it
   seems that it will be difficult to implement.

- Server Features - See server.txt for ALL server-related info.  Logging
  CVARs, and admin features are covered in detail there.

- Napalm Cannon - Shoots flames (duh!) at speed of machine gun.  They will stick to guys and
  burn them till they find water.

- Sniper Rifle - Ever find a perfect sniper spot, but don't want to give it away with the railgun?
  The sniper rifle does twice the damage of the railgun with half the firing rate, but leaves
  no trail. :-)

- Flash Grenades - Though they don't do any real damage, they can be effective if used right.
  When they explode, they temporarily blind anyone within a certain range who can see it.
  The closer you are, the longer your screen will be white.  Affect on the shooter is user
  settable.

*- Laser Trip Mines - Picked up with ammo pack or bandoleer, these babys
   fire a red laser, that when crossed, sets off an explosion and the 
   base.  Very useful for defending flag or booby traps.

- BFG Suit - This is an inventory item that makes a more powerful BFG ball follow you around.
  It lasts 1 second per use and uses 50 cells.  The beams vaporize (almost) anything in range
  with 150 damage per second. (tutorial included)

- Offhand Flashlight - Shines a spot of light where you aim it (duh).  Can be used with
  other weapons at the same time.

- Dual Weapons Tech - Fire two shots at once from each weapon(dual quad railguns, hehehe ;-).
  This is used the same as the other CTF techs.

- Full CTF support - HyperQuake supports regular DeathMatch and CTF.  CTF can be played on ANY
  level, all you have to do is type 'ctf 1' at the console; if Hyperquake detects a CTF level,
  it will use it as normal.  If it doesn't detect a CTF level, it will randomly select a
  deathmatch startpoint and designate that as the red base, and then find the start point
  farthest away and designate it as the blue base.  Techs will spawn as normal.  

- Offhand grapple - Hyperquake now has an offhand grapple.  To set it up,
  type each of these lines into the console:
  
  alias +hook hook
  alias -hook unhook
  bind / +hook
  
  The / can be any key you wish to use to grapple.  To use it now, all 
  you have to do is hold down the / key (or whatever you made it), and
  the grapple will fire.  Release the key, and it will retract.  

- Poison Gun - Sparys poison at short range which turns its victim's screen red and hurts them
  until the find a 100 health or Adrenaline.  One shot poisons someone.

- Pepper spray - About the same as the poison gun except it turns the srceen almost sloid black
  for a few seconds and does no damage.

- Rocket Changes - For players with a ping greater than 500, the rockets they shoot will
  home in on other players.  Also, rockets have more kick back, allowing for higher rocket
  jumps.

*- Eraser style railgun - An option that makes the railgun act like more
   like the one in the movie Eraser.  That is, you go flying back to the
   wall when hit.

HOW TO USE THIS PATCH
---------------------
Let's go through this one thing at a time.  First of all, all commands from CTF still stand.
 'Default selection methods' will mean using weapnext, or through the inventory.

New weapons (Napalm Cannon, Sniper Rifle, Flash grenades, Pepper and poison)
  are use as normal weapons, and are picked up when you get other weapons.
  Here is the weapons they come with:
  
  Napalm Cannon  : Grenade Launcher
  Sniper Rifle   : Railgun
  Flash Grenades : Grenade Launcher
  Pepper Spray   : Shotgun
  Poison Gun     : Shotgun

I am planning to use a system where pressing you won;t have to scroll
  though all the weapons.  eg. Press 6 once for GL, twice for Napalm, 
  and 3 times for Flash GL.

Laser Trip Mines are picked up with the Ammo pack or bandoleer, and are
  used as an inventory item.  You must select it, then aim, and use it.
  It will be tossed a little in front of you when used.

BFG suit is selected through the inventory (the icon that looks like the BFG ball) or by typing
 use "BFG Suit". To activate it, use it like any other inventory item.  BFG suit can be entirely
 disabled by setting allow_bfg_armor to 0. BFG suit will be recieved with the Body armor AND the
 BFG and requires 100 cells to be able to use (But uses only 25 cells per use).

FlashLight can be selected as an inventory item or by typing "use flashlight".  Selecting it
 again will turn it off.  Flashlight is recieved with the Ammo pack or Bandoleer.

To use CTF on a non-CTF level, just set ctf to 1 and load the level. (I strongly recommend
 that the level has at least 5 DM starts).

For anything else, PLEASE look in the inventory or find a server and ask there, as someone
will most likely know.  We don't have time to answer 20 of the same questions via e-mail.

KNOWN BUGS
----------
See todo.txt

PLEASE report any bugs you find to Anozireth via Email or the bug report
form on our homepage.


FREQUENTLY ASKED QUESTIONS:
---------------------------
Q: I connect to a server but it says 'Can't find map : q2ctf*.bsp' (where * is a number
	from 1 to 5), or I get 'Can't find pic: ' errors, what is wrong?
A: The server is running CTF and you did not copy the CTF pak file to your hyper dir.  To
	remedy this, copy pak0.pak from the c:\quake2\CTF directory to c:\quake2\hyper.  Make
	sure to COPY, not MOVE, because if you MOVE it, normal CTF will not work properly.

Q: I am having trouble with the Eraser bots.
A: Read the Eraser bot readme.  If you're still having problems, contact
   Anozireth.

Q: Who do I contact for help?
A: One of us.  You'll probably get an instant response on ICQ If we're not too busy.
+-----------+---------------------------+-----------+------------------------------------------+
| Person    | E-mail                    | ICQ UIN#  | What to contact about                    |
+-----------+---------------------------+-----------+------------------------------------------+
| Dupeq     | dupeq@telefragged.com     | --------- |                |
| Hunter    | hunter@telefragged.com    | --------- | Don't contact Hunter, he won't help you! |
| Anozireth | anozireth@telefragged.com | 11962484  | Contact about bugs.                      |
| aNGeLoRD  | angelord@telefragged.com  | 380123    | Contact about misc. stuff.               |
+-----------+---------------------------+-----------+------------------------------------------+

Q: What is the meaning of life?
A: 3 (or sex maybe ;)


COPYRIGHT/PERMISSIONS
---------------------
You may freely distribute this archive provided it is distrubted intact and no money is charged
for it.  If you would like to sell it on a disk contact us first or suffocate on our lawsuit.


HYPERTEAM
---------
Tom Nicholson
anozireth@telefragged.com

Andrezj Lach
dupeq@

Justin Sherfey
angelord@telefragged.com

Hunter Rognstad
hunter@telefragged.com


Be on alert for more great Mods by
	 __ __               ________
the/ // /_ _____ ___ __/__  ___/  __  __ _
  / _  / // / _ Y -_) __// // -_)'_ `/  ' \
 /_//_/\_, / .__/__/_/  /_/ \__/\_,_/_/_/ /
		/___/_/                          /_/
