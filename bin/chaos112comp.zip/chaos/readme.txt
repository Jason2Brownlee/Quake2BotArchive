
 -= CHAOS DEATHMATCH v1.11 for Quake 2 =-
 =======================================

  To read our enhanced HTML documentation
 go to the DOCS subdirectory and
 double-click on the file index.htm !
 We RECOMMEND to read it before you start 
 ChaosDM the first time!

 For updates/suggestions/help visit us at:
 http://www.planetquake.com/chaotic

 NOTE: Chaos Deathmatch v1.11 requires Quake2 v3.19 or higher


 Chaos Deathmatch v1.11 is Copyright (C) 1998 by Chaotic Dreams
 -------------------------------------------------------------

 Chaotic Dreams
 --------------
 Programming:     Matthias 'Flash' Elter (flash@planetquake.com)
 Arts and Sound:  Stefan 'SPA' Spatz (spa@planetquake.com)
 Level Design:	 Nathanial N 'Kill me Bitch' Pokropowicz (nnp@greennet.net)

  Many thanks to Craig Redinger (car188@psu.edu)
 for chaosdm1.bsp - Jailhouse Frag for Chaos DM !!!
 You can find his copyright note in the file chaosdm1.txt in
 the maps subdirectory.

 Special thanks to Matthew D Hirsch (mh83+@andrew.cmu.edu) for running the 'official'
 Chaos Deathmatch Server Kadath (128.2.98.20)! If you want to play Chaos DM online
 Kadath should be your first adress because Matthew always runs the new versions and
 non public beta releases we sent him.

 The other maps enclosed are solely for use with Chaos Deathmatch
 the maps included are:

 chaosdm2.bsp - Cirith Minor
 chaosdm3.bsp - Cirith Major
 chaosdm4.bsp - Jump
 chaosdm5.bsp - Personal Vendetta
 chaosdm6.bsp - Manufracture 1 on 1

  All map (chaosdm2 - 6) where created in the year 1998 Copyright (C)
 by NATHANIAL N POKROPOWICZ NNP@GREENNET.NET.
 These maps may only be distributed in the Quake 2 addon pac EXTREMITIES.
 Or on the internet for free,for use in Chaos Deathmatch.
 These maps may not be altered in any way.

 All maps (chaosdm2-6) where created with the program WORLD CRAFT 1.6A


DISCLAIMER
==========

THE SOFTWARE, INFORMATION AND DOCUMENTATION IS PROVIDED "AS IS"
WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED.
IN NO EVENT THE AUTHORS (flash@planetquake.com, spa@planetquake.com
and nnp@greennet.net) SHALL BE LIABLE FOR ANY DAMAGES WHATSOEVER INCLUDING DIRECT,
INDIRECT, INCIDENTAL, CONSEQUENTIAL, LOSS OF BUSINESS PROFITS OR SPECIAL DAMAGES,
EVEN IF THE AUTHORS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
THIS INCLUDE, BUT NOT LIMITED TO MERCHANTIBILITY AND FITNESS FOR A 
PARTICULAR FUNCTION. THE ENTIRE RISK RELATED TO THE SOFTWARE PERFORMANCE 
OR QUALITY IS ASSUMED BY THE USER. SOME JURISDICTIONS DO NOT ALLOW 
EXCLUSIONS OF IMPLIED WARRANTIES, THEREFORE THE ABOVE EXCLUSIONS MAY NOT 
APPLY TO YOU.  REVERSE ENGINEER (DECOMPILE) OR DISASSEMBLE OF THIS 
SOFTWARE IS PROHIBITED.IT IS PROHIBITED TO ADD ANY OTHER COPYRIGHT 
INFORMATION (E.G. WITH BBS-ADDS) THEN LISTED EITHER IN THIS LICENSE OR 
WITHIN THE SOFTWARE.THE ARCHIVE AND THE SOFTWARE MAY BE FREELY 
DISTRIBUTED PROVIDED THAT IT IS NOT MODIFIED IN ANY FORM AND THE 
ORIGINAL ARCHIVE REMAINS INTACT WITH ALL FILES.

ALL RIGHTS RESERVED BY THE AUTHORS 
(LISTED EITHER IN THIS LICENSE OR WITHIN THE SOFTWARE).

ALL BRAND NAMES AND PRODUCT NAMES USED ARE TRADEMARKS OR TRADE NAMES 
OF THEIR RESPECTIVE HOLDERS. IF YOU DO NOT AGREE WITH THE TERMS OF 
THIS LICENSE YOU HAVE TO REMOVE THE SOFTWARE FROM YOUR STORAGE DEVICES 
AND DO NOT USE THE SOFTWARE.

Chaotic Dreams 1998
