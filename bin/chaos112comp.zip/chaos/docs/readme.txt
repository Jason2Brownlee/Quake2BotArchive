    -= CHAOS DEATHMATCH ONLINE MANUAL =-

Double-click on the INDEX.HTM to start it!
