Coloured/Teamplay Skin Pack
===========================

Description
-----------
This zip contains 10 different coloured skins for both the male and
female Quake 2 models.

I made this skin pack specifically, though not exclusively, for
teamplay with Ridah's most sexy Eraser bots (http://impact.frag.com)
as I didn't much like the skins that came with the Eraser.

Installation
------------
Simply unzip the files to your baseq2/players directory (making sure
you use folder names).
To use them with Erasers simply edit your bots.cfg so the
teams (and/or bots) use the colours you think look best.

Credit
------
I'm in no way taking credit for the skins themselves.
They are essentially just the Blue CTF skins by id. I changed the heads
to other heads by id that I thought looked better, recoloured them with
Paint Shop Pro 4.14, and used NST and jawMD2 to tidy them up.

However since I did put them together, if you are going to distribute
them on a CD or such, mail me first. If you are an Actura Software
type person, feel free to disembowel yourself.

By Grimlock
-----------
grimlock@one.net.au

http://www2.one.net.au/~grimlock/Q2skins.htm for more id-based skins
(truly original ones soon).

