Quake 2 Basketball
Version 0.94
--------------------------------------------------------------

Title:		Quake 2 Basketball

Author:		Matt Shade

Email:		shade@planetquake.com

Webpage:	http://www.planetquake.com/bball

Details:	Quake 2 Basketball is a partial conversion for 
		Quake 2. It changes Quake 2 to a basketball
		type game.

--------------------------------------------------------------

New Models:	Yes
New Sounds:	Yes
New Graphics:	Yes
New Code:	Yes

--------------------------------------------------------------

Instructions:

1) Download the .zip file and place it in quake2\bball\ directory
2) Unzip the file in the quake\bball\ directory
3) Go to the Quake 2 directory and type:

	quake2.exe +set game bball

4) In the console type "map q2bball1" to begin single player
   OR
   In the console type "exec server.cfg" for a multiplayer game
   OR
   In the console type "exec weapons.cfg" for a multiplayer game
   with weapons
   OR
   In the console type "exec bots.cfg" for a bot game

**Note:
	Quake 2 Basketball requires that you have visual weapons
	turned on.  You must have cl_vwep set to 1, or you will
	get many error messages.  If you don't have the visual
	weapons pack yet, you should really get it anyway.

--------------------------------------------------------------

Game Play

Quake 2 Basketball currently has many different variations of play.
The main differences are autoshoot on or off, and weapons on or off.
Here is an explanation:

AUTOSHOOT: Autoshoot sets how the player shoots.  It is set in the
	Deathmatch Flags for multiplayer games.  For single player,
	type "autoshoot" in the console to toggle it off or on. In
	more detail:

	Autoshoot OFF:
	This mode is based more on precision shooting than
	quick action.  In this mode, when you shoot you control not 
	only the alignment of your shot but the distance it will
	travel.  By holding down the attack button, a power meter
	will appear in the bottom center of the screen.  Letting go
	of the attack button shoots the ball with the displayed
	power, between 0 and 100.  Once the meter reaches 100 the
	ball will automatically be shot with full power.  Autoshoot
	OFF is ideally used with only a few players or when shooting
	by ones self. It is much more difficult than Autoshoot ON.

	Autoshoot ON:
	This mode is based more on an arcade type basketball game.
	The player does not have to aim his shot at all, only press
	the attack button to shoot.  In this mode, the closer you
	are to the basket the better your chance of scoring.  Longer
	shots, like three pointers, will only go in some of the time,
	much like a basketball video game.  This mode is for when
	there are a lot of players, or when you just don't feel like
	having to aim.  Initially, this will be much easier than
	having Autoshoot OFF.  You can set how hard it is to score
	with the difficulty setting.

WEAPONS: Quake 2 Basketball can be played with weapons on or off.
	For that real basketball feel, leave them off.  If you
	just can't playe Quake 2 without killing people, turn them
	on.  They are set in Deathmatch Flags for multiplayer
	games.  Weapons on or off in single player doesn't really
	make a difference.
	When using weapons, pressing 1 will toggle between the
	basketball Hands and the Blaster.

BOTS:	Bots are included in Quake 2 Basketball. They can be used
	by a single player by himself, or to fill in the teams 
	for multiplayer games. For info on how to use the bots,
	check out the bots section further down the page.


--------------------------------------------------------------------
Controls

The following are additional controls added to Quake 2 Basketball.
These controls should be bound to a key for easy use. All normal
Quake 2 controls are still there.

pass - 	The pass command will, hence the name, pass the ball.  It is
	different from plain shooting in that it fires the ball with
	one button tap in a straight line and good speed.  It works
	if autoshoot is on or off.

jumpball - The jumpball command can only be used once the players are
	prompted to call jumpball on the screen.  This command is
	implemented for the occasion in which the ball gets stuck
	someplace out of reach of the player.  After the ball is
	stationary for about 7 seconds, players will be prompted to
	call jumpball.  Possession alternates between the two teams.

team - 	The team command switches teams just like CTF.  Type team red
	or team blue to switch teams, or you can use the server
	specified team names to switch.

chasecam - This command toggles between chasecam on and off. Chasecam
	primarily should be used during gamemode 2, as it is hard to
	aim in gamemode 1 if the chasecam is on.  The chasecam has
	potential problems in multiplayer, so it should be used at
	your own risk until I can totally fix it.

They following commands are all chasecam related.  These commands are
not at all necessary in the game, but give more options to the
chasecam:

camviewlock - toggles the camera viewlock on or off.  This lets the
	camera rotate around the player as he is stationary. Neat
	to look at, but not all that useful.

camzoomout - zooms the camera out

camzoomin - zooms the camera in

camreset - use this command if you were messing around with the
	camviewlock and are now disoriented.  It puts the camera
	back in it's original position.

**The zip file came with an autoexec.cfg file.  This file will
  bind the keys as follows:

  / = pass (Right Mouse Button also passes)
  j = jumpball
  k = chasecam

  i = camviewlock
  l = camzoomout
  o = camzoomini
  u = camreset

  If you don't like this configuration, or would like to use your
  own autoexec.cfg, delete the one that came with it and set things
  up according to your own taste.

-------------------------------
The following variables are changeable in the console:

scorelimit - Sets the score limit for a game.  When the scorelimit
	is hit, the game is over.  Much like fraglimit in deathmatch.
	Set to 0 for no scorelimit.
	Possible Values: 0 through any positive integer
	Default: 0

difficulty - Sets how easy it is to score in gamemode 2. 0 makes you
	score the easiest, or most often, and 10 makes it the hardest
	to score. Can be any value between 0 and 10.
	Possible Values: 0 to 10
	Default: 0

forcejoin - Server automatically assigns a new player to the
	specified team.  The player can only join that team. The
	server can set this to Red or Blue, or to the new team1name
	or team2name.
	Possible Values: Red, Blue, or the team1name or team2name
	Default: ""

team1name - Assigns the team name.  This name shows up on the player
	selection menu, and throughout the game as the players are
	sent messages about scoring and other actions.
	Possible Values: Any characters
	Default: Red Team
team2name - Same as team1name, but for the other team.
	Possible Values: Any characters
	Default: Blue Team

d_bball - This setting isn't actually intended for use.  It was used
	by me during development. It has little purpose now, but if
	you really want, you can set it to 1 and check it out.  It
	currently does only two things. One thing it now does is to
	start the jumpball no matter what the conditions are.  The
	other thing it does is give extended information on your shot
	when in gamemode 2. Not real useful to most people, but it's
	there if you just have to see it.
	Possible Values: 0 or 1
	Default: 0

----------------------------------------------------------------------
Deathmatch Flags

The deathmatch flags control a lot of server changeable options in
the game.  You can set these flags in the included file, server.cfg
This file shows how to make the changes, it is a lot like the CTF
server.cfg file, if you are familiar with that.

Here is a brief description of each new flag, with its value:

DF_NOWEAPONS 131072 - removes weapons from the game
DF_NO_DUNKS  262144 - prohibits dunking
DF_AUTOSHOOT 524288 - makes shooting simple, no aiming required
DF_FORCEJOIN 1048576 - players automatically assigned to even teams
DF_ARMOR_PROTECT 2097152 - don't lose armor from teammate's attacks
DF_KEEP_IN_COURT 4194304 - anyone with the ball leaving the court
			   area is automatically killed
DF_EVEN_JUMPBALL 8388608 - jumpball doesn't start until there is at
			   least one player from each team

To make things easy, I've included two files, server.cfg and
weapons.cfg.  If you don't want to mess with the Deathmatch Flags,
then do this:

For playing without weapons: Type "exec server.cfg" in the console

For playing with weapons: Type "exec weapons.cfg" in the console

If you want to make more exact changes, you'll have to edit the
server.cfg file.

----------------------------------------------------------------------
Bots

Quake 2 Basketball includes the ability to spawn bots to play against. 
The bots are intended to be used by a single player, but can be used
in multiplayer games if desired. It is still necessary to set 
"deathmatch" to "1" in the console anytime you are using bots. The
bots can be spawned on either your own team, or the other team. If
you find the following confusing, don't worry. I've included a
configuration file for bots, so all you have to do is type
"exec bots.cfg" in the console to start a 3-on-3 bot game.

Bot Commands
------------

The following commands are used to control the bots, and can be
entered in the console. Notice that they are server commands, so
people joining a multiplayer server can not issue these commands.

sv bot <team> [<number>]
where <team> is the team for the bot to go on, and <number> is an
optional command for the number of bots to spawn on that team. For
example:
sv bot red
will spawn a bot on the red team
sv bot blue 3
will spawn three bots on the blue team

sv killbot <team> [<number>]
where <team> is the team for the bot to be removed from, and <number>
is an optional command for the number of bots to remove from that
team. For example:
sv killbot red
will remove a bot from the red team
sv killbot blue 3
will remove three bots from the blue team

fixteamsize <size>
where <size> is the number of players you want on each team.  This is
a variable that can be set so that the bots will fill in empty spots
as players enter and leave the game. So if you set "fixteamsize 4"
then if only two real players are in the game on the blue team, then
two bots will be added to the blue team, and four to the red team, so
that each team has a total of four players.  If one of the real
players were to leave, a blue bot would be added to keep four on each
team.

Additional Info
---------------

Passing
You can make a bot on your team pass to you just by pressing your
"pass" key, as if you were passing the ball yourself. The bot will
pass to you if you are open, but if he thinks the pass will be
intercepted he will refuse. Move to make an open passing lane if he
won't pass to you.

Weapons
These bots were designed to play basketball, and not to kill. They
can not use weapons, and will not try to. They are intended for use
with the DF_NOWEAPONS flag set on. Those who wish to play with weapons
on, and to kill the helpless bots, may do so. But I think it's just
plain mean.

----------------------------------------------------------------------
Rules

Quake 2 Basketball follows the normal rules of basketball.  To begin
the game, a jumpball is dropped in the center circle.  Once the proper
requirements have been met (see Deathmatch Flags), the screen will
have a ten second count down for the jumpball, and then the ball will
be dropped.

Players get two points for all shots inside the three point line,
and three points for all shots outside their three point line.
After a team scores, a randomly selected player from the other team
will be teleported to the baseline with the ball to begin his teams
offense.

Any player that does not have the ball will see his empty hands in
front of him (when not in chasecam mode).  Players without the ball
can try to steal it from the player with the ball by pressing the
attack button.  Once the ball is shot or passed, that players hands
automatically become empty (makes sense doesn't it?).

You can dunk the ball by being close to the basket (close to
underneath the rim).  You must be under your own teams basket to 
dunk.  Also, no player from the other team can be close to you if
you want to dunk.

If you get killed, you drop the ball.  If the game is set so that
the player with the ball must remain in the court, then leaving
the court with the ball will kill that player.

If the ball gets stuck, players should call jumpball as described
in the controls section.  Anything else should be easy enough to
figure out once you actually start playing.

--------------------------------------------------------------------
Note for playing in single player

While Quake 2 Basketball is obviously a team game, you can still play
by yourself.  I encourage you to do this once you decide to download
Quake 2 Basketball, and unless someone sets up a server for it, then
it will be the only way some of you can play unless you have a lan.
So, when playing by yourself, you'll want to make sure you have
deathmatch set at 0.  Then just type map q2bball1 in the console to play.
You can still use all the settings, but some obviously have no effect.
If you want to check out how multiplayer is, then you can type
"exec server.cfg" or "exec weapons.cfg". You can then proceed in the
total enjoyment of playing a basketball game against yourself,
switching teams after every score if you want. What fun!

--------------------------------------------------------------------
To Begin

For single player:

Quake 2 Basketball isn't all that fun in single player, but anyway,
if "game" is set to "bball" then just type "map q2bball1" and shoot
away.

For multiplyer:

The server should bring down the console and type "exec server.cfg"
for the default or user defined settings.  The server can also type
"exec weapons.cfg" for weapons play. Simple isn't it?

--------------------------------------------------------------------
Credits

Quake 2 Basketball is made by Matt Shade.  All coding, modelling,
graphics, and one map were made by me.  Additional maps were made
by "S��zZ�". You can email me at shade@planetquake.com

I would also like to thank the following people:

  Gene "S��zZ�" Beaumont - Maps

  Anthony Hams - Linux port

  Stonelance - for his chasecam tutorial, which is the entire basis for
  the chasecam in Quake 2 Basketball

  All contributors to QDevels - I used many of their tutorials as
  important stepping stones throughout the process of making this
  Quake 2 Mod.

  Id Software - Of course, for making Quake 2 and letting us screw
  with it.
