ServObit 1.4 - Server Obituaries (Death Messages) for Quake II v3.14
====================================================================
Name: ServObit
Version: 1.4 (4/8/98)
Quake 2 version: v3.12-3.14
Author: SteQve, a mediocre Quake player (full name: Steve Christey)
Email: Steqve@shore.net
Web page: http://www.shore.net/~steqve/quakemods.html
Description: This mod allows you to configure your own Death Messages
    (Obituaries) for your server.  Obituaries can be selected based on
	weapon, quad/normal damage, the type of killer (Self, Enemy, or World),
	gender of the killer and/or victim, and whether a gib or "mega-gib"
	occurred.  You can have multiple messages per obituary selector; they
	will be generated randomly.  You can substitute killer and victim names
	into the message, insert pronouns specific to killer/victim gender, and
	substitute random words or phrases.  ServObit 1.4 also includes 
	GenderMod 0.1, which tries to determine a player's gender based on
	what model they are using.  It also has a Message of the Day capability,
	plus you can specify different messages to be generated when somebody
	connects to or disconnects from the game.
Credits: See "Credits" section below, but props to idsoftware, newtonD, EAVY,
		 Hawkeye, and Sati, a.k.a. "Queen of Death Messages."
============================================================================

********************************************
Table Of Contents
********************************************
1. Mod Information
2. How the Thing Works
3. Installation
4. Changes Since the Last Version
5. GenderMod 0.1
6. Editing Obits.txt
7. Editing ServObit.ini
8. Text Substitutions
9. Obituary Substitutions (Groups)
10. Message of the Day and Connect/Disconnect Messages
11. Obituary Selectors
12. Formatting Obituary Messages
13. You can have bugs, too
14. ServObit Obituary Test Program - Checking Your Obits.txt
15. Running the Test Program
16. Known bugs
17. Credits
18. Distribution and Modification
10. Obligatory Scribble Music Coalition Quote


********************************************
Mod Information
********************************************

* Play Information *
Single Player           : No
Deathmatch (2-16)       : Yes
New Sounds              : No
New Graphics            : No
New Music               : No 

* Construction *
Base                    : gamex86.dll
Editor(s) used          : Microsoft Visual C++ 4.0
Known Bugs              : None.
Build Time              : Sorry, I don't know what that is.  Wait a second,
                          you mean when I press the F7 key?  Oh, a few 
                          minutes on a Dell P200 with 32M RAM.

Modification Details	: upon request
Files modified          : upon request
Source included         : upon request

********************************************
How The Thing Works
********************************************

You edit the file Obits.txt to configure your Obituaries.  You start your 
server.  ServObit reads the Obits.txt file and sets things up internally.
It also prints out "debugging" information to debug.txt, and it will complain
if you don't enter an Obituary or other data in a way that it needs you to.
People log on to your server; they get your Message of the Day, then their 
presence is announced to the other gib-hungry clients.  The GenderMod
part of ServObit kicks in and tries to determins the player's gender based
on the model they are using.  People fight and then somebody dies, hopefully
in a particularly gruesome fashion for which you have composed the perfect
Obituary.  The server goes through the Obituaries in the order they appear in
Obits.txt, until it finds one that matches based on who did the killing, what
powerups they may have had, what weapon was used, the gender of the killer and
the victim, and whether a gib (or mega-gib) occurred or not.  ServObit then
substitutes killer (and victim) name into your Obituary, as well as some
gender-specific pronouns, and randomly inserts other phrases which you have
defined.  The mayhem ensues as people die and Obituaries are strewn across
the screen.  Eventually somebody gets sick or tired or bothered by the boss
and they leave.  The remaining players receive a random message which sadly
informs them that they have one less person to frag.  The server continues in
this fashion until you stop it or some unknown bug causes it to die a horrible
death.  This latter part is unplanned, but hey, this is software and it runs
on PCs.

********************************************
Installation
********************************************

*** FOLLOW THESE DIRECTIONS CLOSELY.  THEY HAVE CHANGED FROM PREVIOUS 
    VERSIONS ***

1) If you installed earlier versions of ServObit:
   - rename your ServObit directory to something else, or delete it.
   - BACK UP YOUR OLD OBITS.TXT IF YOU CHANGED IT!!

2) Unzip the zip file into your Quake directory.  It will create a ServObit
   directory and a GenderMod directory.  You should have gamex86.dll,
   Obits.txt and other files in your ServObit directory, and ModelGen.dat
   in your GenderMod directory.

3) Edit the Obits.txt file if you want to change ServObit's default
   obituaries and message of the day.  See "Editing Obits.txt" below.
   NOTE: You can use your old Obits.txt if you wish, but you will be missing
   several new death situtations, and you won't be using some of the nice
   new features of ServObit 1.4.  If you have a ServObit 1.0 Obits.txt, 
   you might as well start from scratch.

4) If you changed your Obits.txt, run sotest.exe in your ServObit directory.
   It will "test" your obits for you (this is only necessary if you changed
   Obits.txt).  See the "Running the Test Program" section.

5) Run Quake2 with the command line "quake2 +set game ServObit".   Watch the
   ServObit banner and make sure it doesn't complain about any errors; see
   SrvObLog.txt if it complains.

6) Whenever you add new messages to Obits.txt, they will be reloaded
   when the next level changes.

7) Update the GenderMod/ModelGen.dat file to include the genders of new
   models as they come out.  An "official" ModelGen.dat will be made available
   via the WWW.

********************************************
Changes since last version
********************************************

1) GenderMod 0.1, which tries to address the problem of accurately
reflecting the gender of plugin player models.  Finally, the Crack
Whore can be referred to as "she", and the Snork as "it"!

2) Introduction of a "neuter" gender for models such as the Snork or
tentacle

3) Random substitution of words and phrases into individual death
messages

4) Definition of groups of death messages that can be used to apply to
multiple situations

5) All the different death situations that were in idsoftware's
original 3.14 source code

6) A separate test program to make sure you have identified all
possible obituary outcomes.  No more "generic" death messages because
you forgot to account for a neuter gibbing a female with shrapnel from
a Quad hand grenade.

7) The message of the day can include green text (finally!) and be
quickly disabled by the user.

8) Operator-settable limits on the number of death messages, connect
messages, etc.; no more restrictions by ServObit itself.

9) Fixed a bug in which mega-gibs were not properly identified.

********************************************
GenderMod 0.1
********************************************

GenderMod 0.1 tries to address the problem of accurately identifying the
gender of plugin player models.  It is hoped that some of its solutions
become part of a standard approach that is common across all mods.

The client can specify their own sex by setting the "sex" variable in their
userinfo string (the userinfo also sends information such as the player's 
name and skin).  In their console, they can type:

	set sex m u  --> sets gender to male
	set sex f u  --> sets gender to female
	set sex n u  --> sets gender to neuter

The client's specification is a PROPOSED value.  GenderMod can override this
value if it can verify that the specified gender is inconsistent with the
model used by the player.

The user can use a "gender me" command to find out what GenderMod is using
internally for that user's gender, regardless of what their "sex" variable is.

To see what genders have been applied to what players by GenderMod, use the
"gender players" command.

GenderMod uses the file GenderMod/ModelGen.dat to list model names and their
associated genders ([M]ale, [F]emale, [N]euter).  When the userinfo string
is sent to the server (e.g. when the user changes their skin), GenderMod
checks for the "sex" value, gets the model, and looks through the map for a 
match.  If a match is found and the model is male or female, then that gender
is enforced.  If the match is neuter, or the map doesn't identify the
model, then the user's "sex" variable is used.  Thus users of neuter models 
can set their gender as they wish, or they can do so if GenderMod doesn't know
about their model.  If no sex variable is available, then idsoftware's original
logic applies - if the model name starts with "f", then it is treated as female,
otherwise it is treated as male.

As mentioned, in cases where the model has a male or female gender, the player
can NOT switch to the other gender.  This isn't perfect (e.g. when someone
uses a female skin on a male model), but the idea is to make the gender of
the player as consistent with the model as possible.  (OK, so even with a
female model and an unknown skin the client displays the grunt, but the
*idea* is sound and I cross my fingers daily that idsoftware will let the
client display a female model if it doesn't have a female skin.)

Once the gender has been identified (or "approved"), it is stored in the
client_respawn_t part of the client's edict for speed of lookup.


********************************************
Editing Obits.txt
********************************************

Obits.txt is where all the action happens.  ServObit reads this file when it
starts.  It also reads the file each time a level changes, just in case you
changed it in the meantime.  (If you get into a Bug vs. Feature vs. Lazy
Programmer argument about why it does this, you should argue the Lazy
Programmer perspective.)

Comments and Blank Lines
------------------------
Any line that begins with a # is a comment.  You can write whatever you 
want after that #.  This tells the computer that it's too stupid to 
understand what you're trying to say and it should just ignore you,
kind of like pretending not to hear a conversation in Mandarin Chinese.

Blank lines are nice ways to space things out.  ServObit also ignores them.

********************************************
Editing ServObit.ini
********************************************

OK, it's time to admit it.  ServObit 1.4 isn't written "perfectly".  It uses
more memory than it could (but it's not a lot).  It was easier to code
this way, but it will be fixed in a future version.  In the meantime, you can
work around my laziness a little bit by editing the ServObit.ini file if
necessary.

DO NOT EDIT THIS FILE UNTIL YOU UNDERSTAND HOW SERVOBIT WORKS.  THE ONLY
REASON THIS FILE IS MENTIONED NOW IS THAT YOU COULD MISS IT LATER ON :-)

MaxSelectors and MaxObitMessages will consume memory than the other 
options if you set them too high, so watch them carefully.

a) MaxConnectMessages=20

Maximum number of different connect messages (or disconnect messages).

b) MaxSelectors=1000

If you go to town on the selectors by trying to identify ALL possible
situations, you might run out of available selectors, so you may need to
bump this value up a bit.

c) MaxObitMessages=20

This is the maximum number of messages per selector, including the 
obit groups (but not including all the possible text substitution
combinations).  This is also the maximum number of phrases allowed
per substitution.

Keep this number as low as possible because it can eat memory if you set
it too high.

d) MaxSubstitutions=50

This is the maximum number of substitution definitions (for text
substitutions and obituary group substitutions combined).  Bump this number
up if you go overboard and define loads of substitutions.


********************************************
Text Substitutions
********************************************

Suppose you want to refer to a grenade as a "pineapple" or a "grenade"
or a "fried green tomato."  You can define a text substitution to have
ServObit randomly insert one of these terms into your obituary.  So
you can generate a wider variety of death messages.

You can define as many text substitusions as you want.  However, if you
make more than 50 different substitutions, you will have to set the
MaxSubstitutions variable in your ServObit.ini file.

To define text substitutions in your Obits.txt, make sure you are in
the substitutions section, which starts with

:SUBSTITUTIONS

For each substitution, assign it a unique name, enclosed in brackets.
Then list the different pieces of text you want to substitute.  For
example:

[waskilled]
was eliminated
was rubbed out
was killed
was wiped out
was erased

[rocket]
rocket
missile
fuel-laden phallic symbol
rocket o' love

[grenade]
pineapple
little bomb
grenade
clunky cylinder o' death
fried green tomato

Once you have defined all your different substitutions, mark them with

:END


In your obituary section (see "Formatting Obituaries"), you can then
refer to your substitutions by enclosing the name of the substitution
in % marks.  See the following examples, where $K is the name of the
killer and $V is the name of the victim.

$K tossed a %grenade% into $V's lap
$V %waskilled% by $K's %rocket%

Using these substitutions, you could generate obituaries such as
"Killer tossed a pineapple into Victim's lap", "Victim was erased by
Killer's rocket," "Victim was wiped out by Killer's fuel-laden phallic
symbol," etc.

Your text substitutions can also include the $ "situation"
substitutions such as $K or $V, e.g.:

[killers_rocket]
$K's %rocket%
a rocket with $K's name on it


********************************************
Obituary Substitutions (Groups)
********************************************

Not only can you define simple text substitutions, but you can define
entier groups of obituaries that you can then apply to a wide variety
of situations.  This is most helpful when you want to reuse the same
death messages in a number of slightly different situations.  For
example, you might have a set of obituaries that apply to all Quad
rocket deaths, but you also want to include some obits that only apply
to a particular gender.  You could use an obituary group to define the
rocket obits that are common to all genders.

You define obituary substitutions in the same way you define text
substitutions.  Start with the substitutions header, define your obituary
groups, then conclude with the :END marker:

:SUBSTITUTIONS

[rocket_obit]
$V rode $K's %rocket%
$K feeds $V $HISK %rocket%
$V flew $K's %rocket% to the moon

[grenade_obit]
$K popped $V with $HISK grenade
$V stepped on $K's %grenade%
"Pineapples!" shouted $K to $V, "Get your fresh pineapples here!"

:END


When you want to include an obituary group for a particular situation,
list it after the selector for that particular situation, e.g.:

# Male kills female with Quad rocket:
: E ROCKET_LAUNCHER QUAD MALE FEMALE *
[rocket_obit]
$V asks $K, "Is that a rocket in your pocket, or are you...?"

# Female kills male with Quad rocket:
: E ROCKET_LAUNCHER QUAD FEMALE MALE *
[rocket_obit]
$K shows $V that she has a bigger rocket than he does

See "Formatting Obituaries" for details on what "$" terms you can use.


********************************************
Message of the Day and Connect/Disconnect Messages
********************************************

Message of the Day (Welcome Message)
------------------------------------

The Welcome message is displayed to the client when they first sign on.

You can specify how long to display your message, from 2 to 999 seconds.  
Players can disable the message by pressing F1 or TAB (i.e. by showing the
scoreboard or inventory).

- To start entering your welcome message, put a line that says   :WELCOME <NUMBER>
  where <NUMBER> is a number (the default is 5; the number given in Obits.txt
  is 8).  For example, :WELCOME 10  would print the message for 10 seconds.
- enter multiple lines of text for your message, if you wish.
- to insert a blank line, you *must* put a space in that line.
- to insert the client's name into the message, use $N
- you can insert text substitutions if you wish
- you cannot use substitutions in the
- mark the end of the message with   :END

Connect Messages
----------------

You can set up to 20 different messages that get displayed when the client
first joins the game.

- To start your list of Connect messages, put a line that says   :CONNECT
- each line you enter will become a randomly selected Connect message
- use $N to insert the client's name
- use $HIS for his/her, $HIM for him/her, $SHE for he/she, and $HERSELF
  for himself/herself/itself
- you can insert text substitutions if you wish
- mark the end of the message list with  :END

Disconnect Messages
-------------------

Just like Connect messages, you can set up 20 different messages
- Start the list with    :DISCONNECT
- enter the messages the same way you do the Connect messages
- you can insert text substitutions if you wish
- mark the end of the message list with  :END


********************************************
Obituary Selectors
********************************************

Obituary selectors are used to decide which set of Obituary messages matches
the given death situation.  You describe death situations with the 
following characteristics:
	- whether the person killed him/herself, whether another player killed 
	  them, or whether the world killed them
	- what type of weapon was used
	- whether Quad damage was active or not
	- the gender of the killer
	- the gender of the victim
	- how badly damaged the victim's body is (gib, mega-gib, or "normal")

Each Obituary selector line of the file is of the form:

: KillerType WeaponType PowerType KillerGender VictimGender BodyState

You can use wildcards (*) to match anything of a particular type.  For example,
if you don't care about gender in a situation where a blaster is being used,
you can put a * in the KillerGender and VictimGender spaces.

When ServObit looks through the Obituary selectors, it will use the first
selector that matches the situation.  For this reason, you should be
very careful about the order in which you list the Obituaries, since
the server will pick the first one that matches.

KillerType can be: ENEMY [E], SELF [S], WORLD [W], * (anything)

WeaponType can be specified using a full name or at least its given 
abbreviation: 
  * (anything), [BL]ASTER, [SH]OTGUN, [SUP]ERSHOTGUN,
  [M]ACHINEGUN, [C]HAINGUN, [GR]ENADE_LAUNCHER, [G_]RENADE_SPLASH,
  [HA]ND_GRENADE, [HG_S]PLASH, [HG_H]ELD, [R_]SPLASH, [RO]CKET_LAUNCHER,
  [RA]ILGUN, [HY]PERBLASTER, [BFG_B]LAST, [BFG_L]ASER, [BFG_E]FFECT,
  [TE]LEFRAG, [SUI]CIDE

The world has its own WeaponTypes: [LAV]A, SLIME [SL], WATER [WA], 
  SQUISH [SQ], FALL [F], TOUCH [TO], [LAS]ER, [EX]IT

You can specify any non-environmental weapon with WEAPON [WE].
You can specify environmental weapons with ENVIRONMENT [E]

PowerType can be: N (normal), Q (quad), * (anything)

KillerGender and Victim Gender can be: MALE [M], FEMALE [F], [N]euter, 
     and * (anything)

BodyState can be: GIB [G], MEGAGIB[M], and NORMAL [N].  MegaGib is a new term
  I made up that describes when a player's health goes below -80.  It has no
  meaning in the Quake II engine, but it can be used to identify just how badly
  a player was burned by that Quad BFG ;-)  ServObit handles matching of gibs
  differently than other characteristics.  The BodyState specifier can be 
  interpreted as saying "make sure the body state is at least THIS bad."
  Thus, a MegaGib situation will match a Gib specifier, and a Gib will
  match a Normal specifier, but a Normal situation will not match a MegaGib.
  You will see examples of how this is used in Obits.txt.

For example,

: E ROCKET QUAD * MALE GIB

specifies a situation where a male player is gibbed by another player's
quad rocket.

********************************************
Formatting Obituary messages
********************************************
 
Once you have entered a selector, you can list up to 20 messages which will
be randomly generated when that selector matches the death situation.
Each message must be on a single line.

You can insert information about the situation into the random message.  
You specify where this information is to be placed by using a $ followed
by a special command.

For each message, you can use any combination of the following:

$V = Victim's name
$K = Killer's name
$HISK = his/her/it for Killer's gender
$HISV = his/her/it for Victim's gender
$SHEK = she/he/it for Killer's gender
$SHEV = she/he/it for Victim's gender
$HIMK = him/her/it for Killer's gender
$HIMV = him/her/it for Victim's gender
$HERSELFK = himself/herself/itself for Killer's gender
$HERSELFV = himself/herself/itself for Victim's gender
$G says "destroyed", "gibbed", or "mega-gibbed" depending on body state
$Q says "Quad " if Quad, or nothing if there is no Quad

$G and $Q are useful if you want to have basically the same messages for gib
and megagib situations, or for Quad or normal situations.  It helps reduce
having to put duplicate entries under multiple selectors.

*******************************
You can have bugs, too
*******************************

[This is not a personal hygiene commercial.]

WARNING: Just because this isn't programming, you can still have "bugs."
Be careful with the order in which you list selectors - you might match
an obituary earlier than you intend to.  This applies to any use of 
wildcards.  The file ServObit/debug.txt is created each time you start 
the server.  This can help you find mistakes you may have made.  A test
program is included with the source code so you can make sure the selectors
behave like you expect.

At the end of each main section, use wildcards to catch anything that might
accidentally slip through (or, perhaps, anything that ServObit doesn't 
recognize, which may be possible in extremely rare situations)

Also, run the Obituary Test Program (SOTest.exe) whenever you make a change.

*******************************
ServObit Obituary Test Program - Checking Your Obits.txt
*******************************

ServObit's flexibility comes at a small price.  Because of the wide
variety of different death situations and complexity of the selectors,
you can sometimes miss writing a selector for a specific situation,
especially if you want to write different messages for a lot of very
specific situations.

Whenever ServObit loads obituaries (i.e. on every level change), it
checks for some of these errors, but it doesn't check for all of them,
as some errors take a long time to find, or it is up to you to
determine whether they are really wrong or not (for example, was it
your intention to ignore a situation where a neuter gibs another
neuter with a rocket, and only use a generic rocket message?)
ServObit allows you to define very generic messages (e.g. "Killer
killed Victim") that can be used as a default, but in general you
probably want to have as specific a message as possible.

The ServObit tester runs through all possible death situations (or, a
limited set of them) and generates death messages as if those deaths
had happened in the game.  It also checks the format of Obits.txt to
see if you made any mistakes that could cause problems.  It dumps all
of this information into a SrvObTst.txt file which you can then use to
correct any errors that it displays.

These are some of the specific errors it can catch:

- if you misspell the name of a substitution (so ServObit wouldn't
know what substitutions to use for a death message, which could cause
a sort of ugly death message to be printed out, since it would still
have the %SUBSTITUTION% in it)

- in other cases you might misspell something in your selector, which
will cause ServObit to not be able to process the selector properly.
For example, saying RCOKET instead of ROCKET.

- if you misspell the name of a $ substitution (e.g. $HISSK or
$HERELF)

These are simple errors that it can catch.  

However, when selecting which death messages to apply to which
situation, it can't be certain what your intention is, and it's up to
you to determine if it's really wrong or not.

The SOTEST.EXE program is provided with ServObit to help you test your
changes and make sure you haven't made any of these mistakes.  (OK,
we'll be fair here, it's possible that ServObit could make a mistake,
too ;-)


*******************************
Running the Test Program
*******************************

You must run the SOTest.EXE program in your ServObit directory.  It
will write its results to a SrvObTst.txt log file.  Then look at the
file, taking care of the errors that it prints out, and looking
through the obituaries it generates to make sure they are set up 
properly.

It is suggested that you run the program in an MS-DOS window so you
can see any output it provides.

Here are the different arguments you can supply to SOTest.exe:

	kgen=ARG - do obits for gender of killer where ARG is [M]ale,
	           [F]emale, [N]euter, or [A]ll)

	vgen=ARG - do obits for gender of killer where ARG is [M]ale,
	           [F]emale, [N]euter, or [A]ll)

	power=ARG - do obits for [Q]uad, [N]ormal, or [A]ll

	bstate=ARG - do obits for [N]ormal, [G]ib, [M]ega-gib, or [A]ll

	killertype=ARG - if ARG is ALL, it checks all Enemy/Self/World
	       situations; if ARG=E it checks all Enemy deaths, if ARG=S
	       it checks all Self deaths, if ARG=W it checks all world
	       deaths

	weapon=ARG - if ARG is *, do all possible weapon
               combinations; otherwise, use a weapon name (using the
               same naming convention as in Obits.txt)

	repeats=NUMBER - generate NUMBER messages for each death
	       situation (the default is 3).  You might want to use a high number
		   of repeats to test how your text substitutions look.

	all - do all possible combinations of weapon, kgen/vgen, etc.
	
	none - don't do any combinations; just check the Obits.txt
	       for simple errors and print connect/disconnect messages


You should occasionally use SOTest.exe with the "all" option, as that
is the only way you can be certain that ServObit will print out the
right obituaries for each possible situation.  HOWEVER, the
SrvObTst.txt file can generate a large file, 100K or greater.

In cases where you are SURE you only made minor changes - e.g., you
only changed obits in the hand grenade section - you can use the
specific arguments to SOTest.exe to limit the situations you look at.


Some Sample Uses of the Obituary Test Program
---------------------------------------------

1) Do all combinations:

	SOTest.exe all

2) Do obituaries for all hand grenade situations:

	SOTest.exe weapon=HAND_GRENADE

3) Do obituaries for all cases where female kills male:

	SOTest.exe kgen=F vgen=M

4) Check the Obits.txt for parse errors:

	SOTest.exe none

5) Check all suicides:

	SOTest.exe killertype=Self

6) Generate 10 messages for each rocket situation (you might do this
to check out a new substitution you created):

	SOTest.exe weapon=ROCKET_LAUNCHER messages=10

*******************************
Known Bugs
*******************************

If you've occasionally shot a BFG, killed yourself, and seen a death message
that says you fell, that's a known bug (or is that a feature?).  This is in
the original id software source code.  Try it - aim your BFG straight down
and let 'er rip.  You will fly, then you will fall.  This may not be a bug,
because it could be that it's not the BFG that's killing you, but rather the
long way down ;-)

*******************************
Credits
*******************************

Thanks to idsoftware for making Quake and Quake II so fun and so 
extensible - natch.

Some of the death messages in the Obits.txt were written by Druid [aka 
Scott Franke] of druid-'s GL Journal - http://www-scf.usc.edu/~sfranke/glj
If you've seen them before and they're not id's, they're probably druid's.
James Abbatiello also had some cool death messages I included.
Others were written by Hawkeye or Sati, "Queen of Death Messages."  My own
messages are in there, too - I'm particularly fond of the "Quad Rocket
Express" addition and the female-specific drowning message "Player retains
too much water."

EAVY and I had some great email discussion on how to determine the
gender of models.  Some of his ideas are in GenderMod 0.1, plus he told
me how clients can set the "sex" userinfo variable.

Derek Westcott (!Eradicator!) gave me some very detailed feedback that helped
me fix one bug, and he found and fixed a second one.  These bug fixes
were implemented in ServObit 1.2.

NewtonD (newton@moongates.com) was also helpful on the technical and creative
side.  His ideas for including Connect/Disconnect messages, MOTD's, text
substitutions, and flexible gender pronouns in his own Death Message mod
influenced ServObit.

*******************************
Distribution and Modification
*******************************

This software is Copyright 1998 by SteQven M. Christey and may not be modified
for commercial purposes without express written consent of the author.

By using this software you agree not to hold me responsible for any damage,
direct or indirect, which may arise from its use.

Permission for free distribution of this software is granted to Internet 
sites and their affiliates whose sole or primary focus is Quake or Quake II.
Informally, this includes PlanetQuake.com, Telefragged.com, cdrom.com, etc.
It is the responsibility of any site to ensure that it qualifies for such
permission.

Distribution of this software by other sites and on media other than the 
Internet is only granted by express written consent of the author.  
(That's me, SteQve, in case you weren't paying attention.)

Unlimited modification for noncommercial purposes is granted provided
appropriate credit is given to the author.  

Honest, I didn't plan on this section being so long and bossy.  Just chill
and be good and you'll be fine ;-)

*****************************************
Obligatory Scribble Music Coalition Quote
*****************************************

"At this intersection / We must choose a direction /
 Using introspection / And a mirror's reflection
 With the finger pointing back at us
 How could we think to accuse another?"
    - Wars of the Millenia
