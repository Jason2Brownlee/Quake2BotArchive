/*#include <windows.h>

typedef void (CALLBACK* LPFNDLLFUNC1)(edict_t *ent, vec3_t makeat, int numb);
typedef void (CALLBACK* LPFNDLLFUNC2)(vec3_t makeat, int numb, int type);
typedef qboolean (CALLBACK* LPFNDLLFUNC3)();
typedef qboolean (CALLBACK* LPFNDLLFUNC4)();
typedef void (CALLBACK* LPFNDLLFUNC5)();
typedef void (CALLBACK* LPFNDLLFUNC6)(edict_t *ent);

	HINSTANCE hDLL;               // Handle to DLL

	LPFNDLLFUNC1 MakeWP;
	LPFNDLLFUNC2 MakeWPx;
	LPFNDLLFUNC3 BotConnect;
	LPFNDLLFUNC4 RemoveBot;
	LPFNDLLFUNC5 Write2File;
	LPFNDLLFUNC6 BotAI_Loopthrough;

void LoadDLL () {

	//	DWORD dwParam1;
//	UINT  uParam2, uReturnVal;
	
	hDLL = LoadLibrary("newfamke\\famkebot.dll");
	if (hDLL != NULL){
	//	gi.bprintf(PRINT_HIGH, "DLL loaded\n");

		MakeWP = (LPFNDLLFUNC1)GetProcAddress(hDLL, "MakeWP");
		MakeWPx = (LPFNDLLFUNC1)GetProcAddress(hDLL, "MakeWPx");
		BotConnect = (LPFNDLLFUNC1)GetProcAddress(hDLL, "BotConnect");
		RemoveBot = (LPFNDLLFUNC1)GetProcAddress(hDLL, "RemoveBot");
		Write2File = (LPFNDLLFUNC1)GetProcAddress(hDLL, "Write2File");
		BotAI_Loopthrough = (LPFNDLLFUNC1)GetProcAddress(hDLL, "BotAI_Loopthrough");

//
//		if (!lpfnDllFunc1)   {
//			FreeLibrary(hDLL);   
//			gi.bprintf(PRINT_HIGH, "Function not found\n");
//			return;
//		}
//		else
//		{      // call the function
//			lpfnDllFunc1();
//			gi.bprintf(PRINT_HIGH, "Got to call\n");
//		}
	}
	else
//		gi.bprintf(PRINT_HIGH, "LoadLibrary returned NULL.\n");
	//FreeLibrary(hDLL);       
}
*/

DllImport void MakeWP (edict_t *ent, vec3_t makeat, int numb);
DllImport void MakeWPx (vec3_t makeat, int numb, int type);
DllImport qboolean BotConnect ();
DllImport qboolean RemoveBot ();
DllImport void Write2File ();
DllImport void BotAI_Loopthrough(edict_t *ent);
DllImport void CheckWPStuff ();
