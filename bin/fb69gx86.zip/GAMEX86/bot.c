/*
All of this has been moved to the DLL. This is merely the wrapper.
*/

#include "g_local.h"
#include "m_player.h"
//FOG
#include <windows.h>
#include "gl.h"

void DrawFog (edict_t *ent) {
	if (!gl_fog_tgl->value || ent->lastsaid == 123) {
		glDisable (GL_FOG);   // turn on fog, otherwise you won't see any
		return;
	}

	{
//		GLfloat fogColor[] = {0.0,0.0,1.0,1};   // fog color
		GLfloat fogColor[] = {gl_fog_r->value,gl_fog_g->value,gl_fog_b->value,gl_fog_l->value};   // fog color

		// execute OpenGL commands
		glEnable (GL_FOG);   // turn on fog, otherwise you won't see any

		glFogi (GL_FOG_MODE, GL_EXP2);   // Fog fade using exponential function
		glFogfv (GL_FOG_COLOR, fogColor);   // Set the fog color
//		glFogf (GL_FOG_DENSITY, 0.0020);   // Set the density, don't make it too high.
		glFogf (GL_FOG_DENSITY, gl_fog_dens->value);   // Set the density, don't make it too high.
		glHint (GL_FOG_HINT, GL_NICEST);   // ROS says Set default calculation mode
	}
}
//FOG

DllExport void LinkToMe () {
	gi.bprintf(PRINT_HIGH, "Called\n");
}
