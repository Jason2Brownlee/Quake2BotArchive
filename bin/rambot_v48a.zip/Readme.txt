// ******************************************************************** //
// *                                                                  * //
// * RAMBOT Quake II Module                                           * //
// *                                                                  * //
// ******************************************************************** //


===============
= Information =
===============

File       : rambot_v48a.zip
Version    : 0.48
Date       : November 26, 1998
Author     : Ariel Mirles 'KRYPTYK'
Email      : amirles@exodo.upr.clu.edu
	                
ICQ        : 11196556
             
Web site   : http://www.emux.com/rambot


===============
= Development =
===============

Time       : Too many hours
             
Tool(s)    : Visual C++ 5.0

OS         : Windows NT 4.0
            
Feature(s) : target leading (will aim according to its velocity, enemy velocity, distance and ammo speed)
	         obstacle detection (wall, edge, height, lava, slime) 
		     combat obstacle detection.
	         swimming ability (will not drown while wandering or fighting in water) hehe, at least it will try not to :)
	         best weapon selection
	         strafing
	         circle-strafing
	         continuous-fire/burst-fire shooting
		     shoots rockets at feet of enemy
	         remembers old enemy
	         jumping over/crouching under obstacles
			 limited gap jumping
			 checks for landing before jumping
	         uses all items
			 attack aborting for weapons, ammo or health
	         nodeless roaming (dynamic node path roaming/selection has been disabled)
	         full client emulation (movement, weapon firing, visibility) Hearing not yet implemented.
             optimized AI states for faster play
		     visible weapons (VWEP) support
     
What's new : This version has improved wandering, they are more likely to go up/down stairs, they wont jump or fall down 
			 as often from ledges and now jumps over/ducks under obstacles. Improved jump test for safe jumping, now checks to 
			 see if the landing surface is flat. Most of all, the speed has been increased for less lag, this allows you to play
			 more bots :) Bots now have the ability to abort attacking an enemy if there is a better weapon, ammo for a weapon 
			 it has, or health, it increases their chance of survival. Weapon selection has been optimized, bots no longer drop 
			 weapon while checking for a better weapon. Bots now have a respawn delay of 1.5 seconds.

Known bugs : If you fill the server with bots and try to enter, you will possess a bots body, so leave some client spaces open if
			 other players are going to enter after bots have been added to the game. You no longer have to wait for all players 
			 to enter the game before adding bots, but you must leave space for those who enter after them. Just set the max number
			 of players to a higher value when starting the server. 
			 
			 Sometimes bots will die in a crouched position, so they look like they are just standing there ducked down. The bodies
			 will eventually disappear. They look like they are camping, but they are dead. Just like dead bodies and gibs, they 
			 will disappear.
			 
			 Bots do not spawn across map changes, you must add bots again after the map loads.
			 
			 Occasionally a message will appear about unable to show a certain model frame.		

			 Bot can see through opaque water. 	 
			 
===========
= Content =
===========
        Readme.txt              - This file
        gamex86.dll             - The game DLL
        rambot_i.pcx  	      - RAMBOT skin and picture
        rambot.pcx	      
        
================
= Installation =
================

        Unzip the ZIP file _with subdirectory names_ in your Quake II directory.
e.g. If you installed Quake2 into C:\Quake2, then unzip into C:\Quake2 and
you will get a subdirectory called "C:\Quake2\rambot".
  
        Just create a shortcut to Quake2.exe with the parameters "+set game rambot".
 	
		e.g. C:\ .path. \Quake2\Quake2.exe +set game rambot

Note: Some people, (including me) are unable to run the RAMBOT using this type of 
      installation. I believe this has to do with the quake 2 executable parameters
      that the install creates in the menu shortcut. I personally rename and backup 
      the original gamex86.dll and copy the RAMBOT dll into the baseq2 directory. 

      Don't forget to backup and/or rename the original gamex86.dll!!!
	
      NEW!!! RAMBOT SKIN :)
      Place the RAMBOT skin and picture in the Quake2\baseq2\players\male directory. If you dont, 
      the bots will look like grunts.

============
= Commands =
============
1. sv bot <command>

        <command> :  addbot        - add a RAMBOT to the deathmatch

                        e.g. "sv bot addbot"

                     killbot       - remove a RAMBOT from the server

                        e.g. "sv bot killbot"

   Note: Version 0.45 used the name of the RAMBOT to remove, the bot name is
	     no longer necessary.


=======
= FAQ =
=======

Haahaahaa ha!!!!!  This no longer happens!!! :)
>
>Q. The game slows down when I add RAMBOTs, the more I add the slower it gets, why?
>
>A. The RAMBOT uses dynamically player placed path nodes. What does this mean? It means 
>   that as you walk around the map, you are placing path nodes that the bot uses for 
>   roaming around, if the bot is spawned in the level before the nodes are placed, it
>   will search for available items to get after it gets all obtainable items, it searches
>   for path nodes. This search is what causes the lag, when the bot encounters a player, 
>   it will stop searching and attack. As soon as the bot has nodes to roam, the lag will
>   stop. I recommend that you roam the level before adding bots to the game. I plan to 
>   remedy this in the future.
>
>   The nodes are in a queue, so the early nodes will eventually be reused in the map. 
>   There may be times when later in the game that the bot may spawn where there are no
>   nodes. I recommend small to meduim sized maps to minimize this effect.

The RAMBOT now uses nodeless obstacle detection for "wandering" around a level so as soon as a bot
enters a game, it starts wandering around for items etc. This is also used for fighting and swimming. :)
 
 
Q. When I enter a game with RAMBOTs, the bots don't see or react to me?

A. THIS HAS BEEN FIXED :) Bots may be added before players, bots now see players who enter after 
   the bots :)


Q. I think I have found a bug.  What should I do?

A. Please let me know if you have found a bug.  My email is 
   listed above. Here it is again: 

         amirles@exodo.upr.clu.edu


Q. I have a question that is not in this FAQ.  What should I do?

A. Use the above email address to send me the question.


Q. I keep getting fragged by the RAMBOT.

A. Thats because they don't like to see their enemies alive. :)


Q. Why do RAMBOTs like the water so much?

A. They like to wash the blood from enemy gibs off their rocket launchers :)


Q. Are you gonna release the source code???

A. When I feel that I have done enough, or when my spare time becomes scarce, I 
   might.
   
   
===========
= Credits =
===========

id Software of course, for producing Quake and Quake2.

A project of this size is not easy for one person to do all alone. I wouldn't have
been able to do it if it weren't for the contributions of many people:
First and foremost, I would like to thank Anthony Yuen 'Tangent-' for all of his help and advice, (Thanx!) 
Pedro Nieto(emux.com) for his web expertise in creating the RAMBOT page :). The various websites 
dedicated to Quake2 mods: QdeveLS, Inside3d, Quake2dlls. All of the bot pages: The Bot Epidemic, 
Subhuman's Bot Outpost, Randar's Bot Page and all others who have in one way or another, have made
information available to those who wish to learn more about programming and making mods. 
Thanks to all of you!!!

A BIIIIG thanks to my Bubbistic 'pana' Joel Santos for help on that 'in'-visible bug :)

I would also like to thank the beta testors for their input :)
	DJ MaxiRecon (Thanx Timo!), Lord Fett, Macce, /Zaptor, Milkman, Fuvker, JediMaster, Lord Niubak, 7of10, CMorButts, SuperBallo
Also the 'professional' beta testors :)
	Cube, and the Bot Epidemic/Telefragged staff, SubHuman of the Bot Outpost, Genocyde and c0mpi1e of the BotLaiR 

Thank to Luis A. Lopez for use of the Matematics lab for 'AI testing' :)	
========================
= Copyright/Disclaimer =
========================

Quake II is a registered trademark of id software.

VWEP and/or the visible weapons patch is Copyright (c) 1998 El Nino Quake Extensions

This archive and associated files are Copyright (c) 1998 by Ariel Mirles.

This module was created for my own enjoyment of Quake II and for my artificial intelligence
course :) I also want to thank Dr. Ramon E. Vasquez Espinosa for allowing me to create this for
his AI course.   
This mod is distributed AS IS and I hope you enjoy it.  I will not take any responsibility whatsoever
for your system crashes, any damage or loss of data due to the use of this module.  I personally
guarantee that I have not intentionally added any malicious content to this module.

This module is in no way associated with id Software.

You may freely distribute this archive, as long as it remains intact.

For commercial distributions or distribution on CDs, please contact me and
get my written permission first.

Enjoy.

KRYPTYK (amirles@exodo.upr.clu.edu)
