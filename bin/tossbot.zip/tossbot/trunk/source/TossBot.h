#pragma once

#define WIN32_LEAN_AND_MEAN
// don't bother with hardly used api functions

// Windows Header Files:
#include <windows.h>

#include <commctrl.h>
#pragma comment(lib, "comctl32.lib") // for visual styles
#pragma comment(linker, "/manifestdependency:\"type='win32' \
name='Microsoft.Windows.Common-Controls' version='6.0.0.0' \
processorArchitecture='*' publicKeyToken='6595b64144ccf1df' \
language='*'\"")

// C RunTime Header Files
#include <stdlib.h>
#include <malloc.h>
#include <memory.h>
#include <math.h>
#include <tchar.h>
#include <stdarg.h>
#include <stdio.h>
#include <time.h>

#include "resource.h"
#include "../libs/q2bot/q2bot.h"
#include "../libs/q2map/q2map.h"

#define MAX_LOG 1024
#define MAX_TRASHTALKS 32
#define MAX_CHATLINE 128

#define SKILL_DUMB 0
#define SKILL_EASY 1
#define SKILL_MEDIUM 2
#define SKILL_HARD 3
#define SKILL_HAX 4

// dialog settings
extern bool useTraceFunc;
extern bool useBrushFunc;
extern int tickRate;
extern int ttAverageFreq;
extern char ttFileName[MAX_PATH];
extern char quakeDir[MAX_PATH];
extern char hostname[128], botname[32];
extern unsigned short port;

// From GUI
void DoStats();

// From botmain.cpp
void CreateBot();

// From misc.cpp
void Log_NewMessage(char* format, ...);
void Log_Print(char* string);
void Log_PrintN(char* string);
void Conf_LoadConfig();
void Conf_SaveConfig();
void Conf_Init();

#define PI 3.141592

/* Q2 vector macros */
#define DotProduct(x,y)			(x[0]*y[0]+x[1]*y[1]+x[2]*y[2])
#define VectorSubtract(a,b,c)	(c[0]=a[0]-b[0],c[1]=a[1]-b[1],c[2]=a[2]-b[2])
#define VectorAdd(a,b,c)		(c[0]=a[0]+b[0],c[1]=a[1]+b[1],c[2]=a[2]+b[2])
#define VectorCopy(src,dst)		(dst[0]=src[0],dst[1]=src[1],dst[2]=src[2])
#define VectorClear(a)			*(int *)&(a)[0] = 0, *(int *)&(a)[1] = 0, *(int *)&(a)[2] = 0
#define VectorNegate(a,b)		(b[0]=-a[0],b[1]=-a[1],b[2]=-a[2])
#define VectorSet(v, x, y, z)	(v[0]=(x), v[1]=(y), v[2]=(z))
#define VectorAverage(a,b,o)	((o)[0]=((a)[0]+(b)[0])*0.5f,(o)[1]=((a)[1]+(b)[1])*0.5f,(o)[2]=((a)[2]+(b)[2])*0.5f)
#define VectorCompare(v1,v2)	(v1[0]==v2[0] && v1[1]==v2[1] && v1[2]== v2[2])
#define CrossProduct(v1,v2,c)	(c[0]=v1[1]*v2[2]-v1[2]*v2[1],c[1]=v1[2]*v2[0]-v1[0]*v2[2],c[2]=v1[0]*v2[1]-v1[1]*v2[0])
#define VectorInverse(v)		(v[0]=-v[0],v[1]=-v[1],v[2]=-v[2])
#define VectorScale(in,s,out)	(out[0]=in[0]*(float)(s),out[1]=in[1]*(float)(s),out[2]=in[2]*(float)(s))
#define VectorMA(a,s,b,c)		(c[0]=a[0]+(float)(s)*b[0],c[1]=a[1]+(float)(s)*b[1],c[2]=a[2]+(float)(s)*b[2])
#define ClearBounds(mins,maxs)	(mins[0]=mins[1]=mins[2]=99999,maxs[0]=maxs[1]=maxs[2]=-99999)
/* end Q2 vector macros */

float VectorLength(vec3_t v);
float pitchFromVect(vec3_t delta);
float yawFromVect(vec3_t delta);