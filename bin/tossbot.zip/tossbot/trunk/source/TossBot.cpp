// TossBot.cpp : Defines the entry point for the application.
//

#include "TossBot.h"

// Global Variables:
HINSTANCE hInst;								// current instance

HWND logBox;
HWND infoConnected;
HWND infoTime;
HWND infoPing;
time_t startTime;

HANDLE ConnectThread;
DWORD ConnectThreadID;

// Forward declarations of functions included in this code module:
INT_PTR CALLBACK	MainDialogProc(HWND, UINT, WPARAM, LPARAM);

char hostname[128], botname[32], portstr[6];
unsigned short port;

int WINAPI WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance,LPSTR lpCmdLine,int nCmdShow)
{
	hInst = hInstance;
	// probably best to keep this :)

	Conf_Init();
	Conf_LoadConfig();

	if(DialogBox(hInstance,MAKEINTRESOURCE(IDD_MAINWIN),0,MainDialogProc))
		return 0;
	else
		return 1;
}

// Message handler for about box.
INT_PTR CALLBACK AboutProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		return (INT_PTR)TRUE;

	case WM_COMMAND:
		if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
		{
			EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

INT_PTR CALLBACK ConfigProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		{
			if(useTraceFunc)
				PostMessage(GetDlgItem(hDlg, IDC_USETRACEFUNC), BM_SETCHECK,BST_CHECKED,0);
			if(useBrushFunc)
				PostMessage(GetDlgItem(hDlg, IDC_USEBRUSHFUNC), BM_SETCHECK,BST_CHECKED,0);
			if(strcmp(quakeDir,""))
				SetWindowText(GetDlgItem(hDlg, IDC_QUAKEDIR), quakeDir);
			else
				SetWindowText(GetDlgItem(hDlg, IDC_QUAKEDIR), "C:\\Quake2\\");
		}
		return (INT_PTR)TRUE;

	case WM_COMMAND:
		if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
		{
			if(LOWORD(wParam) == IDOK)
			{
				useTraceFunc = IsDlgButtonChecked(hDlg, IDC_USETRACEFUNC) == TRUE;
				useBrushFunc = IsDlgButtonChecked(hDlg, IDC_USEBRUSHFUNC) == TRUE;
				GetWindowText(GetDlgItem(hDlg,IDC_QUAKEDIR), quakeDir, sizeof(quakeDir));
				Conf_SaveConfig();
			}
			
			EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

void KillBot()
{
	if(ConnectThreadID != 0)
	{
		Log_NewMessage("Killing Thread... ");
		TerminateThread(ConnectThread, 0);
		Log_NewMessage("Done!\r\n");
		if(qbIsConnected())
			qbDisconnect();
		qbShutdown();
		qmUnloadMap();
	}
	ConnectThreadID = 0;
}

void DoStats()
{
	if(qbIsConnected())
	{
		SetWindowText(infoConnected,"Connected");

		// set ping
		char pingstr[4];
		itoa(qbPingTime(),pingstr,10);
		SetWindowText(infoPing,pingstr);

		// set connected time
		char timestr[16];
		int connectedtime;
		connectedtime = time(NULL) - startTime;
		sprintf(timestr, "%.2d:%.2d:%.2d", connectedtime/3600, (connectedtime%3600)/60, ((connectedtime%3600)%60));
		SetWindowText(infoTime,timestr);
	}
	else
		SetWindowText(infoConnected,"Disconnected");
}


// Message handler for main dialog box.
INT_PTR CALLBACK MainDialogProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		InitCommonControls();
		logBox = GetDlgItem(hDlg, IDC_LOGBOX);
		infoConnected = GetDlgItem(hDlg, IDC_INFOCONNECTED);
		infoTime = GetDlgItem(hDlg, IDC_INFOTIME);
		infoPing = GetDlgItem(hDlg, IDC_INFOPING);

		// makes it all so much easier to debug
		SetWindowText(GetDlgItem(hDlg, IDC_HOSTNAMEEDIT), "localhost");
		SetWindowText(GetDlgItem(hDlg, IDC_PORTEDIT), "27910");
		SetWindowText(GetDlgItem(hDlg, IDC_BOTNAMEEDIT), "TossBot");

		SetWindowText(GetDlgItem(hDlg, IDC_LOGBOX), "This program is based on modified Q2BotCore libraries, by Ben Swartzlander.\r\n");
		return (INT_PTR)TRUE;

	case WM_COMMAND:
		switch(wParam)
		{
		case IDC_CONFIGBUTTON:
			DialogBox(hInst,MAKEINTRESOURCE(IDD_CONFIGBOX),hDlg,ConfigProc);
			break;

		case IDC_EXITBUTTON:
			KillBot();
			EndDialog(hDlg, LOWORD(wParam));
			break;

		case IDC_STARTBUTTON:
			char teststr[32];
			GetWindowText(GetDlgItem(hDlg, IDC_STARTBUTTON), teststr, sizeof(teststr));
			if(!strcmp(teststr,"Connect"))
			{
				SetWindowText(GetDlgItem(hDlg, IDC_STARTBUTTON), "Disconnect");

				EnableWindow(GetDlgItem(hDlg, IDC_HOSTNAMEEDIT), FALSE);
				EnableWindow(GetDlgItem(hDlg, IDC_BOTNAMEEDIT), FALSE);
				EnableWindow(GetDlgItem(hDlg, IDC_PORTEDIT), FALSE);

				// Get required info from dialogs...
				GetDlgItemText(hDlg,IDC_HOSTNAMEEDIT,hostname,sizeof(hostname));
				GetDlgItemText(hDlg,IDC_BOTNAMEEDIT,botname,sizeof(botname));
				GetDlgItemText(hDlg,IDC_PORTEDIT,portstr,sizeof(portstr));
				port = (unsigned short)atoi(portstr);

				if(!strcmp(hostname,""))
				{
					MessageBox(hDlg, "No hostname provided! Click Disconnect and enter a hostname.", "TossBot", MB_OK);
					break;
				} 
				else if (!strcmp(portstr,""))
				{
					MessageBox(hDlg, "No port provided! Click Disconnect and enter a port number.", "TossBot", MB_OK);
					break;
				}
				else if (!strcmp(botname,""))
				{
					MessageBox(hDlg, "No name provided! Click Disconnect and enter a name.", "TossBot", MB_OK);
					break;
				}

				startTime = time(NULL);
				ConnectThread=CreateThread(NULL,0,(LPTHREAD_START_ROUTINE)CreateBot,NULL,0,&ConnectThreadID);
			}
			else
			{
				SetWindowText(GetDlgItem(hDlg, IDC_STARTBUTTON), "Connect");

				EnableWindow(GetDlgItem(hDlg, IDC_HOSTNAMEEDIT), TRUE);
				EnableWindow(GetDlgItem(hDlg, IDC_BOTNAMEEDIT), TRUE);
				EnableWindow(GetDlgItem(hDlg, IDC_PORTEDIT), TRUE);
				
				SetWindowText(GetDlgItem(hDlg, IDC_INFOCONNECTED), "Disconnected");
				SetWindowText(GetDlgItem(hDlg, IDC_INFOTIME), "n/a");
				SetWindowText(GetDlgItem(hDlg, IDC_INFOPING), "n/a");

				KillBot();
			}
			break;
		}
	}
	return (INT_PTR)FALSE;
}

