#ifndef IDC_STATIC
#define IDC_STATIC (-1)
#endif

#define IDD_ABOUTBOX                            103
#define IDM_ABOUT                               104
#define IDM_EXIT                                105
#define IDI_TOSSBOT                             107
#define IDI_SMALL                               108
#define IDC_TOSSBOT                             109
#define IDD_MAINWIN                             112
#define IDD_CONFIGBOX                           114
#define IDC_INFOCONNECTED                       1000
#define IDC_LOGBOX                              1001
#define IDC_INFOTIME                            1003
#define IDS_APP_TITLE                           40000
#define IDC_STARTBUTTON                         40001
#define IDC_EXITBUTTON                          40004
#define IDC_HOSTNAMEEDIT                        40008
#define IDC_PORTEDIT                            40009
#define IDC_BOTNAMEEDIT                         40010
#define IDC_INFOPING                            40012
#define IDC_USETRACEFUNC                        40012
#define IDC_USEBRUSHFUNC                        40013
#define IDC_CONFIGBUTTON                        40014
#define IDC_QUAKEDIR                            40015
