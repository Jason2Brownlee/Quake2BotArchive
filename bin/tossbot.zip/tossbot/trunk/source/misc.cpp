#include "TossBot.h"

// Config Variables
#define MIN_TICKRATE 10
#define MAX_TICKRATE 80

bool useTraceFunc;
bool useBrushFunc;
int tickRate;
int ttAverageFreq;
char ttFileName[MAX_PATH];
char quakeDir[MAX_PATH];

// Config Code -- mostly pinched from SimplePluginServer by me :D
FILE * configfile;
char key[256], value[256];

bool stob(char* str)
{
	if (!strcmp(str,"true"))
		return true;
	else
		return false;
}

char* btos(bool boolean)
{
	if (boolean)
		return "true";
	else
		return "false";
}

void Conf_Init()
{
	useTraceFunc = false;
	useBrushFunc = false;

	tickRate = 10;

	ttAverageFreq = 30;
	strncpy(ttFileName, "trashtalk.txt", sizeof(ttFileName));

	strncpy(quakeDir, "C:\\quake2\\", sizeof(quakeDir));
}

int clampatoi(char* str, int min, int max)
{
	int value;

	value = atoi(str);

	value = (value < min ? min : value);
	value = (value > max ? max : value);

	return value;
}

void clampint(int *value, int min, int max)
{
	*value = (*value < min ? min : *value);
	*value = (*value > max ? max : *value);
}

#define ForValue(KEYSTR) else if(!strcmp(KEYSTR,key))
void Conf_LoadConfig()
{
	configfile = fopen("config.txt", "r");

	if (!configfile)
	{
		return; // just use the defaults from conf_init
	}
	else
	{

		while(!feof(configfile))
		{
			strcpy(key,"");
			strcpy(value,"");

			fscanf(configfile,"%s :: %s\r\n",&key,&value);

			if (!strcmp("useTraceFunc",key))
				useTraceFunc = stob(value);
			ForValue("useBrushFunc")
				useBrushFunc = stob(value);
			ForValue("tickRate")
				tickRate = clampatoi(value,MIN_TICKRATE,MAX_TICKRATE);
			ForValue("quakeDir")
				strncpy(quakeDir,value,sizeof(quakeDir));
			ForValue("ttAverageFreq")
				ttAverageFreq = clampatoi(value,1,3600);
			ForValue("ttFileName")
				strncpy(ttFileName,value,sizeof(ttFileName));
		}
		fclose(configfile);
	}

}

void Conf_SaveConfig()
{
	configfile = fopen("config.txt", "w");

	fprintf(configfile,"useTraceFunc :: %s\r\n", btos(useTraceFunc));
	fprintf(configfile,"useBrushFunc :: %s\r\n", btos(useBrushFunc));
	fprintf(configfile,"tickRate :: %d\r\n", tickRate);
	fprintf(configfile,"quakeDir :: %s\r\n", quakeDir);
	fprintf(configfile,"ttAverageFreq :: %d\r\n", ttAverageFreq);
	fprintf(configfile,"ttFileName :: %s\r\n", ttFileName);

	fclose(configfile);

	// clamp values here.
	clampint(&tickRate, MIN_TICKRATE, MAX_TICKRATE);
}

// Log Code - also pinched from SPS, but modified.

extern HWND logBox;

FILE * debuglog;

void Log_Print(char* string)
{
	// thank you MSDN!
	int ndx = GetWindowTextLength(logBox);
	SetFocus(logBox);

	SendMessage(logBox, EM_SETSEL, (WPARAM)ndx, (LPARAM)ndx);
	SendMessage(logBox, EM_REPLACESEL, 0, (LPARAM) ((LPSTR) string));

	if(!debuglog)
	{
		debuglog = fopen("debuglog.txt","w");
		if(debuglog)
			fputs(string,debuglog);
	}
	else
		fputs(string,debuglog);
}


void Log_NewMessage(char* format, ...)
{
	va_list		argptr;
	static char		string[MAX_LOG];
	
	va_start(argptr, format);
	_vsnprintf(string, sizeof(string), format, argptr);
	va_end(argptr);

	Log_Print(string);
}

void Log_PrintN(char* string)
{
	Log_NewMessage("%s\r\n", string);
}

// Some seriously good/confusing vectors stuff from bastardbot
float yawFromVect(vec3_t delta)
{
	if(delta[0]==0) {
		if(delta[1]>=0) {
			return PI/2;
		} else {
			return 3*PI/2;
		}
	} else {
		if(delta[0]>=0) {
			if(delta[1]>=0) {
				return (float)atan(delta[1]/delta[0]);
			} else {
				return 2*PI+(float)atan(delta[1]/delta[0]);
			}
		} else {
			return PI+(float)atan(delta[1]/delta[0]);
		}
	}
}

float pitchFromVect(vec3_t delta)
{
	float delta2;

	delta2=sqrt(delta[0]*delta[0]+delta[1]*delta[1]);
	if(delta2==0) {
		if(delta[2]>=0) {
			return PI/2;
		} else {
			return 3*PI/2;
		}
	} else {
		if(delta2>=0) {
			if(delta[2]>=0) {
				return (float)atan(delta[2]/delta2);
			} else {
				return 2*PI+(float)atan(delta[2]/delta2);
			}
		} else {
			return PI+(float)atan(delta[2]/delta2);
		}
	}
}

// VectorLength from the gamex86.dll source - thanks iD!
float VectorLength(vec3_t v)
{
	float	length;
	
	length = 0;

	length += v[0]*v[0];
	length += v[1]*v[1];
	length += v[2]*v[2];

	length = sqrtf(length);

	return length;
}