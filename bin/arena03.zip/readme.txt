Arena Oak Bot Build Release Notes:
==================================

Version 	0.03 (Public Alpha)

Author: 	John Crickett
Web Page: 	www.telefragged.com/oak
		www.planetquake.com/arena	(Rocket Arena 2)
Email: 		oak@telefragged.com


Credits and Thanks:
===================


Rocket Arena 2:			The RA2 Crew at: 		(www.planetquake.com/arena)

Client Emulation code:		SABIN				(www.planetquake.com/botshop)

Help with Zip Code:		Ryan Feltrin aka Ridah 		(impact.frag.com)

Quake2:				id Software			(www.idsoftware.com)


Instructions:
=============

1.	Unzip to a arena_oak directory and copy the Rocket Arena 2 pak files to that dir.

2.	run quake with "+set game arena_oak +set map ra2map2".

3.	Use the cmd "toarena x" to goto a arena.

4.	Use the cmd "arena_bot <name> <arena>" to add a bot i.e. "toarena oak 2"

5.	Then the cmd "mstart" will start the match.


Additional Instructions:
========================

Setting what weapons, ammo and armor are in the arena is controlled by the following console variables.

shotgun
supershotgun
machinegun
chaingun
grenadelauncher
rocketlauncher
hyperblaster
railgun
bfg
armor
health
shells
bullets
slugs
grenades
rockets
cells


Config Files:
-------------

The configuration of each bot is stored in a config file. The config files are text based. They should be named as
<bot name>.cfg i.e. oak.cfg

Through the use of the config files you can set the bots model, skin. favourite short range weapon and favourite 
long range weapon. The correct format is:

<model>
<skin>
<weapon>
<weapon>

i.e.

male
cipher
Rocket Launcher
Super Shotgun


Version History:
================

* Version 0.03	- Added skin and model support, all PPM's now supported.
		- Stopped bot shooting if it cant see you.
		- Bot can only see infront of itself.
		- Bots revert to spectators after player dies, i.e. dont madly attack the corpse.

* Version 0.02	- Added config files for EACH bot.
		- Bots now jump in combat.
		- Spectator bots dont shoot all the time anymore.
		- Removed the spawn spots.

* Version 0.01	- Initial Build, implementing Client Emulation.
		  RA2 stuff based on publicly released bot tutorials by CRT.
		- Removed weapons drop.
		- Implemented basic combat and movement AI.
		- Added initial pathing support.


Legal Notice:
=============

Distribution:

This bot is Copyright John Crickett 1998. It is being developed solely for my own amusement and as such is provided as is.
You may NOT distribute in any way shape or form, any version of this bot which states it is a private build. i.e the 
intro messages states "Build x.x Private". If you are given a private build by anyone other than myself (J. Crickett), 
please do not accept it and email me details of the distributer.

You may distribute any public i.e. states "Public Version x.x" in the intro message, via the internet so long as the 
zip/installation remains totally intact (intact being defined as containing the same files as the identical zip/installer
on the official web site). You may ONLY distribute this bot on permenant media (i.e. CD/floppy disk etc) if above conditions
are satisfied, and NO charge is made for the ENTIRE CD. A exception is made for regular magazine cover disk/CD's, in which 
case it may be included, though I`d ask any magazines that do to let me know about it, though its  not compulsory to do so.

Disclaimer:

You use the enclosed files entirely at your own risk, I accept NO liability for any damage or loss of data resulting
from the use of this bot.


