================================================================
 EraserX                                   	   v3.03 (Final)
 by Max "Fahrenheit" Lee
................................................................
================================================================

Title                   : EraserX
Author                  : Max "Fahrenheit" Lee
			  fahrenheit@planetquake.com
Homepage                : Expert Quake
			  http://www.planetquake.com/expert/
Additional Credits to   : id Software for Quake 2.

		          Ryan "Ridah" Feltrin, et al for Eraser.

			  Charles "Myrkul" Kendrick for Expert
			  and general Quake 2 coding help.
						  
			  A slew of Eraser mod authors: Anthony 
			  "AnthonyJ" Jacques of Eraser ULTRA, 
			  Manfred "Defcon-X" Nerurkar of RocketBot, 
			  Tom "Anozireth" Nicholson of HyperQuake,
			  and Rick "K2Guy" Shetina of Keys2.

			  Note to Eraser mod authors: replace gi.bprintf
			  with my_bprintf. Ridah has included other
			  Eraser-tolerant printf functions; bots can't
			  digest the ordinary ones, and your mod will
			  overflow.

================================================================

DESCRIPTION

	EraserX is a modified Eraser with support for select Expert
	Quake 2 (v3.0) DM, CTF, and Teamplay features.

	A full listing of unimplemented features and/or bugs is under
	"Known Bugs & Issues." Such features have also been removed
	from the Eraser and EQ2 reference docs.

INSTALLATION

	1. Unzip the EraserX distribution into your quake2 directory.
	For Winzip, "Use Folder Names"; for pkunzip, use the -d flag.

	Both EraserX Win32 and Sparc Solaris binaries have been included.
	All issues, etc. regarding the Sparc Solaris version belong to
	Ucender <fred@via.ecp.fr>, whose help made its compilation possible.

	2. In the eraserx directory, there are 3 batch files: expctf.bat,
	expdm.bat, and expteam.bat; move these up into your quake2 directory.

	You may run these to start a particular EraserX configuration
	(e.g. expctf.bat for EraserX CTF). Sample EraserX config's have
	also been included to emulate EQ2's CTF, DM, and Teamplay modes
	(see expert.txt); these can be found in the eraserx directory and
	in the gameplay mode directories (e.g. eraserx/ctf).

	3. To play CTF, you will need to place Zoid's CTF map pak into the
	eraserx directory.

	4. You may also use the alternate rocket explosion model available
	from the Expert Quake site with EraserX.

	5. Custom map ents go into the eraserx/maps directory, and routes
	into the eraserx/routes directory. You can use either Eraser or
	Eraser ULTRA routes with EraserX; EU routes are "grapple-optimized,"
	meaning that bots will use their hooks more frequently.

	Routes for the official Expert DM/CTF map sets are included; EU routes
	were used whenever available. You may replace these routes or 
	download new ones from:
		http://botepidemic.com/q2rfd
		http://planetquake.com/emporium

	To play on Sparc Solaris, you must convert these routes. In eraserx/routes,
	run the included batch conversion script, fixme.sh, by Ucender <fred@via.ecp.fr>;
	you can also manually convert a route by running the included routefix by
	Michael Johansson <michael.johansson@kal.telia.se>.

RUNNING THE GAME

	To run the game, type:

	quake2 +set game eraserx +set deathmatch 1

	NOTE: +set deathmatch 1 is an important setting!

	To spawn bots within the game, type "bot_num X", where X is the 
        number of bots. You may also spawn bots by typing "bot_name X", where
        X is the name of a bot, for example, EraserX.

	Please see eraser.txt, expert.txt, and user.txt for additional
	info for setting up Eraser and Expert features.

	Sample configurations for EraserX DM, CTF, and Teamplay, have been 
	included. They can be run by typing:

	quake2 +set game eraserx +exec X

	where X is the name of the configuration file (e.g. exctf.cfg); all
	configuration files already have deathmatch 1.

KNOWN BUGS & ISSUES, ETC.
	
	ERASER
	------
	UNIMPLEMENTED FEATURES -
	1. LAUNCHER.CFG - Replaced by Expert level scripting.
	2. MAP CYCLE - Replaced by Expert level cycles.
	3. CAMERA MODE - Broken.

	BUGS -
	1. VIEWABLE WEAPONS - Replaced by cl_vwep, but sometimes models don't show up.
	2. HOOK - You must set grapple 1 to give bots the Expert hook, but EU routes
	will automatically force this, even if your configuration has grapple 0.
	3. POGO - Bots don't know how to rocket jump, so can't simulate the pogo.

	EXPERT QUAKE
	------------
	UNIMPLEMENTED FEATURES -
	1. PLAYERID - You can only use the CTF version; type id at the console.
	2. ENFORCED TEAMS, FAIR TEAMS, NO TEAM SWITCH, TEAM DISTRIBUTION, some
	Expert CTF stuff - I'm afraid that I'll break Eraser's fragile bot CTF code, 
	but I have included a few cosmetic touches (e.g. flag stands).
	3. NO PLATS - Platform navigation is handled by NavLib, which is pre-compiled, so I
	can't modify it to tell bots to avoid missing plats.
	4. GIBSTAT LOGGING, FLOODING & BOT PROTECTIONS, TEAMAUDIO - Lack of time, period.

	BUGS -
	1. MOTD - Doesn't show up upon first spawn, but can still be displayed by typing
	motd or help at the console.

DISCLAIMER

	No malicious content was purposely added to this application, 
	however, I can not take responsibility for your system crashing.

	You may freely distribute this archive, as long as it remains
	PERFECTLY intact, as distributed at:

	http://www.planetquake.com/expert/

ADDITIONAL LEGAL MOJO

	Ridah's disclaimer for a modified Eraser:

	--- BEGIN ---
	The Eraser Bot is a product of Ryan Feltrin, and is available from
	the Eraser Bot homepage, at http://impact.frag.com.

	This program is a modification of the Eraser Bot, and is therefore
	in NO WAY supported by Ryan Feltrin.

	This program MUST NOT be sold in ANY form. If you have paid for 
	this product, you should contact Ryan Feltrin immediately, via
	the Eraser Bot homepage.
	--- END ---