#!/bin/sh

# This script needs to be improved

# Check if there is any compressed route
newfiles=""
for rtzfile in *.rtz
do
        rt3file=`echo "$rtzfile" | sed 's/\.rtz/\.rt3/g' | tr '[A-Z]' '[a-z]'`
	if test ! -f "$rt3file"
	then
		newfiles="$newfiles $rt3file"
		echo "Uncompressing $rtzfile ...\c"
		if unzip "$rtzfile" > /dev/null
		then
			echo done.
		else
			echo failed.
		fi
	fi
done

# Put each filename in lower case
for rt3file in *.rt3
do
	file=`echo "$rt3file" | tr '[A-Z]' '[a-z]'`
	if test "$file" != "$rt3file"
	then
		mv -f "$rt3file" "$file"
	fi
done

# Fix the routes
for rt3file in $newfiles
do
	echo "Fixing $rt3file ...\c"
	routefix "$rt3file" toto > /dev/null
	mv -f toto "$rt3file"
	echo done.
done
