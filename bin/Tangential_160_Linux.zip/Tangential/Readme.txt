// ******************************************************************** //
// *                                                                  * //
// * Tangential Quake II Module                                       * //
// *                                                                  * //
// ******************************************************************** //


===============
= Information =
===============

File       : Tangential_160.zip
Version    : 1.60
Date       : 04 Apr 1998
Author     : Tangent-
Email      : yuen@ug.cs.dal.ca
             ayuen@fastlanetech.com
ICQ        : 4848733 (Work)
             6040729 (Home)
Web site   : http://www.planetquake.com/tangential


===============
= Development =
===============

Time       : [1.00]   1 hour
             [1.10]   3 hours
             [1.11]   0 hour
             [1.20]  10 hours
             [1.30]  15 hours
             [1.40]  20 hours
             [1.45]  10 hours
             [1.50]  25 hours
             [1.51]   0 hour
             [1.60]  30 hours
             ---------------
             Total: 115 hours

Tool(s)    : Visual C++ 5.0 Professional Edition

OS         : Windows95
             WindowsNT 4.0 SP3

Feature(s) : 1. [1.00] Swinging grappling hook (by Bort, see below)
             2. [1.10] Ricocheting blaster projectiles (laser blaster and hyperblaster)
             3. [1.10] Message Of The Day (MOTD.txt)
             4. [1.10] Double laser blaster
             5. [1.10] Player vomits gibs (laster blaster and hyperblaster)
             6. [1.10] Gun scope (zoom in/zoom out)
             7. [1.10] Flash hand grenade (blinding effects)
             8. [1.11] Flash grenade thrower does not blind (fix)
             9. [1.20] SecantBot 1.00
            10. [1.30] SecantBot 1.10
            11. [1.40] Point Release (3.12 and later) compatibility
            14. [1.40] SecantBot 1.20
            15. [1.45] Merge with 3.14 source code
            16. [1.45] SecantBot 1.25
            17. [1.50] Feature toggles
            18. [1.50] Visible Weapon (by Hentai, see below)
            19. [1.50] Chase Camera (by sATaN, see below)
            20. [1.50] SecantBot 1.30
            21. [1.51] Fix: Team scoring bug
            22. [1.51] Fix: BDL parser under Linux
            23. [1.60] Homing rocket (client toggle)
            24. [1.60] Flash grenade (client toggle)
            25. [1.60] Friend or Foe HUD
            26. [1.60] Range Display
            26. [1.60] SecantBot 1.40


===========
= Content =
===========
        Readme.txt              - This file
        gamex86.dll             - The game DLL
        Tangential.cfg          - The default configuration file
        Sample.bdl              - The sample bot configuration file
        Tangential.bat          - Normal server start up batch file
        Tangential_D.bat        - Dedicated server start up batch file
        Default.cfg             - Default game rule file
        Regular.cfg             - Regular game rule file
        BotOnly.cfg             - Bot only game rule file
        pak3.pak                - Game resource file

        /sound
        GrappleHook_Attach.wav  - GrappleHook sound file
        GrappleHook_Detach.wav  - GrappleHook sound file
        GrappleHook_Damage.wav  - GrappleHook sound file
        GrappleHook_Grow.wav    - GrappleHook sound file
        GrappleHook_Shrink.wav  - GrappleHook sound file
        GunScope_ZoomIn.wav     - GunScope sound file
        GunScope_ZoomOut.wav    - GunScope sound file

        /models/items/hook
        skin.pcx                - GrappleHook skin
        tris.md2                - GrappleHook model


================
= Installation =
================

        Unzip the ZIP file _with subdirectory names_ in your Quake II directory.
e.g. If you installed Quake2 into C:\Quake2, then unzip into C:\Quake2 and
you will get a subdirectory called "C:\Quake2\Tangential".

        The "Sample.bdl" file is provided as a guideline for customizing SecantBot.
You can simply rename or copy it to "Bot.bdl" if you do not already have a previous
version of this file.

        If you wish to take advantage of the Visible Weapon feature, you need to
download a copy of the PAK file found at http://www.telefragged.com/tsunami
The VWEP_PAK.ZIP is the file to get.  Extract the PAK2.PAK file into "Quake2\baseq2"
and you are all set.


===========
= Running =
===========

        To run a listen (normal) server with Tangential, use the "Tangential.bat".
You can also create a shortcut to point to this file, which is located in your
Quake II directory.

        To run a dedicated server with Tangential, use the "Tangential_D.bat".
You must specify a starting map file.  e.g.  "Tangential_D base1"  will start a
dedicated server using base1.bsp to start the game.


============
= Commands =
============

0. cmd tangential

        Report the version number of the Tangential DLL.

1. cmd hook <action>

        <action> :  act        - fire the grappling hook
                    deact      - disable the grappling hook
                    grow       - extend the length of the chain
                    shrink     - reduce the length of the chain
                    version    - report the version number

2. cmd motd

        Display the message of the day (motd) from a file called
        "motd.txt" located in the Tagential directory.

3. cmd scope <direction>

        <direction> :  in      - make distant objects to appear bigger
                       out     - return to normal
                       version - report the version number

4. sv sec <command>

        <command> :  summon <name> [team]
                                   - make a bot called <name> with attributes
                                     listed in a file called "Bot.bdl".  By 
                                     default, the bot joins the "FFA" team. 
                                     The optional [team] parameter sets the
                                     team to join.

                        e.g. "sv sec summon Jezebel"

                     dispel <name> - kick the bot called <name> off
                                     the server.

                        e.g. "sv sec dispel Viper"

                     add <skill> <number> [team]
                                   - create <number> of bots of <skill>
                                     level with random skin.  By default,
                                     they join the "FFA" team.  The optional
                                     [team] parameter sets the team to
                                     join.

                        e.g. "sv sec add 5 6"

                     list          - show the list of defined bots found
                                     in a file called "Bot.bdl"

                        e.g. "sv sec list"

                     version       - report the version number

                        e.g. "sv sec version"


   cmd sec <command>

        <command> :  list          - show the list of defined bots found
                                     in a file called "Bot.bdl"

                        e.g. "cmd sec list"

                     version       - report the version number

                        e.g. "cmd sec version"

5. sv list
   cmd list

        Display the list of features that are currently enabled/disabled.

6. sv en <feature>

        <feature> :  double
                     bouncy
                     scope
                     flash
                     hook
                     sec
                     vwep
                     cam
                     home
                     ffhud

        The effect is immediate.
        This command also affects the associated console variable.
        All features are enabled by default.  See Default.cfg.

7. sv dis <feature>

        <feature> :  double
                     bouncy
                     scope
                     flash
                     hook
                     sec
                     vwep
                     cam
                     home
                     ffhud

        The effect is immediate.
        This command also affects the associated console variable.

8. sv team <command>

        <command> :  summon <name> - make a team of bots as specified
                                     in a file called "Bot.bdl"

                        e.g. "sv team summon Cyborgs"

                     dispel <name> - kick the whole team of bots called
                                     <name> off the server

                        e.g. "sv team dispel Testos"

                     list          - show the list of defined teams found
                                     in a file called "Bot.bdl"

                        e.g. "sv team list"

                     score         - show the list of scores for the defined
                                     teams found in a file called "Bot.bdl"

                        e.g. "sv team score"

   cmd team <command>

        <command> :  join <name>   - join a team called <name>

                        e.g. "cmd team join CrackWhores"

                     list          - show the list of defined teams found
                                     in a file called "Bot.bdl"

                     score         - show the list of scores for the defined
                                     teams found in a file called "Bot.bdl"

                        e.g. "cmd team score"

9. cmd cam <command>

        <command> :  toggle        - alternate the chase camera between on
                                     and off

                        e.g. "cmd cam toggle"

                     version       - report the version number

                        e,g, "cmd cam version"

10. cmd ffhud <command>

        <command> :  toggle        - alternate the friend or foe HUD between
                                     on  and off

                        e.g. "cmd ffhud toggle"

                     version       - report the version number

                        e,g, "cmd ffhud version"


=====================
= Console Variables =
=====================

    Console variables can be set at the command line (+set) or from
the console (latched cvars).

1. double  (0/1)

    Disable/Enable the double-blaster feature.

2. bouncy  (0/1)

    Disable/Enable the bouncy-blaster feature.

3. scope   (0/1)

    Disable/Enable the gunscope feature.

4. flash   (0/1)

    Disable/Enable the flashgrenade feature.

5. hook    (0/1)

    Disable/Enable the grapplehook feature.

6. sec     (0/1)

    Disable/Enable the SecantBot feature.

7. vwep    (0/1)

    Disable/Enable the visible weapon feature.

8. cam     (0/1)

    Disable/Enable the chase camera feature.

9. home    (0/1)

    Disable/Enable the homing rocket feature.

10. ffud   (0-1024)

    Disable/Range of the Friend or Foe HUD feature.


=======
= FAQ =
=======

Q. I did all of the above but when I start Quake II it says
   "couldn't exec Tangential.cfg".  What's wrong?

A. Did you unzip using directory names?  In WinZIP, check the box
   that says "using folder names".  Make sure a subdirectory called
   "Tangential" is present in your main Quake II directory.


Q. How do I use the grappling hook effectively?

A. There are 3 keys for the grappling hook.  The activation key (CTRL)
   fires off a new hook in the direction that you're looking at.  If 
   you are already using a hook, it will disappear.  It's like a
   toggle switch.  The O key will shrink the length of the chain, while
   the P key will grow the length.  So, let's say you are hanging from
   a ceiling, you can do "bungee jumping" by using the O and P keys.
   Also, remember that you can still move, or, swing in mid-air.  If
   you have always wanted to be Tarzan, this is your chance.


Q. How do I change the keys to use the grappling hook and other things?

A. Open up a file called "Tangential.cfg" in the Tangential directory.
   Find the lines that say "bind CTRL ...".  Change the key to whatever
   you want.  The file is fairly self-explanatory.


Q. How do I use the flash grenades effectively?

A. Just switch to hand grenade mode (press 'G').  The grenades that you
   throw are now flash grenades.  When it explodes, it will blind everyone
   who is looking directly at it within a certain raidius.  You, the
   thrower, are not affected because you closed your eyes when it exploded.
   Now switch to your favorite weapon and kill those helpless victims who
   are running around blindly (heh).


Q. How do I change the Message Of The Day (MOTD)?

A. Open up a file called "MOTD.txt" in the Tangential directory.  Type
   in anything you want there.  They will be printed on the players'
   screen when connected to the server.  Do not put too much in there
   as there is a limit on the size of the buffer.


Q. What is the gun scope?

A. It is an enhancement to your guns so that you can "zoom" in and nail
   your opponent(s).  It is a perfect companion to the RailGun, especially
   when you are hanging from a high ceiling/slope.  If you are a sniper,
   then you are in heaven.


Q. What is visible weapon (VWep)?

A. VWep is a patch to the game DLL code so that the current gun model is displayed
   on screen.  This way, you can see a BFG carrier coming in and take appropriate
   actions.  For this to work, you need to install the VWEP_PAK.ZIP that can
   be found on the VWep web site or the Download Page of Tangential web site.


Q. What is the chase camera?

A. The chase camera provides a third-person point of view.  The camera follows
   at a fixed distance behind the player and turns to where the player is looking
   at.  It brings the Quake II playing experience onto a whole new level.  It
   has to be seen to be believed.  Toggle it by pressing the / key.


Q. How do I spawn some bots to spice up the deathmatch?

A. Bring down the console (press `).  Type "cmd sec add <skill> <number>".
   This will spawn <number> of SecantBots with <skill> level, normal speed, and
   optimal ping time in the game at a random spawn location.  Now go find them(it).
   Create more bots if you want total mayhem, up to the MaxClients limit.


Q. How do I spawn my customized bot?

A. Bring down the console (press `).  Type "cmd sec summon <name>".
   This will spawn a new SecantBot in the game at a random spawn location.
   The bot has the attributes that you specified in the file "Bot.bdl".


Q. When I try to summon a bot, the game tells me "Unknown bot: <Name>".  Why?

A. Two possible causes.

   - You typed in a wrong or non-existent bot name.  Make sure it is defined
     in a file called "Bot.bdl" in the Tangential directory.  If the file
     does not exist, just rename "Sample.bdl" to "Bot.bdl".

   - The bot is defined incorrectly.  Study the other entries.  Make sure
     the format is correct.


Q. How do I create bots with custom skin and model?

A. Open up a file called "Bot.bdl" in the Tangential directory.  Study
   the comments in the file.  Find the section [Model] and add your own
   model defintion.  Find the section [Skin] to add your own skin defintion.
   Finally, in the [Bot] section, add your new bot entry following the
   format of existing entries.  You can now "summon" the new bot in
   a deathmatch.


Q. How do the different numeric attributes affect a bot?

A. There are currently 3 numeric attributes that give SecantBot a sense
   of "personality".  They are:

       Skill - An overall rating on the bot's ability to roam, aim,
               attack, dodge and aggressiveness.  The higher the skill
               is, the better the bot can perform in these areas.

       Speed - The movement speed of the bot.  The default is 5, which
               is the same as a real player's.  At 1, the bot crawls at
               a _very_ slow pace.  At 9, you may well think you are
               seeing a ghost as the bot "flies" by you.

       Ping  - More commonly known as lag.  This simulates the effect of
               playing over the Internet.  The lower it is, the better
               the bot can survive against a LPB, you, the player with
               a 0 ping.

    The "Sample.bdl" file provides some pre-defined bots with reasonable
    attributes:
    
        "Athena"  and "Cipher"    -  Inexperienced player
        "Jezebel" and "Howitzer"  -  Average player
        "Venus"   and "Psycho"    -  Advanced player
        "Voodoo"  and "Rampage"   -  Special(!)


Q. How do I play SecantBot with teamplay?

A. Currently, SecantBot supports a basic form of teamplay: it won't attack
   its teammates, unless provoked to do so.  It will actively seek players
   and other bots that are not on its current team to destroy.  The team
   with name "FFA" is reserved for free-for-all type of deathmatch.  This
   is the normal mode of play.  To spawn a team of bots, bring down the
   console (press `) and type "sv team summon <name>" where <name> is a
   predefined team found in a file called "Bot.bdl".  Then to join a team,
   type "cmd team join <name>" where <name> can be an existing team or a
   new team.  Remember, killing your teammate results in -1 to your frag
   count.  Be careful.


Q. How do I create my own teams?

A. Open up a file called "Bot.bdl" in the Tangential directory.  Near the
   bottom of the file is the [Team] section.  Study the comments and follow
   the same format in making new teams.  You may have up to 128 bots in a
   team and up to 128 teams with unique names.  You can now "summon" the
   newly assembled team of bots in deathmatch.


Q. How do I enable/disable some features?

A. All features are enabled by default.  There are three easy ways to enable
   or disable features:
   
   Command-line Arguments - 

        This uses the familiar "+set" syntax.

        e.g. "quake2 +set game Tangential +set vwep 0"

        This will disable server support for Visible Weapon.
   
   Console Variables (CVAR) -

        This requires typing a "<cvar> <value>" line in the console.
        The effects will take place for subsequent games.

        e.g. "cam 1"

        This will enable clients to use Chase Camera in subsequent games.
        
   Console Commands -

        This is done through "sv en <feature>" and "sv dis <feature>".
        The effects are immediate and also sets the corresponding cvar
        to the new value.

        e.g. "sv dis hook"

        This will disable the use of grappling hook immediately.


Q. What is the Friend or Foe HUD?

A. The Friend or Foe HUD consists of a Range Display and an indicator.  The
   Range Display shows you the approximate distance, in game units, of the
   closest entity pointed by the crosshair.  The indicator is a text string
   of either "Friendly" or "Hostile".  This is especially useful in teamplay.
   Now you can tell your friends from your enemies in the heat of a battle.


Q. How do I use the gamei386.so with Linux Quake II?

A. Answer this: you are smart enough to get Linux Quake II going, what
   is stopping you from using a MOD?


Q. I see big white cubes when I enable VisibleWeapon.  What is going on?

A. In order to see the weapon that your opponent is currently using, you must
   install a PAK file under your "Quake2\baseq2" directory.  This PAK may be
   obtained by visiting http://www.telefragged.com/tsunami.  Note that
   you only need to install this PAK file once for all other VWep-compatible
   modules.


Q. I think I have found a bug.  What should I do?

A. There is a "Bug" section on the Tangential home page.  Please let me 
   know if you have found a bug that is not already there.  My email is 
   listed above. Here they are again: 

          yuen@ug.cs.dal.ca
          ayuen@fastlanetech.com


Q. I have a question that is not in this FAQ.  What should I do?

A. Use the above email address (either one) to send me the question.


Q. I am bored.

A. Sorry, I cannot help you with that.


===========
= Credits =
===========

The Swinging Grappling Hook was created by Bort.  Permissions have been granted
to modify the source code to merge with the rest of Tangential.

    Email     : perceli@ix.netcom.com
    Web Site  : http://phook.symix.com/hook


The Visible Weapon patch was created by Hentai.  Permissions have been granted
to modify the source code to merge with the rest of Tangential.

    Email     : hentai@intelegenesis.com
    Web Site  : http://www.telefragged.com/vwep


The Chase Camera is based on the tutorial by sATaN posted on QDeveLS.  Some changes
and bug fixes were made to merge with the rest of Tangential.

    Email     :
    Web Site  : http://www.planetquake.com/qdevels


========================
= Copyright/Disclaimer =
========================

Quake II is a registered trademark of id software.

This archive and associated files are Copyright (c) 1998 by Anthony Yuen.

This module was created for my own enjoyment of Quake II.   It is distributed
AS IS and I hope you enjoy it.  I will not take any responsibility whatsoever
for your system crashes, any damage or loss of data due to the use of this
module.  But I guarantee that I have not intentionally added any malicious
content to this module.

This module is in no way associated with id Software.

You may freely distribute this archive, as long as it remains intact.

For commercial distributions or distribution on CDs, please contact me and
get my written permission first.

Enjoy.

Tangent- (yuen@ug.cs.dal.ca, ayuen@fastlanetech.com)

