ACE 
A Quake2 BOT
----------------------------------------------

Current Version:
----------------
Version 008


Thanks To:
----------

- A whole s*#$load of people, you know who you are....


Installation Instructions:
--------------------------

Unzip the files under your main Quake2 directory, for example unzip to c:\quake2\ace.

Here is the shortcut's command line if you need it. 

   quake2 +set game ace +set deathmatch 1 map q2dm1


ACE Commands (Playing):
-----------------------

(DM)
sv addbot <skill> <skin> <name> - Add a bot skill = 1 to 10 (10 highest)
  (i.e. "sv addbot 4 male/sniper Masher", or just "sv addbot" to spawn a random bot)

(CTF)
sv addbot <skill> <red|blue> <skin> <name> - Add a bot skill = 1 to 10 (10 highest)
  (i.e. "sv addbot 4 blue male/sniper Masher", or just "sv addbot" to spawn a random bot)
 
(BOTH)
sv removebot <name> - Remove a bot by name.

sv savenodes - Updates pathing data and saves bots current knowledge of level.

sv acedebug <on|off> - Turns on ACE's debugging messages. Shows when stuck, bot's thought process, node placement and linkage information.

(NOTE: The below commands only give you feedback when debug mode is on.)

cmd addnode <0|1|2|3|4|5|6> - Adds a new node of type 0-6. See details below.
cmd addlink <from> <to> - Adds a link between nodes.
cmd removelink <from> <to> - Removes a link between nodes.
cmd movenode <node> <x y z> - Moves a node to a new location, useful for nudging a node about.
cmd showpath <node> - Shows a path to a given node.
cmd findnode <node> - Find the closest reachable node to your current position.


Legal Info:
-----------

I = Steve Yeager (syeager@axionfx.com)

NO WARRANTIES. I am providing this software as is, without warranty of any kind. I and all my suppliers disclaim all warranties, either expressed or implied, including, but not limited to, implied warranties of merchantability and fitness for a particular purpose, with regard to the ACE Bot and any other software included in the distribution
package or archive.

NO LIABILITIES FOR CONSEQUENTIAL DAMAGES.  To the maximum amount permitted by applicable law, in no event shall I or my suppliers be liable for any damages whatsoever (including, without limitation, damages for loss of business profits, business interruption, loss of business information, or any other loss) arising out of the use of or inability to use this product, even if I have been advised of the possibility of such damages.  
