// ******************************************************************** //
// *                                                                  * //
// * Tangential Quake II Module                                       * //
// *                                                                  * //
// ******************************************************************** //


===============
= Information =
===============

File       : Tangential_130.zip
Version    : 1.30
Date       : 18 Feb 1998
Author     : Tangent-
Email      : yuen@ug.cs.dal.ca
             ayuen@fastlanetech.com
ICQ        : 4848733 (Work)
             6040729 (Home)
Web site   : http://www.geocities.com/SiliconValley/Lab/3733/tangential.html


===============
= Development =
===============

Time       : [1.00]   1 hour
             [1.10]   3 hours
             [1.11]   0 hour
             [1.20]  10 hours
             [1.30]  15 hours
             ---------------
             Total:  29 hours

Tool(s)    : Visual C++ 5.0 Professional Edition

OS         : Windows95
             WindowsNT 4.0 SP3

Feature(s) : 1. [1.00] Swinging grappling hook
             2. [1.10] Ricocheting blaster projectiles (laser blaster and hyperblaster)
             3. [1.10] Message Of The Day (MOTD.txt)
             4. [1.10] Double laser blaster
             5. [1.10] Player vomits gibs (laster blaster and hyperblaster)
             6. [1.10] Gun scope (zoom in/zoom out)
             7. [1.10] Flash hand grenade (blinding effects)
             8. [1.11] Flash grenade thrower does not blind (fix)
             9. [1.20] SecantBot 1.00
            10. [1.30] SecantBot 1.10


===========
= Content =
===========
        Readme.txt              - This file
        gamex86.dll             - The game DLL
        Tangential.cfg          - The default configuration file
        Bot.bdl                 - The bot configuration file

        /sound
        GrappleHook_Attach.wav  - GrappleHook sound file
        GrappleHook_Detach.wav  - GrappleHook sound file
        GrappleHook_Damage.wav  - GrappleHook sound file
        GrappleHook_Grow.wav    - GrappleHook sound file
        GrappleHook_Shrink.wav  - GrappleHook sound file
        GunScope_ZoomIn.wav     - GunScope sound file
        GunScope_ZoomOut.wav    - GunScope sound file

        /models/items
        GrappleHook_Chain.pcx   - GrappleHook skin
        tris.md2                - GrappleHook model


================
= Installation =
================

        Unzip the ZIP file _with subdirectory names_ in your Quake II directory.
e.g. If you installed Quake2 into C:\Quake2, then unzip into C:\Quake2 and
you will get a subdirectory called "C:\Quake2\Tangential".


===========
= Running =
===========

        To run Quake II with Tangential, do:

            quake2 +set game "Tangential" +exec Tangential.cfg

        in your Quake II directory or create a shortcut.


============
= Commands =
============

1. cmd grapplehook <action>

        <action> :  activate   - fire the grappling hook
                    deactivate - disable the grappling hook
                    grow       - extend the length of the chain
                    shrink     - reduce the length of the chain
                    version    - report the version number

2. cmd motd

        Display the message of the day (motd) from a file called
        "motd.txt" located in the Tagential directory.

3. cmd gunscope <direction>

        <direction> : zoomin   - make distant objects to appear bigger
                      zoomout  - return to normal

4. cmd secantbot <command>

        <command> :  summon <name> - make a bot called <name> with
                                     attributes listed in a file
                                     called "bot.bdl".
                  :  version       - report the version number


=======
= FAQ =
=======

Q. I did all of the above but when I start Quake II it says
   "couldn't exec Tangential.cfg".  What's wrong?

A. Did you unzip using directory names?  In WinZIP, check the box
   that says "using folder names".  Make sure a subdirectory called
   "Tangential" is present in your main Quake II directory.


Q. How do I use the grappling hook effectively?

A. There are 3 keys for the grappling hook.  The activation key (CTRL)
   fires off a new hook in the direction that you're looking at.  If 
   you are already using a hook, it will disappear.  It's like a
   toggle switch.  The O key will shrink the length of the chain, while
   the P key will grow the length.  So, let's say you are hanging from
   a ceiling, you can do "bungee jumping" by using the O and P keys.
   Also, remember that you can still move, or, swing in mid-air.  If
   you have always wanted to be Tarzan, this is your chance.


Q. How do I change the keys to use the grappling hook and other things?

A. Open up a file called "Tangential.cfg" in the Tangential directory.
   Find the lines that say "bind CTRL ...".  Change the key to whatever
   you want.  The file is fairly self-explanatory.


Q. How do I use the flash grenades effectively?

A. Just switch to hand grenade mode (press 'G').  The grenades that you
   throw are now flash grenades.  When it explodes, it will blind everyone
   who is looking directly at it within a certain raidius.  You, the
   thrower, are not affected because you closed your eyes when it exploded.
   Now switch to your favorite weapon and kill those helpless victims who
   are running around blindly (heh).


Q. How do I change the Message Of The Day (MOTD)?

A. Open up a file called "MOTD.txt" in the Tangential directory.  Type
   in anything you want there.  They will be printed on the players'
   screen when connected to the server.  Do not put too much in there
   as there is a limit on the size of the buffer.


Q. What is the gun scope?

A. It is an enhancement to your guns so that you can "zoom" in and nail
   your opponent(s).  It is a perfect companion to the RailGun, especially
   when you are hanging from a high ceiling/slope.  If you are a sniper,
   then you are in heaven.


Q. How do I spawn some bots to spice up the deathmatch?

A. Bring down the console (press `).  Type "cmd secantbot summon <name>".
   This will spawn a new SecantBot in the game at a random spawn location.
   Now go find it.  Create more bots if you want total mayhem.


Q. How do I create bots with custom skin and model?

A. Open up a files called "Bot.bdl" in the Tangential directory.  Study
   the comments in the file.  Find the section [Model] and add your own
   model defintion.  Find the section [Skin] to add your own skin defintion.
   Finally, in the [Bot] section, add your new bot entry following the
   format of existing entries.  You can now "summon" the new bot in
   a deathmatch.


Q. I think I have found a bug.  What should I do?

A. There is a "Bug" section on the Tangential home page.  Please let me 
   know if you have found a bug that is not already there.  My email is 
   listed above. Here they are again: 

          yuen@ug.cs.dal.ca
          ayuen@fastlanetech.com


Q. I have a question that is not in this FAQ.  What should I do?

A. Use the above email address (either one) to send me the question.


Q. I am bored.

A. Sorry, I cannot help you with that.


========================
= Copyright/Disclaimer =
========================

This archive and associated files are Copyright (c) 1998 by Anthony Yuen.

This module was created for my own enjoyment of Quake II.   It is distributed
AS IS and I hope you enjoy it.  I will not take any responsibility whatsoever
for your system crashes, any damage or loss of data due to the use of this
module.  But I guarantee that I have not intentionally added any malicious
content to this module.

This module is in no way associated with id Software.

You may freely distribute this archive, as long as it remains intact.

For commercial distributions or distribution on CDs, please contact me and
get my written permission first.

Enjoy.

Tangent- (yuen@ug.cs.dal.ca, ayuen@fastlanetech.com)

